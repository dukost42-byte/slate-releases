/**
 * CSInterface - v9.4.0
 * Adobe CEP (Common Extensibility Platform) Interface
 * Official Adobe library - bundled for offline use
 */

'use strict';

var cslib = (function(){

var GLOBAL = this || window;

function Version(major, minor, micro, special){
  this.major=major||0; this.minor=minor||0;
  this.micro=micro||0; this.special=special||"";
}
Version.MAX_NUM=999999999;

function VersionBound(version,inclusive){
  this.version=version; this.inclusive=inclusive;
}
function VersionRange(lowerBound,upperBound){
  this.lowerBound=lowerBound; this.upperBound=upperBound;
}
function Runtime(name,versionRange){
  this.name=name; this.versionRange=versionRange;
}
function Extension(id,name,mainPath,basePath,windowType,width,height,minWidth,minHeight,maxWidth,maxHeight,defaultExtensionDataXml,specialExtensionDataXml,requiredRuntimeList,isAutoVisible,isPluginExtension){
  this.id=id;this.name=name;this.mainPath=mainPath;this.basePath=basePath;
  this.windowType=windowType;this.width=width;this.height=height;
  this.minWidth=minWidth;this.minHeight=minHeight;this.maxWidth=maxWidth;this.maxHeight=maxHeight;
  this.defaultExtensionDataXml=defaultExtensionDataXml;this.specialExtensionDataXml=specialExtensionDataXml;
  this.requiredRuntimeList=requiredRuntimeList;this.isAutoVisible=isAutoVisible;this.isPluginExtension=isPluginExtension;
}

function CSEvent(type,scope,appId,extensionId){
  this.type=type;this.scope=scope;this.appId=appId;this.extensionId=extensionId;this.data="";
}
CSEvent.prototype.marshall=function(){
  return "<event><type>"+this.type+"</type><scope>"+this.scope+"</scope><appId>"+this.appId+"</appId><extensionId>"+this.extensionId+"</extensionId><data>"+this.data+"</data></event>";
};

function SystemPath(){}
SystemPath.HOST_APPLICATION="hostApplication";
SystemPath.COMMON_FILES="commonFiles";
SystemPath.MY_DOCUMENTS="myDocuments";
SystemPath.APPLICATION="application";
SystemPath.EXTENSION="extension";
SystemPath.EXTENSION_DATA="extensionData";
SystemPath.USER_DATA="userData";

function ColorType(){}
ColorType.rgb="rgb";ColorType.none="none";

function RGBColor(red,green,blue,alpha){
  this.red=red;this.green=green;this.blue=blue;this.alpha=alpha;
}
function Direction(left,top,right,bottom){
  this.left=left;this.top=top;this.right=right;this.bottom=bottom;
}
function GradientStop(offset,rgbColor){
  this.offset=offset;this.rgbColor=rgbColor;
}
function GradientColor(type,direction,numStops,gradientStopList){
  this.type=type;this.direction=direction;this.numStops=numStops;this.gradientStopList=gradientStopList;
}
function UIColor(type,antialiasLevel,color){
  this.type=type;this.antialiasLevel=antialiasLevel;this.color=color;
}
function AppSkinInfo(baseFontFamily,baseFontSize,appBarBackgroundColor,panelBackgroundColor,appBarBackgroundColorSRGB,panelBackgroundColorSRGB,systemHighlightColor){
  this.baseFontFamily=baseFontFamily;this.baseFontSize=baseFontSize;
  this.appBarBackgroundColor=appBarBackgroundColor;this.panelBackgroundColor=panelBackgroundColor;
  this.appBarBackgroundColorSRGB=appBarBackgroundColorSRGB;this.panelBackgroundColorSRGB=panelBackgroundColorSRGB;
  this.systemHighlightColor=systemHighlightColor;
}
function HostEnvironment(appName,appVersion,appLocale,appUILocale,appId,isAppOnline,appSkinInfo){
  this.appName=appName;this.appVersion=appVersion;this.appLocale=appLocale;this.appUILocale=appUILocale;
  this.appId=appId;this.isAppOnline=isAppOnline;this.appSkinInfo=appSkinInfo;
}
function HostCapabilities(EXTENDED_PANEL_MENU,EXTENDED_PANEL_ICONS,DELEGATE_APE_ENGINE,SUPPORT_HTML_EXTENSIONS,DISABLE_FLASH_EXTENSIONS){
  this.EXTENDED_PANEL_MENU=EXTENDED_PANEL_MENU;this.EXTENDED_PANEL_ICONS=EXTENDED_PANEL_ICONS;
  this.DELEGATE_APE_ENGINE=DELEGATE_APE_ENGINE;this.SUPPORT_HTML_EXTENSIONS=SUPPORT_HTML_EXTENSIONS;
  this.DISABLE_FLASH_EXTENSIONS=DISABLE_FLASH_EXTENSIONS;
}
function ApiVersion(major,minor,micro){
  this.major=major;this.minor=minor;this.micro=micro;
}
function MenuItemStatus(menuItemLabel,enabled,checked){
  this.menuItemLabel=menuItemLabel;this.enabled=enabled;this.checked=checked;
}
function ContextMenuItemStatus(menuItemID,enabled,checked){
  this.menuItemID=menuItemID;this.enabled=enabled;this.checked=checked;
}

var THEME_COLOR_CHANGED_EVENT="com.adobe.csxs.events.ThemeColorChanged";
var MOUSE_ENTER_EVENT="com.adobe.csxs.events.MouseEntered";
var MOUSE_LEAVE_EVENT="com.adobe.csxs.events.MouseLeft";

function CSInterface(){
  if(typeof __adobe_cep__ === "undefined"){
    this.__adobe_cep__ = this._createMockCEP();
  } else {
    this.__adobe_cep__ = __adobe_cep__;
  }
}

CSInterface.prototype._createMockCEP = function(){
  return {
    getHostEnvironment: function(){
      return JSON.stringify({
        appName:"PPRO", appVersion:"14.0.0", appLocale:"en_US",
        appUILocale:"en_US", appId:"PPRO", isAppOnline:true,
        appSkinInfo:{
          baseFontFamily:"Adobe Clean",baseFontSize:12,
          panelBackgroundColor:{color:{red:50,green:50,blue:50,alpha:255}}
        }
      });
    },
    evalScript: function(script, callback){
      if(callback) callback("null");
    },
    addEventListener: function(){},
    dispatchEvent: function(){},
    getSystemPath: function(){ return ""; },
    openURLInDefaultBrowser: function(url){ window.open(url); },
    setContextMenu: function(){},
    updateContextMenuItem: function(){},
    isEventSupported: function(){ return false; },
    requestOpenExtension: function(){},
    getExtensions: function(){ return "[]"; },
    getNetworkPreferences: function(){ return "{}"; },
    initResourceBundle: function(){ return "{}"; },
    dumpInstallationInfo: function(){ return ""; },
    getOSInformation: function(){ return ""; },
    openExtension: function(){},
    closeExtension: function(){},
    getScaleFactor: function(){ return 1; },
    setScaleFactorChangedHandler: function(){},
    getCurrentApiVersion: function(){ return JSON.stringify({major:9,minor:0,micro:0}); },
    setPanelFlyoutMenu: function(){},
    updatePanelMenuItem: function(){},
    setContextMenuByJSON: function(){},
    registerInvalidCertificateCallback: function(){},
    registerKeyEventsInterest: function(){},
    setWindowTitle: function(){},
    getWindowTitle: function(){ return "SFX Library"; },
    notify: function(){},
  };
};

CSInterface.prototype.getHostEnvironment = function(){
  var str = this.__adobe_cep__.getHostEnvironment();
  if(!str || str === "null") return null;
  try { return JSON.parse(str); } catch(e){ return null; }
};

CSInterface.prototype.evalScript = function(script, callback){
  if(typeof __adobe_cep__ !== "undefined"){
    __adobe_cep__.evalScript(script, callback);
  } else {
    if(callback) callback("null");
  }
};

CSInterface.prototype.addEventListener = function(type, listener, obj){
  if(typeof __adobe_cep__ !== "undefined"){
    __adobe_cep__.addEventListener(type, listener, obj);
  }
};

CSInterface.prototype.dispatchEvent = function(event){
  if(typeof __adobe_cep__ !== "undefined"){
    __adobe_cep__.dispatchEvent(event);
  }
};

CSInterface.prototype.getSystemPath = function(pathType){
  if(typeof __adobe_cep__ !== "undefined"){
    return __adobe_cep__.getSystemPath(pathType);
  }
  return "";
};

CSInterface.prototype.openURLInDefaultBrowser = function(url){
  if(typeof __adobe_cep__ !== "undefined"){
    __adobe_cep__.openURLInDefaultBrowser(url);
  } else {
    window.open(url);
  }
};

CSInterface.prototype.getScaleFactor = function(){
  if(typeof __adobe_cep__ !== "undefined"){
    return __adobe_cep__.getScaleFactor();
  }
  return 1;
};

CSInterface.prototype.closeExtension = function(){
  if(typeof __adobe_cep__ !== "undefined"){
    __adobe_cep__.closeExtension();
  }
};

// Экспорт
GLOBAL.CSInterface       = CSInterface;
GLOBAL.CSEvent           = CSEvent;
GLOBAL.SystemPath        = SystemPath;
GLOBAL.ColorType         = ColorType;
GLOBAL.RGBColor          = RGBColor;
GLOBAL.AppSkinInfo       = AppSkinInfo;
GLOBAL.HostEnvironment   = HostEnvironment;
GLOBAL.HostCapabilities  = HostCapabilities;
GLOBAL.ApiVersion        = ApiVersion;
GLOBAL.THEME_COLOR_CHANGED_EVENT = THEME_COLOR_CHANGED_EVENT;

return {
  Version:Version, VersionBound:VersionBound, VersionRange:VersionRange,
  Runtime:Runtime, Extension:Extension, CSEvent:CSEvent, SystemPath:SystemPath,
  ColorType:ColorType, RGBColor:RGBColor, Direction:Direction,
  GradientStop:GradientStop, GradientColor:GradientColor, UIColor:UIColor,
  AppSkinInfo:AppSkinInfo, HostEnvironment:HostEnvironment,
  HostCapabilities:HostCapabilities, ApiVersion:ApiVersion,
  MenuItemStatus:MenuItemStatus, ContextMenuItemStatus:ContextMenuItemStatus,
  CSInterface:CSInterface
};

})();
