// ============================================================
//  MF Library — host.jsx  v2.0
//  ExtendScript bridge: Premiere Pro ↔ CEP Panel
//
//  Изменения v2.0:
//   • ФИКС странных символов: File.name в ExtendScript возвращает
//     URI-encoded имя (пробел → %20, кириллица → %D0%97...).
//     Теперь все имена декодируются через decodeName().
//   • ФИКС поиска импортированного файла: findProjectItem сравнивал
//     закодированное имя с декодированным именем в проекте,
//     из-за чего вставка на таймлайн падала для русских имён.
//   • Сканирование папок осталось как fallback — основная панель
//     теперь сканирует диск через Node.js (см. main.js), это быстрее.
// ============================================================

var SUPPORTED_EXTS = ["wav", "mp3", "aiff", "aif", "aac"];

// Декодировать URI-encoded имя файла/папки
function decodeName(item) {
  try {
    return decodeURI(item.name);
  } catch (e) {
    // если decodeURI упал (некорректные %-последовательности) —
    // displayName уже декодирован системой
    return item.displayName ? String(item.displayName) : String(item.name);
  }
}

// Обрезка пробелов без String.trim (его нет в старом ExtendScript)
function trimStr(s) {
  if (s === undefined || s === null) return "";
  s = String(s);
  var a = 0, b = s.length;
  while (a < b) { var c = s.charAt(a); if (c === " " || c === "\t" || c === "\n" || c === "\r") a++; else break; }
  while (b > a) { var d = s.charAt(b - 1); if (d === " " || d === "\t" || d === "\n" || d === "\r") b--; else break; }
  return s.substring(a, b);
}

// Получить список папок в директории (только 1 уровень — для сайдбара)
function getFolders(folderPath) {
  var folder = new Folder(folderPath);
  if (!folder.exists) return JSON.stringify({ error: "Папка не найдена: " + folderPath });

  var items = folder.getFiles();
  var result = [];
  for (var i = 0; i < items.length; i++) {
    if (items[i] instanceof Folder) {
      result.push({
        name: decodeName(items[i]),
        path: items[i].fsName,
        hasSubs: hasSubFolders(items[i])
      });
    }
  }
  result.sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; });
  return JSON.stringify(result);
}

// Есть ли подпапки внутри (принимаем сам объект Folder — без лишнего new)
function hasSubFolders(folder) {
  var items = folder.getFiles();
  for (var i = 0; i < items.length; i++) {
    if (items[i] instanceof Folder) return true;
  }
  return false;
}

// Рекурсивно собрать ВСЕ SFX из папки и всех подпапок
function getSfxFiles(folderPath) {
  var folder = new Folder(folderPath);
  if (!folder.exists) return JSON.stringify({ error: "Папка не найдена" });

  var result = [];
  collectSfxRecursive(folder, result);
  result.sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; });
  return JSON.stringify(result);
}

function collectSfxRecursive(folder, result) {
  var items = folder.getFiles();
  for (var i = 0; i < items.length; i++) {
    var item = items[i];
    if (item instanceof Folder) {
      collectSfxRecursive(item, result);
    } else if (item instanceof File) {
      var realName = decodeName(item);
      var ext = realName.split(".").pop().toLowerCase();
      for (var j = 0; j < SUPPORTED_EXTS.length; j++) {
        if (SUPPORTED_EXTS[j] === ext) {
          result.push({
            name: realName,
            path: item.fsName,
            ext:  ext.toUpperCase()
          });
          break;
        }
      }
    }
  }
}

// Добавить файл на таймлайн Premiere Pro
// v2.2: опциональные inSec/outSec — вставка только выделенного диапазона.
// Медиа в проекте остаётся ПОЛНЫМ (это просто in/out у master clip),
// поэтому клип на таймлайне можно растянуть обратно.
function addToTimeline(filePath, inSec, outSec) {
  try {
    var file = new File(filePath);
    if (!file.exists) return JSON.stringify({ ok: false, msg: "Файл не найден: " + filePath });

    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, msg: "Нет активной Sequence. Открой или создай последовательность." });

    var realName = decodeName(file);

    app.project.importFiles([filePath], true, app.project.rootItem, false);

    // Ищем по ДЕКОДИРОВАННОМУ имени — в Project Panel имена хранятся без %20
    var projectItem = findProjectItem(realName);
    if (!projectItem) {
      return JSON.stringify({ ok: false, msg: "Файл импортирован в Project Panel. Перетащи на таймлайн вручную." });
    }

    var trimmed = false;
    if (typeof inSec === "number" && typeof outSec === "number" && outSec > inSec) {
      try {
        projectItem.setInPoint(inSec, 4);   // 4 = audio+video
        projectItem.setOutPoint(outSec, 4);
        trimmed = true;
      } catch (eT) {}
    }

    var insertTime = seq.getPlayerPosition();
    var startSec   = insertTime.seconds;
    var durSec     = getItemDuration(projectItem);

    if (seq.audioTracks.numTracks === 0) {
      return JSON.stringify({ ok: false, msg: "Нет аудио-дорожек в sequence." });
    }

    var trackIdx = -1;
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var tr = seq.audioTracks[t];
      try { if (tr.isLocked && tr.isLocked()) continue; } catch (eL) {}
      if (trackHasSpace(tr, startSec, durSec)) { trackIdx = t; break; }
    }

    if (trackIdx === -1) {
      return JSON.stringify({ ok: false, msg: "Все аудио-дорожки заняты на позиции плейхеда. Добавь дорожку (A" + (seq.audioTracks.numTracks + 1) + ")." });
    }

    seq.audioTracks[trackIdx].insertClip(projectItem, insertTime);
    var note = trimmed ? " (фрагмент)" : "";
    return JSON.stringify({ ok: true, msg: "Добавлено на A" + (trackIdx + 1) + note + ": " + realName });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: "Ошибка: " + e.message });
  }
}

// Перед drag&drop выделенного диапазона: импортировать файл целиком
// и выставить in/out у master clip — Premiere при дропе использует
// существующий элемент проекта с этими точками.
function prepareTrim(filePath, inSec, outSec) {
  try {
    var file = new File(filePath);
    if (!file.exists) return JSON.stringify({ ok: false, msg: "Файл не найден" });
    var realName = decodeName(file);

    var item = findProjectItem(realName);
    if (!item) {
      app.project.importFiles([filePath], true, app.project.rootItem, false);
      item = findProjectItem(realName);
    }
    if (!item) return JSON.stringify({ ok: false, msg: "Не удалось импортировать" });

    item.setInPoint(inSec, 4);
    item.setOutPoint(outSec, 4);
    return JSON.stringify({ ok: true });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: e.message });
  }
}

// Сбросить in/out (durSec — полная длительность, известна панели из декодера)
function resetTrim(filePath, durSec) {
  try {
    var file = new File(filePath);
    if (!file.exists) return JSON.stringify({ ok: false });
    var item = findProjectItem(decodeName(file));
    if (!item) return JSON.stringify({ ok: true }); // нечего сбрасывать

    try { item.clearInPoint(4); item.clearOutPoint(4); }
    catch (eC) {
      // в старых версиях clear-методов нет — ставим явно 0..durSec
      item.setInPoint(0, 4);
      if (typeof durSec === "number" && durSec > 0) item.setOutPoint(durSec, 4);
    }
    return JSON.stringify({ ok: true });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: e.message });
  }
}

// Длительность импортированного аудио в секундах
function getItemDuration(projectItem) {
  try {
    var inP  = projectItem.getInPoint();
    var outP = projectItem.getOutPoint();
    var d = outP.seconds - inP.seconds;
    if (d > 0) return d;
  } catch (e) {}
  return 0.5; // не смогли определить — проверяем хотя бы полсекунды
}

// Свободна ли дорожка в интервале [start; start + dur]
function trackHasSpace(track, start, dur) {
  var end = start + dur;
  try {
    for (var i = 0; i < track.clips.numItems; i++) {
      var c  = track.clips[i];
      var cs = c.start.seconds;
      var ce = c.end.seconds;
      // пересечение интервалов
      if (cs < end && ce > start) return false;
    }
  } catch (e) {
    return false; // не смогли прочитать клипы — считаем занятой, идём дальше
  }
  return true;
}

function findProjectItem(name) {
  return searchItem(app.project.rootItem, name);
}

function searchItem(item, name) {
  if (item.name === name && item.type !== ProjectItemType.BIN) return item;
  if (item.children) {
    for (var i = 0; i < item.children.numItems; i++) {
      var found = searchItem(item.children[i], name);
      if (found) return found;
    }
  }
  return null;
}

// ── Навесить аудиоэффект на выделенный клип через QE DOM ──
// QE DOM недокументирован и нестабилен между версиями, поэтому всё в try,
// и наружу всегда уходит честный JSON-результат ok/false.
function applyAudioEffect(effectName) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции." });

    // активируем QE DOM
    var qeOk = false;
    try { if (typeof qe === "undefined") app.enableQE(); qeOk = (typeof qe !== "undefined"); }
    catch (eQE) { qeOk = false; }
    if (!qeOk || !qe) {
      return JSON.stringify({ ok: false, reason: "no_qe", msg: "QE DOM недоступен в этой версии Premiere." });
    }

    var qseq = qe.project.getActiveSequence();
    if (!qseq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции (QE)." });

    // собираем ВСЕ выделенные аудиоклипы (трек + индекс + старт)
    var targets = [];
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var clips = seq.audioTracks[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var cl = clips[c];
        var selected = false;
        try { selected = cl.isSelected && cl.isSelected(); } catch (eSel) { selected = false; }
        if (selected) targets.push({ trackIdx: t, clipIdx: c, start: cl.start.seconds });
      }
    }

    // ничего не выделено — честно просим выделить (НЕ лепим на первый клип)
    if (targets.length === 0) {
      return JSON.stringify({ ok: false, reason: "no_clip",
        msg: "Выдели на таймлайне аудиоклип(ы), к которым применить эффект." });
    }

    var applied = 0, failed = 0;
    for (var k = 0; k < targets.length; k++) {
      var tg = targets[k];
      var qtrack = qseq.getAudioTrackAt(tg.trackIdx);
      if (!qtrack) { failed++; continue; }

      var qclip = qtrack.getItemAt(tg.clipIdx);
      if (!qclip || !sameStart(qclip, tg.start)) {
        for (var qi = 0; qi < qtrack.numItems; qi++) {
          var qc = qtrack.getItemAt(qi);
          if (qc && sameStart(qc, tg.start)) { qclip = qc; break; }
        }
      }
      if (!qclip) { failed++; continue; }

      try {
        var okAdd = qclip.addAudioEffect(qe.project.getAudioEffectByName(effectName));
        if (okAdd) applied++; else failed++;
      } catch (eAdd) { failed++; }
    }

    if (applied === 0) {
      return JSON.stringify({ ok: false, reason: "add_failed",
        msg: "Premiere не принял эффект «" + effectName + "» (QE мог не сработать на этой сборке)." });
    }
    var rmsg = "Навешено «" + effectName + "» на клипов: " + applied;
    if (failed) rmsg += " (не удалось: " + failed + ")";
    return JSON.stringify({ ok: true, effect: effectName, applied: applied, failed: failed, msg: rmsg });
  } catch (e) {
    return JSON.stringify({ ok: false, reason: "exception", msg: "Ошибка: " + e.message });
  }
}

// Применить ЦЕПОЧКУ эффектов (массив имён) на все выделенные аудиоклипы.
// namesJson — JSON-массив имён эффектов Premiere.
function applyAudioEffectChain(namesJson) {
  try {
    var names = [];
    try { names = JSON.parse(namesJson) || []; } catch (eP) { names = []; }
    if (!names.length) return JSON.stringify({ ok: false, msg: "Пустой пресет." });

    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции." });

    var qeOk = false;
    try { if (typeof qe === "undefined") app.enableQE(); qeOk = (typeof qe !== "undefined"); }
    catch (eQE) { qeOk = false; }
    if (!qeOk || !qe) return JSON.stringify({ ok: false, reason: "no_qe", msg: "QE DOM недоступен в этой версии Premiere." });

    var qseq = qe.project.getActiveSequence();
    if (!qseq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции (QE)." });

    // выделенные аудиоклипы
    var targets = [];
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var clips = seq.audioTracks[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var cl = clips[c];
        var selected = false;
        try { selected = cl.isSelected && cl.isSelected(); } catch (eSel) { selected = false; }
        if (selected) targets.push({ trackIdx: t, clipIdx: c, start: cl.start.seconds });
      }
    }
    if (targets.length === 0) {
      return JSON.stringify({ ok: false, reason: "no_clip",
        msg: "Выдели на таймлайне аудиоклип(ы), к которым применить пресет." });
    }

    var clipsdone = 0, effDone = 0, effFail = 0;
    var missing = {}; // эффекты, которых нет в Premiere
    for (var k = 0; k < targets.length; k++) {
      var tg = targets[k];
      var qtrack = qseq.getAudioTrackAt(tg.trackIdx);
      if (!qtrack) continue;
      var qclip = qtrack.getItemAt(tg.clipIdx);
      if (!qclip || !sameStart(qclip, tg.start)) {
        for (var qi = 0; qi < qtrack.numItems; qi++) {
          var qc = qtrack.getItemAt(qi);
          if (qc && sameStart(qc, tg.start)) { qclip = qc; break; }
        }
      }
      if (!qclip) continue;

      var anyOnThisClip = false;
      for (var e = 0; e < names.length; e++) {
        try {
          var fx = qe.project.getAudioEffectByName(names[e]);
          if (!fx) { missing[names[e]] = true; effFail++; continue; }
          var ok = qclip.addAudioEffect(fx);
          if (ok) { effDone++; anyOnThisClip = true; } else { effFail++; }
        } catch (eAdd) { effFail++; }
      }
      if (anyOnThisClip) clipsdone++;
    }

    if (effDone === 0) {
      var miss = [];
      for (var m in missing) if (missing.hasOwnProperty(m)) miss.push(m);
      var mm = miss.length ? (" Не найдены эффекты: " + miss.join(", ") + ".") : "";
      return JSON.stringify({ ok: false, reason: "add_failed",
        msg: "Не удалось применить пресет (QE мог не сработать)." + mm });
    }
    var rmsg = "Пресет применён: эффектов " + effDone + " на клипов " + clipsdone;
    if (effFail) rmsg += " (пропущено: " + effFail + ")";
    return JSON.stringify({ ok: true, applied: effDone, clips: clipsdone, msg: rmsg });
  } catch (e) {
    return JSON.stringify({ ok: false, reason: "exception", msg: "Ошибка: " + e.message });
  }
}

// Применить ЦЕПОЧКУ эффектов С ПАРАМЕТРАМИ на выделенные клипы.
// payloadJson = {"names":[...], "settings":[[{n,i,v}...],...]}
// Эффекты добавляются проверенным QE-путём, затем настройки выставляются
// на только что добавленные компоненты через стандартный DOM (best-effort).
function applyAudioEffectChainEx(payloadJson) {
  try {
    var payload = null;
    try { payload = JSON.parse(payloadJson); } catch (eP) { payload = null; }
    if (!payload) return JSON.stringify({ ok: false, msg: "Битый пресет." });
    var names = payload.names || [];
    var settings = payload.settings || [];
    if (!names.length) return JSON.stringify({ ok: false, msg: "Пустой пресет." });

    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции." });

    var qeOk = false;
    try { if (typeof qe === "undefined") app.enableQE(); qeOk = (typeof qe !== "undefined"); }
    catch (eQE) { qeOk = false; }
    if (!qeOk || !qe) return JSON.stringify({ ok: false, reason: "no_qe", msg: "QE DOM недоступен в этой версии Premiere." });

    var qseq = qe.project.getActiveSequence();
    if (!qseq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции (QE)." });

    var targets = [];
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var clips = seq.audioTracks[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var cl = clips[c];
        var selected = false;
        try { selected = cl.isSelected && cl.isSelected(); } catch (eSel) { selected = false; }
        if (selected) targets.push({ trackIdx: t, clipIdx: c, start: cl.start.seconds, item: cl });
      }
    }
    if (targets.length === 0) {
      return JSON.stringify({ ok: false, reason: "no_clip",
        msg: "Выдели на таймлайне аудиоклип(ы), к которым применить пресет." });
    }

    var clipsdone = 0, effDone = 0, effFail = 0, paramsDone = 0;
    var missing = {};
    for (var k = 0; k < targets.length; k++) {
      var tg = targets[k];
      var qtrack = qseq.getAudioTrackAt(tg.trackIdx);
      if (!qtrack) continue;
      var qclip = qtrack.getItemAt(tg.clipIdx);
      if (!qclip || !sameStart(qclip, tg.start)) {
        qclip = null;
        for (var qi = 0; qi < qtrack.numItems; qi++) {
          var qc = qtrack.getItemAt(qi);
          if (qc && sameStart(qc, tg.start)) { qclip = qc; break; }
        }
      }
      if (!qclip) continue;

      // снимок имеющихся эффектов (чтобы потом найти именно новые)
      var preCount = countFxByName(tg.item);

      var anyOnThisClip = false;
      for (var e = 0; e < names.length; e++) {
        try {
          var fx = qe.project.getAudioEffectByName(names[e]);
          if (!fx) { missing[names[e]] = true; effFail++; continue; }
          var ok = qclip.addAudioEffect(fx);
          if (ok) { effDone++; anyOnThisClip = true; } else { effFail++; }
        } catch (eAdd) { effFail++; }
      }
      if (anyOnThisClip) clipsdone++;

      // настройки на только что добавленные эффекты (best-effort, не ломает применение)
      try { paramsDone += applyParamsToNewFx(tg.item, names, settings, preCount); } catch (ePar) {}
    }

    if (effDone === 0) {
      var miss = [];
      for (var m in missing) if (missing.hasOwnProperty(m)) miss.push(m);
      var mm = miss.length ? (" Не найдены эффекты: " + miss.join(", ") + ".") : "";
      return JSON.stringify({ ok: false, reason: "add_failed",
        msg: "Не удалось применить пресет (QE мог не сработать)." + mm });
    }
    var rmsg = "Пресет применён: эффектов " + effDone + " на клипов " + clipsdone;
    if (paramsDone) rmsg += ", параметров " + paramsDone;
    if (effFail) rmsg += " (пропущено: " + effFail + ")";
    return JSON.stringify({ ok: true, applied: effDone, clips: clipsdone, params: paramsDone, msg: rmsg });
  } catch (e) {
    return JSON.stringify({ ok: false, reason: "exception", msg: "Ошибка: " + e.message });
  }
}

// Сравнить старт QE-клипа с секундами (QE start бывает .secs / .ticks)
function sameStart(qclip, sec) {
  try {
    if (qclip.start && typeof qclip.start.secs !== "undefined") return Math.abs(qclip.start.secs - sec) < 0.06;
  } catch (e1) {}
  try {
    if (qclip.start && typeof qclip.start.ticks !== "undefined") {
      var s = Number(qclip.start.ticks) / 254016000000;
      return Math.abs(s - sec) < 0.06;
    }
  } catch (e2) {}
  return false;
}

// "Fx Slot 1: Parametric Equalizer" → "Parametric Equalizer"
function cleanFxName(name) {
  var p = name.indexOf(":");
  if (p > -1 && name.toLowerCase().indexOf("fx slot") === 0) return trimStr(name.substring(p + 1));
  return name;
}
// встроенные компоненты клипа, которые не считаем эффектами
function isBuiltinClipComp(name) {
  var n = name.toLowerCase();
  return (n === "volume" || n === "channel volume" || n === "panner" || n === "pan" || n === "opacity" || n === "audio");
}

// ── Параметры эффектов (стандартный DOM: component.properties → ComponentParam) ──
// Снять значения всех параметров компонента: [{n:имя, i:индекс, v:значение}]
function readCompParams(comp) {
  var out = [];
  var props = null;
  try { props = comp.properties; } catch (e0) { return out; }
  if (!props) return out;
  var pc = 0; try { pc = props.numItems; } catch (e1) { pc = 0; }
  for (var i = 0; i < pc; i++) {
    try {
      var pr = props[i];
      if (!pr) continue;
      var pname = pr.displayName ? String(pr.displayName) : ("p" + i);
      var val, got = false;
      try { val = pr.getValue(); got = true; } catch (eg) { got = false; }
      if (got && typeof val !== "undefined" && val !== null) {
        out.push({ n: pname, i: i, v: val });
      }
    } catch (ep) {}
  }
  return out;
}

// Собрать настройки для списка имён эффектов с клипа (выравнивание по позиции).
function readClipFxSettings(cl, names) {
  var settings = [];
  var fxComps = [];
  try {
    var comps = cl.components;
    var cnt = 0; try { cnt = comps ? comps.numItems : 0; } catch (eN) { cnt = 0; }
    for (var i = 0; i < cnt; i++) {
      try {
        var comp = comps[i];
        if (!comp) continue;
        var dn = comp.displayName ? String(comp.displayName) : "";
        if (!dn || isBuiltinClipComp(dn)) continue;
        fxComps.push(comp);
      } catch (e1) {}
    }
  } catch (e0) {}
  for (var k = 0; k < names.length; k++) {
    if (k < fxComps.length) settings.push(readCompParams(fxComps[k]));
    else settings.push([]);
  }
  return settings;
}

// Выставить значения параметров на компонент. Возвращает число успешно выставленных.
function applyCompParams(comp, params) {
  if (!params || !params.length) return 0;
  var done = 0;
  var props = null;
  try { props = comp.properties; } catch (e0) { return 0; }
  if (!props) return 0;
  var pc = 0; try { pc = props.numItems; } catch (e1) { pc = 0; }
  for (var k = 0; k < params.length; k++) {
    var sp = params[k];
    var target = null;
    // сперва по индексу (с проверкой имени)
    if (typeof sp.i === "number" && sp.i >= 0 && sp.i < pc) {
      try { var cand = props[sp.i]; if (cand && (!sp.n || String(cand.displayName) === sp.n)) target = cand; } catch (e2) {}
    }
    // иначе по имени
    if (!target && sp.n) {
      for (var j = 0; j < pc; j++) {
        try { var c2 = props[j]; if (c2 && String(c2.displayName) === sp.n) { target = c2; break; } } catch (e3) {}
      }
    }
    if (!target) continue;
    var ok = false;
    try { target.setValue(sp.v, true); ok = true; } catch (eSet) {
      try { target.setValue(sp.v); ok = true; } catch (eSet2) { ok = false; }
    }
    if (ok) done++;
  }
  return done;
}

// Сколько не-встроенных компонентов (по displayName) уже есть на клипе.
function countFxByName(item) {
  var m = {};
  try {
    var comps = item.components;
    var cnt = 0; try { cnt = comps ? comps.numItems : 0; } catch (eN) { cnt = 0; }
    for (var i = 0; i < cnt; i++) {
      try {
        var comp = comps[i];
        if (!comp) continue;
        var dn = comp.displayName ? String(comp.displayName) : "";
        if (!dn || isBuiltinClipComp(dn)) continue;
        m[dn] = (m[dn] || 0) + 1;
      } catch (e1) {}
    }
  } catch (e0) {}
  return m;
}

// Выставить настройки на ТОЛЬКО ЧТО добавленные эффекты (вхождения сверх preCount).
function applyParamsToNewFx(item, names, settings, preCount) {
  var done = 0;
  var comps = null;
  try { comps = item.components; } catch (e0) { return 0; }
  if (!comps) return 0;
  var cnt = 0; try { cnt = comps.numItems; } catch (e1) { cnt = 0; }

  var used = {};
  for (var key in preCount) if (preCount.hasOwnProperty(key)) used[key] = preCount[key];

  for (var n = 0; n < names.length; n++) {
    var nm = names[n];
    var sp = settings[n] || [];
    var wantOccurrence = (used[nm] || 0); // пропустить уже «израсходованные» вхождения
    used[nm] = (used[nm] || 0) + 1;
    if (!sp.length) continue;

    var seen = 0, target = null;
    for (var i = 0; i < cnt; i++) {
      try {
        var comp = comps[i];
        if (!comp) continue;
        var dn = comp.displayName ? String(comp.displayName) : "";
        if (dn !== nm) continue;
        if (seen === wantOccurrence) { target = comp; break; }
        seen++;
      } catch (e2) {}
    }
    if (target) done += applyCompParams(target, sp);
  }
  return done;
}

// Прочитать аудиоэффекты с ПЕРВОГО выделенного аудиоклипа (через QE)
function getClipEffects() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, msg: "Нет активной секвенции." });
    if (typeof qe === "undefined") app.enableQE();
    if (typeof qe === "undefined") return JSON.stringify({ ok: false, reason: "no_qe", msg: "QE DOM недоступен." });
    var qseq = qe.project.getActiveSequence();
    if (!qseq) return JSON.stringify({ ok: false, reason: "no_seq", msg: "Нет активной секвенции (QE)." });

    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var clips = seq.audioTracks[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var cl = clips[c];
        var sel = false;
        try { sel = cl.isSelected && cl.isSelected(); } catch (eS) { sel = false; }
        if (!sel) continue;

        var qtr = qseq.getAudioTrackAt(t);
        if (!qtr) continue;
        var qclip = qtr.getItemAt(c);
        if (!qclip || !sameStart(qclip, cl.start.seconds)) {
          for (var qi = 0; qi < qtr.numItems; qi++) {
            var qc = qtr.getItemAt(qi);
            if (qc && sameStart(qc, cl.start.seconds)) { qclip = qc; break; }
          }
        }
        if (!qclip) continue;

        var names = [];
        var cnt = 0; try { cnt = qclip.numComponents; } catch (eC) {}
        for (var i = 0; i < cnt; i++) {
          try {
            var comp = qclip.getComponentAt(i);
            if (comp && comp.name) {
              var nm = String(comp.name);
              if (!isBuiltinClipComp(nm)) names.push(cleanFxName(nm));
            }
          } catch (eK) {}
        }
        var settings = readClipFxSettings(cl, names);
        return JSON.stringify({ ok: true, track: t, effects: names, settings: settings });
      }
    }
    return JSON.stringify({ ok: false, reason: "no_clip", msg: "Выдели аудиоклип на таймлайне." });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: "Ошибка: " + e.message });
  }
}

function selectFolder() {
  var f = Folder.selectDialog("Выбери корневую папку с SFX");
  if (f) return f.fsName;
  return "";
}

// ── Обрезка свежедобавленного клипа после drag&drop ──
// Перетаскивается ОРИГИНАЛЬНЫЙ файл (полное медиа), а после дропа клип
// обрезается до выделения. Снапшот нужен, чтобы среди клипов с тем же
// файлом найти именно новый.

// Ключи "track:startTicks" всех клипов с этим медиа в активной секвенции
function clipKeysForPath(mediaPath) {
  var seq = app.project.activeSequence;
  if (!seq) return null;
  var keys = [];
  var wanted = String(mediaPath).toLowerCase();
  for (var t = 0; t < seq.audioTracks.numTracks; t++) {
    var tr = seq.audioTracks[t];
    for (var c = 0; c < tr.clips.numItems; c++) {
      var cl = tr.clips[c];
      try {
        var mp = cl.projectItem ? String(cl.projectItem.getMediaPath()) : "";
        if (mp.toLowerCase() === wanted) keys.push(t + ":" + String(cl.start.ticks));
      } catch (eI) {}
    }
  }
  return keys;
}

// Снапшот ДО дропа (вызывается панелью при начале перетаскивания)
function listClipsByPath(mediaPath) {
  var keys = clipKeysForPath(mediaPath);
  return keys === null ? "" : keys.join(";");
}

// Найти клип с этим медиа, которого НЕ было в снапшоте, и обрезать
// до [inSec; outSec]. Медиа остаётся полным — клип тянется в обе стороны.
function trimNewClipByPath(mediaPath, inSec, outSec, snapshot) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, msg: "no sequence" });

    var snap = {};
    if (snapshot) {
      var parts = String(snapshot).split(";");
      for (var i = 0; i < parts.length; i++) if (parts[i]) snap[parts[i]] = true;
    }

    var wanted = String(mediaPath).toLowerCase();
    var target = null;

    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var tr = seq.audioTracks[t];
      for (var c = 0; c < tr.clips.numItems; c++) {
        var cl = tr.clips[c];
        try {
          var mp = cl.projectItem ? String(cl.projectItem.getMediaPath()) : "";
          if (mp.toLowerCase() !== wanted) continue;
          var key = t + ":" + String(cl.start.ticks);
          if (!snap[key]) target = cl; // новый клип, которого не было до дропа
        } catch (eI) {}
      }
    }
    if (!target) return JSON.stringify({ ok: false, msg: "clip not found yet" });

    var wantDur = outSec - inSec;

    // уже обрезан корректно? (повторный вызов после успеха)
    var curIn  = target.inPoint.seconds;
    var curDur = target.end.seconds - target.start.seconds;
    if (Math.abs(curIn - inSec) < 0.05 && Math.abs(curDur - wantDur) < 0.05) {
      return JSON.stringify({ ok: true, msg: "already" });
    }

    var startSec = target.start.seconds;

    // 1) ПРАВЫЙ край — через точку выхода ИСТОЧНИКА, и обязательно ДО inPoint:
    //    так за правым краем остаётся медиа, и его можно растянуть обратно.
    //    (если резать через end, Premiere считает источник законченным)
    var tOut = new Time(); tOut.seconds = outSec;
    try { target.outPoint = tOut; } catch (eO) {}

    // 2) ЛЕВЫЙ край — точка входа источника
    var tIn = new Time(); tIn.seconds = inSec;
    try { target.inPoint = tIn; } catch (eIn) {}

    // 3) вернуть клип на место дропа
    try {
      var tStart = new Time(); tStart.seconds = startSec;
      target.start = tStart;
    } catch (eS) { startSec = target.start.seconds; }

    // 4) контроль: если правый край не подрезался — дорезаем через end
    var dur = target.end.seconds - target.start.seconds;
    if (Math.abs(dur - wantDur) > 0.05) {
      try {
        var tEnd = new Time(); tEnd.seconds = target.start.seconds + wantDur;
        target.end = tEnd;
      } catch (eE) {}
    }

    // 5) финальная проверка фактического состояния
    var fIn  = target.inPoint.seconds;
    var fDur = target.end.seconds - target.start.seconds;
    var good = Math.abs(fIn - inSec) < 0.05 && Math.abs(fDur - wantDur) < 0.05;
    return JSON.stringify({
      ok: good,
      msg: good ? "trimmed" : ("in=" + fIn.toFixed(2) + " dur=" + fDur.toFixed(2))
    });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: e.message });
  }
}

// ── Вставить уже обработанный (запечённый) звук как клип ──
// Используется как fallback, когда QE не сработал. Логика как в addToTimeline.
function insertProcessed(filePath, inSec, outSec) {
  return addToTimeline(filePath, inSec, outSec);
}

function folderExists(path) {
  return (new Folder(path)).exists ? "true" : "false";
}

// ── Свой браузер папок: список дисков/стартовых точек ──
function listDrives() {
  var result = [];
  try {
    if ($.os.indexOf("Windows") !== -1) {
      // перебираем буквы дисков
      var letters = "CDEFGHIJKLMNOPQRSTUVWXYZ".split("");
      for (var i = 0; i < letters.length; i++) {
        var d = new Folder(letters[i] + ":/");
        if (d.exists) result.push({ name: letters[i] + ":\\", path: d.fsName });
      }
    } else {
      // macOS: домашняя, /Volumes/*
      var home = Folder("~");
      if (home.exists) result.push({ name: "Домашняя", path: home.fsName });
      var vol = new Folder("/Volumes");
      if (vol.exists) {
        var vs = vol.getFiles();
        for (var j = 0; j < vs.length; j++) {
          if (vs[j] instanceof Folder) result.push({ name: vs[j].name, path: vs[j].fsName });
        }
      }
    }
    // полезные точки
    var desktop = Folder.desktop;
    if (desktop && desktop.exists) result.push({ name: "Рабочий стол", path: desktop.fsName });
    var docs = Folder.myDocuments;
    if (docs && docs.exists) result.push({ name: "Документы", path: docs.fsName });
  } catch (e) {}
  return JSON.stringify(result);
}

// Список подпапок (для навигации в браузере), + родитель
function browseFolder(folderPath) {
  var folder = new Folder(folderPath);
  if (!folder.exists) return JSON.stringify({ error: "Папка не найдена" });

  var subs = [];
  try {
    var items = folder.getFiles();
    for (var i = 0; i < items.length; i++) {
      if (items[i] instanceof Folder) {
        var nm = decodeName(items[i]);
        if (nm.charAt(0) === ".") continue; // скрытые
        subs.push({ name: nm, path: items[i].fsName });
      }
    }
    subs.sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; });
  } catch (e) {}

  var parent = "";
  try { if (folder.parent && folder.parent.exists) parent = folder.parent.fsName; } catch (e2) {}

  return JSON.stringify({
    path: folder.fsName,
    name: decodeName(folder) || folder.fsName,
    parent: parent,
    subs: subs
  });
}

// ══════════════════════════════════════════════
//  СОРТЕР PROJECT-ПАНЕЛИ (раскладка по бинам)
// ══════════════════════════════════════════════
// Раскладывает клипы корня проекта (или выделенной папки) по бинам типа.
// opts (JSON-строка): { cats:{audio,video,images,graphics,sequences,offline},
//   names:{...}, removeEmpty, removeUnused, ignore:"...", selectedOnly }
// Использует документированный API: project.rootItem, createBin, moveBin.
function runProjectSort(optsJson) {
  try {
    var opts = {};
    try { opts = JSON.parse(optsJson) || {}; } catch (eP) { opts = {}; }
    var cats  = opts.cats  || {};
    var names = opts.names || {};

    var proj = app.project;
    if (!proj) return JSON.stringify({ ok: false, msg: "Нет открытого проекта" });

    // корень сортировки: выделенная папка или корень проекта
    var root = proj.rootItem;
    if (opts.selectedOnly) {
      var sel = (proj.getSelection && proj.getSelection()) || [];
      for (var s = 0; s < sel.length; s++) {
        if (sel[s] && sel[s].type === ProjectItemType.BIN) { root = sel[s]; break; }
      }
    }

    // список игнорируемых имён (через запятую)
    var ignore = {};
    if (opts.ignore) {
      var ig = String(opts.ignore).split(",");
      for (var g = 0; g < ig.length; g++) {
        var nm = trimStr(ig[g]).toLowerCase();
        if (nm) ignore[nm] = true;
      }
    }

    // какие бины нужны
    var binCache = {};
    function binFor(key) {
      if (!cats[key]) return null;
      if (binCache[key]) return binCache[key];
      var title = names[key] || key;
      var b = findOrCreateBin(root, title);
      binCache[key] = b;
      return b;
    }

    // расширение из пути (или имени) клипа — без regex (надёжнее в ExtendScript)
    function extOf(p) {
      if (!p) return "";
      p = String(p);
      try { p = decodeURIComponent(p); } catch (eD) {}
      // обрезать хвостовые пробелы и слэши вручную
      var end = p.length;
      while (end > 0) {
        var ch = p.charAt(end - 1);
        if (ch === " " || ch === "\t" || ch === "/" || ch === "\\") end--;
        else break;
      }
      p = p.substring(0, end);
      var dot = p.lastIndexOf(".");
      if (dot < 0 || dot < p.length - 6) return ""; // нет адекватного расширения
      return p.substring(dot + 1).toLowerCase();
    }

    // расширение принадлежит списку?
    function extIn(ext, list) {
      for (var i = 0; i < list.length; i++) if (list[i] === ext) return true;
      return false;
    }
    var EXT_AUDIO = ["wav","mp3","aiff","aif","aifc","aac","m4a","flac","ogg","oga","wma","caf","opus","mka"];
    var EXT_VIDEO = ["mov","mp4","m4v","avi","mxf","mts","m2ts","mpg","mpeg","mkv","wmv","webm","flv","3gp","3g2","dv","vob","ts","r3d","braw"];
    var EXT_GFX   = ["psd","ai","eps","svg","prproj","aep"];
    var EXT_IMG   = ["jpg","jpeg","png","gif","tif","tiff","bmp","tga","targa","exr","webp","dpx","hdr","ico","heic","heif"];

    // классификация одного клипа — по расширению, НЕ по типу
    // (импортированные клипы в Premiere обычно типа CLIP, а не FILE)
    function classify(item) {
      try { if (item.isOffline && item.isOffline()) return "offline"; } catch (eO) {}

      var path = "";
      try { path = item.getMediaPath ? (item.getMediaPath() || "") : ""; } catch (eM) {}
      var ext = extOf(path);
      if (!ext) ext = extOf(item.name || "");

      if (ext) {
        if (extIn(ext, EXT_AUDIO)) return "audio";
        if (extIn(ext, EXT_VIDEO)) return "video";
        if (extIn(ext, EXT_GFX))   return "graphics";
        if (extIn(ext, EXT_IMG))   return "images";
      }

      // нет/неизвестное расширение — пробуем по медиа-флагам клипа
      try {
        var hasV = item.hasVideo && item.hasVideo();
        var hasA = item.hasAudio && item.hasAudio();
        if (hasV) return "video";
        if (hasA) return "audio";
      } catch (eH) {}

      return null;
    }

    var moved = 0, skipped = 0;
    // собираем верхнеуровневые клипы (не трогаем то, что уже в наших бинах)
    var toProcess = [];
    var n = root.children.numItems;
    for (var i = 0; i < n; i++) {
      var it = root.children[i];
      if (!it) continue;
      var lname = (it.name || "").toLowerCase();
      if (ignore[lname]) { skipped++; continue; }
      if (it.type === ProjectItemType.BIN) continue; // существующие бины не трогаем
      toProcess.push(it);
    }

    // секвенции: сверяем по списку project.sequences (надёжнее, чем по типу)
    var seqNames = {};
    try {
      for (var q = 0; q < proj.sequences.numSequences; q++) {
        seqNames[proj.sequences[q].name] = true;
      }
    } catch (eSq) {}

    for (var p = 0; p < toProcess.length; p++) {
      var item = toProcess[p];
      var key = null;
      if (seqNames[item.name]) key = "sequences";
      else key = classify(item);
      if (!key) { skipped++; continue; }

      var bin = binFor(key);
      if (!bin) { skipped++; continue; } // категория выключена

      // подпапки по типу файла (если включено): Images → PNG/JPG/SVG и т.п.
      // подпапка создаётся только когда реально встретился файл такого расширения.
      var dest = bin;
      if (opts.subByExt && key !== "sequences" && key !== "offline") {
        var mp = "";
        try { mp = item.getMediaPath ? (item.getMediaPath() || "") : ""; } catch (eMp) {}
        var ex = extOf(mp);
        if (!ex) ex = extOf(item.name || "");
        if (ex) dest = findOrCreateBin(bin, ex.toUpperCase());
      }
      try { item.moveBin(dest); moved++; } catch (eMv) { skipped++; }
    }

    // удалить неиспользованные клипы (нет на таймлайнах) — если включено
    var removedUnused = 0;
    if (opts.removeUnused) removedUnused = removeUnusedClips(root);

    // удалить пустые бины — если включено
    var removedEmpty = 0;
    if (opts.removeEmpty) removedEmpty = removeEmptyBins(root);

    return JSON.stringify({
      ok: true, moved: moved, skipped: skipped,
      removedUnused: removedUnused, removedEmpty: removedEmpty
    });
  } catch (e) {
    return JSON.stringify({ ok: false, msg: "Ошибка сортировки: " + e.toString() });
  }
}

function findOrCreateBin(parent, title) {
  var n = parent.children.numItems;
  for (var i = 0; i < n; i++) {
    var c = parent.children[i];
    if (c && c.type === ProjectItemType.BIN && c.name === title) return c;
  }
  return parent.createBin(title);
}

// Удалить клипы, не использованные ни в одной секвенции
function removeUnusedClips(root) {
  var used = {};
  try {
    for (var s = 0; s < app.project.sequences.numSequences; s++) {
      var seq = app.project.sequences[s];
      collectUsedFromSequence(seq, used);
    }
  } catch (e) {}

  var removed = 0;
  // имена секвенций — их не трогаем как «неиспользованные»
  var seqNames = {};
  try {
    for (var s2 = 0; s2 < app.project.sequences.numSequences; s2++) seqNames[app.project.sequences[s2].name] = true;
  } catch (eSn) {}

  // обходим рекурсивно и удаляем неиспользованные клипы (любого типа, кроме бинов/секвенций)
  function walk(bin) {
    for (var i = bin.children.numItems - 1; i >= 0; i--) {
      var it = bin.children[i];
      if (!it) continue;
      if (it.type === ProjectItemType.BIN) { walk(it); continue; }
      if (seqNames[it.name]) continue; // секвенции не удаляем
      var nodeId = "";
      try { nodeId = it.nodeId; } catch (eN) {}
      if (!used[it.name] && !used[nodeId]) {
        try { it.deleteBin(); removed++; } catch (eD) {}
      }
    }
  }
  try { walk(root); } catch (eW) {}
  return removed;
}

function collectUsedFromSequence(seq, used) {
  try {
    var tracks = ["videoTracks", "audioTracks"];
    for (var t = 0; t < tracks.length; t++) {
      var grp = seq[tracks[t]];
      for (var k = 0; k < grp.numTracks; k++) {
        var trk = grp[k];
        for (var c = 0; c < trk.clips.numItems; c++) {
          var clip = trk.clips[c];
          if (clip && clip.projectItem) {
            used[clip.projectItem.name] = true;
            try { used[clip.projectItem.nodeId] = true; } catch (eI) {}
          }
        }
      }
    }
  } catch (e) {}
}

// Удалить пустые бины (рекурсивно, снизу вверх)
function removeEmptyBins(root) {
  var removed = 0;
  function walk(bin) {
    for (var i = bin.children.numItems - 1; i >= 0; i--) {
      var it = bin.children[i];
      if (it && it.type === ProjectItemType.BIN) {
        walk(it);
        if (it.children.numItems === 0) {
          try { it.deleteBin(); removed++; } catch (eD) {}
        }
      }
    }
  }
  try { walk(root); } catch (eW) {}
  return removed;
}
