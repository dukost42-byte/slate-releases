/* ===== Motion Panel — picker.js =====
   Логика отдельного плавающего окна выбора цвета (modeless-расширение).
   Канонический цвет хранится в HSB (квадрат S/B + полоса Hue), RGB/HSL/HEX — производные.
   Результат уходит в панель двумя путями: CEP-событие mp.picker.result + $.global.MP_pickResult. */

var cs = new CSInterface();
var $ = function (s) { return document.querySelector(s); };

var sbArea = $('#sbArea'), sbCursor = $('#sbCursor');
var hueStrip = $('#hueStrip'), hueCursor = $('#hueCursor');
var preview = $('#pickPreview');
var fR = $('#fR'), fG = $('#fG'), fB2 = $('#fB2');
var lH = $('#lH'), lS = $('#lS'), lL = $('#lL');
var fHex = $('#fHex');

var st = { h: 32, s: 45, b: 50 };
var sent = false; // защита от двойной отправки

/* ---------- конвертации ---------- */
function clampInt(v, a, b) { v = Math.round(+v || 0); return Math.max(a, Math.min(b, v)); }

function hsbToRgb(h, s, v) {
  s /= 100; v /= 100;
  var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function rgbToHsb(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
  if (d) {
    if (mx === r) h = 60 * (((g - b) / d) % 6);
    else if (mx === g) h = 60 * ((b - r) / d + 2);
    else h = 60 * ((r - g) / d + 4);
  }
  if (h < 0) h += 360;
  return [h, mx ? (d / mx) * 100 : 0, mx * 100];
}
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0, l = (mx + mn) / 2, s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    if (mx === r) h = 60 * (((g - b) / d) % 6);
    else if (mx === g) h = 60 * ((b - r) / d + 2);
    else h = 60 * ((r - g) / d + 4);
  }
  if (h < 0) h += 360;
  return [h, s * 100, l * 100];
}
function hslToRgb(h, s, l) {
  s /= 100; l /= 100;
  var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function hexToRgb(hex) {
  hex = (hex || '').replace('#', '').trim();
  if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null;
  return [parseInt(hex.substr(0, 2), 16), parseInt(hex.substr(2, 2), 16), parseInt(hex.substr(4, 2), 16)];
}
function rgbToHex(r, g, b) {
  function p(n) { n = Math.max(0, Math.min(255, Math.round(n))).toString(16); return n.length < 2 ? '0' + n : n; }
  return (p(r) + p(g) + p(b)).toUpperCase();
}

/* ---------- отрисовка ---------- */
function render(skipInputs) {
  var rgb = hsbToRgb(st.h, st.s, st.b);
  var hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
  sbArea.style.background = 'hsl(' + st.h + ',100%,50%)';
  sbCursor.style.left = st.s + '%';
  sbCursor.style.top = (100 - st.b) + '%';
  hueCursor.style.top = (st.h / 360 * 100) + '%';
  preview.style.background = '#' + hex;
  if (!skipInputs) {
    fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
    var hsl = rgbToHsl(rgb[0], rgb[1], rgb[2]);
    lH.value = Math.round(hsl[0]); lS.value = Math.round(hsl[1]); lL.value = Math.round(hsl[2]);
    fHex.value = hex;
  }
}

/* ---------- drag (mouse — работает во всех версиях CEP) ---------- */
function drag(el, onMove) {
  el.addEventListener('mousedown', function (e) {
    e.preventDefault();
    onMove(e);
    function mm(ev) { onMove(ev); }
    function mu() {
      window.removeEventListener('mousemove', mm);
      window.removeEventListener('mouseup', mu);
    }
    window.addEventListener('mousemove', mm);
    window.addEventListener('mouseup', mu);
  });
}
drag(sbArea, function (e) {
  var r = sbArea.getBoundingClientRect();
  st.s = Math.max(0, Math.min(100, (e.clientX - r.left) / r.width * 100));
  st.b = Math.max(0, Math.min(100, 100 - (e.clientY - r.top) / r.height * 100));
  render();
});
drag(hueStrip, function (e) {
  var r = hueStrip.getBoundingClientRect();
  st.h = Math.max(0, Math.min(359.9, (e.clientY - r.top) / r.height * 360));
  render();
});

/* ---------- ввод значений ---------- */
function fromRgb() {
  var hsb = rgbToHsb(clampInt(fR.value, 0, 255), clampInt(fG.value, 0, 255), clampInt(fB2.value, 0, 255));
  st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
  render(true);
  var rgb = hsbToRgb(st.h, st.s, st.b);
  var hsl = rgbToHsl(rgb[0], rgb[1], rgb[2]);
  lH.value = Math.round(hsl[0]); lS.value = Math.round(hsl[1]); lL.value = Math.round(hsl[2]);
  fHex.value = rgbToHex(rgb[0], rgb[1], rgb[2]);
}
function fromHsl() {
  var rgb = hslToRgb(clampInt(lH.value, 0, 360), clampInt(lS.value, 0, 100), clampInt(lL.value, 0, 100));
  var hsb = rgbToHsb(rgb[0], rgb[1], rgb[2]);
  st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
  render(true);
  fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
  fHex.value = rgbToHex(rgb[0], rgb[1], rgb[2]);
}
function fromHex() {
  var rgb = hexToRgb(fHex.value);
  if (!rgb) return;
  var hsb = rgbToHsb(rgb[0], rgb[1], rgb[2]);
  st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
  render(true);
  fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
  var hsl = rgbToHsl(rgb[0], rgb[1], rgb[2]);
  lH.value = Math.round(hsl[0]); lS.value = Math.round(hsl[1]); lL.value = Math.round(hsl[2]);
}
[fR, fG, fB2].forEach(function (i) { i.addEventListener('input', fromRgb); });
[lH, lS, lL].forEach(function (i) { i.addEventListener('input', fromHsl); });
fHex.addEventListener('input', fromHex);
fHex.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') cancel(); });

/* ---------- пипетка: настоящий захват цвета с экрана ----------
   В CEF браузерный EyeDropper не работает, а $.colorPicker на Windows — это системный
   диалог без забора с экрана (и он же подвешивал AE модальным окном). Поэтому в AE
   запускаем системную пипетку через PowerShell (Node child_process, АСИНХРОННО — AE не виснет):
   ждём клик мышью в любом месте экрана и читаем пиксель ровно под курсором. */
function setStatus(msg) {
  var el = $('#pickStatus');
  if (!el) return;
  el.textContent = msg || '';
  el.style.display = msg ? 'block' : 'none';
}
function nodeRequire(mod) {
  if (typeof require === 'function') return require(mod);
  if (window.cep_node && window.cep_node.require) return window.cep_node.require(mod);
  if (window.require) return window.require(mod);
  return null;
}
var PS_PICK = [
  'Add-Type -AssemblyName System.Windows.Forms',
  'Add-Type -AssemblyName System.Drawing',
  'function Get-Pix($x,$y){',
  '  $bmp = New-Object System.Drawing.Bitmap 1,1',
  '  $gg = [System.Drawing.Graphics]::FromImage($bmp)',
  '  $gg.CopyFromScreen($x, $y, 0, 0, $bmp.Size)',
  '  $col = $bmp.GetPixel(0,0)',
  '  $gg.Dispose(); $bmp.Dispose()',
  '  return $col',
  '}',
  '$res = "CANCEL"',
  'try {',
  '  $vs = [System.Windows.Forms.SystemInformation]::VirtualScreen',
  '  $form = New-Object System.Windows.Forms.Form',
  '  $form.FormBorderStyle = "None"',
  '  $form.StartPosition = "Manual"',
  '  $form.Location = New-Object System.Drawing.Point($vs.X, $vs.Y)',
  '  $form.Size = New-Object System.Drawing.Size($vs.Width, $vs.Height)',
  '  $form.TopMost = $true',
  '  $form.ShowInTaskbar = $false',
  '  $form.BackColor = "Black"',
  '  $form.Opacity = 0.02',
  '  $form.Cursor = [System.Windows.Forms.Cursors]::Cross',
  '  $form.KeyPreview = $true',
  '  $tip = New-Object System.Windows.Forms.Form',
  '  $tip.FormBorderStyle = "None"',
  '  $tip.StartPosition = "Manual"',
  '  $tip.TopMost = $true',
  '  $tip.ShowInTaskbar = $false',
  '  $tip.Size = New-Object System.Drawing.Size(104, 24)',
  '  $tip.BackColor = "Black"',
  '  $lbl = New-Object System.Windows.Forms.Label',
  '  $lbl.Dock = "Fill"',
  '  $lbl.TextAlign = "MiddleCenter"',
  '  $lbl.Font = New-Object System.Drawing.Font("Consolas", 10)',
  '  $lbl.Text = "#------"',
  '  $tip.Controls.Add($lbl)',
  '  $script:ticks = 0',
  '  $timer = New-Object System.Windows.Forms.Timer',
  '  $timer.Interval = 50',
  '  $timer.Add_Tick({',
  '    $script:ticks++',
  '    if ($script:ticks -gt 600) { $form.Tag = "CANCEL"; $form.Close(); return }',
  '    $p = [System.Windows.Forms.Cursor]::Position',
  '    $c = Get-Pix $p.X $p.Y',
  '    $lbl.Text = ("#{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B)',
  '    $lbl.BackColor = [System.Drawing.Color]::FromArgb([int]$c.R, [int]$c.G, [int]$c.B)',
  '    if ((($c.R*0.299)+($c.G*0.587)+($c.B*0.114)) -lt 110) { $lbl.ForeColor = "White" } else { $lbl.ForeColor = "Black" }',
  '    $tip.Location = New-Object System.Drawing.Point(([int]$p.X + 18), ([int]$p.Y - 30))',
  '  })',
  '  $form.Add_MouseDown({',
  '    $p = [System.Windows.Forms.Cursor]::Position',
  '    $timer.Stop()',
  '    $tip.Hide(); $form.Opacity = 0',
  '    [System.Windows.Forms.Application]::DoEvents()',
  '    Start-Sleep -Milliseconds 40',
  '    $c = Get-Pix $p.X $p.Y',
  '    $form.Tag = ("{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B)',
  '    $form.Close()',
  '  })',
  '  $form.Add_KeyDown({ if ($_.KeyCode -eq "Escape") { $form.Tag = "CANCEL"; $form.Close() } })',
  '  $form.Add_FormClosing({ $timer.Stop(); try { $tip.Close() } catch {} })',
  '  $form.Add_Shown({ $form.Activate(); $tip.Show() })',
  '  $timer.Start()',
  '  [System.Windows.Forms.Application]::Run($form)',
  '  if ($form.Tag) { $res = [string]$form.Tag }',
  '} catch { $res = "ERR" }',
  "[System.IO.File]::WriteAllText('@@RESULT@@', $res)"
].join('\n');

/* ---- быстрая пипетка: «тёплый» PowerShell-хост ----
   Тяжёлая загрузка WinForms (~1.5–3с) выполняется заранее — при открытии окна пикера.
   По клику хосту пишется файл-триггер, и оверлей-прицел появляется мгновенно.
   Если хост недоступен — откат на разовый запуск (oneShotPick). */
var HOST_PS = [
  'Add-Type -AssemblyName System.Windows.Forms',
  'Add-Type -AssemblyName System.Drawing',
  'function Get-Pix($x,$y){',
  '  $bmp = New-Object System.Drawing.Bitmap 1,1',
  '  $gg = [System.Drawing.Graphics]::FromImage($bmp)',
  '  $gg.CopyFromScreen($x, $y, 0, 0, $bmp.Size)',
  '  $col = $bmp.GetPixel(0,0)',
  '  $gg.Dispose(); $bmp.Dispose()',
  '  return $col',
  '}',
  'function Invoke-Pick {',
  '  $r = "CANCEL"',
  '  try {',
  '    $vs = [System.Windows.Forms.SystemInformation]::VirtualScreen',
  '    $form = New-Object System.Windows.Forms.Form',
  '    $form.FormBorderStyle = "None"',
  '    $form.StartPosition = "Manual"',
  '    $form.Location = New-Object System.Drawing.Point($vs.X, $vs.Y)',
  '    $form.Size = New-Object System.Drawing.Size($vs.Width, $vs.Height)',
  '    $form.TopMost = $true',
  '    $form.ShowInTaskbar = $false',
  '    $form.BackColor = "Black"',
  '    $form.Opacity = 0.02',
  '    $form.Cursor = [System.Windows.Forms.Cursors]::Cross',
  '    $form.KeyPreview = $true',
  '    $tip = New-Object System.Windows.Forms.Form',
  '    $tip.FormBorderStyle = "None"',
  '    $tip.StartPosition = "Manual"',
  '    $tip.TopMost = $true',
  '    $tip.ShowInTaskbar = $false',
  '    $tip.Size = New-Object System.Drawing.Size(104, 24)',
  '    $tip.BackColor = "Black"',
  '    $lbl = New-Object System.Windows.Forms.Label',
  '    $lbl.Dock = "Fill"',
  '    $lbl.TextAlign = "MiddleCenter"',
  '    $lbl.Font = New-Object System.Drawing.Font("Consolas", 10)',
  '    $lbl.Text = "#------"',
  '    $tip.Controls.Add($lbl)',
  '    $script:ticks = 0',
  '    $timer = New-Object System.Windows.Forms.Timer',
  '    $timer.Interval = 50',
  '    $timer.Add_Tick({',
  '      $script:ticks++',
  '      if ($script:ticks -gt 600) { $form.Tag = "CANCEL"; $form.Close(); return }',
  '      $p = [System.Windows.Forms.Cursor]::Position',
  '      $c = Get-Pix $p.X $p.Y',
  '      $lbl.Text = ("#{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B)',
  '      $lbl.BackColor = [System.Drawing.Color]::FromArgb([int]$c.R, [int]$c.G, [int]$c.B)',
  '      if ((($c.R*0.299)+($c.G*0.587)+($c.B*0.114)) -lt 110) { $lbl.ForeColor = "White" } else { $lbl.ForeColor = "Black" }',
  '      $tip.Location = New-Object System.Drawing.Point(([int]$p.X + 18), ([int]$p.Y - 30))',
  '    })',
  '    $form.Add_MouseDown({',
  '      $p = [System.Windows.Forms.Cursor]::Position',
  '      $timer.Stop()',
  '      $tip.Hide(); $form.Opacity = 0',
  '      [System.Windows.Forms.Application]::DoEvents()',
  '      Start-Sleep -Milliseconds 40',
  '      $c = Get-Pix $p.X $p.Y',
  '      $form.Tag = ("{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B)',
  '      $form.Close()',
  '    })',
  '    $form.Add_KeyDown({ if ($_.KeyCode -eq "Escape") { $form.Tag = "CANCEL"; $form.Close() } })',
  '    $form.Add_FormClosing({ $timer.Stop(); try { $tip.Close() } catch {} })',
  '    $form.Add_Shown({ $form.Activate(); $tip.Show() })',
  '    $timer.Start()',
  '    [System.Windows.Forms.Application]::Run($form)',
  '    if ($form.Tag) { $r = [string]$form.Tag }',
  '  } catch { $r = "ERR" }',
  '  return $r',
  '}',
  'try { if (Test-Path \'@@TRIG@@\') { Remove-Item \'@@TRIG@@\' -Force } } catch {}',
  'try { if (Test-Path \'@@RES@@\') { Remove-Item \'@@RES@@\' -Force } } catch {}',
  '$idle = 0',
  'while ($true) {',
  '  if (Test-Path \'@@TRIG@@\') {',
  '    try { Remove-Item \'@@TRIG@@\' -Force } catch {}',
  '    $hex = Invoke-Pick',
  '    try { [System.IO.File]::WriteAllText(\'@@RES@@\', $hex) } catch {}',
  '    $idle = 0',
  '  } else {',
  '    Start-Sleep -Milliseconds 110',
  '    $idle += 110',
  '    if ($idle -gt 600000) { break }',
  '  }',
  '}'
].join('\n');

var ED = { ps: null, trig: null, res: null, child: null, exited: false };
function edPaths(osMod) {
  var d = osMod.tmpdir();
  ED.ps   = d + '\\mp_eyedrop_host.ps1';
  ED.trig = d + '\\mp_eyedrop_trig.txt';
  ED.res  = d + '\\mp_eyedrop_res.txt';
}
function edSpawnHost(cp, osMod, fsMod) {
  try {
    edPaths(osMod);
    var script = HOST_PS.split('@@TRIG@@').join(ED.trig).split('@@RES@@').join(ED.res);
    fsMod.writeFileSync(ED.ps, script, 'utf8');
    try { if (fsMod.existsSync(ED.trig)) fsMod.unlinkSync(ED.trig); } catch (e) {}
    try { if (fsMod.existsSync(ED.res)) fsMod.unlinkSync(ED.res); } catch (e) {}
    ED.exited = false;
    ED.child = cp.spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Sta', '-WindowStyle', 'Hidden', '-File', ED.ps], { windowsHide: true });
    ED.child.on('exit', function () { ED.exited = true; });
    ED.child.on('error', function () { ED.exited = true; ED.child = null; });
  } catch (e) { ED.child = null; ED.exited = true; }
}
function edAlive() { return !!(ED.child && !ED.exited); }
function edKill() { try { if (ED.child) ED.child.kill(); } catch (e) {} ED.child = null; ED.exited = true; }
function edPrewarm() {
  if (!cs.isCEP()) return;
  var cp, osMod, fsMod;
  try { cp = nodeRequire('child_process'); osMod = nodeRequire('os'); fsMod = nodeRequire('fs'); } catch (e) { return; }
  if (osMod.platform() !== 'win32') return;
  if (!edAlive()) edSpawnHost(cp, osMod, fsMod);
}

function hostPick(cp, osMod, fsMod) {
  setStatus('Наведи прицел на нужный цвет и кликни один раз  ·  Esc — отмена');
  try { if (fsMod.existsSync(ED.res)) fsMod.unlinkSync(ED.res); } catch (e) {}
  try { fsMod.writeFileSync(ED.trig, '1', 'utf8'); }
  catch (e) { oneShotPick(cp, osMod, fsMod); return; }
  var waited = 0;
  var iv = setInterval(function () {
    waited += 60;
    if (ED.exited) {                         // хост умер — откат
      clearInterval(iv);
      edSpawnHost(cp, osMod, fsMod);
      oneShotPick(cp, osMod, fsMod);
      return;
    }
    var out = null;
    try { if (fsMod.existsSync(ED.res)) out = fsMod.readFileSync(ED.res, 'utf8'); } catch (e) {}
    if (out !== null) {
      clearInterval(iv);
      try { fsMod.unlinkSync(ED.res); } catch (e) {}
      setStatus('');
      out = (out || '').trim().toUpperCase();
      var m = out.match(/[0-9A-F]{6}/);
      if (m && out.indexOf('CANCEL') !== 0 && out.indexOf('ERR') !== 0) { fHex.value = m[0]; fromHex(); return; }
      if (out.indexOf('CANCEL') === 0) return;
      setStatus('Не удалось взять цвет'); setTimeout(function () { setStatus(''); }, 2000);
      return;
    }
    if (waited > 40000) { clearInterval(iv); setStatus(''); }
  }, 60);
}

function oneShotPick(cp, osMod, fsMod) {
  var stamp = Date.now();
  var resFile = osMod.tmpdir() + '\\mp_eyedrop_' + stamp + '.txt';
  var psFile  = osMod.tmpdir() + '\\mp_eyedrop_' + stamp + '.ps1';
  var script = PS_PICK.replace('@@RESULT@@', function () { return resFile; });
  try { fsMod.writeFileSync(psFile, script, 'utf8'); }
  catch (e) { setStatus('Не удалось подготовить пипетку'); setTimeout(function () { setStatus(''); }, 2000); return; }
  setStatus('Наведи прицел на нужный цвет и кликни один раз  ·  Esc — отмена');
  var cmd = 'powershell -NoProfile -ExecutionPolicy Bypass -Sta -WindowStyle Hidden -File "' + psFile + '"';
  cp.exec(cmd, { windowsHide: true, timeout: 45000 }, function () {
    setStatus('');
    var out = '';
    try { out = fsMod.readFileSync(resFile, 'utf8'); } catch (e) {}
    try { fsMod.unlinkSync(resFile); } catch (e) {}
    try { fsMod.unlinkSync(psFile); } catch (e) {}
    out = (out || '').trim().toUpperCase();
    var m = out.match(/[0-9A-F]{6}/);
    if (m && out.indexOf('CANCEL') !== 0 && out.indexOf('ERR') !== 0) { fHex.value = m[0]; fromHex(); return; }
    if (out.indexOf('CANCEL') === 0) return;
    setStatus('Не удалось взять цвет'); setTimeout(function () { setStatus(''); }, 2000);
  });
}

/* ---- macOS: нативная пипетка-лупа ----
   Основной путь — системный NSColorSampler (macOS 10.15+): лупа поверх экрана, один клик
   по ЛЮБОМУ пикселю — ровно как на Windows, без рамок и без отдельного бинарника.
   Дёргаем его через JXA (osascript -l JavaScript + ObjC-мост). Если ОС/движок не поддержит —
   авто-откат на системный диалог `choose color` (в нём лупа тоже есть). */
function toHex2(n) { n = n & 255; var s = n.toString(16); return s.length < 2 ? '0' + s : s; }

var MAC_SAMPLER_JS = [
  "ObjC.import('AppKit');",
  "var __o = 'ERR';",
  "(function(){",
  "  try {",
  "    if (!$.NSColorSampler) { __o='ERR'; return; }",
  "    var app = $.NSApplication.sharedApplication;",
  "    try { app.setActivationPolicy($.NSApplicationActivationPolicyAccessory); } catch(e0){}",
  "    try { app.activateIgnoringOtherApps(true); } catch(e1){}",
  "    var done=false; __o='CANCEL';",
  "    var s = $.NSColorSampler.alloc.init;",
  "    s.showSamplerWithSelectionHandler(function(c){",
  "      try {",
  "        if (c && !c.isNil()) {",
  "          var rc = c.colorUsingColorSpace($.NSColorSpace.sRGBColorSpace);",
  "          if (!rc || rc.isNil()) rc = c.colorUsingColorSpace($.NSColorSpace.deviceRGBColorSpace);",
  "          if (rc && !rc.isNil()) {",
  "            __o = Math.round(rc.redComponent*255)+','+Math.round(rc.greenComponent*255)+','+Math.round(rc.blueComponent*255);",
  "          }",
  "        }",
  "      } catch(e2){}",
  "      done=true;",
  "    });",
  "    var rl = $.NSRunLoop.currentRunLoop;",
  "    var t0 = $.NSDate.date;",
  "    while(!done){",
  "      rl.runModeBeforeDate($.NSDefaultRunLoopMode, $.NSDate.dateWithTimeIntervalSinceNow(0.1));",
  "      if ($.NSDate.date.timeIntervalSinceDate(t0) > 120) break;",
  "    }",
  "  } catch(e){ __o='ERR'; }",
  "})();",
  "__o;"
].join('\n');

function macPick(cp, osMod, fsMod) {
  var jsf = osMod.tmpdir() + '/mp_eyedrop_' + Date.now() + '.js';
  try { fsMod.writeFileSync(jsf, MAC_SAMPLER_JS, 'utf8'); }
  catch (e) { macPickDialog(cp, osMod, fsMod); return; }
  setStatus('Пипетка: наведи лупу на нужный пиксель и кликни  ·  Esc — отмена');
  cp.exec('osascript -l JavaScript ' + JSON.stringify(jsf), { timeout: 180000 }, function (err, stdout) {
    try { fsMod.unlinkSync(jsf); } catch (e) {}
    var out = String(stdout || '').trim();
    if (out.indexOf('CANCEL') === 0) { setStatus(''); return; }          // отмена — без отката
    var m = out.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (m) {
      setStatus('');
      fHex.value = (toHex2(+m[1]) + toHex2(+m[2]) + toHex2(+m[3])).toUpperCase();
      fromHex();
      return;
    }
    macPickDialog(cp, osMod, fsMod);                                      // 'ERR'/пусто — откат на диалог цвета
  });
}

/* запасной путь: системный диалог цвета `choose color` (лупа внутри). Возвращает {R,G,B} 0..65535. */
function macPickDialog(cp, osMod, fsMod) {
  var rgb = hsbToRgb(st.h, st.s, st.b);
  var r16 = Math.round(rgb[0] / 255 * 65535), g16 = Math.round(rgb[1] / 255 * 65535), b16 = Math.round(rgb[2] / 255 * 65535);
  var scpt = osMod.tmpdir() + '/mp_eyedrop_' + Date.now() + '.scpt';
  var script = [
    'try',
    '  set c to choose color default color {' + r16 + ', ' + g16 + ', ' + b16 + '}',
    '  return ((item 1 of c) as integer) & "," & ((item 2 of c) as integer) & "," & ((item 3 of c) as integer)',
    'on error',
    '  return "CANCEL"',
    'end try'
  ].join('\n');
  try { fsMod.writeFileSync(scpt, script, 'utf8'); }
  catch (e) { setStatus('Не удалось открыть пипетку'); setTimeout(function () { setStatus(''); }, 2500); return; }
  setStatus('Открылся выбор цвета — нажми лупу-пипетку и кликни по пикселю, затем OK');
  cp.exec('osascript ' + JSON.stringify(scpt), { timeout: 180000 }, function (err, stdout) {
    setStatus('');
    try { fsMod.unlinkSync(scpt); } catch (e) {}
    var out = String(stdout || '').trim();
    if (!out || out.indexOf('CANCEL') === 0) return;
    var m = out.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (!m) { setStatus('Не удалось взять цвет'); setTimeout(function () { setStatus(''); }, 2500); return; }
    fHex.value = (toHex2(Math.round(+m[1] / 65535 * 255)) + toHex2(Math.round(+m[2] / 65535 * 255)) + toHex2(Math.round(+m[3] / 65535 * 255))).toUpperCase();
    fromHex();
  });
}

function screenPick() {
  var cp = null, osMod = null, fsMod = null;
  try { cp = nodeRequire('child_process'); osMod = nodeRequire('os'); fsMod = nodeRequire('fs'); } catch (e) {}
  if (!cp || !osMod || !fsMod) { setStatus('Пипетка требует Node — перезапусти After Effects'); return; }
  var plat = osMod.platform();
  if (plat === 'darwin') { macPick(cp, osMod, fsMod); return; }   // macOS — системный screencapture
  if (plat !== 'win32') { setStatus('Пипетка по экрану пока только на Windows и macOS'); return; }
  // пипетка — РАЗОВЫМ запуском: тяжёлый PowerShell/WinForms поднимается только сейчас и сам
  // завершается после забора цвета. Никакого «тёплого хоста» — он давал CPU-спайк при открытии
  // окна и фриз AE на OK, когда процесс ещё догружал сборки.
  oneShotPick(cp, osMod, fsMod);
}

$('#eyedropBtn').addEventListener('click', function () {
  setStatus('');
  if (!cs.isCEP()) {
    // браузер (отладка): EyeDropper API тут работает
    if (window.EyeDropper) {
      new EyeDropper().open().then(function (res) {
        if (res && res.sRGBHex) { fHex.value = res.sRGBHex.replace('#', '').toUpperCase(); fromHex(); }
      }).catch(function () {});
    } else {
      setStatus('Пипетка недоступна в этой среде');
    }
    return;
  }
  screenPick();   // в AE: Windows — оверлей-прицел (разовый запуск), macOS — нативная лупа NSColorSampler
});

/* ---------- результат -> панель + закрытие ---------- */
function finish(payload) {
  if (sent) return;
  sent = true;
  if (cs.isCEP()) {
    cs.evalScript('$.global.MP_pickResult="' + payload + '";', function () {});
    cs.dispatchEvent('mp.picker.result', payload);
    // закрытие окна откладываем: снос CEP-окна на миг морозит главный поток AE, и если закрыть
    // сразу, применение цвета в панели ждёт этой заморозки. Дадим панели применить цвет первой.
    setTimeout(function () { try { cs.closeExtension(); } catch (e) {} }, 60);
  }
}
function ok() {
  var rgb = hsbToRgb(st.h, st.s, st.b);
  finish(rgbToHex(rgb[0], rgb[1], rgb[2]));
}
function cancel() { finish('cancel'); }
$('#pickOk').addEventListener('click', ok);
$('#pickCancel').addEventListener('click', cancel);

/* закрытие окна крестиком тоже отменяет ожидание в панели (иначе она опрашивает впустую) */
window.addEventListener('beforeunload', function () {
  if (!sent && cs.isCEP()) {
    try { cs.evalScript('$.global.MP_pickResult="cancel";', function () {}); } catch (e) {}
  }
  edKill();   // гасим тёплый хост пипетки — иначе при повторном открытии будет второй хост на тех же файлах
});

/* ---------- старт ----------
   Стартовый цвет приходит двумя путями: $.global.MP_pickStart (читаем при загрузке)
   и событие mp.picker.open (на случай, когда окно уже было открыто и переиспользуется). */
function bringToFront() { try { window.focus(); } catch (e) {} }

function setStart(hex) {
  sent = false;
  bringToFront();
  hex = (hex || '').replace('#', '');
  var rgb = hexToRgb(hex) || [127, 100, 70];
  var hsb = rgbToHsb(rgb[0], rgb[1], rgb[2]);
  st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
  render();
}
cs.addEventListener('mp.picker.open', function (ev) {
  if (ev && ev.data !== undefined && ev.data !== '') setStart(String(ev.data));
  // хост пипетки заранее НЕ прогреваем — поднимается лениво только по клику пипеткой (см. screenPick)
});
if (cs.isCEP()) {
  cs.evalScript('String($.global.MP_pickStart)', function (v) {
    if (v && v !== 'undefined' && v !== 'browser' && v !== 'null') setStart(v);
    else render();
  });
} else {
  render(); // браузер
}

/* подстраховка к авто-«второму клику» из панели — тянем окно на передний план */
bringToFront();
setTimeout(bringToFront, 60);
setTimeout(bringToFront, 220);
