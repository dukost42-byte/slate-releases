/* Минимальная обёртка над CEP. В After Effects использует __adobe_cep__,
   в обычном браузере evalScript возвращает "browser" (для отладки UI). */
function CSInterface() {}

CSInterface.prototype.evalScript = function (script, callback) {
  callback = callback || function () {};
  if (window.__adobe_cep__) {
    window.__adobe_cep__.evalScript(script, callback);
  } else {
    // Режим отладки в браузере — хоста нет
    setTimeout(function () { callback("browser"); }, 0);
  }
};

CSInterface.prototype.isCEP = function () {
  return !!window.__adobe_cep__;
};

/* ---- доп. CEP API: окно-расширение и обмен событиями между расширениями ---- */

CSInterface.prototype.getHostEnvironment = function () {
  if (window.__adobe_cep__) {
    try { return JSON.parse(window.__adobe_cep__.getHostEnvironment()); } catch (e) {}
  }
  return {};
};

CSInterface.prototype.getAppId = function () {
  var h = this.getHostEnvironment();
  return (h && h.appName) ? h.appName : "AEFT";
};

/* открыть другое расширение этого же бандла (наш modeless-пикер) */
CSInterface.prototype.requestOpenExtension = function (id, params) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.requestOpenExtension(id, params || "");
  }
};

/* закрыть текущее расширение (вызывается из окна пикера) */
CSInterface.prototype.closeExtension = function () {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.closeExtension();
  }
};

/* подписка на CEP-событие (для связи панель <-> окно пикера) */
CSInterface.prototype.addEventListener = function (type, listener) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.addEventListener(type, listener, null);
  }
};

/* отправка CEP-события другому расширению этого же приложения */
CSInterface.prototype.dispatchEvent = function (type, data) {
  if (!window.__adobe_cep__) return;
  var event = {
    type: type,
    scope: "APPLICATION",
    appId: this.getAppId(),
    extensionId: "",
    data: (data === undefined || data === null) ? "" : String(data)
  };
  try { window.__adobe_cep__.dispatchEvent(event); } catch (e) {}
};
