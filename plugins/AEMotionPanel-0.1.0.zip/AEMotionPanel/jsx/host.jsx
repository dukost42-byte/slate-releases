/* ===== Motion Panel — host.jsx (ExtendScript для After Effects) ===== */

/* путь к расширению. MP_EXT_PATH ставится из main.js (CEP getSystemPath) — самый надёжный
   способ; $.fileName как запасной (часто пуст в CEP). Нужно, чтобы найти .ffx в бандле. */
var MP_HOST_FILE = "";
try { MP_HOST_FILE = $.fileName; } catch (eHF) {}
var MP_EXT_PATH = "";
function MP_setExtPath(p) { MP_EXT_PATH = p ? String(p) : ""; return "ok"; }

/* File для файла из корня бандла. Перебираем кандидатов: путь из main.js (как есть и
   декодированный), и путь от $.fileName — какой-нибудь да существует. */
function MP_pseudoFile(name) {
    var cands = [];
    if (MP_EXT_PATH) {
        cands.push(MP_EXT_PATH + "/" + name);
        try { cands.push(decodeURIComponent(MP_EXT_PATH) + "/" + name); } catch (e1) {}
    }
    if (MP_HOST_FILE) {
        try { cands.push(File(MP_HOST_FILE).parent.parent.fsName + "/" + name); } catch (e2) {}
    }
    for (var i = 0; i < cands.length; i++) {
        try { var f = new File(cands[i]); if (f.exists) return f; } catch (e3) {}
    }
    return null;
}
/* для диагностики: какой путь нашёлся (или последний проверенный) */
function MP_pseudoPath(name) {
    var f = MP_pseudoFile(name);
    if (f) return f.fsName;
    if (MP_EXT_PATH) return MP_EXT_PATH + "/" + name + " (нет)";
    return "ext-path пуст";
}
/* ===== Normalize Track — НАШЕ нативное переосмысление (по мотивам Normalize Track, idea D.Hashimoto).
   jsxbin скомпилирован, точную математику оттуда не достать — это реконструкция техники:
   управляющий null совмещаем с опорной плоскостью, парентим выделенные слои + камеру БЕЗ ПРЫЖКА
   (мировые позиции сохраняются), затем сдвигаем весь риг к центру композиции с нулевой ориентацией.
   Камера и контент двигаются жёстко вместе → картинка/привязка сохраняются, но трекинг оказывается
   в удобном экранном пространстве у центра компа. ⚠️ Проверять на реальном трекинге, масштаб — на доводку. */
function MP_ntComp() {
    var it = app.project.activeItem;
    if (!(it instanceof CompItem)) return null;
    return it;
}
function MP_ntCamera(comp) {
    for (var i = 1; i <= comp.numLayers; i++) { if (comp.layer(i) instanceof CameraLayer) return comp.layer(i); }
    return null;
}
function MP_ntIsBase(nm) {
    nm = String(nm).toLowerCase();
    return nm.indexOf("ground") !== -1 || nm.indexOf("floor") !== -1 || nm.indexOf("wall") !== -1;
}
var MP_NT_CTRL = "Normalize Track";
function MP_ntControl(comp) {
    for (var i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i);
        try { if (L.nullLayer && String(L.name).indexOf(MP_NT_CTRL) !== -1) return L; } catch (e) {}
    }
    return null;
}
function MP_ntCopyTransform(src, dst) {
    var mns = ["ADBE Position", "ADBE Orientation", "ADBE Rotate X", "ADBE Rotate Y", "ADBE Rotate Z"];
    var sg = src.property("ADBE Transform Group"), dg = dst.property("ADBE Transform Group");
    for (var i = 0; i < mns.length; i++) {
        try { dg.property(mns[i]).setValue(sg.property(mns[i]).value); } catch (e) {}
    }
}
function MP_ntZero(nl, comp) {
    var g = nl.property("ADBE Transform Group");
    try { g.property("ADBE Position").setValue([comp.width / 2, comp.height / 2, 0]); } catch (e0) {}
    try { g.property("ADBE Orientation").setValue([0, 0, 0]); } catch (e1) {}
    try { g.property("ADBE Rotate X").setValue(0); } catch (e2) {}
    try { g.property("ADBE Rotate Y").setValue(0); } catch (e3) {}
    try { g.property("ADBE Rotate Z").setValue(0); } catch (e4) {}
}
function MP_ntNormalize() {
    var comp = MP_ntComp();
    if (!comp) return "err:Нужна активная композиция.";
    var sel = comp.selectedLayers;
    if (!sel || sel.length === 0) return "err:Выдели опорную плоскость (Ground / Floor / Wall).";
    var base = null;
    for (var i = 0; i < sel.length; i++) { if (MP_ntIsBase(sel[i].name)) { base = sel[i]; break; } }
    if (!base) return "err:Среди выделенных нет плоскости Ground / Floor / Wall.";
    var cam = MP_ntCamera(comp);
    if (!cam) return "err:В композиции нет 3D-камеры (нужен 3D Camera Tracker).";
    app.beginUndoGroup("Normalize Track — нормализация");
    try {
        if (!base.threeDLayer) base.threeDLayer = true;
        var nl = comp.layers.addNull();
        nl.threeDLayer = true;
        nl.name = MP_NT_CTRL;
        MP_ntCopyTransform(base, nl);                 // null совмещаем с опорной плоскостью
        // парентим выделенные + камеру к null (без прыжка — мировые позиции сохраняются)
        var kids = [];
        for (var k = 0; k < sel.length; k++) kids.push(sel[k]);
        var hasCam = false;
        for (var c = 0; c < kids.length; c++) { if (kids[c].index === cam.index) hasCam = true; }
        if (!hasCam) kids.push(cam);
        for (var p = 0; p < kids.length; p++) {
            if (kids[p].index === nl.index) continue;
            try { kids[p].parent = nl; } catch (eP) {}   // присваивание parent = без прыжка
        }
        MP_ntZero(nl, comp);                          // сдвигаем риг к центру компа
        nl.moveToEnd();
        nl.shy = true;
        nl.locked = true;
        return "ok:" + kids.length;
    } catch (e) {
        return "err:" + e.toString();
    } finally {
        app.endUndoGroup();
    }
}
function MP_ntAdd() {
    var comp = MP_ntComp();
    if (!comp) return "err:Нужна активная композиция.";
    var nl = MP_ntControl(comp);
    if (!nl) return "err:Управляющий null «Normalize Track» не найден — сначала нормализуй.";
    var sel = comp.selectedLayers;
    if (!sel || sel.length === 0) return "err:Выдели слои для добавления в трек.";
    app.beginUndoGroup("Normalize Track — добавить слои");
    try {
        var n = 0;
        for (var i = 0; i < sel.length; i++) {
            if (sel[i].index === nl.index) continue;
            try { sel[i].parent = nl; n++; } catch (e) {}   // без прыжка
        }
        return "ok:" + n;
    } catch (e2) {
        return "err:" + e2.toString();
    } finally {
        app.endUndoGroup();
    }
}
function MP_ntRemove() {
    var comp = MP_ntComp();
    if (!comp) return "err:Нужна активная композиция.";
    var nl = MP_ntControl(comp);
    if (!nl) return "err:Управляющий null «Normalize Track» не найден — нечего убирать.";
    app.beginUndoGroup("Normalize Track — убрать");
    try {
        try { if (nl.locked) nl.locked = false; } catch (eL) {}
        var nlIdx = nl.index;
        var kids = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            try { if (L.parent && L.parent.index === nlIdx) kids.push(L); } catch (e) {}
        }
        for (var k = 0; k < kids.length; k++) { try { kids[k].parent = null; } catch (e2) {} }   // отцепляем без прыжка
        nl.remove();
        return "ok:" + kids.length;
    } catch (e3) {
        return "err:" + e3.toString();
    } finally {
        app.endUndoGroup();
    }
}
function MP_ntHelp() {
    alert("Normalize Track — наша версия\n\n" +
        "Приводит 3D-трекинг в удобное экранное пространство: новые 3D-элементы появляются у центра композиции в нормальном масштабе, а привязка к футажу сохраняется.\n\n" +
        "Как пользоваться:\n" +
        "1) Сделай 3D Camera Tracker, задай плоскость земли и создай Solid/Null. Переименуй его в Ground, Floor или Wall.\n" +
        "2) Выдели эту плоскость (и при желании другие слои трека) → Normalize. Камера подцепится сама, внизу появится залоченный управляющий null.\n" +
        "3) Добавить ещё слои в трек — выдели их и жми «+».\n" +
        "4) Убрать эффект — жми «−» (управляющий null удалится).\n\n" +
        "Идея: Daniel Hashimoto. Оригинал: Lloyd Alvarez.");
    return "ok";
}

/* ---------- helpers ---------- */
function MP_getComp() {
    var c = app.project.activeItem;
    if (c && c instanceof CompItem) return c;
    return null;
}

function MP_clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/* ---------- 1) Anchor Point grid ----------
   ax, ay в диапазоне 0..1 (0 — лево/верх, 0.5 — центр, 1 — право/низ).
   Двигаем anchor point, компенсируя position, чтобы слой визуально не сдвинулся. */
function MP_setAnchor(ax, ay) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var layers = comp.selectedLayers;
    if (!layers.length) return "err:Выбери слой";

    app.beginUndoGroup("Move Anchor Point");
    try {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            var t = comp.time;
            var r = L.sourceRectAtTime(t, false);

            var newA = [r.left + r.width * ax, r.top + r.height * ay];
            var apProp = L.property("ADBE Transform Group").property("ADBE Anchor Point");
            var posProp = L.property("ADBE Transform Group").property("ADBE Position");
            var sclProp = L.property("ADBE Transform Group").property("ADBE Scale");

            var oldA = apProp.value;
            var scl = sclProp.value;
            var dx = (newA[0] - oldA[0]) * scl[0] / 100;
            var dy = (newA[1] - oldA[1]) * scl[1] / 100;

            // поворот учитываем
            var rot = (L.threeDLayer ? L.property("ADBE Transform Group").property("ADBE Rotate Z").value
                                     : L.property("ADBE Transform Group").property("ADBE Rotate Z").value) * Math.PI / 180;
            var rdx = dx * Math.cos(rot) - dy * Math.sin(rot);
            var rdy = dx * Math.sin(rot) + dy * Math.cos(rot);

            if (L.threeDLayer && oldA.length === 3) newA.push(oldA[2]);

            if (apProp.numKeys > 0) apProp.setValueAtTime(t, newA); else apProp.setValue(newA);

            var pos = posProp.value;
            var newPos = (pos.length === 3) ? [pos[0] + rdx, pos[1] + rdy, pos[2]] : [pos[0] + rdx, pos[1] + rdy];
            if (posProp.numKeys > 0) posProp.setValueAtTime(t, newPos); else posProp.setValue(newPos);
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok";
}

/* ---------- 2) Цвет берётся отдельным окном-пикером, НЕ системным диалогом ----------
   $.colorPicker открывал модальное окно ОС и подвешивал AE — убрано.
   Оставлено как заглушка: панель выбирает цвет через picker.html. */
function MP_pickColor(startHex) {
    return "browser";
}


/* ---------- Add Null ----------
   Принцип (как в Coco/Limber): null встаёт точно в позицию слоя (его anchor в комп-
   координатах), слой парентится к нему, после парентинга позиция слоя
   автоматически становится локальной (например 50,50 если null 100x100).
   Никакого визуального смещения — двигается только система координат. */

/* позиция слоя в координатах композиции (точка его anchor point) */
function MP_layerWorldPos(L, comp) {
    var tr = L.property("ADBE Transform Group");
    var pos = tr.property("ADBE Position").value;
    if (!L.parent) return [pos[0], pos[1]];
    // есть родитель — переводим локальную позицию в мировую через матрицу родителя
    var P = L.parent.property("ADBE Transform Group");
    var pp = P.property("ADBE Position").value;
    var pa = P.property("ADBE Anchor Point").value;
    var ps = P.property("ADBE Scale").value;
    var pr = P.property("ADBE Rotate Z").value * Math.PI / 180;
    var lx = (pos[0] - pa[0]) * ps[0] / 100;
    var ly = (pos[1] - pa[1]) * ps[1] / 100;
    return [pp[0] + lx * Math.cos(pr) - ly * Math.sin(pr),
            pp[1] + lx * Math.sin(pr) + ly * Math.cos(pr)];
}

/* создаёт null с anchor в его геометрическом центре, position — в заданной точке */
function MP_makeNullAt(comp, worldPt) {
    var n = comp.layers.addNull();
    var tr = n.property("ADBE Transform Group");
    var r = n.sourceRectAtTime(0, false);
    var w = (r.width  > 0) ? r.width  : 100;
    var h = (r.height > 0) ? r.height : 100;
    tr.property("ADBE Anchor Point").setValue([r.left + w / 2, r.top + h / 2]);
    tr.property("ADBE Position").setValue([worldPt[0], worldPt[1]]);
    return n;
}

/* парентинг БЕЗ скачка вида.
   По доке AE: присваивание child.parent = X — это парентинг, при котором AE САМ
   пересчитывает трансформ ребёнка (позицию/поворот), чтобы он визуально НЕ сдвинулся
   (position становится локальной — напр. 50,50 для нуля 100x100). Это и нужно (как Coco).
   setParentWithJump, наоборот, оставляет значения как есть, и ребёнок прыгает —
   поэтому он только аварийный фолбэк, если прямое присваивание вдруг бросит ошибку. */
function MP_parentKeep(child, parentLayer) {
    try {
        child.parent = parentLayer;
    } catch (e) {
        try { child.setParentWithJump(parentLayer); } catch (e2) {}
    }
}

function MP_addNull(mode) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var sel = comp.selectedLayers.slice ? comp.selectedLayers.slice() : comp.selectedLayers;

    app.beginUndoGroup("Add Null");
    try {
        if (mode === "alt") {
            var n0 = MP_makeNullAt(comp, [comp.width / 2, comp.height / 2]);
            n0.name = "Null";
        } else if (sel.length === 0) {
            var n1 = MP_makeNullAt(comp, [comp.width / 2, comp.height / 2]);
            n1.name = "Null";
        } else {
            var allNulls = true;
            for (var a = 0; a < sel.length; a++) if (!sel[a].nullLayer) { allNulls = false; break; }

            if (mode === "shift") {
                // отдельный null каждому слою — точно в его позицию (anchor), парентим
                for (var i = 0; i < sel.length; i++) {
                    var L = sel[i];
                    var wp = MP_layerWorldPos(L, comp);
                    var idxBefore = L.index;
                    var n2 = MP_makeNullAt(comp, wp);
                    n2.name = L.name;
                    if (L.threeDLayer) n2.threeDLayer = true;   // 3д-слой → 3д-нулл
                    n2.inPoint = Math.max(0, L.inPoint);
                    n2.outPoint = Math.min(comp.duration, L.outPoint);
                    n2.moveBefore(comp.layer(idxBefore + 1)); // над своим слоем
                    MP_parentKeep(L, n2);
                }
            } else {
                // один общий null: в позиции верхнего выделенного слоя
                var top = sel[0];
                var inM = sel[0].inPoint, outM = sel[0].outPoint;
                var any3d = false;
                for (var j = 0; j < sel.length; j++) {
                    if (sel[j].inPoint < inM) inM = sel[j].inPoint;
                    if (sel[j].outPoint > outM) outM = sel[j].outPoint;
                    if (sel[j].index < top.index) top = sel[j];
                    if (sel[j].threeDLayer) any3d = true;
                }
                var topWp = MP_layerWorldPos(top, comp);
                var topIdxBefore = top.index;
                var n4 = MP_makeNullAt(comp, topWp);
                n4.name = allNulls ? "Primary" : top.name;
                if (allNulls) n4.label = 2;
                if (any3d) n4.threeDLayer = true;   // среди выделенных есть 3д → нулл тоже 3д
                n4.inPoint = Math.max(0, inM);
                n4.outPoint = Math.min(comp.duration, outM);
                n4.moveBefore(comp.layer(topIdxBefore + 1)); // над верхним выделенным
                for (var k = 0; k < sel.length; k++) MP_parentKeep(sel[k], n4);
            }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok";
}

/* ---------- Текст: Split и конвертация в шейпы ---------- */
function MP_isTextLayer(L) {
    try { return L.property("ADBE Text Properties") !== null && L instanceof TextLayer; }
    catch (e) { return false; }
}
function MP_setText(L, str) {
    var doc = L.property("ADBE Text Properties").property("ADBE Text Document");
    var v = doc.value;
    v.text = str;
    doc.setValue(v);
}

/* центрирует anchor слоя по его баундам без визуального сдвига (rot учитывается) */
function MP_centerAnchor(L, comp) {
    var t = comp.time;
    var r = L.sourceRectAtTime(t, false);
    var newA = [r.left + r.width / 2, r.top + r.height / 2];
    var tr = L.property("ADBE Transform Group");
    var oldA = tr.property("ADBE Anchor Point").value;
    var scl = tr.property("ADBE Scale").value;
    var dx = (newA[0] - oldA[0]) * scl[0] / 100;
    var dy = (newA[1] - oldA[1]) * scl[1] / 100;
    var rot = tr.property("ADBE Rotate Z").value * Math.PI / 180;
    var rdx = dx * Math.cos(rot) - dy * Math.sin(rot);
    var rdy = dx * Math.sin(rot) + dy * Math.cos(rot);
    if (oldA.length === 3) newA.push(oldA[2]);
    tr.property("ADBE Anchor Point").setValue(newA);
    var pos = tr.property("ADBE Position").value;
    var np = (pos.length === 3) ? [pos[0] + rdx, pos[1] + rdy, pos[2]] : [pos[0] + rdx, pos[1] + rdy];
    tr.property("ADBE Position").setValue(np);
}

/* mode: "chars" | "words" | "lines" */
function MP_splitText(mode) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var sel = comp.selectedLayers.slice ? comp.selectedLayers.slice() : comp.selectedLayers;
    var texts = [];
    for (var i = 0; i < sel.length; i++) if (MP_isTextLayer(sel[i])) texts.push(sel[i]);
    if (!texts.length) return "err:Выбери текстовый слой";

    var made = 0;
    app.beginUndoGroup("Split Text");
    try {
        for (var t = 0; t < texts.length; t++) {
            var TL = texts[t];
            var doc = TL.property("ADBE Text Properties").property("ADBE Text Document").value;
            var full = doc.text;
            if (!full) continue;

            var lineHeight = doc.autoLeading ? doc.fontSize * 1.2 : doc.leading;
            var lines = full.split(/\r\n|\r|\n/);

            // единицы: {str, line, startInLine}
            var units = [];
            if (mode === "lines") {
                for (var li = 0; li < lines.length; li++) {
                    if (lines[li].length) units.push({ str: lines[li], line: li, startInLine: 0 });
                }
            } else if (mode === "words") {
                for (var lw = 0; lw < lines.length; lw++) {
                    var re = /\S+/g, m;
                    while ((m = re.exec(lines[lw])) !== null) {
                        units.push({ str: m[0], line: lw, startInLine: m.index });
                    }
                }
            } else { // chars
                for (var lc = 0; lc < lines.length; lc++) {
                    for (var ci = 0; ci < lines[lc].length; ci++) {
                        var ch = lines[lc].charAt(ci);
                        if (ch !== " " && ch !== "\t") {
                            units.push({ str: ch, line: lc, startInLine: ci });
                        }
                    }
                }
            }
            if (!units.length) continue;

            // измеритель тем же стилем и выравниванием
            var meas = TL.duplicate();
            meas.enabled = false;
            function rectOf(str) {
                MP_setText(meas, str);
                return meas.sourceRectAtTime(comp.time, false);
            }
            function widthOf(str) {
                if (!str) return 0;
                return rectOf(str).width;
            }
            // ширина строки с учётом ведущих и хвостовых пробелов:
            // обрамляем точками и вычитаем ширину ".."
            var wDots = widthOf("..");
            function advanceOf(str) {
                if (!str) return 0;
                return widthOf("." + str + ".") - wDots;
            }
            // левый край каждой строки в координатах слоя (живёт своё выравнивание)
            var lineLeft = [];
            for (var ll = 0; ll < lines.length; ll++) {
                lineLeft[ll] = lines[ll].length ? rectOf(lines[ll]).left : 0;
            }

            var basePos = TL.property("ADBE Transform Group").property("ADBE Position").value;
            var scl = TL.property("ADBE Transform Group").property("ADBE Scale").value;

            for (var u = 0; u < units.length; u++) {
                var un = units[u];
                var prefix = lines[un.line].substring(0, un.startInLine);
                // где юнит стоял в оригинале (координаты слоя)
                var xTarget = lineLeft[un.line] + advanceOf(prefix);
                // где его глифы окажутся в собственном слое-дубликате (то же выравнивание)
                var xOwn = rectOf(un.str).left;

                var dup = TL.duplicate();
                MP_setText(dup, un.str);
                dup.name = un.str;

                var dx = xTarget - xOwn;
                var dy = un.line * lineHeight;
                var np = [basePos[0] + dx * scl[0] / 100, basePos[1] + dy * scl[1] / 100];
                if (basePos.length === 3) np.push(basePos[2]);
                dup.property("ADBE Transform Group").property("ADBE Position").setValue(np);
                MP_centerAnchor(dup, comp); // якорь в центр текста
                made++;
            }
            meas.remove();
            TL.enabled = false;
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return made ? "ok:" + made : "err:Нечего разделять";
}

function MP_textToShapes() {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    var has = false;
    for (var i = 0; i < sel.length; i++) if (MP_isTextLayer(sel[i])) { has = true; break; }
    if (!has) return "err:Выбери текстовый слой";
    app.beginUndoGroup("Text to Shapes");
    try {
        var cmd = 0;
        try { cmd = app.findMenuCommandId("Create Shapes from Text"); } catch (e) {}
        if (!cmd || cmd <= 0) cmd = 3781; // стабильный ID команды
        app.executeCommand(cmd);
    } catch (e2) {
        app.endUndoGroup();
        return "err:" + e2.toString();
    }
    app.endUndoGroup();
    return "ok";
}

/* ---------- Unprecomp ----------
   Переносит все слои выбранных прекомпозов в текущую композицию.
   Трансформ прекомпоза сохраняется через служебный Null-родитель. */
function MP_unprecomp() {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var sel = comp.selectedLayers.slice ? comp.selectedLayers.slice() : comp.selectedLayers;
    var targets = [];
    for (var i = 0; i < sel.length; i++) {
        if (sel[i].source && sel[i].source instanceof CompItem) targets.push(sel[i]);
    }
    if (!targets.length) return "err:Выбери слой-прекомпоз";

    app.beginUndoGroup("Unprecomp");
    try {
        for (var t = 0; t < targets.length; t++) {
            var L = targets[t];
            var inner = L.source;
            var tr = L.property("ADBE Transform Group");
            var Lp = tr.property("ADBE Position").value;
            var La = tr.property("ADBE Anchor Point").value;
            var Ls = tr.property("ADBE Scale").value;
            var Lr = tr.property("ADBE Rotate Z").value;
            var sx = Ls[0] / 100, sy = Ls[1] / 100;
            var ang = Lr * Math.PI / 180;
            var cosA = Math.cos(ang), sinA = Math.sin(ang);
            var ident = Math.abs(Lr) < 1e-4 && Math.abs(sx - 1) < 1e-4 && Math.abs(sy - 1) < 1e-4 &&
                        Math.abs(Lp[0] - La[0]) < 1e-3 && Math.abs(Lp[1] - La[1]) < 1e-3;

            function mapPoint(p) {
                var dx = (p[0] - La[0]) * sx, dy = (p[1] - La[1]) * sy;
                var x = Lp[0] + dx * cosA - dy * sinA;
                var y = Lp[1] + dx * sinA + dy * cosA;
                return (p.length === 3) ? [x, y, p[2]] : [x, y];
            }
            function bakeLayer(c) {
                if (ident) return;
                var ctr = c.property("ADBE Transform Group");
                try {
                    var pp = ctr.property("ADBE Position");
                    if (pp.numKeys > 0) {
                        for (var k = 1; k <= pp.numKeys; k++) pp.setValueAtKey(k, mapPoint(pp.keyValue(k)));
                    } else {
                        pp.setValue(mapPoint(pp.value));
                    }
                } catch (e1) {}
                try {
                    var sp = ctr.property("ADBE Scale");
                    if (sp.numKeys > 0) {
                        for (var k2 = 1; k2 <= sp.numKeys; k2++) {
                            var sv = sp.keyValue(k2);
                            var ns = [sv[0] * sx, sv[1] * sy];
                            if (sv.length === 3) ns.push(sv[2]);
                            sp.setValueAtKey(k2, ns);
                        }
                    } else {
                        var sv0 = sp.value;
                        var ns0 = [sv0[0] * sx, sv0[1] * sy];
                        if (sv0.length === 3) ns0.push(sv0[2]);
                        sp.setValue(ns0);
                    }
                } catch (e2) {}
                try {
                    if (Math.abs(Lr) > 1e-4) {
                        var rp = c.property("ADBE Transform Group").property("ADBE Rotate Z");
                        if (rp.numKeys > 0) {
                            for (var k3 = 1; k3 <= rp.numKeys; k3++) rp.setValueAtKey(k3, rp.keyValue(k3) + Lr);
                        } else {
                            rp.setValue(rp.value + Lr);
                        }
                    }
                } catch (e3) {}
            }

            // снизу вверх: каждая копия ложится поверх предыдущей — порядок сохраняется
            for (var li = inner.numLayers; li >= 1; li--) {
                inner.layer(li).copyToComp(comp);
                var c = comp.layer(1);
                c.startTime = c.startTime + L.startTime;
                if (!c.parent) bakeLayer(c);
            }
            L.remove();
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + targets.length;
}

/* ---------- Import палитры ----------
   Создаёт Null Object на таймлайне; цвета палитры — эффекты Color Control
   в том же порядке, что и в панели. hexList: "AABBCC,DDEEFF,..." */
function MP_importPalette(name, hexList) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var hexes = hexList.split(",");
    if (!hexes.length || hexes[0] === "") return "err:В палитре нет цветов";

    app.beginUndoGroup("Import Palette");
    try {
        var nullLayer = comp.layers.addNull(comp.duration);
        nullLayer.name = name;
        nullLayer.label = 14; // приметный цвет лейбла
        var fxGroup = nullLayer.property("ADBE Effect Parade");
        for (var i = 0; i < hexes.length; i++) {
            var hex = hexes[i];
            var r = parseInt(hex.substr(0, 2), 16) / 255;
            var g = parseInt(hex.substr(2, 2), 16) / 255;
            var b = parseInt(hex.substr(4, 2), 16) / 255;
            var fx = fxGroup.addProperty("ADBE Color Control");
            fx.name = (i + 1) + " — #" + hex;
            fx.property("ADBE Color Control-0001").setValue([r, g, b]);
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok";
}

/* ---------- Применение цвета палитры к выделенным слоям ----------
   Текст — цвет текста; шейп — все Fill внутри; солид — цвет солида;
   остальное (прекомпоз, футаж и т.п.) — эффект Fill с этим цветом. */
function MP_setShapeFills(group, rgb) {
    var n = 0;
    for (var i = 1; i <= group.numProperties; i++) {
        var p = group.property(i);
        if (!p) continue;
        if (p.matchName === "ADBE Vector Graphic - Fill") {
            try {
                p.property("ADBE Vector Fill Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
                n++;
            } catch (e) {}
        } else if (p.numProperties && p.numProperties > 0) {
            try { n += MP_setShapeFills(p, rgb); } catch (e2) {}
        }
    }
    return n;
}

/* рекурсивно красит все Stroke (обводки) в шейп-группе */
function MP_setShapeStrokes(group, rgb) {
    var n = 0;
    for (var i = 1; i <= group.numProperties; i++) {
        var p = group.property(i);
        if (!p) continue;
        if (p.matchName === "ADBE Vector Graphic - Stroke") {
            try {
                p.property("ADBE Vector Stroke Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
                n++;
            } catch (e) {}
        } else if (p.numProperties && p.numProperties > 0) {
            try { n += MP_setShapeStrokes(p, rgb); } catch (e2) {}
        }
    }
    return n;
}

/* target: "fill" (по умолчанию) | "stroke" */
function MP_applyColor(hex, target) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var sel = comp.selectedLayers.slice ? comp.selectedLayers.slice() : comp.selectedLayers;
    if (!sel.length) return "nosel";

    var stroke = (target === "stroke");
    var r = parseInt(hex.substr(0, 2), 16) / 255;
    var g = parseInt(hex.substr(2, 2), 16) / 255;
    var b = parseInt(hex.substr(4, 2), 16) / 255;
    var rgb = [r, g, b];
    var count = 0;

    app.beginUndoGroup(stroke ? "Apply Palette Stroke Color" : "Apply Palette Color");
    try {
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i];
            var applied = false;

            // текст
            try {
                if (L instanceof TextLayer) {
                    var doc = L.property("ADBE Text Properties").property("ADBE Text Document");
                    var v = doc.value;
                    if (stroke) {
                        v.applyStroke = true;
                        v.strokeColor = rgb;
                        if (!v.strokeWidth || v.strokeWidth <= 0) v.strokeWidth = 2;
                    } else {
                        v.applyFill = true;
                        v.fillColor = rgb;
                    }
                    doc.setValue(v);
                    applied = true;
                }
            } catch (e1) {}

            // шейп: красим все заливки/обводки внутри
            if (!applied) {
                try {
                    if (L instanceof ShapeLayer) {
                        var root = L.property("ADBE Root Vectors Group");
                        var changed = stroke ? MP_setShapeStrokes(root, rgb) : MP_setShapeFills(root, rgb);
                        if (root && changed > 0) applied = true;
                    }
                } catch (e2) {}
            }

            // солид (у солида нет обводки — только в режиме заливки)
            if (!applied && !stroke) {
                try {
                    if (L.source && L.source.mainSource && (L.source.mainSource instanceof SolidSource) && !L.nullLayer) {
                        L.source.mainSource.color = rgb;
                        applied = true;
                    }
                } catch (e3) {}
            }

            // всё остальное — эффект Fill (только в режиме заливки)
            if (!applied && !stroke) {
                try {
                    var fxg = L.property("ADBE Effect Parade");
                    var fill = null;
                    for (var f = 1; f <= fxg.numProperties; f++) {
                        if (fxg.property(f).matchName === "ADBE Fill") { fill = fxg.property(f); break; }
                    }
                    if (!fill) fill = fxg.addProperty("ADBE Fill");
                    try { fill.property("ADBE Fill-0002").setValue(rgb); }
                    catch (e4) { fill.property("Color").setValue(rgb); }
                    applied = true;
                } catch (e5) {}
            }

            if (applied) count++;
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    if (count) return "ok:" + count;
    return stroke ? "nostroke" : "err:Не получилось применить цвет";
}

/* ---------- 3) Применение cubic-bezier к выделенным ключам ----------
   x1,y1,x2,y2 — как в cubic-bezier(). Применяем к каждой паре соседних
   выделенных ключей выбранных свойств (аналог Flow). */
function MP_applyCubic(x1, y1, x2, y2) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var props = comp.selectedProperties;
    if (!props.length) return "err:Выбери ключи на свойстве";

    x1 = MP_clamp(x1, 0.001, 1); x2 = MP_clamp(x2, 0, 0.999);
    var applied = 0;

    app.beginUndoGroup("Apply Cubic Ease");
    try {
        for (var p = 0; p < props.length; p++) {
            var prop = props[p];
            if (!(prop instanceof Property) || prop.numKeys < 2) continue;
            var keys = prop.selectedKeys;
            if (keys.length < 2) continue;
            keys.sort(function (a, b) { return a - b; });

            for (var k = 0; k < keys.length - 1; k++) {
                var k1 = keys[k], k2 = keys[k + 1];
                if (k2 !== k1 + 1) continue; // только соседние

                var t1 = prop.keyTime(k1), t2 = prop.keyTime(k2);
                var v1 = prop.keyValue(k1), v2 = prop.keyValue(k2);
                var dur = t2 - t1;
                if (dur <= 0) continue;

                var dims = (v1 instanceof Array) ? v1.length : 1;
                var avg = [], dist;
                if (dims === 1) {
                    avg = [(v2 - v1) / dur];
                } else {
                    for (var d = 0; d < dims; d++) avg.push((v2[d] - v1[d]) / dur);
                }

                var outInf = MP_clamp(x1 * 100, 0.1, 100);
                var inInf  = MP_clamp((1 - x2) * 100, 0.1, 100);

                var outEase = [], inEase = [];
                for (var d2 = 0; d2 < dims; d2++) {
                    var a = avg[d2];
                    outEase.push(new KeyframeEase(a * (y1 / x1), outInf));
                    inEase.push(new KeyframeEase(a * ((1 - y2) / (1 - x2)), inInf));
                }
                // спец-случай spatial position: speed скалярный
                if (prop.propertyValueType === PropertyValueType.TwoD_SPATIAL ||
                    prop.propertyValueType === PropertyValueType.ThreeD_SPATIAL) {
                    var dd = 0;
                    if (dims >= 2) {
                        var dxv = v2[0] - v1[0], dyv = v2[1] - v1[1];
                        var dzv = (dims === 3) ? v2[2] - v1[2] : 0;
                        dd = Math.sqrt(dxv * dxv + dyv * dyv + dzv * dzv) / dur;
                    }
                    outEase = [new KeyframeEase(dd * (y1 / x1), outInf)];
                    inEase  = [new KeyframeEase(dd * ((1 - y2) / (1 - x2)), inInf)];
                }

                prop.setInterpolationTypeAtKey(k1, prop.keyInInterpolationType(k1), KeyframeInterpolationType.BEZIER);
                prop.setInterpolationTypeAtKey(k2, KeyframeInterpolationType.BEZIER, prop.keyOutInterpolationType(k2));
                prop.setTemporalEaseAtKey(k1, prop.keyInTemporalEase(k1), outEase);
                prop.setTemporalEaseAtKey(k2, inEase, prop.keyOutTemporalEase(k2));
                applied++;
            }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return applied > 0 ? "ok:" + applied : "err:Нужно минимум 2 соседних выделенных ключа";
}

/* ---------- Add Limb ----------
   Создаёт упрощённую "конечность": два контроллера-нуля (верх/низ) и между ними
   шейп-линию с управляющими слайдерами (Length / Bend / Bend Direction).
   Аналог Limber/Duik: тянешь за нули — линия гнётся. */
function MP_addLimb() {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";

    // следующий номер конечности (Limb1, Limb2, ...)
    var idx = 1;
    try {
        var maxN = 0, re = /^Limb(\d+)_/;
        for (var li = 1; li <= comp.numLayers; li++) {
            var mm = re.exec(comp.layer(li).name || "");
            if (mm) { var nn = parseInt(mm[1], 10); if (nn > maxN) maxN = nn; }
        }
        idx = maxN + 1;
    } catch (eIdx) {}
    var P = "Limb" + idx + "_";

    app.beginUndoGroup("Add Limb " + idx);
    try {
        var cx = comp.width / 2, cy = comp.height / 2;
        var len = Math.min(comp.height * 0.4, 270);
        var BLACK = [0, 0, 0, 1], RED = [0.9, 0.1, 0.1, 1];
        var NL = String.fromCharCode(10);

        // ---------- хелперы шейпов ----------
        function rootOf(L) { return L.property("ADBE Root Vectors Group"); }
        function addGroup(root, nm) { var g = root.addProperty("ADBE Vector Group"); g.name = nm; return g.property("ADBE Vectors Group"); }
        function addEllipse(vg, w, h) { var e = vg.addProperty("ADBE Vector Shape - Ellipse"); try { e.property("ADBE Vector Ellipse Size").setValue([w, h]); } catch (e1) {} return e; }
        function addRect(vg, w, h, pos) { var r = vg.addProperty("ADBE Vector Shape - Rect"); try { r.property("ADBE Vector Rect Size").setValue([w, h]); } catch (e2) {} try { r.property("ADBE Vector Rect Position").setValue(pos || [0, 0]); } catch (e3) {} return r; }
        function addStroke(vg, col, w) { var s = vg.addProperty("ADBE Vector Graphic - Stroke"); try { s.property("ADBE Vector Stroke Color").setValue(col); } catch (e4) {} try { s.property("ADBE Vector Stroke Width").setValue(w); } catch (e5) {} try { s.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (e6) {} return s; }
        function addFill(vg, col) { var f = vg.addProperty("ADBE Vector Graphic - Fill"); try { f.property("ADBE Vector Fill Color").setValue(col); } catch (e7) {} return f; }

        // ---------- хелперы эффектов-контроллеров ----------
        function fxOf(L) { return L.property("ADBE Effect Parade"); }
        function slider(L, nm, val) { var e = fxOf(L).addProperty("ADBE Slider Control"); e.name = nm; try { e.property(1).setValue(val); } catch (e8) {} return e; }
        function checkbox(L, nm, val) { var e = fxOf(L).addProperty("ADBE Checkbox Control"); e.name = nm; try { e.property(1).setValue(val ? 1 : 0); } catch (e9) {} return e; }
        function angleC(L, nm, val) { var e = fxOf(L).addProperty("ADBE Angle Control"); e.name = nm; try { e.property(1).setValue(val); } catch (e10) {} return e; }
        function colorC(L, nm, col) { var e = fxOf(L).addProperty("ADBE Color Control"); e.name = nm; try { e.property(1).setValue(col); } catch (e11) {} return e; }
        function layerC(L, nm) { var e = fxOf(L).addProperty("ADBE Layer Control"); e.name = nm; return e; }

        function tr(L) { return L.property("ADBE Transform Group"); }
        function centerAnchor(L) { try { var r = L.sourceRectAtTime(0, false); tr(L).property("ADBE Anchor Point").setValue([r.left + r.width / 2, r.top + r.height / 2]); } catch (eA) {} }
        function setPos(L, x, y) { try { tr(L).property("ADBE Position").setValue([x, y]); } catch (eP) {} }
        function mkLabel(L) { try { L.label = 9; } catch (eL) {} }

        // ===================== создаём слои =====================
        // 6) Base — видимая линия из ДВУХ костей-прямоугольников (top->mid, mid->bot).
        //    Параметрические rect+fill рендерятся гарантированно (в отличие от editable-path).
        var base = comp.layers.addShape(); base.name = P + "Base"; mkLabel(base);
        function addBone(L, nm) {
            var g = rootOf(L).addProperty("ADBE Vector Group"); g.name = nm;
            var c = g.property("ADBE Vectors Group");
            var r = c.addProperty("ADBE Vector Shape - Rect");
            try { r.property("ADBE Vector Rect Size").setValue([100, 4]); } catch (eRS) {}
            try { r.property("ADBE Vector Rect Position").setValue([0, 0]); } catch (eRP) {}
            var f = addFill(c, RED);
            return { rect: r, fill: f, xf: g.property("ADBE Vector Transform Group") };
        }
        var boneUp = addBone(base, "Bone Upper");   // top -> mid
        var boneLo = addBone(base, "Bone Lower");   // mid -> bot
        var pathToggle = layerC(base, "Path Toggle");
        var styleToggle = layerC(base, "Style Toggle");
        colorC(base, "Color", RED);
        slider(base, "Width", 4);

        // 4) top control (верхний круг-мишень)
        var top = comp.layers.addShape(); top.name = P + "top_1"; mkLabel(top);
        var topRing = addGroup(rootOf(top), "Ring"); addEllipse(topRing, 44, 44); addStroke(topRing, BLACK, 2);
        var topCr = addGroup(rootOf(top), "Cross"); addRect(topCr, 2, 18, [0, 0]); addRect(topCr, 18, 2, [0, 0]); addFill(topCr, BLACK);
        slider(top, "Ctrl Big Size", 67.5);

        // 5) top_Rotation (родитель — top)
        var topR = comp.layers.addShape(); topR.name = P + "top_Rotation_1"; mkLabel(topR);
        var topRV = addGroup(rootOf(topR), "Tick"); addRect(topRV, 2, 14, [0, 0]); addFill(topRV, BLACK);
        checkbox(topR, "Stretch", 0); checkbox(topR, "Auto Rotation", 1);

        // 3) mid (локоть)
        var mid = comp.layers.addShape(); mid.name = P + "mid_1"; mkLabel(mid);
        var midDot = addGroup(rootOf(mid), "Dot"); addEllipse(midDot, 9, 9); addFill(midDot, BLACK);
        var midRing = addGroup(rootOf(mid), "Ring"); addEllipse(midRing, 16, 16); addStroke(midRing, BLACK, 1.5);
        slider(mid, "Mid Point Offset (%)", 50);
        var midBaseLimb = layerC(mid, "Base Limb");
        checkbox(mid, "Mid Toggle", 0); checkbox(mid, "Mid Rotation", 0);

        // 2) bot_Rotation (родитель — bot)
        var botR = comp.layers.addShape(); botR.name = P + "bot_Rotation_1"; mkLabel(botR);
        var botRV = addGroup(rootOf(botR), "Tick"); addRect(botRV, 2, 14, [0, 0]); addFill(botRV, BLACK);
        checkbox(botR, "Stretch", 0); checkbox(botR, "Auto Rotation", 1);

        // 1) bot control (главный — несёт основные настройки)
        var bot = comp.layers.addShape(); bot.name = P + "bot_1"; mkLabel(bot);
        var botRing = addGroup(rootOf(bot), "Ring"); addEllipse(botRing, 44, 44); addStroke(botRing, BLACK, 2);
        var botCr = addGroup(rootOf(bot), "Cross"); addRect(botCr, 2, 18, [0, 0]); addRect(botCr, 18, 2, [0, 0]); addFill(botCr, BLACK);
        // «MP Limb» (отдельными контроллерами — сгруппированный псевдоэффект скриптом не создать)
        slider(bot, "Limb Length", 270);
        slider(bot, "Mid Point Offset", 50);
        slider(bot, "Mid Point Realism", 95);
        slider(bot, "Bend Direction", 100);
        slider(bot, "Bend Curvature", 67.5);
        checkbox(bot, "Flip", 0);
        angleC(bot, "Flip Range", 80);
        angleC(bot, "Flip Angle", 0);
        layerC(bot, "Ground Layer");
        slider(bot, "Bot Ctrl Size", 67.5);
        colorC(bot, "Ctrl Color", BLACK);
        slider(bot, "Limb Angle", 0);
        slider(bot, "Recurs Scale", 1);

        // ===================== порядок (сверху вниз как на скрине) =====================
        bot.moveToBeginning();
        botR.moveAfter(bot);
        mid.moveAfter(botR);
        top.moveAfter(mid);
        topR.moveAfter(top);
        base.moveAfter(topR);

        // ===================== якоря / позиции =====================
        centerAnchor(top); setPos(top, cx, cy - len / 2);
        centerAnchor(bot); setPos(bot, cx, cy + len / 2);
        centerAnchor(mid);
        centerAnchor(topR); centerAnchor(botR);
        try { tr(base).property("ADBE Anchor Point").setValue([0, 0]); } catch (eBA) {}
        try { tr(base).property("ADBE Position").setValue([0, 0]); } catch (eBP) {}

        // ===================== родители (rotation-слои в центр контроллера) =====================
        try { topR.parent = top; setPos(topR, 0, 0); } catch (ePt) {}
        try { botR.parent = bot; setPos(botR, 0, 0); } catch (ePb) {}

        // ===================== guide layers: контроллеры не рендерятся =====================
        try { top.guideLayer = true; bot.guideLayer = true; mid.guideLayer = true; topR.guideLayer = true; botR.guideLayer = true; } catch (eG) {}

        // ===================== ссылки Layer Control (по итоговым индексам) =====================
        try { midBaseLimb.property(1).setValue(base.index); } catch (eLC1) {}
        try { pathToggle.property(1).setValue(base.index); } catch (eLC2) {}
        try { styleToggle.property(1).setValue(base.index); } catch (eLC3) {}

        // ===================== выражения =====================
        var Lt = '"' + P + 'top_1"', Lb = '"' + P + 'bot_1"', Lm = '"' + P + 'mid_1"';

        // mid: настоящий двухкостный IK по длине костей (закон косинусов).
        // total=Limb Length делится Mid Point Offset на L1/L2; локоть выносится
        // перпендикулярно хорде top->bot на высоту h = sqrt(L1^2 - a^2),
        // где a = проекция локтя на хорду. h=0 при перерастяжении => кость прямая.
        // Realism / Bend Curvature / Bend Direction — масштабы выноса (знак Direction = сторона сгиба).
        tr(mid).property("ADBE Position").expression =
            'var Lb=thisComp.layer(' + Lb + ');' + NL +
            'var T=thisComp.layer(' + Lt + ').transform.position;' + NL +
            'var B=Lb.transform.position;' + NL +
            'var total=Lb.effect("Limb Length")(1);' + NL +
            'var ratio=Math.max(0.02,Math.min(0.98,Lb.effect("Mid Point Offset")(1)/100));' + NL +
            'var L1=total*ratio, L2=total*(1-ratio);' + NL +
            'var dv=sub(B,T); var d=Math.max(length(dv),0.001);' + NL +
            'var u=div(dv,d); var perp=[-u[1],u[0]];' + NL +
            'var a=(d*d+L1*L1-L2*L2)/(2*d);' + NL +
            'var h=Math.sqrt(Math.max(L1*L1-a*a,0));' + NL +
            'var realism=Lb.effect("Mid Point Realism")(1)/100;' + NL +
            'var curve=Lb.effect("Bend Curvature")(1)/67.5;' + NL +
            'var dir=Lb.effect("Bend Direction")(1)/100;' + NL +
            'var H=h*realism*curve*dir;' + NL +
            'add(add(T,mul(u,a)),mul(perp,H));';

        // Base: каждая кость — прямоугольник, растянутый и повёрнутый между двумя точками.
        // Position группы = середина отрезка, Rotation = угол вдоль него, Rect Size = [длина, ширина].
        function wireBone(bone, LA, LB) {
            var A = 'var A=thisComp.layer(' + LA + ').transform.position;' + NL;
            var B = 'var B=thisComp.layer(' + LB + ').transform.position;' + NL;
            bone.xf.property("ADBE Vector Position").expression = A + B + 'mul(add(A,B),0.5);';
            bone.xf.property("ADBE Vector Rotation").expression = A + B + 'radiansToDegrees(Math.atan2(B[1]-A[1],B[0]-A[0]));';
            bone.rect.property("ADBE Vector Rect Size").expression = A + B + '[length(sub(B,A)),effect("Width")(1)];';
            bone.fill.property("ADBE Vector Fill Color").expression = 'effect("Color")(1)';
        }
        wireBone(boneUp, Lt, Lm);   // верхняя кость: top -> mid
        wireBone(boneLo, Lm, Lb);   // нижняя кость: mid -> bot

        // Auto Rotation: верхняя кость (top->mid), нижняя (mid->bot)
        tr(topR).property("ADBE Rotation").expression =
            'if(effect("Auto Rotation")(1)==1){' + NL +
            'var a=thisComp.layer(' + Lt + ').transform.position;' + NL +
            'var b=thisComp.layer(' + Lm + ').transform.position;' + NL +
            'radiansToDegrees(Math.atan2(b[1]-a[1],b[0]-a[0]))+90;}else{value;}';
        tr(botR).property("ADBE Rotation").expression =
            'if(effect("Auto Rotation")(1)==1){' + NL +
            'var a=thisComp.layer(' + Lm + ').transform.position;' + NL +
            'var b=thisComp.layer(' + Lb + ').transform.position;' + NL +
            'radiansToDegrees(Math.atan2(b[1]-a[1],b[0]-a[0]))+90;}else{value;}';

        // размер контроллеров от слайдеров (67.5 => 100%)
        tr(top).property("ADBE Scale").expression = 'var s=effect("Ctrl Big Size")(1)/67.5*100; [s,s];';
        tr(bot).property("ADBE Scale").expression = 'var s=effect("Bot Ctrl Size")(1)/67.5*100; [s,s];';

        // выделим главный (нижний) контроллер
        try { for (var dd = 1; dd <= comp.numLayers; dd++) comp.layer(dd).selected = false; } catch (eDsel) {}
        bot.selected = true;

    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + idx;
}


/* ---------- Пипетка ----------
   Раньше тут был $.colorPicker (системный диалог ОС) — он подвешивал AE и не давал
   забор пикселя с экрана. Настоящая экранная пипетка живёт в окне picker.html
   (захват пикселя под курсором через PowerShell). Здесь — заглушка. */
function MP_eyedropper() {
    return "browser";
}

/* ====================== Elastic / Bounce ======================
   Вешают выражение на выбранные СВОЙСТВА (P/S/R/T...) и добавляют контроллер-слайдеры.
   mode: "click" — один общий контроллер (на слое первого свойства),
         "shift" — свой контроллер на каждом слое с выбранными свойствами,
         "alt"   — отдельный нулевой Control Layer с контроллером.            */

/* поднимаемся от свойства до его слоя */
function MP_propLayer(prop) {
    var p = prop;
    for (var k = 0; k < 24; k++) {
        if (!p.parentProperty) break;
        p = p.parentProperty;
    }
    return p;
}

/* адрес свойства: индекс слоя + путь индексов вниз. Нужен, чтобы переразрешить ссылку
   ПОСЛЕ applyPreset (он протухает старые объекты-ссылки на свойства). */
function MP_propAddr(prop) {
    var path = [], p = prop, guard = 0;
    while (p && p.parentProperty && guard < 32) { path.unshift(p.propertyIndex); p = p.parentProperty; guard++; }
    return { li: (p && p.index != null) ? p.index : -1, path: path };
}
function MP_resolveAddr(comp, addr) {
    try {
        if (addr.li < 1) return null;
        var p = comp.layer(addr.li);
        for (var i = 0; i < addr.path.length; i++) p = p.property(addr.path[i]);
        return p;
    } catch (e) { return null; }
}

/* выбранные свойства, которым можно задать выражение */
function MP_selProps(comp) {
    var out = [];
    var sp = comp.selectedProperties;
    for (var i = 0; i < sp.length; i++) {
        var p = sp[i];
        try { if (p.canSetExpression) out.push(p); } catch (e) {}
    }
    return out;
}

/* рекурсивный обход свойств: собирает листовые свойства с ключами, на которые можно повесить выражение */
function MP_walkKeyed(p, out, depth) {
    if (depth > 8) return;
    var type;
    try { type = p.propertyType; } catch (eT) { return; }
    if (type === PropertyType.PROPERTY) {
        try { if (p.canSetExpression && p.numKeys > 0) out.push(p); } catch (e2) {}
    } else {
        var n = 0;
        try { n = p.numProperties; } catch (e3) { n = 0; }
        for (var i = 1; i <= n; i++) {
            try { MP_walkKeyed(p.property(i), out, depth + 1); } catch (e4) {}
        }
    }
}

/* свойства с ключами у ВЫДЕЛЕННЫХ СЛОЁВ (когда выделен слой, а не конкретное свойство) */
function MP_keyedPropsOfSelectedLayers(comp) {
    var out = [];
    try {
        var ls = comp.selectedLayers;
        for (var i = 0; i < ls.length; i++) MP_walkKeyed(ls[i], out, 0);
    } catch (e) {}
    return out;
}

/* добавляет на слой набор слайдеров/чекбокс под нужный контроллер */
function MP_addCtrl(layer, kind) {
    var fx = layer.property("ADBE Effect Parade");
    function slider(nm, val) {
        var e = fx.addProperty("ADBE Slider Control");
        e.name = nm;
        e.property(1).setValue(val);
    }
    function checkbox(nm, val) {
        var e = fx.addProperty("ADBE Checkbox Control");
        e.name = nm;
        e.property(1).setValue(val);
    }
    if (kind === "elastic") {
        slider("Amplitude", 100); slider("Frequency", 100); slider("Decay", 100);
    } else {
        slider("Amplitude", 50); slider("Gravity", 15); slider("Max Jumps", 5); checkbox("Jump In/Out", 0);
    }
}

/* проверка: есть ли на слое эффект с таким именем */
function MP_hasEffect(layer, nm) {
    try {
        var fx = layer.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) { if (fx.property(i).name === nm) return true; }
    } catch (e) {}
    return false;
}
/* добавить контроллер на слой, только если его там ещё нет (по сигнатурному параметру) */
function MP_ensureCtrl(layer, kind) {
    var sig = (kind === "elastic") ? "Decay" : "Gravity";
    if (MP_hasEffect(layer, sig)) return;
    MP_addCtrl(layer, kind);
}

/* ctrlName: имя отдельного контроллер-слоя (режим alt) ИЛИ null/"" — тогда
   ссылки идут на СВОЙ слой (thisLayer). Свой-слой вариант переживает Shift+D
   и любую перестановку слоёв — выражение всегда «знает», где его контроллер. */
function MP_elasticExpr(ctrlName, grouped) {
    var NL = String.fromCharCode(10);
    var c = ctrlName ? ('thisComp.layer("' + ctrlName + '").') : '';
    var A, F, D;
    if (grouped) {
        A = c + 'effect("Elastic Controller")(1)';
        F = c + 'effect("Elastic Controller")(2)';
        D = c + 'effect("Elastic Controller")(3)';
    } else {
        A = c + 'effect("Amplitude")(1)';
        F = c + 'effect("Frequency")(1)';
        D = c + 'effect("Decay")(1)';
    }
    return [
        // функции — на верхнем уровне (вне try), иначе legacy-движок AE отвергает выражение
        'function calc(amp, freq, decay, n){',
        '  var t = time - key(n).time;',
        '  var v = velocityAtTime(key(n).time - thisComp.frameDuration/10);',
        '  return v * (amp/freq) * Math.sin(freq*t*2*Math.PI) / Math.exp(t*(decay*2)*Math.E);',
        '}',
        'function elastic(amp, freq, decay){',
        '  if (numKeys == 0) return 0;',
        '  var n = nearestKey(time).index;',
        '  if (key(n).time > time) n--;',
        '  return (n > 1 && time <= key(n).time + (1/decay)) ? calc(amp,freq,decay,n) + calc(amp,freq,decay,n-1) : 0;',
        '}',
        'try {',
        '  var amp = ' + A + '/10/100;',
        '  var freq = ' + F + '/100;',
        '  var decay = ' + D + '/100;',
        '  value + elastic(amp, freq, decay);',
        '} catch (e) { value; }'
    ].join(NL);
}

function MP_bounceExpr(ctrlName, grouped) {
    var NL = String.fromCharCode(10);
    var c = ctrlName ? ('thisComp.layer("' + ctrlName + '").') : '';
    var A, G, M, J;
    if (grouped) {
        A = c + 'effect("Bounce Controller")(1)';
        G = c + 'effect("Bounce Controller")(2)';
        M = c + 'effect("Bounce Controller")(3)';
        J = c + 'effect("Bounce Controller")(4)';
    } else {
        A = c + 'effect("Amplitude")(1)';
        G = c + 'effect("Gravity")(1)';
        M = c + 'effect("Max Jumps")(1)';
        J = c + 'effect("Jump In/Out")(1)';
    }
    return [
        'var ampC = ' + A + '/100;',
        'var g = ' + G + '*100;',
        'var nMax = Math.round(' + M + ');',
        'var io = ' + J + ';',
        'var el = 0.7;',
        'function bnc(tt, v0){',
        '  var vl = length(v0);',
        '  if (vl < 1) return value*0;',
        '  var vu = (value instanceof Array) ? normalize(v0) : ((v0 < 0) ? -1 : 1);',
        '  var tCur = 0, seg = 2*vl/g, tN = seg, nb = 1;',
        '  while (tN < tt && nb <= nMax){ vl *= el; seg *= el; tCur = tN; tN += seg; nb++; }',
        '  if (nb <= nMax){ var dt = tt - tCur; return vu*dt*(vl - g*dt/2); }',
        '  return value*0;',
        '}',
        'var out = value;',
        'if (numKeys > 0){',
        '  var nk = nearestKey(time).index;',
        '  if (key(nk).time > time) nk--;',
        '  if (nk >= 1){',
        '    var t = time - key(nk).time;',
        '    var v0 = -velocityAtTime(key(nk).time - thisComp.frameDuration/10)*ampC*el;',
        '    out = value + bnc(t, v0);',
        '  } else if (io == 1 && time < key(1).time){',
        '    var t2 = key(1).time - time;',
        '    var v2 = velocityAtTime(key(1).time + thisComp.frameDuration/10)*ampC*el;',
        '    out = value + bnc(t2, v2);',
        '  }',
        '}',
        'out;'
    ].join(NL);
}

function MP_applyAnim(kind, mode) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var props = MP_selProps(comp);
    if (!props.length) return "noprops";

    function exprFor(nm) { return (kind === "elastic") ? MP_elasticExpr(nm) : MP_bounceExpr(nm); }

    app.beginUndoGroup((kind === "elastic" ? "Elastic" : "Bounce") + " (" + mode + ")");
    var count = 0;
    try {
        if (mode === "alt") {
            // отдельный Control Layer — ссылки по имени (общий внешний контроллер)
            var ctrl = comp.layers.addNull();
            ctrl.name = (kind === "elastic" ? "Elastic" : "Bounce") + " Controls";
            try { ctrl.label = 9; } catch (eL) {}
            MP_addCtrl(ctrl, kind);
            var aExpr = exprFor(ctrl.name);
            for (var i = 0; i < props.length; i++) {
                try { props[i].expression = aExpr; count++; } catch (e1) {}
            }
        } else {
            // click и shift: контроллер на КАЖДОМ слое со своими свойствами,
            // выражение ссылается на СВОЙ слой (без имени) → переживает Shift+D и перестановку.
            var ownExpr = exprFor(null);
            var seen = [];
            for (var j = 0; j < props.length; j++) {
                var L = MP_propLayer(props[j]);
                var has = false;
                for (var s = 0; s < seen.length; s++) { if (seen[s] === L) { has = true; break; } }
                if (!has) { MP_ensureCtrl(L, kind); seen.push(L); }
                try { props[j].expression = ownExpr; count++; } catch (e2) {}
            }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return count ? "ok:" + count : "err:Не удалось применить выражение";
}

/* Elastic — только обычный клик. Контроллер — единый псевдоэффект "Elastic Controller"
   из pseudo.ffx (applyPreset). Если файла нет/не применился — фолбэк на 3 слайдера.
   Выражение вешается на ПЕРЕРАЗРЕШЁННые свойства: applyPreset протухает старые ссылки. */
function MP_elastic(mode) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var props = MP_selProps(comp);
    if (!props.length) props = MP_keyedPropsOfSelectedLayers(comp); // выделен слой, а не свойство
    if (!props.length) return "noprops";

    // адреса свойств (слой + путь индексов) — пока ссылки валидны
    var addrs = [];
    for (var a = 0; a < props.length; a++) addrs.push(MP_propAddr(props[a]));

    var ffx = MP_pseudoFile("pseudo.ffx");
    var useFfx = !!(ffx && ffx.exists);
    var gExpr = MP_elasticExpr(null, true);   // под единый псевдоэффект
    var fExpr = MP_elasticExpr(null, false);  // под 3 слайдера-фолбэк

    app.beginUndoGroup("Elastic");
    var count = 0, lastErr = "", ctrlOk = 0, fellBack = 0;
    try {
        // 1) КОНТРОЛЛЕР — по разу на уникальный слой
        var keys = [];
        for (var i = 0; i < addrs.length; i++) {
            var li = addrs[i].li;
            if (li < 1) continue;
            var dup = false;
            for (var s = 0; s < keys.length; s++) { if (keys[s] === li) { dup = true; break; } }
            if (dup) continue;
            keys.push(li);
            var L = comp.layer(li);
            if (MP_hasEffect(L, "Elastic Controller") || MP_hasEffect(L, "Decay")) continue;
            var applied = false;
            if (useFfx) {
                try {
                    for (var d = 1; d <= comp.numLayers; d++) comp.layer(d).selected = false;
                    L.selected = true;
                    L.applyPreset(ffx);
                    applied = MP_hasEffect(L, "Elastic Controller");
                    if (!applied) lastErr = "preset применился, но 'Elastic Controller' не найден";
                } catch (eP) { lastErr = "preset: " + eP.toString(); }
            }
            if (!applied) { MP_addCtrl(L, "elastic"); fellBack++; } else ctrlOk++;
        }
        // 2) ВЫРАЖЕНИЕ — переразрешаем свойство по адресу (свежая ссылка) и вешаем
        for (var k = 0; k < addrs.length; k++) {
            var pr = MP_resolveAddr(comp, addrs[k]);
            if (!pr) { lastErr = "свойство не найдено после применения пресета"; continue; }
            var Lp = comp.layer(addrs[k].li);
            var expr = MP_hasEffect(Lp, "Elastic Controller") ? gExpr : fExpr;
            try { pr.expression = expr; count++; }
            catch (eX) { lastErr = "expr: " + eX.toString(); }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    var diag = "ffx=" + (useFfx ? "found" : "MISSING") + " ext=" + (MP_EXT_PATH ? "set" : "EMPTY") + " ctrl=" + ctrlOk + " fb=" + fellBack + (lastErr ? " (" + lastErr + ")" : "");
    app.endUndoGroup();
    if (count) return "ok:" + count + " §" + diag;
    return "err:" + (lastErr || "выражение не назначено") + " §" + diag;
}
/* Bounce — обычный клик. Контроллер — единый псевдоэффект "Bounce Controller" из bounce.ffx.
   Если файла нет/не применился — фолбэк на отдельные контролы (Amplitude/Gravity/Max Jumps/Jump In/Out).
   Выражение вешается на ПЕРЕРАЗРЕШЁННые свойства (applyPreset протухает старые ссылки). */
function MP_bounce(mode) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var props = MP_selProps(comp);
    if (!props.length) props = MP_keyedPropsOfSelectedLayers(comp);
    if (!props.length) return "noprops";

    var addrs = [];
    for (var a = 0; a < props.length; a++) addrs.push(MP_propAddr(props[a]));

    var ffx = MP_pseudoFile("bounce.ffx");
    var useFfx = !!(ffx && ffx.exists);
    var gExpr = MP_bounceExpr(null, true);   // под единый псевдоэффект
    var fExpr = MP_bounceExpr(null, false);  // под отдельные контролы-фолбэк

    app.beginUndoGroup("Bounce");
    var count = 0, lastErr = "", ctrlOk = 0, fellBack = 0;
    try {
        var keys = [];
        for (var i = 0; i < addrs.length; i++) {
            var li = addrs[i].li;
            if (li < 1) continue;
            var dup = false;
            for (var s = 0; s < keys.length; s++) { if (keys[s] === li) { dup = true; break; } }
            if (dup) continue;
            keys.push(li);
            var L = comp.layer(li);
            if (MP_hasEffect(L, "Bounce Controller") || MP_hasEffect(L, "Gravity")) continue;
            var applied = false;
            if (useFfx) {
                try {
                    for (var d = 1; d <= comp.numLayers; d++) comp.layer(d).selected = false;
                    L.selected = true;
                    L.applyPreset(ffx);
                    applied = MP_hasEffect(L, "Bounce Controller");
                    if (!applied) lastErr = "preset применился, но 'Bounce Controller' не найден";
                } catch (eP) { lastErr = "preset: " + eP.toString(); }
            }
            if (!applied) { MP_addCtrl(L, "bounce"); fellBack++; } else ctrlOk++;
        }
        for (var k = 0; k < addrs.length; k++) {
            var pr = MP_resolveAddr(comp, addrs[k]);
            if (!pr) { lastErr = "свойство не найдено после применения пресета"; continue; }
            var Lp = comp.layer(addrs[k].li);
            var expr = MP_hasEffect(Lp, "Bounce Controller") ? gExpr : fExpr;
            try { pr.expression = expr; count++; }
            catch (eX) { lastErr = "expr: " + eX.toString(); }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    var diag = "ffx=" + (useFfx ? "found" : "MISSING") + " ext=" + (MP_EXT_PATH ? "set" : "EMPTY") + " ctrl=" + ctrlOk + " fb=" + fellBack + (lastErr ? " (" + lastErr + ")" : "");
    app.endUndoGroup();
    if (count) return "ok:" + count + " §" + diag;
    return "err:" + (lastErr || "выражение не назначено") + " §" + diag;
}

/* ---------- Duplicate (глубокое дублирование ВЫДЕЛЕННОГО СЛОЯ) ----------
   Дублирует выбранный на таймлайне слой (копия встаёт прямо над ним), и если его
   источник — прекомпоз, делает ЕГО и все вложенные прекомпозы независимыми копиями:
   правки в дубликате не трогают оригинал, общей «ветки» с исходным композом не остаётся.
   Внутреннее переиспользование сохраняется (один и тот же прекомп в дереве → одна копия).
   Слои без прекомпоза-источника просто дублируются как обычно. */
function MP_duplicateComp(replace) {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "err:Выдели слой на таймлайне";

    app.beginUndoGroup(replace ? "Duplicate \u2192 replace source (deep)" : "Duplicate layer (deep precomps)");
    var map = {};   // id оригинального прекомпоза -> независимая копия
    function dupComp(c) {
        if (map[c.id]) return map[c.id];
        var d = c.duplicate();
        map[c.id] = d;
        for (var k = 1; k <= d.numLayers; k++) {
            var L = d.layer(k);
            var s = null;
            try { s = L.source; } catch (e1) {}
            if (s && (s instanceof CompItem)) {
                var cd = dupComp(s);
                try { L.replaceSource(cd, false); } catch (e2) {}
            }
        }
        return d;
    }

    // снимок выбранных слоёв (дублирование меняет состав/индексы)
    var layers = [];
    for (var i = 0; i < sel.length; i++) layers.push(sel[i]);

    var count = 0, lastName = "";
    try {
        for (var j = 0; j < layers.length; j++) {
            var orig = layers[j];
            if (replace) {
                // Shift: НЕ создаём новый слой — заменяем источник самого слоя независимой копией прекомпоза (на месте)
                var so = null;
                try { so = orig.source; } catch (eo) {}
                if (so && (so instanceof CompItem)) {
                    var cdo = dupComp(so);
                    try { orig.replaceSource(cdo, false); count++; lastName = orig.name; } catch (eRo) {}
                }
                // если источник не прекомпоз — заменять нечего, слой пропускаем
            } else {
                var dup = orig.duplicate();   // копия встаёт прямо над оригиналом
                count++;
                lastName = dup.name;
                var s = null;
                try { s = dup.source; } catch (eS) {}
                if (s && (s instanceof CompItem)) {
                    var cd = dupComp(s);
                    try { dup.replaceSource(cd, false); } catch (eR) {}
                }
            }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    if (!count) return replace ? "err:У выбранного слоя нет прекомпоза для замены" : "err:Не удалось продублировать";
    return "ok:" + (count === 1 ? lastName : (count + " сл."));
}

/* ============================================================
   STAGGER / SEQUENCE: сдвигаем выделенные слои вперёд группами.
   amount — сколько слоёв в одной группе (двигаются вместе),
   step   — на сколько кадров каждая следующая группа позже предыдущей.
============================================================ */
function MP_stagger(amount, step, dir) {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "nosel";
    amount = Math.round(amount); if (!amount || amount < 1) amount = 1;
    var fd = comp.frameDuration;            // длительность кадра, сек
    var stepSec = (step || 0) * fd;         // шаг в секундах
    // снимок и сортировка по порядку на таймлайне (сверху вниз)
    var layers = [];
    for (var i = 0; i < sel.length; i++) layers.push(sel[i]);
    layers.sort(function (a, b) { return a.index - b.index; });
    if (dir === "bottom") { layers.reverse(); }                      // снизу вверх
    else if (dir === "random") {                                     // случайный порядок
        for (var s = layers.length - 1; s > 0; s--) { var rnd = Math.floor(Math.random() * (s + 1)); var tmp = layers[s]; layers[s] = layers[rnd]; layers[rnd] = tmp; }
    }                                                                // иначе "top" — сверху вниз (по умолчанию)
    app.beginUndoGroup("Stagger / sequence layers");
    try {
        for (var j = 0; j < layers.length; j++) {
            var grp = Math.floor(j / amount);
            var off = grp * stepSec;
            if (off !== 0) { try { layers[j].startTime = layers[j].startTime + off; } catch (eL) {} }
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + layers.length;
}

// Сдвинуть выделенные слои так, чтобы их точка входа совпала с плейхедом
function MP_arrangeToPlayhead() {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "nosel";
    var t = comp.time;
    app.beginUndoGroup("Arrange layers to playhead");
    var n = 0;
    try {
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i], inP = 0;
            try { inP = L.inPoint; } catch (e1) {}
            try { L.startTime = L.startTime + (t - inP); n++; } catch (e2) {}
        }
    } catch (e) { app.endUndoGroup(); return "err:" + e.toString(); }
    app.endUndoGroup();
    return "ok:" + n;
}

// Развернуть порядок выделенных слоёв в стеке (обратная укладка)
function MP_reverseStack() {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || sel.length < 2) return "err:Выдели минимум 2 слоя";
    var layers = [];
    for (var i = 0; i < sel.length; i++) layers.push(sel[i]);
    layers.sort(function (a, b) { return a.index - b.index; });   // сверху вниз
    app.beginUndoGroup("Reverse stacking order");
    try {
        // двигаем каждый следующий сверху слой на самый верх выделения → порядок переворачивается
        var top = layers[0];
        for (var k = 1; k < layers.length; k++) {
            try { layers[k].moveBefore(top); } catch (eM) {}
            top = layers[k];
        }
    } catch (e) { app.endUndoGroup(); return "err:" + e.toString(); }
    app.endUndoGroup();
    return "ok:" + layers.length;
}


/* масштабировать времена всех ключей слоя в k раз (якорь — начало компа, t=0) */
function MP_scaleLayerKeys(layer, k) {
    if (k === 1) return;
    function walk(g) {
        var np = 0; try { np = g.numProperties; } catch (e0) { return; }
        for (var i = 1; i <= np; i++) {
            var p = null; try { p = g.property(i); } catch (e1) {}
            if (!p) continue;
            var pt = null; try { pt = p.propertyType; } catch (e2) {}
            if (pt === PropertyType.PROPERTY) {
                var n = 0; try { n = p.numKeys; } catch (e3) {}
                if (n > 0) {
                    if (k > 1) { for (var a = n; a >= 1; a--) { try { p.setKeyTime(a, p.keyTime(a) * k); } catch (eA) {} } }
                    else       { for (var b = 1; b <= n; b++) { try { p.setKeyTime(b, p.keyTime(b) * k); } catch (eB) {} } }
                }
            } else {
                var sub = 0; try { sub = p.numProperties; } catch (e4) {}
                if (sub > 0) walk(p);
            }
        }
    }
    try { walk(layer); } catch (e) {}
}

function MP_fitPrecomp(stretchKeys) {
    if (stretchKeys === "false" || stretchKeys === false) stretchKeys = false; else stretchKeys = true;   // false = только тайминг; иначе полное растяжение
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "err:Выдели прекомпоз на таймлайне";
    var T = comp.duration;                       // целевая длина = длина текущей композиции
    if (T <= 0) return "err:Некорректная длительность композиции";

    // корни — источники-композиции выделенных слоёв (+ сами слои, чтобы подогнать их длину)
    var roots = [];
    var selLayers = [];
    for (var i0 = 0; i0 < sel.length; i0++) {
        var src0 = null; try { src0 = sel[i0].source; } catch (eS0) {}
        if (src0 && (src0 instanceof CompItem)) { roots.push(src0); selLayers.push(sel[i0]); }
    }
    if (!roots.length) return "err:Выдели слой-прекомпоз (композицию)";

    app.beginUndoGroup(stretchKeys ? "Fit precomp to comp length (stretch)" : "Fit precomp to comp length (timing only)");
    var seen = {};    // общий прекомпоз растягиваем только один раз
    var tseen = {};   // и отдельно — те, что только удлиняем по таймингу

    // рекурсивно тянем длительность и outPoint'ы БЕЗ растяжения (скорость анимации не меняется)
    function extendTimingOnly(c) {
        if (!c || !(c instanceof CompItem) || tseen[c.id]) return;
        tseen[c.id] = true;
        try { if (T > c.duration) c.duration = T; } catch (eDur) {}
        for (var j = 1; j <= c.numLayers; j++) {
            var L = c.layer(j);
            var isAdj = false; try { isAdj = (L.adjustmentLayer === true); } catch (eA) {}
            if (isAdj) continue;
            try { L.outPoint = T; } catch (eO) {}
            var src = null; try { src = L.source; } catch (eSr) {}
            if (src && (src instanceof CompItem)) extendTimingOnly(src);   // вложенный прекомпоз — тоже только тайминг
        }
        try { c.duration = T; } catch (eD2) {}
    }

    // фитим исходник выделенного прекомпоза
    function fit(c) {
        if (!c || !(c instanceof CompItem) || seen[c.id]) return;
        seen[c.id] = true;
        var D = c.duration;
        if (D <= 0) return;
        var ratio = T / D;
        // удлиняем комп заранее, чтобы слои не обрезались
        try { if (T > c.duration) c.duration = T; } catch (e2) {}
        for (var j = 1; j <= c.numLayers; j++) {
            var L = c.layer(j);
            var isAdjL = false; try { isAdjL = (L.adjustmentLayer === true); } catch (eAdjL) {}
            if (isAdjL) continue;   // корректирующие слои не трогаем
            if (!stretchKeys) { try { L.outPoint = T; } catch (eTimO) {} continue; }   // обычный клик: только удлиняем слой
            // Shift:
            var srcL = null; try { srcL = L.source; } catch (eSrcL) {}
            if (srcL && (srcL instanceof CompItem)) {
                // вложенный прекомпоз — НЕ растягиваем (скорость как была), только тянем его тайминг под T (рекурсивно внутрь)
                try { L.outPoint = T; } catch (eOpN) {}
                extendTimingOnly(srcL);
            } else {
                // обычный слой — растягиваем под T (ключи масштабируются пропорционально)
                var oldIn = 0, oldStretch = 100;
                try { oldIn = L.inPoint; } catch (e4) {}
                try { oldStretch = L.stretch; } catch (e5) {}
                try { L.stretch = oldStretch * ratio; } catch (e11) {}
                var shift = oldIn * ratio - oldIn;
                if (shift) { try { L.startTime = L.startTime + shift; } catch (e12) {} }
            }
        }
        try { c.duration = T; } catch (e13) {}
    }

    try {
        for (var r = 0; r < roots.length; r++) fit(roots[r]);
        // подгоняем сами выделенные слои под длину текущей композиции:
        // источник уже стал длиной T → растягиваем слой на весь комп и проигрываем 1:1
        for (var q = 0; q < selLayers.length; q++) {
            var SL = selLayers[q];
            var isAdjSL = false; try { isAdjSL = (SL.adjustmentLayer === true); } catch (eAdjSL) {}
            if (isAdjSL) continue;   // Fit to comp не трогает корректирующие слои
            if (!stretchKeys) { try { SL.outPoint = T; } catch (eqTim) {} continue; }   // обычный клик: только удлиняем
            try { SL.stretch = 100; } catch (eq1) {}
            try { SL.startTime = 0; } catch (eq2) {}
            try { SL.outPoint = T; } catch (eq3) {}
            try { SL.inPoint = 0; } catch (eq4) {}
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + roots.length;
}

/* ============================================================
   CROP COMP — обрезает прекомпоз до содержимого.
   Берём выделенный слой-прекомпоз, считаем габариты его контента
   (sourceRectAtTime — в координатах источника, на текущем кадре),
   уменьшаем композицию-источник до этих габаритов, сдвигаем внутренние
   корневые слои к началу и репозиционируем ВСЕ слои-инстансы этого
   источника (в любом компе проекта), чтобы визуально ничего не съехало.
   ⚠️ Источник общий для всех его инстансов — поэтому двигаем все инстансы.
============================================================ */
function MP_shiftLayerPos(L, dx, dy) {
    var poP;
    try { poP = L.property("ADBE Transform Group").property("ADBE Position"); } catch (e0) { return; }
    if (!poP) return;
    try {
        if (poP.numKeys > 0) {
            for (var ki = 1; ki <= poP.numKeys; ki++) {
                var v = poP.keyValue(ki);
                poP.setValueAtTime(poP.keyTime(ki), (v.length === 3) ? [v[0] + dx, v[1] + dy, v[2]] : [v[0] + dx, v[1] + dy]);
            }
        } else {
            var v0 = poP.value;
            poP.setValue((v0.length === 3) ? [v0[0] + dx, v0[1] + dy, v0[2]] : [v0[0] + dx, v0[1] + dy]);
        }
    } catch (e1) {}
}

/* двигаем один слой-инстанс источника так, чтобы центр кропа остался на месте.
   Считаем в системе координат непосредственного родителя слоя (учитываем
   собственные anchor/position/scale/rotateZ слоя); цепочка родителей выше не
   меняется, поэтому вид сохраняется. anchor → новый центр уменьшенного компа. */
/* вычисляет целевые якорь/позицию инстанса по ТЕКУЩИМ (до ресайза) значениям.
   Возвращает структуру, которую потом применяем ПОСЛЕ ресайза. */
function MP_cropComputeTarget(L, C, S) {
    var t = 0; try { t = C.time; } catch (eT) {}
    var tr = L.property("ADBE Transform Group");
    var apP = tr.property("ADBE Anchor Point");
    var poP = tr.property("ADBE Position");
    var scP = tr.property("ADBE Scale");
    var roP = tr.property("ADBE Rotate Z");
    var a = apP.valueAtTime(t, false);
    var p = poP.valueAtTime(t, false);
    var sc = scP.valueAtTime(t, false);
    var rz = roP.valueAtTime(t, false) * Math.PI / 180;
    var ox = (S.cropCx - a[0]) * sc[0] / 100;
    var oy = (S.cropCy - a[1]) * sc[1] / 100;
    var localX = p[0] + ox * Math.cos(rz) - oy * Math.sin(rz);
    var localY = p[1] + ox * Math.sin(rz) + oy * Math.cos(rz);
    var newAnchor = (a.length === 3) ? [S.newW / 2, S.newH / 2, a[2]] : [S.newW / 2, S.newH / 2];
    return { L: L, t: t, p: p, localX: localX, localY: localY, newAnchor: newAnchor };
}

/* применяет якорь/позицию ПОСЛЕ ресайза источника, перетирая авто-правки AE */
function MP_cropApplyTarget(tg) {
    try {
        var L = tg.L, t = tg.t, p = tg.p;
        var tr = L.property("ADBE Transform Group");
        var apP = tr.property("ADBE Anchor Point");
        var poP = tr.property("ADBE Position");
        if (poP.numKeys > 0) {
            var dpx = tg.localX - p[0], dpy = tg.localY - p[1];
            for (var ki = 1; ki <= poP.numKeys; ki++) {
                var pv = poP.keyValue(ki);
                poP.setValueAtTime(poP.keyTime(ki), (pv.length === 3) ? [pv[0] + dpx, pv[1] + dpy, pv[2]] : [pv[0] + dpx, pv[1] + dpy]);
            }
        } else {
            poP.setValue((p.length === 3) ? [tg.localX, tg.localY, p[2]] : [tg.localX, tg.localY]);
        }
        if (apP.numKeys > 0) apP.setValueAtTime(t, tg.newAnchor); else apP.setValue(tg.newAnchor);
    } catch (e) {}
}

/* точка из системы координат слоя L → координаты его композиции (2D, через цепочку родителей) */
function MP_ptToComp(L, pt, t) {
    var tr = L.property("ADBE Transform Group");
    var a = tr.property("ADBE Anchor Point").valueAtTime(t, false);
    var p = tr.property("ADBE Position").valueAtTime(t, false);
    var sc = tr.property("ADBE Scale").valueAtTime(t, false);
    var rz = tr.property("ADBE Rotate Z").valueAtTime(t, false) * Math.PI / 180;
    var ox = (pt[0] - a[0]) * sc[0] / 100;
    var oy = (pt[1] - a[1]) * sc[1] / 100;
    var wx = p[0] + ox * Math.cos(rz) - oy * Math.sin(rz);
    var wy = p[1] + ox * Math.sin(rz) + oy * Math.cos(rz);
    if (L.parent) return MP_ptToComp(L.parent, [wx, wy], t);
    return [wx, wy];
}

/* габариты всего видимого контента композиции src (в её координатах) на времени t.
   Считаем по внутренним слоям, т.к. sourceRectAtTime самого прекомпоза у слоя без
   непрерывной растеризации возвращает полный кадр композиции, а не рамку контента. */
function MP_innerBounds(src, t) {
    var minX = null, minY = null, maxX = null, maxY = null;
    for (var i = 1; i <= src.numLayers; i++) {
        var L = src.layer(i);
        var en = true; try { en = L.enabled; } catch (e0) {}
        if (!en) continue;
        var hv = true; try { hv = L.hasVideo; } catch (e1) {}
        if (!hv) continue;
        var isNull = false; try { isNull = L.nullLayer; } catch (e2) {}
        if (isNull) continue;
        var isAdj = false; try { isAdj = L.adjustmentLayer; } catch (e3) {}
        if (isAdj) continue;
        if ((L instanceof CameraLayer) || (L instanceof LightLayer)) continue;
        var r = null; try { r = L.sourceRectAtTime(t, false); } catch (e4) { r = null; }
        if (!r || r.width <= 0 || r.height <= 0) continue;
        var corners = [[r.left, r.top], [r.left + r.width, r.top], [r.left, r.top + r.height], [r.left + r.width, r.top + r.height]];
        for (var c = 0; c < 4; c++) {
            var w = null;
            try { w = MP_ptToComp(L, corners[c], t); } catch (e5) { w = null; }
            if (!w) continue;
            if (minX === null || w[0] < minX) minX = w[0];
            if (minY === null || w[1] < minY) minY = w[1];
            if (maxX === null || w[0] > maxX) maxX = w[0];
            if (maxY === null || w[1] > maxY) maxY = w[1];
        }
    }
    if (minX === null) return null;
    return { minX: minX, minY: minY, maxX: maxX, maxY: maxY };
}

function MP_cropComp() {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "err:Выдели слой-прекомпоз на таймлайне";

    // уникальные источники-прекомпозы из выделения + замер габаритов (на текущем кадре)
    var sources = [];
    var srcSeen = {};
    var hasPre = false;
    for (var i = 0; i < sel.length; i++) {
        var s = null; try { s = sel[i].source; } catch (eS) {}
        if (!s || !(s instanceof CompItem)) continue;
        hasPre = true;
        if (srcSeen[s.id]) continue;
        srcSeen[s.id] = true;
        // время ВНУТРИ прекомпоза, соответствующее текущему кадру родителя
        var stretch = 100; try { stretch = sel[i].stretch; } catch (eSt) {}
        if (!stretch) stretch = 100;
        var startT = 0; try { startT = sel[i].startTime; } catch (eStt) {}
        var tIn = (comp.time - startT) * 100 / stretch;
        if (tIn < 0) tIn = 0;
        if (tIn > s.duration) tIn = (s.duration > 0 ? s.duration : 0);
        // габариты контента — по внутренним слоям (надёжно)
        var bb = MP_innerBounds(s, tIn);
        if (!bb) {   // запасной путь: рамка самого прекомпоза
            var r = null; try { r = sel[i].sourceRectAtTime(comp.time, false); } catch (eR) { r = null; }
            if (r && r.width > 0 && r.height > 0) bb = { minX: r.left, minY: r.top, maxX: r.left + r.width, maxY: r.top + r.height };
        }
        if (!bb) continue;
        var bw = bb.maxX - bb.minX, bh = bb.maxY - bb.minY;
        if (bw <= 0 || bh <= 0) continue;
        var nW = Math.round(bw), nH = Math.round(bh);
        if (nW < 1) nW = 1; if (nH < 1) nH = 1;
        if (nW > 30000) nW = 30000; if (nH > 30000) nH = 30000;
        sources.push({ src: s, minX: bb.minX, minY: bb.minY, newW: nW, newH: nH, cropCx: (bb.minX + bb.maxX) / 2, cropCy: (bb.minY + bb.maxY) / 2, tIn: tIn });
    }
    if (!hasPre) return "err:Это не прекомпоз — выдели слой-композицию";
    if (!sources.length) return "err:На текущем кадре в прекомпозе нет видимого контента";

    app.beginUndoGroup("Crop Comp to Content");
    try {
        // все композиции проекта — чтобы подвинуть КАЖДЫЙ инстанс источника
        var comps = [];
        for (var ai = 1; ai <= app.project.numItems; ai++) {
            var it = app.project.item(ai);
            if (it instanceof CompItem) comps.push(it);
        }
        for (var si = 0; si < sources.length; si++) {
            var S = sources[si];
            // 1) собрать инстансы источника и ВЫЧИСЛИТЬ цели по старым значениям (до ресайза)
            var targets = [];
            for (var ci = 0; ci < comps.length; ci++) {
                var C = comps[ci];
                for (var li = 1; li <= C.numLayers; li++) {
                    var L = C.layer(li);
                    var ls = null; try { ls = L.source; } catch (eLS) {}
                    if (!ls || ls.id !== S.src.id) continue;
                    targets.push(MP_cropComputeTarget(L, C, S));
                }
            }
            // 2) уменьшаем источник. AE при ресайзе сам подстраивает якоря слоёв и
            //    инстансов — поэтому центрирование контента и репозицию инстансов делаем
            //    ПОСЛЕ ресайза, перетирая авто-правки AE.
            try { S.src.width = S.newW; } catch (eW) {}
            try { S.src.height = S.newH; } catch (eH) {}
            // 3) центрируем контент в новом кадре по СВЕЖЕМУ замеру
            var bb2 = MP_innerBounds(S.src, S.tIn);
            if (bb2) {
                var cx2 = (bb2.minX + bb2.maxX) / 2, cy2 = (bb2.minY + bb2.maxY) / 2;
                var sdx = S.newW / 2 - cx2, sdy = S.newH / 2 - cy2;
                if (sdx !== 0 || sdy !== 0) {
                    for (var j = 1; j <= S.src.numLayers; j++) {
                        var IL = S.src.layer(j);
                        if (IL.parent) continue;                               // дети уедут с родителем
                        if ((IL instanceof CameraLayer) || (IL instanceof LightLayer)) continue;
                        MP_shiftLayerPos(IL, sdx, sdy);
                    }
                }
            }
            // 4) применяем якорь/позицию инстансам ПОСЛЕ ресайза
            for (var ti = 0; ti < targets.length; ti++) MP_cropApplyTarget(targets[ti]);
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    // отладка: финальное состояние выделенного прекомпоза
    try {
        var dbgL = null;
        for (var di = 0; di < sel.length; di++) {
            var ds = null; try { ds = sel[di].source; } catch (eD) {}
            if (ds && (ds instanceof CompItem)) { dbgL = sel[di]; break; }
        }
        if (dbgL) {
            var dtr = dbgL.property("ADBE Transform Group");
            var fa = dtr.property("ADBE Anchor Point").value;
            var fp = dtr.property("ADBE Position").value;
            var fbb = MP_innerBounds(dbgL.source, 0);
            var fc = fbb ? [Math.round((fbb.minX + fbb.maxX) / 2), Math.round((fbb.minY + fbb.maxY) / 2)] : null;
            $.global.MP_cropDbg = "src=" + dbgL.source.width + "x" + dbgL.source.height +
                " anchor=" + Math.round(fa[0]) + "," + Math.round(fa[1]) +
                " pos=" + Math.round(fp[0]) + "," + Math.round(fp[1]) +
                " contentC=" + (fc ? (fc[0] + "," + fc[1]) : "none");
        }
    } catch (eDbg) {}
    app.endUndoGroup();
    return "ok:" + sources.length;
}

/* ============================================================
   UPSCALE → 4K: независимая глубокая копия выделенного прекомпоза.
   Дублируем прекомпоз и ВСЕ вложенные прекомпозы (оригинал не трогаем),
   переводим композиции с Full HD на 4K (3840 по ширине) и масштабируем
   все пространственные свойства/ключи в тот же множитель — идеальная копия
   по анимациям и размеру. (Под капотом: Duplicate-дерево + ресайз + масштаб ключей.)
============================================================ */
function MP_mulVal(v, f) {
    if (v instanceof Array) { var o = []; for (var i = 0; i < v.length; i++) o[i] = v[i] * f; return o; }
    return v * f;
}
function MP_scaleSpatialProp(p, f) {
    if (!p) return;
    var nk = 0; try { nk = p.numKeys; } catch (e0) { return; }
    if (nk > 0) {
        for (var i = 1; i <= nk; i++) {
            try { p.setValueAtKey(i, MP_mulVal(p.keyValue(i), f)); } catch (eK) {}
            var sp = false; try { sp = p.isSpatial; } catch (eS) {}
            if (sp) { try { p.setSpatialTangentsAtKey(i, MP_mulVal(p.keyInSpatialTangent(i), f), MP_mulVal(p.keyOutSpatialTangent(i), f)); } catch (eT) {} }
        }
    } else { try { p.setValue(MP_mulVal(p.value, f)); } catch (eV) {} }
}
function MP_scaleShapeProp(p, f) {                     // маска/путь: вершины и тангенсы × f
    if (!p) return;
    function sc(sh) {
        var v = sh.vertices, it = sh.inTangents, ot = sh.outTangents, i, ns;
        for (i = 0; i < v.length; i++)  v[i]  = [v[i][0] * f,  v[i][1] * f];
        for (i = 0; i < it.length; i++) it[i] = [it[i][0] * f, it[i][1] * f];
        for (i = 0; i < ot.length; i++) ot[i] = [ot[i][0] * f, ot[i][1] * f];
        ns = new Shape(); ns.vertices = v; ns.inTangents = it; ns.outTangents = ot; ns.closed = sh.closed; return ns;
    }
    var nk = 0; try { nk = p.numKeys; } catch (e0) { return; }
    if (nk > 0) { for (var i = 1; i <= nk; i++) { try { p.setValueAtKey(i, sc(p.keyValue(i))); } catch (eK) {} } }
    else { try { p.setValue(sc(p.value)); } catch (eV) {} }
}
function MP_scaleLayer4K(L, f, srcIsComp) {
    var tr = null; try { tr = L.property("ADBE Transform Group"); } catch (e) {}
    if (!tr) { try { tr = L.transform; } catch (e2) {} }
    if (tr) {
        var pos = null; try { pos = tr.property("ADBE Position"); } catch (eP) {}
        if (pos) {
            var sep = false; try { sep = pos.dimensionsSeparated; } catch (eD) {}
            if (sep) { for (var d = 0; d < 3; d++) { var sub = null; try { sub = pos.getSeparationFollower(d); } catch (eSf) {} if (sub) MP_scaleSpatialProp(sub, f); } }
            else { MP_scaleSpatialProp(pos, f); }
        }
        if (srcIsComp) {
            // источник — наш увеличенный прекомпоз: масштабируем якорь, scale слоя оставляем как есть
            var anc = null; try { anc = tr.property("ADBE Anchor Point"); } catch (eA) {}
            MP_scaleSpatialProp(anc, f);
        } else {
            // футаж/текст/фигуры/солид: увеличиваем сам слой (Scale × f); якорь в координатах источника не трогаем
            var scl = null; try { scl = tr.property("ADBE Scale"); } catch (eSc) {}
            MP_scaleSpatialProp(scl, f);
        }
    }
    if (srcIsComp) {                                   // маски прекомп-слоя заданы в координатах увеличенного компа
        var mp = null; try { mp = L.property("ADBE Mask Parade"); } catch (eM) {}
        if (mp) {
            var nm = 0; try { nm = mp.numProperties; } catch (eN) {}
            for (var m = 1; m <= nm; m++) {
                var msk = null; try { msk = mp.property(m); } catch (eMm) {}
                if (!msk) continue;
                var pathP = null; try { pathP = msk.property("ADBE Mask Shape"); } catch (eMs) {}
                MP_scaleShapeProp(pathP, f);
            }
        }
    }
}
function MP_upscale4K() {
    var comp = MP_getComp();
    if (!comp || !(comp instanceof CompItem)) return "err:Нет активной композиции";

    var f = 3840 / (comp.width || 1920);              // Full HD (1920) → 4K (3840) = ×2
    if (!(f > 0) || Math.abs(f - 1) < 0.001) return "err:Композиция уже 4K (или нулевая ширина)";

    app.beginUndoGroup("4K Copy");
    var map = {};      // id оригинала -> независимая копия

    // независимый глубокий дубликат: комп + ВСЕ вложенные прекомпозы (оригиналы не трогаем)
    function dupTree(c) {
        if (map[c.id]) return map[c.id];
        var d = c.duplicate();
        map[c.id] = d;
        for (var k = 1; k <= d.numLayers; k++) {
            var L = d.layer(k), s = null;
            try { s = L.source; } catch (e1) {}
            if (s && (s instanceof CompItem)) { var cd = dupTree(s); try { L.replaceSource(cd, false); } catch (e2) {} }
        }
        return d;
    }
    // непрерывная растеризация на всех слоях-прекомпозах копии — векторы/текст остаются чёткими при апскейле
    function collapseAll(c, seen) {
        if (seen[c.id]) return; seen[c.id] = true;
        for (var k = 1; k <= c.numLayers; k++) {
            var L = c.layer(k), s = null;
            try { s = L.source; } catch (e1) {}
            if (s && (s instanceof CompItem)) {
                try { L.collapseTransformation = true; } catch (eC) {}
                collapseAll(s, seen);
            }
        }
    }

    var out = null;
    try {
        var src = dupTree(comp);                                  // независимая копия рабочего компа + всё внутри
        try { collapseAll(src, {}); } catch (eCa) {}              // чёткость вложенного вектора в 4K

        var w4 = Math.round(comp.width  * f);
        var h4 = Math.round(comp.height * f);
        out = app.project.items.addComp(comp.name + " 4K", w4, h4, comp.pixelAspect, comp.duration, comp.frameRate);

        // вкладываем копию и пинуем её ровно в центр 4K-компа с масштабом ×f.
        // позиция/размер заданы фиксированными значениями (без умножения свойств слоёв) — уехать в угол нечему
        var lay = out.layers.add(src);
        try { lay.collapseTransformation = true; } catch (eC0) {}
        var tr = lay.property("ADBE Transform Group");
        try { tr.property("ADBE Anchor Point").setValue([comp.width / 2, comp.height / 2]); } catch (eA) {}
        try { tr.property("ADBE Position").setValue([w4 / 2, h4 / 2]); } catch (eP) {}
        try { tr.property("ADBE Scale").setValue([100 * f, 100 * f]); } catch (eS) {}

        try { out.openInViewer(); } catch (eO) {}                 // открываем 4K-комп (в прекомпоз не ныряем)
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + (out ? out.name : "4K");
}


function MP_exprNorm(s) { return String(s).replace(/\s+/g, "").toLowerCase(); }
function MP_bigrams(s) {
    var m = {};
    for (var i = 0; i < s.length - 1; i++) { var g = s.substr(i, 2); m[g] = (m[g] || 0) + 1; }
    return m;
}
/* мера похожести текста (коэффициент Дайса по биграммам), 0..1 */
function MP_dice(a, b) {
    if (a === b) return 1;
    if (!a.length || !b.length) return 0;
    var A = MP_bigrams(a), B = MP_bigrams(b), inter = 0, total = 0, g;
    for (g in A) total += A[g];
    for (g in B) total += B[g];
    for (g in A) if (B[g]) inter += Math.min(A[g], B[g]);
    return total ? (2 * inter / total) : 0;
}
/* рекурсивно собираем непустые выражения со всех свойств группы/слоя */
function MP_walkExpr(grp, out) {
    var n;
    try { n = grp.numProperties; } catch (e) { return; }
    for (var i = 1; i <= n; i++) {
        var p;
        try { p = grp.property(i); } catch (e2) { continue; }
        if (!p) continue;
        if (p.propertyType === PropertyType.PROPERTY) {
            try {
                if (p.canSetExpression && p.expression && p.expression !== "") out.push(p.expression);
            } catch (e3) {}
        } else {
            MP_walkExpr(p, out);
        }
    }
}
function MP_collectExpressions() {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var found = [];
    var props = comp.selectedProperties;
    if (props && props.length) {
        // выделены конкретные свойства (напр. Y Position) — берём выражения только с них
        for (var pi = 0; pi < props.length; pi++) {
            var pp = props[pi];
            if (pp.propertyType === PropertyType.PROPERTY) {
                try { if (pp.canSetExpression && pp.expression && pp.expression !== "") found.push(pp.expression); } catch (ePp) {}
            } else {
                MP_walkExpr(pp, found);   // выделена группа свойств — обходим её
            }
        }
    } else {
        // выделен только слой — собираем со всего слоя
        var sel = comp.selectedLayers;
        if (!sel || !sel.length) return "nosel";
        for (var i = 0; i < sel.length; i++) { try { MP_walkExpr(sel[i], found); } catch (e) {} }
    }
    if (!found.length) return "noexpr";
    // объединяем только ОДИНАКОВЫЕ (по тексту без пробелов) — разные выражения остаются раздельными
    var norms = [], texts = [];
    for (var k = 0; k < found.length; k++) {
        var norm = MP_exprNorm(found[k]);
        var dup = false;
        for (var n = 0; n < norms.length; n++) { if (norms[n] === norm) { dup = true; break; } }
        if (!dup) { norms.push(norm); texts.push(found[k]); }
    }
    return "ok:" + texts.length + "<<<MPHEAD>>>" + texts.join("<<<MPEXPR>>>");
}
/* применяем выражение ко всем выделенным свойствам, которые это поддерживают */
function MP_applyExpression(code, target) {
    var comp = MP_getComp();
    if (!comp) return "err:Нет активной композиции";
    var props = comp.selectedProperties;
    if (!props || !props.length) return "noprops";
    app.beginUndoGroup("Apply Expression");
    var cnt = 0;
    try {
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            try {
                if (p.canSetExpression) { p.expression = String(code); cnt++; }
            } catch (e) {}
        }
    } catch (e2) { app.endUndoGroup(); return "err:" + e2.toString(); }
    app.endUndoGroup();
    if (!cnt) return "noprops";
    return "ok:" + cnt;
}

/* ============================================================
   SORT: автоматическая раскладка элементов проекта по папкам
   cfgJson — JSON-строка с именами папок и флагами.
============================================================ */
function MP_trim(s) { return String(s == null ? "" : s).replace(/^\s+/, "").replace(/\s+$/, ""); }
function MP_ext(name) { var s = String(name); var d = s.lastIndexOf("."); return d >= 0 ? s.substring(d + 1).toLowerCase() : ""; }

function MP_sortProject(cfgJson) {
    var proj = app.project;
    if (!proj) return "err:Нет открытого проекта";

    var cfg = {};
    try {
        if (typeof JSON !== "undefined" && JSON && JSON.parse) cfg = JSON.parse(cfgJson);
        else cfg = eval("(" + cfgJson + ")");
    } catch (eJ) { try { cfg = eval("(" + cfgJson + ")"); } catch (eJ2) { cfg = {}; } }

    function nm(k, def) { var v = cfg[k]; v = (v == null) ? "" : MP_trim(v); return v.length ? v : def; }
    var NAMES = {
        comps:   nm("comps", "Comps"),
        audio:   nm("audio", "Audio"),
        video:   nm("video", "Video"),
        images:  nm("images", "Images"),
        old:     nm("old", "Old Folders"),
        aipsd:   nm("aipsd", "AI & PSD"),
        ns:      nm("nullssolids", "Nulls & Solids"),
        missing: nm("missing", "Missing Content")
    };

    var ignore = {};
    if (cfg.ignore) {
        var parts = String(cfg.ignore).split(",");
        for (var p = 0; p < parts.length; p++) { var ti = MP_trim(parts[p]).toLowerCase(); if (ti) ignore[ti] = true; }
    }
    var removeOld    = !!cfg.removeOld;
    var removeUnused = !!cfg.removeUnused;
    var selectedOnly = !!cfg.selectedOnly;
    var subByExt     = !!cfg.subByExt;

    // область сортировки (если включено «только выбранная папка»)
    var scope = null;
    if (selectedOnly) {
        var sel = proj.selection;
        for (var s = 0; s < sel.length; s++) { if (sel[s] instanceof FolderItem) { scope = sel[s]; break; } }
        if (!scope) return "err:Включён режим «только выбранная папка», но папка не выбрана в панели Project";
    }
    var parentFor = scope ? scope : proj.rootFolder;

    function inScope(it) {
        if (!scope) return true;
        var f = it.parentFolder;
        while (f && f !== proj.rootFolder) { if (f === scope) return true; f = f.parentFolder; }
        return false;
    }
    function snapshot() { var a = []; for (var i = 1; i <= proj.numItems; i++) a.push(proj.item(i)); return a; }

    app.beginUndoGroup("Sort Project");
    var moved = 0, removed = 0;
    try {
        // 1) удалить неиспользуемый футаж
        if (removeUnused) {
            var arrU = snapshot();
            for (var u = arrU.length - 1; u >= 0; u--) {
                var iu = arrU[u];
                if (!(iu instanceof FootageItem)) continue;
                if (!inScope(iu)) continue;
                if (ignore[iu.name.toLowerCase()]) continue;
                var used = true; try { used = iu.usedIn.length > 0; } catch (eUu) { used = true; }
                if (!used) { try { iu.remove(); removed++; } catch (eUr) {} }
            }
        }

        // 2) снимок ПАПОК до создания категорий (это «старые папки»)
        var preFolders = [];
        var arr0 = snapshot();
        for (var f0 = 0; f0 < arr0.length; f0++) { if (arr0[f0] instanceof FolderItem) preFolders.push(arr0[f0]); }

        // ленивое создание/поиск папки-категории внутри parentFor
        var folders = {};
        function getFolder(name) {
            if (folders[name]) return folders[name];
            for (var k = 1; k <= proj.numItems; k++) {
                var it = proj.item(k);
                if (it instanceof FolderItem && it.name === name && it.parentFolder === parentFor) { folders[name] = it; return it; }
            }
            var nf = proj.items.addFolder(name);
            try { if (parentFor !== proj.rootFolder) nf.parentFolder = parentFor; } catch (ePf) {}
            folders[name] = nf;
            return nf;
        }

        // классификация айтема -> ключ категории
        function classify(it) {
            if (it instanceof CompItem) return "comps";
            if (!(it instanceof FootageItem)) return null;
            var miss = false; try { miss = it.footageMissing; } catch (eM) {}
            if (miss) return "missing";
            var src = null; try { src = it.mainSource; } catch (eS) {}
            if (src && (src instanceof SolidSource)) return "ns";
            var file = null; try { file = src ? src.file : null; } catch (eF) {}
            if (!file) return "ns";
            var ext = MP_ext(file.name);
            if (ext === "ai" || ext === "eps" || ext === "psd") return "aipsd";
            var isStill = false, hv = false, ha = false;
            try { isStill = src.isStill; } catch (e1) {}
            try { hv = it.hasVideo; } catch (e2) {}
            try { ha = it.hasAudio; } catch (e3) {}
            if (isStill) return "images";
            if (hv) return "video";
            if (ha) return "audio";
            return "images";
        }

        // подпапка по расширению внутри категории (find-or-create)
        function getSub(parent, name) {
            for (var ks = 1; ks <= proj.numItems; ks++) {
                var it2 = proj.item(ks);
                if (it2 instanceof FolderItem && it2.name === name && it2.parentFolder === parent) return it2;
            }
            var nfs = proj.items.addFolder(name);
            try { nfs.parentFolder = parent; } catch (eSub) {}
            return nfs;
        }

        // 3) разложить айтемы по категориям
        var arr = snapshot();
        for (var m = 0; m < arr.length; m++) {
            var it = arr[m];
            if (it instanceof FolderItem) continue;
            if (!inScope(it)) continue;
            if (ignore[it.name.toLowerCase()]) continue;
            var key = classify(it);
            if (!key) continue;
            var folder = getFolder(NAMES[key]);
            // подпапки по типу файла: Images → PNG/JPG/…, Video → MOV/MP4/… (кроме comps/missing/nulls&solids)
            var dest = folder;
            if (subByExt && key !== "comps" && key !== "missing" && key !== "ns") {
                var ex = "";
                var s3 = null; try { s3 = it.mainSource; } catch (e3a) {}
                var fl3 = null; try { fl3 = s3 ? s3.file : null; } catch (e3b) {}
                if (fl3) ex = MP_ext(fl3.name);
                if (!ex) ex = MP_ext(it.name);
                if (ex) dest = getSub(folder, ex.toUpperCase());
            }
            if (it.parentFolder === dest) continue;
            try { it.parentFolder = dest; moved++; } catch (eMove) {}
        }

        // 4) старые папки: пустые — удалить (если включено) / непустые — собрать в «Old Folders»
        var oldF = null;
        for (var of = 0; of < preFolders.length; of++) {
            var fld = preFolders[of];
            var isCat = false; for (var cn in folders) { if (folders[cn] === fld) { isCat = true; break; } }
            if (isCat) continue;
            if (ignore[fld.name.toLowerCase()]) continue;
            if (!inScope(fld)) continue;
            var cnt = 0; try { cnt = fld.numItems; } catch (eCnt) {}
            if (cnt === 0) {
                if (removeOld) { try { fld.remove(); removed++; } catch (eRf) {} }
            } else {
                if (!oldF) oldF = getFolder(NAMES.old);
                if (fld !== oldF && fld.parentFolder !== oldF) { try { fld.parentFolder = oldF; } catch (eMf) {} }
            }
        }

        // 5) убрать пустые категории, которые создали, но не заполнили
        for (var cn2 in folders) {
            var cf = folders[cn2];
            try { if (cf.numItems === 0) cf.remove(); } catch (eEc) {}
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:" + moved + "/" + removed;
}

/* ===== Текстовые пресеты: применение анимации к выделенным слоям (база) =====
   Надёжные ключи Transform/Opacity + Gaussian Blur с ease-out. Применяется как анимация всего слоя
   (посимвольный стаггер / печатная машинка / счётчик — отдельной доработкой). */
function MP_tfxParse(str) {
    var o = {};
    if (!str) return o;
    var parts = str.split(",");
    for (var i = 0; i < parts.length; i++) {
        var kv = parts[i].split(":");
        if (kv.length === 2) { var n = parseFloat(kv[1]); if (!isNaN(n)) o[kv[0]] = n; }
    }
    return o;
}
function MP_tfxEaseKey(prop, idx, easeIn, easeOut) {
    try {
        var dim = 1;
        try { var v = prop.keyValue(idx); if (v instanceof Array) dim = v.length; } catch (eD) {}
        var ins = [], outs = [];
        for (var d = 0; d < dim; d++) { ins.push(easeIn); outs.push(easeOut); }
        prop.setTemporalEaseAtKey(idx, ins, outs);
    } catch (e) {}
}
function MP_tfxKeys(prop, t1, v1, t2, v2) {
    prop.setValueAtTime(t1, v1);
    prop.setValueAtTime(t2, v2);
    var fast = new KeyframeEase(0, 16), slow = new KeyframeEase(0, 80);
    MP_tfxEaseKey(prop, prop.nearestKeyIndex(t1), fast, fast);   // старт — быстрый
    MP_tfxEaseKey(prop, prop.nearestKeyIndex(t2), slow, slow);   // финиш — плавное замедление (ease-out)
}
/* easing = тот же кубический безье, что и в превью (точное совпадение по ощущению) */
function MP_tfxCB() {
    return "function _cb(x,x1,y1,x2,y2){if(x<=0)return 0;if(x>=1)return 1;var t=x;for(var i=0;i<8;i++){var c=1-t;var bx=3*c*c*t*x1+3*c*t*t*x2+t*t*t;var dd=3*c*c*x1+6*c*t*(x2-x1)+3*t*t*(1-x2);if(Math.abs(bx-x)<1e-4)break;if(dd===0)break;t=t-(bx-x)/dd;if(t<0)t=0;if(t>1)t=1;}var c2=1-t;return 3*c2*c2*t*y1+3*c2*t*t*y2+t*t*t;}";
}
function MP_tfxBez(presetId) {
    var spring = (presetId === 'bounceup' || presetId === 'wordbounce' || presetId === 'bouncerotate' || presetId === 'softbounce');
    return spring ? "0.2,1.5,0.3,1" : "0.2,0.7,0.2,1";
}
/* маркер «TR In»/«TR Out» с длительностью = длине анимации */
function MP_tfxMarker(L, comment, t, dur) {
    try {
        var mp = L.property("ADBE Marker");
        var mv = new MarkerValue(comment);
        try { mv.duration = dur; } catch (eD) {}
        mp.setValueAtTime(t, mv);
    } catch (e) {}
}
/* progress-выражение, привязанное к маркеру (поиск по комментарию перебором — без textIndex) */
function MP_tfxLookup(mname) {
    return "var t0=0,d=1;var mk=thisLayer.marker;for(var i=1;i<=mk.numKeys;i++){if(mk.key(i).comment=='" + mname + "'){t0=mk.key(i).time;d=mk.key(i).duration;break;}}var p=(time-t0)/Math.max(0.001,d);p=p<0?0:(p>1?1:p);";
}
/* whole-layer пресеты (hero/iris/softbounce) и фолбэк для не-текстовых слоёв; mode: 'in'|'out' */
function MP_tfxWhole(L, presetId, P, mode) {
    var bz = MP_tfxBez(presetId);
    var mname = (mode === 'out') ? "TR Out" : "TR In";
    var base = MP_tfxCB() + MP_tfxLookup(mname);
    var fF = (mode === 'out') ? "var f=1-_cb(p," + bz + ");" : "var f=_cb(p," + bz + ");";
    var fO = (mode === 'out') ? "var fo=1-_cb(p,0.2,0.7,0.2,1);" : "var fo=_cb(p,0.2,0.7,0.2,1);";
    var tg = L.property("ADBE Transform Group");
    try { tg.property("ADBE Opacity").expression = base + fO + "value*fo"; } catch (eO) {}
    var s0 = null;
    if (P.scale != null) s0 = P.scale; else if (P.amp != null) s0 = Math.max(0, 100 - P.amp);
    if (s0 != null) { try { tg.property("ADBE Scale").expression = base + fF + "var k=(" + s0 + "+(100-" + s0 + ")*f)/100;value*k"; } catch (eS) {} }
    if (P.dist != null) { try { tg.property("ADBE Position").expression = base + fF + "var o=(value.length>2)?[0," + P.dist + "*(1-f),0]:[0," + P.dist + "*(1-f)];value+o"; } catch (eP) {} }
    if (P.rot != null) { try { tg.property("ADBE Rotate Z").expression = base + fF + "value+(" + P.rot + "*(1-f))"; } catch (eR) {} }
    if (P.blur != null && P.blur > 0) {
        try {
            var fx = L.property("ADBE Effect Parade"), g;
            try { g = fx.addProperty("ADBE Gaussian Blur 2"); } catch (eG) { g = fx.addProperty("ADBE Gaussian Blur"); }
            g.property(1).expression = base + fF + "(" + P.blur + "*(1-f))";
        } catch (eB) {}
    }
}
/* per-char lookup: ищем маркер, выводим cd (длит. буквы), sg (сдвиг), delay, e — всё привязано к маркеру */
function MP_tfxLk(mname, N, i, r) {
    return "var t0=0,D=1;var mk=thisLayer.marker;for(var j=1;j<=mk.numKeys;j++){if(mk.key(j).comment=='" + mname + "'){t0=mk.key(j).time;D=mk.key(j).duration;break;}}var N=" + N + ",i=" + i + ",r=" + r + ";var cd=D/(1+(N-1)*r);var sg=r*cd;var delay=t0+i*sg;var e=time-delay;";
}
function MP_tfxF(mname, curve, N, i, r, mode) {
    var f = (mode === 'out')
        ? "var f=e<=0?1:(e>=cd?0:1-_cb(e/cd," + curve + "));"
        : "var f=e<=0?0:(e>=cd?1:_cb(e/cd," + curve + "));";
    return MP_tfxLk(mname, N, i, r) + f;
}
/* посимвольный пресет: ОДИН аниматор на весь текст.
   Свойства аниматора держат «стартовые» значения, а посимвольный прогресс задаёт
   Amount у Expression Selector — ТОЛЬКО там доступны textIndex/textTotal
   (в выражениях самих свойств Position/Opacity/Scale их нет). */
function MP_tfxSetAnimProps(pr, presetId, P) {
    try { pr.addProperty("ADBE Text Opacity").setValue(0); } catch (eOp) {}   // гаснут все пресеты
    if (presetId === 'slideup' || presetId === 'bounceup') {
        var dist = (P.dist != null ? P.dist : (presetId === 'bounceup' ? 80 : 60));
        try { pr.addProperty("ADBE Text Position 3D").setValue([0, dist, 0]); } catch (e1) {}
    } else if (presetId === 'wordstagger') {
        var wb = (P.blur != null ? P.blur : 8);
        try { pr.addProperty("ADBE Text Position 3D").setValue([16, 0, 0]); } catch (e3) {}
        try { pr.addProperty("ADBE Text Blur").setValue([wb, wb]); } catch (e5) {}
    } else if (presetId === 'letterstagger') {
        var ls = (P.scale != null ? P.scale : 80);
        try { pr.addProperty("ADBE Text Position 3D").setValue([0, 10, 0]); } catch (e6) {}
        try { pr.addProperty("ADBE Text Scale 3D").setValue([ls, ls, 100]); } catch (e7) {}
    } else if (presetId === 'wordbounce' || presetId === 'burst') {
        var s0 = (presetId === 'burst') ? (P.scale != null ? P.scale : 140) : Math.max(0, 100 - (P.amp != null ? P.amp : 40));
        try { pr.addProperty("ADBE Text Scale 3D").setValue([s0, s0, 100]); } catch (e9) {}
    } else if (presetId === 'bouncerotate') {
        var r0 = (P.rot != null ? P.rot : 25);
        try { pr.addProperty("ADBE Text Rotation").setValue(r0); } catch (e11) {}
    }
    // typewriter: достаточно Opacity=0 — жёсткое появление задаёт сам Amount-селектор
}
/* выражение Amount у Expression Selector: посимвольный прогресс по textIndex/textTotal,
   привязка к маркеру TR In/Out; кривая та же, что в превью. Amount: 100% = «стартовое» состояние, 0% = базовое. */
function MP_tfxSelAmount(mname, curve, r, mode, presetId) {
    var lk = "var t0=0,D=1;var mk=thisLayer.marker;for(var j=1;j<=mk.numKeys;j++){if(mk.key(j).comment=='" + mname + "'){t0=mk.key(j).time;D=mk.key(j).duration;break;}}" +
        "var N=textTotal,i=textIndex-1,r=" + r + ";if(N<1)N=1;var cd=D/(1+(N-1)*r);var sg=r*cd;var delay=t0+i*sg;var e=time-delay;";
    if (presetId === 'typewriter') {
        return lk + (mode === 'out' ? "(e>0?100:0)" : "(e>0?0:100)");
    }
    var prog = "var prog=e<=0?0:(e>=cd?1:_cb(e/cd," + curve + "));";
    return MP_tfxCB() + lk + prog + (mode === 'out' ? "prog*100" : "(1-prog)*100");
}
function MP_tfxAnimator(L, presetId, P, mode, N) {
    var animators = L.property("ADBE Text Properties").property("ADBE Text Animators");
    var bz = MP_tfxBez(presetId);
    var mname = (mode === 'out') ? "TR Out" : "TR In";
    var dur = P.dur ? P.dur : 0.8;
    var stag = (P.stag != null ? P.stag : (presetId === 'burst' ? 0.02 : 0.04));
    var r = stag / Math.max(0.001, dur);

    var anim = animators.addProperty("ADBE Text Animator");
    try { anim.name = "MP " + presetId + " " + mode; } catch (eN2) {}
    var pr = anim.property("ADBE Text Animator Properties");
    MP_tfxSetAnimProps(pr, presetId, P);

    // селекторы: убираем дефолтный Range, ставим ОДИН Expression Selector с посимвольным Amount
    var selectors = anim.property("ADBE Text Selectors");
    for (var z = selectors.numProperties; z >= 1; z--) { try { selectors.property(z).remove(); } catch (eRm) {} }
    var es = null;
    try { es = selectors.addProperty("ADBE Text Expressible Selector"); } catch (eES) { es = null; }
    if (es) {
        var amt = null;
        try { amt = es.property("ADBE Text Expressible Amount"); } catch (eAm) {}
        if (!amt) { try { for (var q = 1; q <= es.numProperties; q++) { var pp = es.property(q); if (pp && pp.canSetExpression) { amt = pp; break; } } } catch (eFind) {} }
        if (amt) { try { amt.expression = MP_tfxSelAmount(mname, bz, r, mode, presetId); } catch (eEx) {} }
    } else {
        try { anim.remove(); } catch (eDel) {}                 // Expression Selector недоступен — откат к по-символьному способу
        MP_tfxAnimatorLegacy(L, presetId, P, mode, N);
    }
}
/* запасной путь: по аниматору на каждый символ (жёсткий range-селектор по индексу) */
function MP_tfxAnimatorLegacy(L, presetId, P, mode, N) {
    if (N < 1) N = 1;
    if (N > 80) N = 80;
    var animators = L.property("ADBE Text Properties").property("ADBE Text Animators");
    var bz = MP_tfxBez(presetId);
    var mname = (mode === 'out') ? "TR Out" : "TR In";
    var dur = P.dur ? P.dur : 0.8;
    var stag = (P.stag != null ? P.stag : (presetId === 'burst' ? 0.02 : 0.04));
    var r = stag / Math.max(0.001, dur);
    for (var i = 0; i < N; i++) {
        var anim = animators.addProperty("ADBE Text Animator");
        try { anim.name = "MP " + presetId + " " + mode + " " + (i + 1); } catch (eN2) {}
        var pr = anim.property("ADBE Text Animator Properties");
        var fF = MP_tfxCB() + MP_tfxF(mname, bz, N, i, r, mode);
        var fO = MP_tfxCB() + MP_tfxF(mname, "0.2,0.7,0.2,1", N, i, r, mode);
        if (presetId === 'slideup' || presetId === 'bounceup') {
            var dist = (P.dist != null ? P.dist : (presetId === 'bounceup' ? 80 : 60));
            try { pr.addProperty("ADBE Text Position 3D").expression = fF + "[0," + dist + "*(1-f),0]"; } catch (e1) {}
            try { pr.addProperty("ADBE Text Opacity").expression = fO + "f*100"; } catch (e2) {}
        } else if (presetId === 'wordstagger') {
            var wb = (P.blur != null ? P.blur : 8);
            try { pr.addProperty("ADBE Text Position 3D").expression = fF + "[16*(1-f),0,0]"; } catch (e3) {}
            try { pr.addProperty("ADBE Text Opacity").expression = fO + "f*100"; } catch (e4) {}
            try { pr.addProperty("ADBE Text Blur").expression = fO + "var b=" + wb + "*(1-f);[b,b]"; } catch (e5) {}
        } else if (presetId === 'letterstagger') {
            var ls = (P.scale != null ? P.scale : 80);
            try { pr.addProperty("ADBE Text Position 3D").expression = fF + "[0,10*(1-f),0]"; } catch (e6) {}
            try { pr.addProperty("ADBE Text Scale 3D").expression = fF + "var s=" + ls + "+(100-" + ls + ")*f;[s,s,100]"; } catch (e7) {}
            try { pr.addProperty("ADBE Text Opacity").expression = fO + "f*100"; } catch (e8) {}
        } else if (presetId === 'wordbounce' || presetId === 'burst') {
            var s0 = (presetId === 'burst') ? (P.scale != null ? P.scale : 140) : Math.max(0, 100 - (P.amp != null ? P.amp : 40));
            try { pr.addProperty("ADBE Text Scale 3D").expression = fF + "var s=" + s0 + "+(100-" + s0 + ")*f;[s,s,100]"; } catch (e9) {}
            try { pr.addProperty("ADBE Text Opacity").expression = fO + "f*100"; } catch (e10) {}
        } else if (presetId === 'bouncerotate') {
            var r0 = (P.rot != null ? P.rot : 25);
            try { pr.addProperty("ADBE Text Rotation").expression = fF + "(" + r0 + "*(1-f))"; } catch (e11) {}
            try { pr.addProperty("ADBE Text Opacity").expression = fO + "f*100"; } catch (e12) {}
        } else {
            try { pr.addProperty("ADBE Text Opacity").expression = MP_tfxLk(mname, N, i, r) + (mode === 'out' ? "(e>0?0:100)" : "(e>0?100:0)"); } catch (e13) {}
        }
        var selectors = anim.property("ADBE Text Selectors");
        var sel = (selectors.numProperties >= 1) ? selectors.property(1) : selectors.addProperty("ADBE Text Selector");
        try { sel.property("ADBE Text Percent Start").setValue(i * 100 / N); } catch (eSs) {}
        try { sel.property("ADBE Text Percent End").setValue((i + 1) * 100 / N); } catch (eEe) {}
        try { sel.property("ADBE Text Range Advanced").property("ADBE Text Selector Smoothness").setValue(0); } catch (eSm) {}
    }
}

/* счётчик: Slider Control + выражение на Source Text (нужен текстовый слой) */
function MP_tfxCounter(L, P, t0, t1) {
    if (!(L instanceof TextLayer)) return false;
    try {
        var fx = L.property("ADBE Effect Parade");
        var s = fx.addProperty("ADBE Slider Control");
        try { s.name = "MP Counter"; } catch (eNm) {}
        MP_tfxKeys(s.property(1), t0, (P.from != null ? P.from : 0), t1, (P.to != null ? P.to : 100));
        var src = L.property("ADBE Text Properties").property("ADBE Text Document");
        src.expression = 'Math.round(effect("MP Counter")("Slider")) + ""';
        return true;
    } catch (e) { return false; }
}

function MP_applyTextPreset(presetId, paramStr, mode) {
    mode = (mode === 'out' || mode === 'both') ? mode : 'in';
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "err:Open a composition first";
    var sel = comp.selectedLayers;
    if (!sel || sel.length === 0) return "err:Select one or more layers";
    var P = MP_tfxParse(paramStr);
    var dur = P.dur ? P.dur : 0.8;
    var stag = (P.stag != null ? P.stag : (presetId === 'burst' ? 0.02 : 0.04));
    var perChar = { slideup: 1, bounceup: 1, wordstagger: 1, letterstagger: 1, wordbounce: 1, burst: 1, bouncerotate: 1, typewriter: 1 };
    var doIn = (mode === 'in' || mode === 'both');
    var doOut = (mode === 'out' || mode === 'both');
    app.beginUndoGroup("Apply text " + mode + ": " + presetId);
    var done = 0;
    try {
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i];
            var nChars = 8;
            try { if (L instanceof TextLayer) { var tx = L.property("ADBE Text Properties").property("ADBE Text Document").value.text; if (tx && tx.length > 0) nChars = tx.length; } } catch (eTx) {}
            var animLen = dur + Math.max(0, nChars - 1) * stag;
            if (presetId === 'counter') {
                if (doIn) { MP_tfxMarker(L, "TR In", comp.time, dur); if (!MP_tfxCounter(L, P, comp.time, comp.time + dur)) MP_tfxWhole(L, presetId, P, 'in'); }
                done++; continue;
            }
            if (doIn) {
                MP_tfxMarker(L, "TR In", comp.time, animLen);
                if (perChar[presetId] && (L instanceof TextLayer)) MP_tfxAnimator(L, presetId, P, 'in', nChars);
                else MP_tfxWhole(L, presetId, P, 'in');
            }
            if (doOut) {
                var outStart = comp.time;
                try { outStart = Math.max(comp.time, L.outPoint - animLen); } catch (eOp) {}
                MP_tfxMarker(L, "TR Out", outStart, animLen);
                if (perChar[presetId] && (L instanceof TextLayer)) MP_tfxAnimator(L, presetId, P, 'out', nChars);
                else MP_tfxWhole(L, presetId, P, 'out');
            }
            done++;
        }
    } catch (e) {
        app.endUndoGroup();
        return "err:" + e.toString();
    }
    app.endUndoGroup();
    return "ok:Applied " + mode + " to " + done + " layer(s)";
}


/* ============================================================
   Текстовая анимация с таймлайна: захват -> пресет, и применение.
   В ExtendScript нет JSON.stringify — пишем свой сериализатор (MP_json),
   парсинг данных при применении делаем через JSON.parse / eval-фолбэк.
============================================================ */
function MP_jstr(s) {
    s = String(s);
    var out = '"';
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i), code = s.charCodeAt(i);
        if (c === '"') out += '\\"';
        else if (c === '\\') out += '\\\\';
        else if (c === '\n') out += '\\n';
        else if (c === '\r') out += '\\r';
        else if (c === '\t') out += '\\t';
        else if (code < 32) { var h = code.toString(16); while (h.length < 4) h = '0' + h; out += '\\u' + h; }
        else out += c;
    }
    return out + '"';
}
function MP_json(o) {
    var ty = typeof o;
    if (o === null || o === undefined) return "null";
    if (ty === "number") return isFinite(o) ? String(o) : "null";
    if (ty === "boolean") return o ? "true" : "false";
    if (ty === "string") return MP_jstr(o);
    if (o instanceof Array) {
        var a = [];
        for (var i = 0; i < o.length; i++) a.push(MP_json(o[i]));
        return "[" + a.join(",") + "]";
    }
    if (ty === "object") {
        var p = [];
        for (var k in o) { if (o.hasOwnProperty(k)) p.push(MP_jstr(k) + ":" + MP_json(o[k])); }
        return "{" + p.join(",") + "}";
    }
    return "null";
}
function MP_parseArg(arg) {
    var v = null;
    try { if (typeof JSON !== "undefined" && JSON && JSON.parse) v = JSON.parse(arg); else v = eval("(" + arg + ")"); }
    catch (e) { try { v = eval("(" + arg + ")"); } catch (e2) { v = null; } }
    return v;
}

/* значение свойства -> число или массив чисел (TextDocument и пр. -> null) */
function MP_capVal(v) {
    if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(v[i]); return a; }
    if (typeof v === "number") return v;
    return null;
}
function MP_easeArr(arr) {
    var o = [];
    try { for (var i = 0; i < arr.length; i++) o.push([arr[i].speed, arr[i].influence]); } catch (e) {}
    return o;
}
/* сериализуем одно свойство: базовое значение, выражение, кейфреймы (время/значение/интерполяция/ease/тангенсы) */
function MP_capProp(p) {
    var out = { mn: "", ex: "", bv: null, sp: false, keys: [] };
    try { out.mn = p.matchName; } catch (e) {}
    try { if (p.canSetExpression && p.expression && p.expression !== "") out.ex = p.expression; } catch (e) {}
    try { out.bv = MP_capVal(p.value); } catch (e) {}
    try { out.sp = !!p.isSpatial; } catch (e) {}
    var nk = 0; try { nk = p.numKeys; } catch (e) {}
    for (var i = 1; i <= nk; i++) {
        var k = {};
        try { k.t = p.keyTime(i); } catch (e) { continue; }
        try { k.v = MP_capVal(p.keyValue(i)); } catch (e) { k.v = null; }
        try { k.ii = p.keyInInterpolationType(i); k.oi = p.keyOutInterpolationType(i); } catch (e) {}
        try { k.ie = MP_easeArr(p.keyInTemporalEase(i)); k.oe = MP_easeArr(p.keyOutTemporalEase(i)); } catch (e) {}
        if (out.sp) { try { k.it = MP_capVal(p.keyInSpatialTangent(i)); k.ot = MP_capVal(p.keyOutSpatialTangent(i)); } catch (e) {} }
        out.keys.push(k);
    }
    return out;
}
function MP_propHasData(o) { return (o.keys && o.keys.length) || (o.ex && o.ex.length); }

function MP_captureTextAnim() {
    var comp = MP_getComp();
    if (!comp) return "err:Open a composition first";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "nosel";
    var L = sel[0];

    var data = { src: "", fps: 30, t0: 0, transform: [], animators: [] };
    try { data.src = L.name; } catch (e) {}
    try { data.fps = comp.frameRate; } catch (e) {}

    var minT = Number.MAX_VALUE, hasKey = false;
    function noteKeys(co) { for (var i = 0; i < co.keys.length; i++) { var tt = co.keys[i].t; if (typeof tt === "number") { hasKey = true; if (tt < minT) minT = tt; } } }

    // Transform-группа (стандартные свойства)
    try {
        var tg = L.property("ADBE Transform Group");
        var TN = ["ADBE Anchor Point", "ADBE Position", "ADBE Scale", "ADBE Rotate Z", "ADBE Opacity"];
        for (var ti = 0; ti < TN.length; ti++) {
            var pp = null; try { pp = tg.property(TN[ti]); } catch (e) {}
            if (!pp) continue;
            var co = MP_capProp(pp);
            if (MP_propHasData(co)) { data.transform.push(co); noteKeys(co); }
        }
    } catch (e) {}

    // Текстовые аниматоры
    try {
        var anims = L.property("ADBE Text Properties").property("ADBE Text Animators");
        var an = 0; try { an = anims.numProperties; } catch (e) {}
        for (var ai = 1; ai <= an; ai++) {
            var A = null; try { A = anims.property(ai); } catch (e) { continue; }
            if (!A) continue;
            var ablk = { name: "", props: [], selectors: [] };
            try { ablk.name = A.name; } catch (e) {}
            var apg = null; try { apg = A.property("ADBE Text Animator Properties"); } catch (e) {}
            if (apg) {
                var pn = 0; try { pn = apg.numProperties; } catch (e) {}
                for (var pi = 1; pi <= pn; pi++) {
                    var P = null; try { P = apg.property(pi); } catch (e) { continue; }
                    if (!P) continue;
                    if (P.propertyType !== PropertyType.PROPERTY) continue;
                    var co2 = MP_capProp(P);
                    if (MP_propHasData(co2) || co2.bv != null) { ablk.props.push(co2); noteKeys(co2); }
                }
            }
            var selg = null; try { selg = A.property("ADBE Text Selectors"); } catch (e) {}
            if (selg) {
                var sn = 0; try { sn = selg.numProperties; } catch (e) {}
                for (var si = 1; si <= sn; si++) {
                    var S = null; try { S = selg.property(si); } catch (e) { continue; }
                    if (!S) continue;
                    var sblk = { start: null, end: null, offset: null };
                    try { sblk.start = MP_capProp(S.property("ADBE Text Percent Start")); if (sblk.start) noteKeys(sblk.start); } catch (e) {}
                    try { sblk.end = MP_capProp(S.property("ADBE Text Percent End")); if (sblk.end) noteKeys(sblk.end); } catch (e) {}
                    var off = null;
                    try { off = S.property("ADBE Text Percent Offset"); } catch (e) {}
                    if (!off) { try { off = S.property("ADBE Text Index Offset"); } catch (e) {} }
                    if (off) { try { sblk.offset = MP_capProp(off); if (sblk.offset) noteKeys(sblk.offset); } catch (e) {} }
                    ablk.selectors.push(sblk);
                }
            }
            if (ablk.props.length || ablk.selectors.length) data.animators.push(ablk);
        }
    } catch (e) {}

    if (!data.transform.length && !data.animators.length) return "noanim";
    data.t0 = hasKey ? minT : 0;
    return "ok:" + MP_json(data);
}

/* пересобираем свойство по сериализованным данным со сдвигом времени (ts — масштаб, base — старт) */
function MP_rebuildProp(p, co, t0, base, ts) {
    if (!p || !co) return;
    if (co.ex) { try { p.expression = String(co.ex); } catch (e) {} }
    if (co.keys && co.keys.length) {
        var times = [];
        for (var i = 0; i < co.keys.length; i++) {
            var k = co.keys[i];
            if (k.v === null || k.v === undefined) continue;
            var tt = base + (k.t - t0) * ts;
            try { p.setValueAtTime(tt, k.v); times.push({ tt: tt, k: k }); } catch (e) {}
        }
        for (var j = 0; j < times.length; j++) {
            var tt2 = times[j].tt, k2 = times[j].k, idx = 0;
            try { idx = p.nearestKeyIndex(tt2); } catch (e) { continue; }
            try { if (k2.ii != null && k2.oi != null) p.setInterpolationTypeAtKey(idx, k2.ii, k2.oi); } catch (e) {}
            try {
                if (k2.ie && k2.oe) {
                    var ins = [], outs = [], d;
                    for (d = 0; d < k2.ie.length; d++) ins.push(new KeyframeEase(k2.ie[d][0], k2.ie[d][1]));
                    for (d = 0; d < k2.oe.length; d++) outs.push(new KeyframeEase(k2.oe[d][0], k2.oe[d][1]));
                    p.setTemporalEaseAtKey(idx, ins, outs);
                }
            } catch (e) {}
            try { if (co.sp && k2.it && k2.ot) p.setSpatialTangentsAtKey(idx, k2.it, k2.ot); } catch (e) {}
        }
    } else if (co.bv != null && !co.ex) {
        try { p.setValue(co.bv); } catch (e) {}
    }
}

function MP_applyCapturedTextAnim(arg) {
    var payload = MP_parseArg(arg);
    if (!payload || !payload.cap) return "err:bad data";
    var cap = payload.cap;
    var ts = (payload.ts != null) ? payload.ts : 1;
    var delay = (payload.delay != null) ? payload.delay : 0;

    var comp = MP_getComp();
    if (!comp) return "err:Open a composition first";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "nosel";

    var t0 = cap.t0 || 0;
    var base = comp.time + delay;

    app.beginUndoGroup("Apply Captured Text Anim");
    var done = 0;
    try {
        for (var s = 0; s < sel.length; s++) {
            var L = sel[s];
            // Transform
            if (cap.transform && cap.transform.length) {
                var tg = null; try { tg = L.property("ADBE Transform Group"); } catch (e) {}
                if (tg) {
                    for (var ti = 0; ti < cap.transform.length; ti++) {
                        var co = cap.transform[ti], p = null;
                        try { p = tg.property(co.mn); } catch (e) {}
                        if (p) MP_rebuildProp(p, co, t0, base, ts);
                    }
                }
            }
            // Аниматоры (только для текстовых слоёв)
            if (cap.animators && cap.animators.length && (L instanceof TextLayer)) {
                var anims = null; try { anims = L.property("ADBE Text Properties").property("ADBE Text Animators"); } catch (e) {}
                if (anims) {
                    for (var ai = 0; ai < cap.animators.length; ai++) {
                        var ab = cap.animators[ai];
                        var A = anims.addProperty("ADBE Text Animator");
                        try { if (ab.name) A.name = "MP " + ab.name; } catch (e) {}
                        var apg = A.property("ADBE Text Animator Properties");
                        for (var pi = 0; pi < ab.props.length; pi++) {
                            var pc = ab.props[pi], np = null;
                            try { np = apg.addProperty(pc.mn); } catch (e) { np = null; }
                            if (np) MP_rebuildProp(np, pc, t0, base, ts);
                        }
                        if (ab.selectors && ab.selectors.length) {
                            var selg = A.property("ADBE Text Selectors");
                            var S = (selg.numProperties >= 1) ? selg.property(1) : selg.addProperty("ADBE Text Selector");
                            var sc = ab.selectors[0];
                            if (sc.start) { try { MP_rebuildProp(S.property("ADBE Text Percent Start"), sc.start, t0, base, ts); } catch (e) {} }
                            if (sc.end) { try { MP_rebuildProp(S.property("ADBE Text Percent End"), sc.end, t0, base, ts); } catch (e) {} }
                            if (sc.offset) {
                                var off = null;
                                try { off = S.property("ADBE Text Percent Offset"); } catch (e) {}
                                if (!off) { try { off = S.property("ADBE Text Index Offset"); } catch (e) {} }
                                if (off) { try { MP_rebuildProp(off, sc.offset, t0, base, ts); } catch (e) {} }
                            }
                        }
                    }
                }
            }
            done++;
        }
    } catch (e) { app.endUndoGroup(); return "err:" + e.toString(); }
    app.endUndoGroup();
    if (!done) return "nosel";
    return "ok:Applied to " + done + " layer(s)";
}

/* ============================================================
   Шрифты: список (app.fonts, AE 2022+) и применение по PostScript-имени
============================================================ */
function MP_listFonts() {
    var out = [];
    try {
        if (app.fonts && app.fonts.allFonts) {
            var all = app.fonts.allFonts, seen = {};
            for (var i = 0; i < all.length; i++) {
                var f = all[i], fam = "", ps = "", sty = "";
                try { fam = f.familyName; } catch (e) {}
                try { ps = f.postScriptName; } catch (e) {}
                try { sty = f.styleName; } catch (e) {}
                if (!fam) continue;
                var isReg = /regular|book|roman|medium|^$/i.test(sty || "");
                if (!seen[fam] || (isReg && !seen[fam].reg)) seen[fam] = { fam: fam, ps: ps, sty: sty, reg: isReg };
            }
            for (var k in seen) { if (seen.hasOwnProperty(k)) out.push({ family: seen[k].fam, ps: seen[k].ps, style: seen[k].sty }); }
        }
    } catch (e) {}
    return MP_json({ ok: true, fonts: out });
}
function MP_fontPsByFamily(fam) {
    try {
        if (app.fonts && app.fonts.allFonts) {
            var all = app.fonts.allFonts, first = null;
            for (var i = 0; i < all.length; i++) {
                var f = all[i], ff = "";
                try { ff = f.familyName; } catch (e) {}
                if (ff === fam) {
                    var sty = ""; try { sty = f.styleName; } catch (e) {}
                    if (/regular|book|roman/i.test(sty)) { try { return f.postScriptName; } catch (e) {} }
                    if (!first) { try { first = f.postScriptName; } catch (e) {} }
                }
            }
            if (first) return first;
        }
    } catch (e) {}
    return null;
}
function MP_applyFont(ps, family) {
    var comp = MP_getComp();
    if (!comp) return "err:Open a composition first";
    var sel = comp.selectedLayers;
    if (!sel || !sel.length) return "nosel";
    var useps = (ps && String(ps).length) ? String(ps) : MP_fontPsByFamily(family);
    if (!useps) useps = String(family || "");
    if (!useps.length) return "err:No font";
    app.beginUndoGroup("Apply Font");
    var n = 0;
    try {
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i];
            try {
                if (L instanceof TextLayer) {
                    var doc = L.property("ADBE Text Properties").property("ADBE Text Document");
                    var v = doc.value; v.font = useps; doc.setValue(v); n++;
                }
            } catch (e) {}
        }
    } catch (e2) { app.endUndoGroup(); return "err:" + e2.toString(); }
    app.endUndoGroup();
    if (!n) return "notext";
    return "ok:" + n;
}
