// ============================================================
//  MF Library — main.js  v3.0
//  • Темы интерфейса (серая PR / оранжевая / светлая / свой цвет)
//  • Клик по звуку = мгновенное воспроизведение
//  • Резайзер ширины сайдбара
//  • Панель плеера: волна, луп, громкость, pitch, reverse, seek
//  • Node.js-сканирование + индекс (из v2)
// ============================================================

var csInterface = new CSInterface();

// ── Явная загрузка host.jsx ───────────────────────────────────────────
// Premiere 2026 (переход на UXP) не всегда подхватывает <ScriptPath> из
// манифеста: панель грузится, а ExtendScript-скрипт — нет, и тогда любой
// вызов host-функции возвращает «EvalScript error.». Поэтому грузим host.jsx
// сами через встроенный $.evalFile (он доступен и без host.jsx) и проверяем
// готовность пробой mfPing(). Идемпотентно: повторная загрузка просто
// переопределяет функции.
var hostReady = false;
function loadHostJSX(cb) {
  var ext = "";
  try { ext = csInterface.getSystemPath(SystemPath.EXTENSION); } catch (e) { ext = ""; }
  if (!ext) { if (cb) cb(false, "no_ext_path"); return; }
  var jsxPath = (ext + "/jsx/host.jsx").replace(/\\/g, "/").replace(/"/g, '\\"');
  var probe =
    '(function(){try{$.evalFile("' + jsxPath + '");' +
    'return (typeof mfPing==="function")?mfPing():"NO_PING_AFTER_LOAD";}' +
    'catch(e){return "EVALFILE_FAIL:"+e.toString();}})()';
  csInterface.evalScript(probe, function (res) {
    hostReady = (res === "MFLIB_HOST_OK");
    if (cb) cb(hostReady, res);
  });
}
// Гарантировать, что host.jsx загружен, затем выполнить cb(ok, res).
function ensureHost(cb) {
  if (hostReady) { if (cb) cb(true, "cached"); return; }
  loadHostJSX(cb);
}

// ── Node.js (если доступен) ───────────────────
var nodeFs = null, nodePath = null, nodeOs = null;
(function () {
  try {
    var req = null;
    if (typeof window.cep_node !== "undefined" && window.cep_node.require) {
      req = window.cep_node.require;
    } else if (typeof require === "function") {
      req = require;
    }
    if (req) { nodeFs = req("fs"); nodePath = req("path"); nodeOs = req("os"); }
  } catch (e) { nodeFs = null; nodePath = null; nodeOs = null; }
})();

var SUPPORTED_EXTS = { wav: 1, mp3: 1, aiff: 1, aif: 1, aac: 1 };
var RENDER_CHUNK   = 300;
var DIRS_PER_TICK  = 40;

var state = {
  roots: [],          // массив корневых папок
  rootPath: "",       // последний добавленный корень (для совместимости)
  currentPath: "", history: [],
  allFolders: [], currentSfx: [], filteredSfx: [],
  renderedCount: 0, selectedFile: null, searchQuery: "",
  displayedFolderPath: "",
  lastFolderPath: "",  // последняя реальная папка (для возврата из избранного/коллекций)
  viewMode: "list",   // "list" | "grid"
  gridDir:  "h",      // "h" — строки (скролл вниз), "v" — колонки (скролл вбок)
  gridCols: 4,        // дискретный шаг сетки: 2..8 колонок/рядов
  folderMode: "tree", // "tree" — даблклик раскрывает, "nav" — заходит внутрь
  folderExpand: "single", // "single" — открыта одна ветка, "multi" — сколько угодно
  tab: "folders",     // "folders" | "favs" | "cols"
  favFolder: "__all__", // фильтр избранного по папке-источнику ("__all__" = все)
  selPaths: {},       // мультивыделение в дереве (path → true)
  selAnchor: null,    // якорь для Shift-выделения
  openCol: null,      // id раскрытой коллекции
  colView: null,      // { colId, childKey } — что показано справа из коллекции
  mode: "sfx",        // "sfx" | "fx" — верхний переключатель режимов
  fxLayout: "tab",    // всегда отдельная вкладка (выбор раскладки убран из настроек)
  fxLabels: "full",   // "full" — полные названия | "abbr" — только аббревиатуры
  fxSize: 1,          // 0..3 — размер кнопок эффектов (вкладочный режим)
  fxDockH: 150,       // высота нижней панели эффектов, px
  fxBoard: {},        // раскладка доски: abbr -> {x, y, size}
  fxTileSize: 64,     // базовый размер плитки (слайдер задаёт всем сразу)
  fxEdit: false,      // режим редактирования доски (карандаш): таскать/менять размер
  fxSection: "fx",    // "fx" — доска эффектов | "presets" — пресеты голоса
  searchActive: false,// поиск активен → дерево слева в режиме фильтра
};

var favorites = {};   // path → { name, ext, path } помеченные звёзды
var collections = []; // [{ id, name, folders:[{name,path}], sounds:[{name,path,ext,dir}] }]
var folderColors = {}; // path -> hex цвет иконки папки

var index = { ready: false, building: false, files: [], folders: {}, scanned: 0 };

var STORAGE_ROOT  = "sfxlibrary_root_path_v2"; // legacy single-root
var STORAGE_ROOTS = "mflib_roots";
var STORAGE_FAVS  = "mflib_favorites";
var STORAGE_COLS  = "mflib_collections";
var STORAGE_THEME = "mflib_theme";
var STORAGE_SIDEW = "mflib_sidebar_w";
var STORAGE_VIEW  = "mflib_view";
var STORAGE_FCOLORS = "mflib_folder_colors";
var STORAGE_FXBOARD = "mflib_fx_board";

// ══════════════════════════════════════════════
//  ТЕМЫ
// ══════════════════════════════════════════════
var THEMES = {
  gray: {
    bg:"#1e1e1e", panel:"#262626", sidebar:"#222222", border:"#3a3a3a",
    accent:"#2d8ceb", accentDim:"#1f6ab8",
    text:"#dcdcdc", textDim:"#8a8a8a", textMuted:"#5c5c5c",
    selectedBg:"#2a4a70", hover:"#2e2e2e",
    tableHead:"#232323", scroll:"#454545",
    overlay:"rgba(30,30,30,0.95)", selectedText:"#ffffff"
  },
  orange: {
    bg:"#211e1c", panel:"#2b2724", sidebar:"#252220", border:"#3b3531",
    accent:"#e0744e", accentDim:"#b8532f",
    text:"#e3ddd8", textDim:"#8a817a", textMuted:"#5f5852",
    selectedBg:"#4d3326", hover:"#332e2a",
    tableHead:"#262220", scroll:"#4a423c",
    overlay:"rgba(33,30,28,0.95)", selectedText:"#ffffff"
  },
  light: {
    bg:"#f0eeec", panel:"#fafafa", sidebar:"#f3f1ef", border:"#d8d4d0",
    accent:"#e0744e", accentDim:"#c45c38",
    text:"#2b2b2b", textDim:"#6e6e6e", textMuted:"#9c9691",
    selectedBg:"#f4d6c8", hover:"#e7e4e1",
    tableHead:"#eceae8", scroll:"#c4c0bc",
    overlay:"rgba(240,238,236,0.96)", selectedText:"#7a3318"
  }
};

function applyThemeVars(t) {
  var r = document.documentElement.style;
  r.setProperty("--bg", t.bg);
  r.setProperty("--panel", t.panel);
  r.setProperty("--sidebar-bg", t.sidebar);
  r.setProperty("--border", t.border);
  r.setProperty("--accent", t.accent);
  r.setProperty("--accent-dim", t.accentDim);
  r.setProperty("--text", t.text);
  r.setProperty("--text-dim", t.textDim);
  r.setProperty("--text-muted", t.textMuted);
  r.setProperty("--selected-bg", t.selectedBg);
  r.setProperty("--selected-border", t.accent);
  r.setProperty("--hover-bg", t.hover);
  r.setProperty("--table-head", t.tableHead);
  r.setProperty("--scroll", t.scroll);
  r.setProperty("--overlay-bg", t.overlay);
  r.setProperty("--selected-text", t.selectedText);

  // Бейджи форматов — от акцента темы:
  // WAV = акцент, MP3 = акцент со сдвигом тона, AIFF = ещё сдвиг
  var light = luminance(t.bg) > 0.5;
  function badge(hex) {
    return {
      bg: mixHex(hex, t.bg, light ? 0.22 : 0.28),
      fg: light ? shadeHex(hex, -0.45) : shadeHex(hex, 0.35)
    };
  }
  var wav  = badge(t.accent);
  var mp3  = badge(hueShift(t.accent, 55));
  var aiff = badge(hueShift(t.accent, -75));
  var aac  = badge(hueShift(t.accent, 130));
  r.setProperty("--ext-wav-bg",  wav.bg);  r.setProperty("--ext-wav-fg",  wav.fg);
  r.setProperty("--ext-mp3-bg",  mp3.bg);  r.setProperty("--ext-mp3-fg",  mp3.fg);
  r.setProperty("--ext-aiff-bg", aiff.bg); r.setProperty("--ext-aiff-fg", aiff.fg);
  r.setProperty("--ext-aac-bg",  aac.bg);  r.setProperty("--ext-aac-fg",  aac.fg);
}

// rgba из hex
function hexToRgba(hex, a) { var c = hexToRgb(hex); return "rgba(" + c.r + "," + c.g + "," + c.b + "," + a + ")"; }

// Текущее состояние темы: базовый пресет + ручные переопределения цветов
var themeBase = "orange";
var themeOverrides = {}; // { accent?, bg?, panel?, text? }

// Собрать полную тему из базы + ручных цветов (пере-вычисляет зависимые)
function buildCustomTheme(baseName, ov) {
  var base = THEMES[baseName] || THEMES.gray;
  var t = {}; for (var k in base) t[k] = base[k];
  if (ov.accent) t.accent = ov.accent;
  if (ov.bg)     t.bg = ov.bg;
  if (ov.panel)  t.panel = ov.panel;
  if (ov.text)   t.text = ov.text;

  // зависимые цвета пере-вычисляем из выбранных
  t.accentDim    = shadeHex(t.accent, -0.25);
  t.selectedBg   = mixHex(t.accent, t.bg, 0.32);
  t.selectedText = (luminance(t.accent) > 0.55) ? "#1a1a1a" : "#ffffff";
  t.textDim      = mixHex(t.text, t.bg, 0.42);
  t.textMuted    = mixHex(t.text, t.bg, 0.62);
  t.border       = mixHex(t.text, t.bg, 0.20);
  t.sidebar      = shadeHex(t.bg, luminance(t.bg) > 0.5 ? -0.03 : 0.05);
  t.hover        = shadeHex(t.bg, luminance(t.bg) > 0.5 ? -0.05 : 0.08);
  t.tableHead    = shadeHex(t.bg, luminance(t.bg) > 0.5 ? -0.02 : 0.03);
  t.scroll       = mixHex(t.text, t.bg, 0.32);
  t.overlay      = hexToRgba(t.bg, 0.95);
  return t;
}

function hasOverrides(ov) {
  return !!(ov && (ov.accent || ov.bg || ov.panel || ov.text));
}

// Выбор базового пресета (сбрасывает ручные цвета)
function setTheme(name) {
  if (!THEMES[name]) name = "orange";
  themeBase = name;
  themeOverrides = {};
  applyTheme();
}

// Применить текущую тему (база + ручные переопределения)
function applyTheme(skipSync) {
  var t = hasOverrides(themeOverrides) ? buildCustomTheme(themeBase, themeOverrides) : THEMES[themeBase];
  applyThemeVars(t);
  persistTheme();

  // подсветить активный пресет
  var rows = document.querySelectorAll(".theme-row");
  for (var i = 0; i < rows.length; i++) rows[i].classList.toggle("active", rows[i].dataset.theme === themeBase);

  if (!skipSync) syncColorPickers(t);
  player.redrawWave();
  resetThumbs();
}

function persistTheme() {
  try { localStorage.setItem(STORAGE_THEME, JSON.stringify({ name: themeBase, ov: themeOverrides })); } catch (e) {}
}

// Прочитать выбранные цвета из 4 свотчей в themeOverrides
function readColorOverrides() {
  var ids = { accent: "col-accent", bg: "col-bg", panel: "col-panel", text: "col-text" };
  themeOverrides = {};
  for (var k in ids) { var el = document.getElementById(ids[k]); if (el && el.dataset.color) themeOverrides[k] = el.dataset.color; }
}

// Живое изменение (input): только CSS-переменные, БЕЗ перерисовки волн/миниатюр.
// Дросселируем через requestAnimationFrame — максимум один пересчёт за кадр.
var _colorRAF = null;
function applyManualColorsLive() {
  readColorOverrides();
  if (_colorRAF) return;
  _colorRAF = requestAnimationFrame(function () {
    _colorRAF = null;
    var t = hasOverrides(themeOverrides) ? buildCustomTheme(themeBase, themeOverrides) : THEMES[themeBase];
    applyThemeVars(t); // дёшево: только установка CSS-переменных
  });
}

// Завершение выбора (change): тяжёлая часть один раз — перерисовка + сохранение.
function commitManualColors() {
  readColorOverrides();
  applyTheme(true);
}

// ══════════════════════════════════════════════
//  КАСТОМНАЯ ПАЛИТРА (в стиле плагина)
// ══════════════════════════════════════════════
function rgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  var h = 0, s = max === 0 ? 0 : d / max, v = max;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60; if (h < 0) h += 360;
  }
  return { h: h, s: s, v: v };
}
function hsvToRgb(h, s, v) {
  var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  return { r: Math.round((r + m) * 255), g: Math.round((g + m) * 255), b: Math.round((b + m) * 255) };
}
function rgbObjHex(o) { return rgbToHex(o.r, o.g, o.b); }

var cp = { h: 0, s: 0, v: 0, target: null, orig: null, onLive: null, onCommit: null };

function openColorPicker(swatch, hex, onLive, onCommit) {
  cp.target = swatch; cp.orig = hex; cp.onLive = onLive; cp.onCommit = onCommit;
  var rgb = hexToRgb(hex || "#000000");
  var hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);
  cp.h = hsv.h; cp.s = hsv.s; cp.v = hsv.v;
  var pop = document.getElementById("cp-pop");
  pop.style.visibility = "hidden"; pop.classList.remove("hidden");
  // позиция рядом со свотчем, в пределах окна
  var r = swatch.getBoundingClientRect();
  var pw = pop.offsetWidth, ph = pop.offsetHeight, vw = window.innerWidth, vh = window.innerHeight, pad = 8;
  var left = r.right + 8; if (left + pw + pad > vw) left = r.left - pw - 8; if (left < pad) left = pad;
  var top = r.top; if (top + ph + pad > vh) top = vh - ph - pad; if (top < pad) top = pad;
  pop.style.left = left + "px"; pop.style.top = top + "px"; pop.style.visibility = "";
  cpRender();
}

function cpRender() {
  var sv = document.getElementById("cp-sv");
  var hueHex = rgbObjHex(hsvToRgb(cp.h, 1, 1));
  sv.style.background = "linear-gradient(to top, #000, rgba(0,0,0,0)), linear-gradient(to right, #fff, " + hueHex + ")";
  document.getElementById("cp-sv-marker").style.left = (cp.s * 100) + "%";
  document.getElementById("cp-sv-marker").style.top = ((1 - cp.v) * 100) + "%";
  document.getElementById("cp-hue-marker").style.left = (cp.h / 360 * 100) + "%";

  var rgb = hsvToRgb(cp.h, cp.s, cp.v);
  var hex = rgbToHex(rgb.r, rgb.g, rgb.b);
  document.getElementById("cp-preview").style.background = hex;
  setIfNotFocused("cp-r", rgb.r); setIfNotFocused("cp-g", rgb.g); setIfNotFocused("cp-b", rgb.b);
  setIfNotFocused("cp-hex", hex.substring(1).toUpperCase());

  if (cp.target) { cp.target.dataset.color = hex; cp.target.style.background = hex; }
  if (cp.onLive) cp.onLive();
}
function setIfNotFocused(id, val) { var el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val; }

function cpFromRgbInputs() {
  var r = clamp255(document.getElementById("cp-r").value);
  var g = clamp255(document.getElementById("cp-g").value);
  var b = clamp255(document.getElementById("cp-b").value);
  var hsv = rgbToHsv(r, g, b); cp.h = hsv.h; cp.s = hsv.s; cp.v = hsv.v; cpRender();
}
function cpFromHexInput() {
  var v = String(document.getElementById("cp-hex").value).trim().replace("#", "");
  if (/^[0-9a-fA-F]{6}$/.test(v)) { var rgb = hexToRgb("#" + v); var hsv = rgbToHsv(rgb.r, rgb.g, rgb.b); cp.h = hsv.h; cp.s = hsv.s; cp.v = hsv.v; cpRender(); }
}
function clamp255(x) { x = parseInt(x, 10); if (isNaN(x)) x = 0; return Math.max(0, Math.min(255, x)); }

function cpClose() { document.getElementById("cp-pop").classList.add("hidden"); }
function cpOk() { cpClose(); if (cp.onCommit) cp.onCommit(); cp.target = null; }
function cpCancel() {
  if (cp.target && cp.orig) { cp.target.dataset.color = cp.orig; cp.target.style.background = cp.orig; }
  if (cp.onLive) cp.onLive();
  cpClose(); if (cp.onCommit) cp.onCommit(); cp.target = null;
}

function bindColorPicker() {
  var sv = document.getElementById("cp-sv");
  var hue = document.getElementById("cp-hue");
  if (!sv || !hue) return;

  function svMove(e) {
    var r = sv.getBoundingClientRect();
    cp.s = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    cp.v = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    cpRender();
  }
  function hueMove(e) {
    var r = hue.getBoundingClientRect();
    cp.h = Math.max(0, Math.min(359.9, (e.clientX - r.left) / r.width * 360));
    cpRender();
  }
  function dragger(moveFn) {
    return function (e) {
      e.preventDefault(); moveFn(e);
      function mv(ev) { moveFn(ev); }
      function up() { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); }
      document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
    };
  }
  sv.addEventListener("mousedown", dragger(svMove));
  hue.addEventListener("mousedown", dragger(hueMove));

  ["cp-r", "cp-g", "cp-b"].forEach(function (id) { var el = document.getElementById(id); if (el) el.addEventListener("input", cpFromRgbInputs); });
  var hex = document.getElementById("cp-hex"); if (hex) hex.addEventListener("input", cpFromHexInput);
  document.getElementById("cp-ok").addEventListener("click", cpOk);
  document.getElementById("cp-cancel").addEventListener("click", cpCancel);

  // свотчи открывают палитру
  ["col-accent", "col-bg", "col-panel", "col-text"].forEach(function (id) {
    var sw = document.getElementById(id);
    if (sw) sw.addEventListener("click", function () {
      openColorPicker(sw, sw.dataset.color || "#000000", applyManualColorsLive, commitManualColors);
    });
  });

  // клик вне палитры = OK (применить и закрыть)
  document.addEventListener("mousedown", function (e) {
    var pop = document.getElementById("cp-pop");
    if (pop && !pop.classList.contains("hidden") && !pop.contains(e.target) &&
        !(e.target.classList && e.target.classList.contains("cc-swatch"))) {
      cpOk();
    }
  });
}

// Сброс ручных цветов к базовому пресету
function resetManualColors() {
  themeOverrides = {};
  applyTheme();
}

// Обновить свотчи под текущую тему
function syncColorPickers(t) {
  var map = { "col-accent": t.accent, "col-bg": t.bg, "col-panel": t.panel, "col-text": t.text };
  for (var id in map) {
    var el = document.getElementById(id);
    if (el && map[id]) { var hx = toHex6(map[id]); el.dataset.color = hx; el.style.background = hx; }
  }
}

// нормализовать в #rrggbb (color input требует именно такой формат)
function toHex6(hex) {
  if (!hex) return "#000000";
  hex = String(hex).trim();
  if (hex.charAt(0) !== "#") return "#000000";
  if (hex.length === 4) return "#" + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  return hex.substring(0, 7);
}

function shadeHex(hex, amt) { // amt: -1..1
  var c = hexToRgb(hex);
  var f = amt < 0 ? 0 : 255, p = Math.abs(amt);
  return rgbToHex(
    Math.round((f - c.r) * p + c.r),
    Math.round((f - c.g) * p + c.g),
    Math.round((f - c.b) * p + c.b)
  );
}
function mixHex(hexA, hexB, ratioA) {
  var a = hexToRgb(hexA), b = hexToRgb(hexB);
  return rgbToHex(
    Math.round(a.r * ratioA + b.r * (1 - ratioA)),
    Math.round(a.g * ratioA + b.g * (1 - ratioA)),
    Math.round(a.b * ratioA + b.b * (1 - ratioA))
  );
}
function hexToRgb(hex) {
  hex = hex.replace("#", "");
  return {
    r: parseInt(hex.substr(0, 2), 16),
    g: parseInt(hex.substr(2, 2), 16),
    b: parseInt(hex.substr(4, 2), 16)
  };
}
function rgbToHex(r, g, b) {
  function h(n) { n = Math.max(0, Math.min(255, n)); var s = n.toString(16); return s.length === 1 ? "0" + s : s; }
  return "#" + h(r) + h(g) + h(b);
}
function luminance(hex) {
  var c = hexToRgb(hex);
  return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255;
}
// Сдвиг тона цвета на deg градусов (через HSL)
function hueShift(hex, deg) {
  var c = hexToRgb(hex);
  var r = c.r / 255, g = c.g / 255, b = c.b / 255;
  var max = Math.max(r, g, b), min = Math.min(r, g, b);
  var h, s, l = (max + min) / 2;
  if (max === min) { h = 0; s = 0; }
  else {
    var d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r)      h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
    else if (max === g) h = ((b - r) / d + 2) / 6;
    else                h = ((r - g) / d + 4) / 6;
  }
  h = (h + deg / 360) % 1; if (h < 0) h += 1;
  function hue2rgb(p, q, t) {
    if (t < 0) t += 1; if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  }
  var R, G, B;
  if (s === 0) { R = G = B = l; }
  else {
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;
    R = hue2rgb(p, q, h + 1/3); G = hue2rgb(p, q, h); B = hue2rgb(p, q, h - 1/3);
  }
  return rgbToHex(Math.round(R * 255), Math.round(G * 255), Math.round(B * 255));
}

// ══════════════════════════════════════════════
//  ПЛЕЕР (Web Audio)
// ══════════════════════════════════════════════
var player = {
  ctx: null, gain: null,
  buffer: null,      // оригинальный буфер
  revBuffer: null,   // развёрнутый (lazy)
  source: null,
  file: null,
  playing: false,
  offset: 0,         // позиция в секундах в ТЕКУЩЕМ буфере
  startedAt: 0,
  rate: 1,
  pitch: 0,
  loop: false,
  reversed: false,
  volume: 0.8,
  duration: 0,
  raf: null,
  loadToken: 0,
  waveCache: null,   // offscreen canvas с волной
  selStart: null,    // выделенный диапазон (сек, в текущей ориентации буфера)
  selEnd: null,

  ensureCtx: function () {
    if (!this.ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
      this.gain = this.ctx.createGain();
      this.gain.gain.value = this.volume;
      this.gain.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") { try { this.ctx.resume(); } catch (e) {} }
  },

  // ── загрузка файла → AudioBuffer ──
  load: function (file, autoplay) {
    this.ensureCtx();
    this.stopSource();
    this.file = file;
    this.buffer = null; this.revBuffer = null;
    this.offset = 0; this.playing = false; this.duration = 0;
    this.waveCache = null;
    this.clearSelection();

    var token = ++this.loadToken;
    var self = this;

    showPlayer();
    setPlayBtn(false);
    document.getElementById("pl-cur").textContent = "00:00.00";
    document.getElementById("pl-total").textContent = "…";
    clearWaveCanvas("Загружаю…");

    readFileArrayBuffer(file.path, function (ab, err) {
      if (token !== self.loadToken) return; // выбрали другой файл
      if (err || !ab) { clearWaveCanvas("Не удалось прочитать файл"); return; }
      self.ctx.decodeAudioData(ab, function (buf) {
        if (token !== self.loadToken) return;
        self.buffer = buf;
        self.duration = buf.duration;
        document.getElementById("pl-total").textContent = fmtTime(buf.duration);
        self.buildWaveCache();
        self.redrawWave();
        if (autoplay) self.play();
      }, function () {
        if (token !== self.loadToken) return;
        clearWaveCanvas("Формат не поддерживается для предпрослушки");
      });
    });
  },

  activeBuffer: function () {
    if (!this.reversed) return this.buffer;
    if (!this.revBuffer && this.buffer) this.revBuffer = reverseBuffer(this.ctx, this.buffer);
    return this.revBuffer;
  },

  play: function () {
    var buf = this.activeBuffer();
    if (!buf) return;
    this.ensureCtx();
    this.stopSource();

    var src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = this.loop;
    src.playbackRate.value = this.rate;
    src.connect(this.gain);

    var self = this;
    src.onended = function () {
      if (self.source !== src) return; // остановили вручную
      self.playing = false;
      self.source = null;
      self.offset = 0;
      setPlayBtn(false);
      syncRowPlaying();
      self.updatePlayhead(0);
      document.getElementById("pl-cur").textContent = "00:00.00";
    };

    if (this.offset >= this.duration) this.offset = 0;
    src.start(0, this.offset);
    this.source = src;
    this.startedAt = this.ctx.currentTime;
    this.playing = true;
    setPlayBtn(true);
    syncRowPlaying();
    this.tick();
  },

  pause: function () {
    if (!this.playing) return;
    this.offset = this.position();
    this.stopSource();
    this.playing = false;
    setPlayBtn(false);
    syncRowPlaying();
  },

  toggle: function () { this.playing ? this.pause() : this.play(); },

  stopSource: function () {
    if (this.source) {
      var s = this.source;
      this.source = null;
      try { s.onended = null; s.stop(); } catch (e) {}
    }
    if (this.raf) { cancelAnimationFrame(this.raf); this.raf = null; }
  },

  reset: function () {
    this.loadToken++;
    this.stopSource();
    this.playing = false;
    this.file = null; this.buffer = null; this.revBuffer = null;
    this.offset = 0; this.waveCache = null;
    setPlayBtn(false);
  },

  position: function () {
    if (!this.playing || !this.ctx) return this.offset;
    var pos = this.offset + (this.ctx.currentTime - this.startedAt) * this.rate;
    if (this.loop && this.duration > 0) pos = pos % this.duration;
    return Math.min(pos, this.duration);
  },

  seek: function (t) {
    t = Math.max(0, Math.min(t, this.duration));
    var wasPlaying = this.playing;
    this.stopSource();
    this.playing = false;
    this.offset = t;
    if (wasPlaying) this.play();
    else { this.updatePlayhead(this.duration ? t / this.duration : 0);
           document.getElementById("pl-cur").textContent = fmtTime(t); }
  },

  setPitch: function (semi) {
    this.pitch = semi;
    var newRate = Math.pow(2, semi / 12);
    if (this.playing && this.source) {
      this.offset = this.position();
      this.startedAt = this.ctx.currentTime;
      this.source.playbackRate.value = newRate;
    }
    this.rate = newRate;
    document.getElementById("pl-pitch-val").textContent = semi;
  },

  setReverse: function (on) {
    if (on === this.reversed) return;
    var pos = this.position();
    var wasPlaying = this.playing;
    this.stopSource();
    this.playing = false;
    this.reversed = on;
    this.offset = Math.max(0, this.duration - pos); // зеркалим позицию
    if (this.hasSelection()) {
      var a = this.duration - this.selEnd, b = this.duration - this.selStart;
      this.selStart = a; this.selEnd = b;
    }
    this.waveCache = null;
    this.buildWaveCache();
    this.redrawWave();
    this.drawSelection();
    if (wasPlaying) this.play();
  },

  setLoop: function (on) {
    this.loop = on;
    if (this.source) this.source.loop = on;
    document.getElementById("pl-loop").classList.toggle("active", on);
  },

  setVolume: function (v) {
    this.volume = v;
    if (this.gain) this.gain.gain.value = v;
  },

  tick: function () {
    var self = this;
    function frame() {
      if (!self.playing) return;
      var pos = self.position();
      self.updatePlayhead(self.duration ? pos / self.duration : 0);
      document.getElementById("pl-cur").textContent = fmtTime(pos);
      self.raf = requestAnimationFrame(frame);
    }
    this.raf = requestAnimationFrame(frame);
  },

  updatePlayhead: function (frac) {
    var wrap = document.getElementById("pl-wave-wrap");
    var ph   = document.getElementById("pl-playhead");
    ph.style.left = Math.round(frac * wrap.clientWidth) + "px";
  },

  // ── выделение диапазона ──
  setSelection: function (aSec, bSec) {
    this.selStart = Math.max(0, Math.min(aSec, bSec));
    this.selEnd   = Math.min(this.duration, Math.max(aSec, bSec));
    this.drawSelection();
  },
  clearSelection: function () {
    this.selStart = null; this.selEnd = null;
    var el = document.getElementById("pl-selection");
    if (el) el.classList.add("hidden");
  },
  hasSelection: function () {
    return this.selStart !== null && this.selEnd !== null && (this.selEnd - this.selStart) > 0.01;
  },
  drawSelection: function () {
    var el = document.getElementById("pl-selection");
    if (!el) return;
    if (!this.hasSelection() || !this.duration) { el.classList.add("hidden"); return; }
    var wrap = document.getElementById("pl-wave-wrap");
    var x1 = (this.selStart / this.duration) * wrap.clientWidth;
    var x2 = (this.selEnd   / this.duration) * wrap.clientWidth;
    el.style.left  = Math.round(x1) + "px";
    el.style.width = Math.max(2, Math.round(x2 - x1)) + "px";
    el.classList.remove("hidden");
  },
  // выделение в координатах ОРИГИНАЛЬНОГО файла (с учётом reverse)
  selectionInOriginal: function () {
    if (!this.hasSelection()) return null;
    if (!this.reversed) return { inSec: this.selStart, outSec: this.selEnd };
    return { inSec: this.duration - this.selEnd, outSec: this.duration - this.selStart };
  },

  // ── волна ──
  buildWaveCache: function () {
    var buf = this.activeBuffer();
    if (!buf) return;
    var wrap = document.getElementById("pl-wave-wrap");
    var W = Math.max(50, wrap.clientWidth);
    var H = Math.max(40, wrap.clientHeight);

    var off = document.createElement("canvas");
    off.width = W; off.height = H;
    var g = off.getContext("2d");

    var chans = Math.min(2, buf.numberOfChannels);
    var laneH = H / chans;
    var color = getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "#ddd";
    g.fillStyle = color;

    for (var ch = 0; ch < chans; ch++) {
      var data = buf.getChannelData(ch);
      var step = Math.max(1, Math.floor(data.length / W));
      var mid  = laneH * ch + laneH / 2;
      var amp  = (laneH / 2) * 0.92;

      for (var x = 0; x < W; x++) {
        var start = Math.floor(x * data.length / W);
        var min = 1, max = -1;
        for (var i = 0; i < step; i++) {
          var v = data[start + i];
          if (v === undefined) break;
          if (v < min) min = v;
          if (v > max) max = v;
        }
        if (min > max) { min = 0; max = 0; }
        var y1 = mid - max * amp;
        var y2 = mid - min * amp;
        g.fillRect(x, y1, 1, Math.max(1, y2 - y1));
      }
    }
    this.waveCache = off;
  },

  redrawWave: function () {
    var canvas = document.getElementById("pl-wave");
    if (!canvas) return;
    var wrap = document.getElementById("pl-wave-wrap");
    canvas.width  = wrap.clientWidth;
    canvas.height = wrap.clientHeight;
    var g = canvas.getContext("2d");
    g.clearRect(0, 0, canvas.width, canvas.height);
    if (!this.buffer) return;
    if (!this.waveCache ||
        this.waveCache.width !== canvas.width ||
        this.waveCache.height !== canvas.height) {
      this.buildWaveCache();
    }
    if (this.waveCache) g.drawImage(this.waveCache, 0, 0, canvas.width, canvas.height);
  }
};

function readFileArrayBuffer(path, cb) {
  if (nodeFs) {
    try {
      var data = nodeFs.readFileSync(path);
      var ab = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      cb(ab, null);
      return;
    } catch (e) { /* fallthrough к XHR */ }
  }
  try {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", toFileUrl(path), true);
    xhr.responseType = "arraybuffer";
    xhr.onload  = function () { cb(xhr.response, null); };
    xhr.onerror = function () { cb(null, new Error("XHR failed")); };
    xhr.send();
  } catch (e2) { cb(null, e2); }
}

function reverseBuffer(ctx, buf) {
  var out = ctx.createBuffer(buf.numberOfChannels, buf.length, buf.sampleRate);
  for (var ch = 0; ch < buf.numberOfChannels; ch++) {
    var src = buf.getChannelData(ch);
    var dst = out.getChannelData(ch);
    for (var i = 0, n = src.length; i < n; i++) dst[i] = src[n - 1 - i];
  }
  return out;
}

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  var m  = Math.floor(sec / 60);
  var s  = Math.floor(sec % 60);
  var cs = Math.floor((sec - Math.floor(sec)) * 100);
  function p(n) { return n < 10 ? "0" + n : "" + n; }
  return p(m) + ":" + p(s) + "." + p(cs);
}

function showPlayer() {
  document.getElementById("player-panel").classList.remove("hidden");
}
function hidePlayer() {
  document.getElementById("player-panel").classList.add("hidden");
  player.reset();
  syncRowPlaying();
}
function setPlayBtn(playing) {
  var b = document.getElementById("pl-play");
  b.textContent = playing ? "⏸" : "▶";
  b.classList.toggle("playing", playing);
}
function clearWaveCanvas(msg) {
  var canvas = document.getElementById("pl-wave");
  var wrap = document.getElementById("pl-wave-wrap");
  canvas.width = wrap.clientWidth; canvas.height = wrap.clientHeight;
  var g = canvas.getContext("2d");
  g.clearRect(0, 0, canvas.width, canvas.height);
  if (msg) {
    g.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--text-muted").trim() || "#777";
    g.font = "11px sans-serif";
    g.textAlign = "center";
    g.fillText(msg, canvas.width / 2, canvas.height / 2);
  }
  player.updatePlayhead(0);
}

// строки списка: подсветка играющего
function syncRowPlaying() {
  var rows = document.querySelectorAll(".sfx-item");
  for (var i = 0; i < rows.length; i++) {
    var f = state.filteredSfx[+rows[i].dataset.idx];
    var isCur = f && state.selectedFile && f.path === state.selectedFile.path;
    rows[i].classList.toggle("playing", !!(isCur && player.playing));
    var pb = rows[i].querySelector(".sfx-play-btn");
    if (pb) pb.textContent = (isCur && player.playing) ? "⏸" : "▶";
  }
}

// ══════════════════════════════════════════════
//  ИНИЦИАЛИЗАЦИЯ
// ══════════════════════════════════════════════
document.addEventListener("DOMContentLoaded", function () {
  // Premiere 2026: явно догружаем host.jsx (см. loadHostJSX), т.к.
  // авто-подхват <ScriptPath> в новой версии срабатывает не всегда.
  ensureHost(function (ok, res) {
    if (!ok) { try { console.warn("[MF Library] host.jsx не загрузился:", res); } catch (e) {} }
  });
  // тема (новый формат: {name, ov:{...}}; старый: {name, custom:hex})
  var saved = null;
  try { saved = JSON.parse(localStorage.getItem(STORAGE_THEME)); } catch (e) {}
  if (saved && saved.name) {
    themeBase = THEMES[saved.name] ? saved.name : "orange";
    if (saved.ov && typeof saved.ov === "object") {
      themeOverrides = saved.ov;
    } else if (saved.custom) {
      // миграция старого формата (был только акцент)
      themeBase = "gray";
      themeOverrides = { accent: saved.custom };
    } else {
      themeOverrides = {};
    }
    applyTheme();
  } else {
    setTheme("orange");
  }

  // ширина сайдбара
  var sw = parseInt(localStorage.getItem(STORAGE_SIDEW), 10);
  if (sw && sw >= 120 && sw <= 500) setSidebarWidth(sw);

  // вид списка
  try {
    var v = JSON.parse(localStorage.getItem(STORAGE_VIEW));
    if (v) {
      if (v.mode === "grid" || v.mode === "list") state.viewMode = v.mode;
      if (v.dir === "h" || v.dir === "v") state.gridDir = v.dir;
      if (v.cols >= 2 && v.cols <= 8) state.gridCols = v.cols;
      if (v.fmode === "tree" || v.fmode === "nav") state.folderMode = v.fmode;
      if (v.fexp === "multi" || v.fexp === "single") state.folderExpand = v.fexp;
      state.fxLayout = "tab"; // раскладка зафиксирована: отдельная вкладка (док убран)
      if (v.fxLabels === "full" || v.fxLabels === "abbr") state.fxLabels = v.fxLabels;
      if (typeof v.fxSize === "number" && v.fxSize >= 0 && v.fxSize <= 3) state.fxSize = v.fxSize;
      if (typeof v.fxDockH === "number" && v.fxDockH >= 90 && v.fxDockH <= 400) state.fxDockH = v.fxDockH;
      if (typeof v.fxTileSize === "number" && v.fxTileSize >= 40 && v.fxTileSize <= 130) state.fxTileSize = v.fxTileSize;
    }
  } catch (e) {}

  // избранное
  try {
    var favArr = JSON.parse(localStorage.getItem(STORAGE_FAVS));
    if (favArr && favArr.length) {
      for (var fi = 0; fi < favArr.length; fi++) favorites[favArr[fi].path] = favArr[fi];
    }
  } catch (e) {}
  updateFavCount();

  // коллекции
  try {
    var colArr = JSON.parse(localStorage.getItem(STORAGE_COLS));
    if (colArr && colArr.length) collections = colArr;
  } catch (e) {}

  // цвета папок
  try {
    var fc = JSON.parse(localStorage.getItem(STORAGE_FCOLORS));
    if (fc) folderColors = fc;
  } catch (e) {}

  // раскладка доски эффектов
  try {
    var fb2 = JSON.parse(localStorage.getItem(STORAGE_FXBOARD));
    if (fb2) {
      state.fxBoard = fb2;
      // базовый размер слайдера — по самой крупной плитке
      var mx = 0; for (var bk in fb2) { var pb = fb2[bk]; mx = Math.max(mx, pb.w || pb.size || 0, pb.h || pb.size || 0); }
      if (mx) state.fxTileSize = mx;
    }
  } catch (e) {}

  bindEvents();
  bindSettings();
  bindResizer();
  bindPlayer();
  bindViewControls();
  cleanupTmpFragments();
  bindFolderBrowser();
  bindFxControls();
  loadPresets();
  applyFxLayout();

  // восстановление корней: новый формат (массив) или legacy (одна папка)
  var roots = [];
  try { roots = JSON.parse(localStorage.getItem(STORAGE_ROOTS)) || []; } catch (e) {}
  if (!roots.length) {
    var legacy = localStorage.getItem(STORAGE_ROOT);
    if (legacy) roots = [legacy];
  }
  if (!roots.length) return;

  if (nodeFs) {
    var valid = [];
    for (var i = 0; i < roots.length; i++) {
      try { if (nodeFs.existsSync(roots[i])) valid.push(roots[i]); } catch (e) {}
    }
    if (valid.length) initRoots(valid);
  } else {
    // ExtendScript fallback — проверяем существование по очереди
    var checked = [], pending = roots.length;
    roots.forEach(function (rp) {
      csInterface.evalScript('folderExists("' + escPath(rp) + '")', function (res) {
        if (res === "true") checked.push(rp);
        if (--pending === 0 && checked.length) initRoots(checked);
      });
    });
  }
});

// ══════════════════════════════════════════════
//  СОБЫТИЯ UI
// ══════════════════════════════════════════════
// ══════════════════════════════════════════════
//  РЕЖИМ EFFECTS (вкладка SFX | Effects, push-анимация)
// ══════════════════════════════════════════════
// Каталог эффектов — имена точно как в Premiere (для QE getAudioEffectByName),
// abbr — короткая подпись на кнопке.
var FX_GROUPS = [
  { title: "Low & High pass", items: [
    { abbr: "LP",  label: "LowPass",  fx: "Lowpass" },
    { abbr: "HP",  label: "HighPass", fx: "Highpass" }
  ]},
  { title: "Bass & Treble", items: [
    { abbr: "BAS", label: "Bass",   fx: "Bass" },
    { abbr: "TRB", label: "Treble", fx: "Treble" }
  ]},
  { title: "Reverb", items: [
    { abbr: "CRV", label: "Convolution Reverb", fx: "Convolution Reverb" },
    { abbr: "SRV", label: "Studio Reverb",      fx: "Studio Reverb" },
    { abbr: "URV", label: "Surround Reverb",    fx: "Surround Reverb" }
  ]},
  { title: "EQ", items: [
    { abbr: "PEQ",  label: "Simple Param. EQ",  fx: "Simple Parametric EQ" },
    { abbr: "PEQ+", label: "Parametric EQ",     fx: "Parametric Equalizer" }
  ]},
  { title: "Compressor", items: [
    { abbr: "MBC", label: "Multiband Comp.",   fx: "Multiband Compressor" },
    { abbr: "SBC", label: "Single-band Comp.", fx: "Single-band Compressor" },
    { abbr: "TUB", label: "Tube Comp.",        fx: "Tube-modeled Compressor" }
  ]}
];

function setMode(mode) {
  state.mode = mode;

  // подсветка кнопок
  document.getElementById("mode-sfx").classList.toggle("active", mode === "sfx");
  document.getElementById("mode-fx").classList.toggle("active", mode === "fx");

  // SFX ↔ Effects
  if (state.fxLayout === "tab") {
    document.getElementById("view-track").classList.toggle("show-fx", mode === "fx");
    if (mode === "fx") setFxSection(state.fxSection);
  } else {
    // режим «док»: основная вью всегда SFX, эффекты живут в доке снизу
    document.getElementById("view-track").classList.remove("show-fx");
  }
}

// ── Применить расположение эффектов (док снизу или вкладка) ──
function applyFxLayout() {
  var dock = document.getElementById("fx-dock");
  var dockMode = state.fxLayout === "dock";

  // режим «док»: панель эффектов внизу видна всегда.
  // режим «вкладка»: дока нет (эффекты в отдельной вью).
  dock.classList.toggle("hidden", !dockMode);

  if (dockMode) {
    dock.style.height = state.fxDockH + "px";
    // в доке основная вью — SFX (эффекты снизу), но переключатель НЕ прячем
    document.getElementById("view-track").classList.remove("show-fx");
    if (state.mode === "fx") {
      state.mode = "sfx";
      document.getElementById("mode-sfx").classList.add("active");
      document.getElementById("mode-fx").classList.remove("active");
    }
  }
  // синхронизируем активную саб-секцию (эффекты/пресеты) и отрисуем её
  setFxSection(state.fxSection);
  syncFooterToButtons(); // обновить инфо/кнопку в шапке дока
}

// Синхронизируем инфо и кнопку «В таймлайн» в шапке дока эффектов.
function syncFooterToButtons() {
  var has = !!state.selectedFile;
  var txt = has ? stripExt(state.selectedFile.name) : "Кликни по звуку — он сразу заиграет";
  var cls = has ? "has-file" : "";

  var info = document.getElementById("selected-info");
  if (info) { info.textContent = txt; info.className = cls; }
  var b = document.getElementById("btn-add-timeline");
  if (b) b.disabled = !has;
}

// Базовые пресеты обработки голоса: цепочка эффектов Premiere.
// Имена должны совпадать с именами аудиоэффектов в Premiere (для QE).
var VOICE_PRESETS = [
  { title: "Голос — базовая обработка", chain: ["Parametric Equalizer", "Hard Limiter", "DeNoise"] },
  { title: "Голос — чистый (шумодав + лимитер)", chain: ["DeNoise", "Hard Limiter"] },
  { title: "Голос — тёплый эфир (EQ + компрессор + лимитер)", chain: ["Parametric Equalizer", "Single-band Compressor", "Hard Limiter"] }
];

// Пользовательские пресеты (редактируемые). При первом запуске — из VOICE_PRESETS.
var STORAGE_PRESETS = "mflib_presets";
var presets = [];
var editingPresetId = null;

function loadPresets() {
  var saved = null;
  try { saved = JSON.parse(localStorage.getItem(STORAGE_PRESETS)); } catch (e) {}
  if (saved && saved.length) {
    presets = saved;
  } else {
    presets = VOICE_PRESETS.map(function (p, i) { return { id: "p_seed_" + i, title: p.title, chain: p.chain.slice() }; });
    savePresets();
  }
}
function savePresets() { try { localStorage.setItem(STORAGE_PRESETS, JSON.stringify(presets)); } catch (e) {} }
function presetById(id) { for (var i = 0; i < presets.length; i++) if (presets[i].id === id) return presets[i]; return null; }


// Плоский список всех эффектов с устойчивым id (= аббревиатура)
var FX_ALL = (function () {
  var out = [];
  FX_GROUPS.forEach(function (g) {
    g.items.forEach(function (it) { out.push(it); });
  });
  return out;
})();

var FX_TILE_MIN = 28, FX_TILE_MAX = 160, FX_TILE_DEF = 64, FX_GAP = 18;
var FX_GRID = 11;        // шаг сетки для перемещения (поэтапно, мельче — точнее)
var FX_SIZE_STEP = 11;   // шаг изменения размера по каждой оси (поэтапно)
function snapStep(v, step) { return Math.round(v / step) * step; }
function snapDim(v) {
  var n = Math.round((v - FX_TILE_MIN) / FX_SIZE_STEP);
  var s = FX_TILE_MIN + n * FX_SIZE_STEP;
  return Math.max(FX_TILE_MIN, Math.min(FX_TILE_MAX, s));
}

// нормализуем позицию к {x,y,w,h} (старый формат хранил {size})
function fxPos(abbr) {
  var p = state.fxBoard[abbr];
  if (!p) return null;
  if (p.w === undefined || p.h === undefined) {
    var s = p.size || FX_TILE_DEF;
    p.w = s; p.h = s;
  }
  return p;
}

// Гарантировать раскладку для всех эффектов (новые — авто-сетка слева направо)
function ensureFxLayout(boardW) {
  var def = state.fxTileSize || FX_TILE_DEF;
  var cols = Math.max(1, Math.floor((boardW - FX_GAP) / (def + FX_GAP)));
  var placed = 0;
  FX_ALL.forEach(function (it) {
    if (!state.fxBoard[it.abbr]) {
      var c = placed % cols, r = Math.floor(placed / cols);
      state.fxBoard[it.abbr] = {
        x: FX_GAP + c * (def + FX_GAP),
        y: FX_GAP + r * (def + FX_GAP),
        w: def, h: def
      };
    } else {
      fxPos(it.abbr); // миграция старого формата
    }
    placed++;
  });
}

function saveFxBoard() {
  try { localStorage.setItem(STORAGE_FXBOARD, JSON.stringify(state.fxBoard)); } catch (e) {}
}

// Содержимое плитки: аббревиатура крупно + (опц.) название мелко
function fxTileInner(it) {
  if (state.fxLabels === "abbr") {
    return '<span class="fxt-abbr">' + escHtml(it.abbr) + "</span>";
  }
  return '<span class="fxt-abbr">' + escHtml(it.abbr) + "</span>" +
         '<span class="fxt-lbl">' + escHtml(it.label) + "</span>";
}

// Подогнать размер текста под размеры плитки (w × h)
function fitTileText(tile, w, h) {
  var m = Math.min(w, h);
  var abbr = tile.querySelector(".fxt-abbr");
  var lbl  = tile.querySelector(".fxt-lbl");
  if (abbr) abbr.style.fontSize = Math.max(8, Math.round(m * 0.34)) + "px";
  if (lbl) {
    // подпись прячем на совсем мелких плитках, иначе масштабируем
    if (m < 46) { lbl.style.display = "none"; }
    else { lbl.style.display = ""; lbl.style.fontSize = Math.max(7, Math.round(m * 0.15)) + "px"; }
  }
}

// Рендер доски эффектов в заданный контейнер
function renderFxBoard(container) {
  if (!container) return;
  container.classList.add("fx-board");
  container.classList.toggle("fx-board-edit", state.fxEdit);
  var boardW = container.clientWidth || 300;
  ensureFxLayout(boardW);

  container.innerHTML = "";
  var maxBottom = 0;

  FX_ALL.forEach(function (it) {
    var pos = fxPos(it.abbr);
    var tile = document.createElement("div");
    tile.className = "fx-tile";
    tile.title = state.fxEdit ? (it.label + " — таскай / угол меняет ширину и высоту") : it.label;
    tile.style.left = pos.x + "px";
    tile.style.top = pos.y + "px";
    tile.style.width = pos.w + "px";
    tile.style.height = pos.h + "px";
    tile.dataset.abbr = it.abbr;
    tile.innerHTML = fxTileInner(it) + '<span class="fx-resize"></span>';

    bindTileDrag(tile, it, container);
    container.appendChild(tile);
    fitTileText(tile, pos.w, pos.h);

    maxBottom = Math.max(maxBottom, pos.y + pos.h);
  });

  // высота доски под нижнюю плитку (чтобы был скролл, если надо)
  container.style.minHeight = (maxBottom + FX_GAP) + "px";
}

// Перетаскивание + независимый ресайз ширины/высоты (только в режиме редактирования)
function bindTileDrag(tile, it, container) {
  var pos = fxPos(it.abbr);

  tile.addEventListener("mousedown", function (e) {
    if (e.button !== 0) return;

    // вне режима редактирования плитка работает как кнопка — навесить эффект
    if (!state.fxEdit) return;

    var resizing = e.target.classList.contains("fx-resize");
    var startX = e.clientX, startY = e.clientY;
    var origX = pos.x, origY = pos.y, origW = pos.w, origH = pos.h;
    tile.classList.add("dragging");
    document.body.classList.add("fx-board-busy");
    e.preventDefault();
    e.stopPropagation();

    function onMove(ev) {
      var dx = ev.clientX - startX, dy = ev.clientY - startY;

      if (resizing) {
        // ширина и высота — НЕЗАВИСИМО и поэтапно (можно сделать прямоугольник)
        var nw = snapDim(origW + dx);
        var nh = snapDim(origH + dy);
        pos.w = nw; pos.h = nh;
        tile.style.width = nw + "px";
        tile.style.height = nh + "px";
        fitTileText(tile, nw, nh);
      } else {
        // перемещение поэтапно по сетке
        var bw = container.clientWidth;
        var nx = snapStep(origX + dx, FX_GRID);
        var ny = snapStep(origY + dy, FX_GRID);
        nx = Math.max(0, Math.min(nx, Math.max(0, bw - pos.w)));
        ny = Math.max(0, ny);
        pos.x = nx; pos.y = ny;
        tile.style.left = nx + "px";
        tile.style.top = ny + "px";
      }
    }
    function onUp() {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      tile.classList.remove("dragging");
      document.body.classList.remove("fx-board-busy");
      saveFxBoard();
      var maxB = 0;
      for (var k in state.fxBoard) { var p = fxPos(k); maxB = Math.max(maxB, p.y + p.h); }
      container.style.minHeight = (maxB + FX_GAP) + "px";
    }
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  });

  // в обычном режиме клик навешивает эффект
  tile.addEventListener("click", function () {
    if (!state.fxEdit) applyEffect(it, tile);
  });
}

function renderFxDock() {
  if (state.fxSection === "presets") { renderPresets(); return; }
  renderFxBoard(document.getElementById("fx-dock-body"));
}

// Рендер эффектов в отдельную вкладку (режим «tab») — СТАРЫЙ дизайн с группами
function renderFxGroups() {
  var box = document.getElementById("fx-groups");
  if (!box) return;
  box.classList.remove("fx-board", "fx-board-edit");
  box.innerHTML = "";
  var frag = document.createDocumentFragment();

  FX_GROUPS.forEach(function (g) {
    var grp = document.createElement("div");
    grp.className = "fxg-group";
    var t = document.createElement("div");
    t.className = "fxg-title";
    t.textContent = g.title;
    grp.appendChild(t);

    var grid = document.createElement("div");
    grid.className = "fxg-grid";
    g.items.forEach(function (it) {
      var btn = document.createElement("button");
      btn.className = "fxg-btn";
      btn.title = it.label;
      btn.textContent = (state.fxLabels === "abbr") ? it.abbr : it.label;
      btn.addEventListener("click", function () { applyEffect(it, btn); });
      grid.appendChild(btn);
    });
    grp.appendChild(grid);
    frag.appendChild(grp);
  });
  box.appendChild(frag);
}

// Перерисовать активную доску (док или вкладка)
function renderActiveFxBoard() {
  if (state.fxLayout === "dock") renderFxDock();
  else renderFxGroups();
}

// ── Саб-вкладки: Эффекты / Пресеты голоса ──
function setFxSection(sec) {
  if (sec !== "fx" && sec !== "presets") return;
  state.fxSection = sec;
  var fx = sec === "fx";

  // подсветка кнопок (и в доке, и во вкладке)
  ["fxsub-fx", "fxsub-fx-d"].forEach(function (id) { var b = document.getElementById(id); if (b) b.classList.toggle("active", fx); });
  ["fxsub-presets", "fxsub-presets-d"].forEach(function (id) { var b = document.getElementById(id); if (b) b.classList.toggle("active", !fx); });

  // во вкладочном режиме переключаем контейнеры (через display — надёжно)
  var grp = document.getElementById("fx-groups");
  var prs = document.getElementById("fx-presets");
  if (grp) { grp.style.display = fx ? "" : "none"; grp.classList.toggle("hidden", !fx); }
  if (prs) { prs.style.display = fx ? "none" : "flex"; prs.classList.toggle("hidden", fx); }

  // кнопка-карандаш нужна только для доски эффектов
  var edit = document.getElementById("fx-edit");
  if (edit) edit.style.display = fx ? "" : "none";

  if (fx) { renderActiveFxBoard(); }
  else { renderPresets(); }
}

// Рендер карточек пресетов в нужный контейнер (вкладка или док)
function presetsBox() {
  return (state.fxLayout === "dock") ? document.getElementById("fx-dock-body") : document.getElementById("fx-presets");
}

function setPresetStatus(msg, type) {
  flashStatus(msg, type);
}

function renderPresets() {
  var box = presetsBox();
  if (!box) return;
  box.classList.remove("fx-board", "fx-board-edit");
  box.innerHTML = "";
  var frag = document.createDocumentFragment();

  presets.forEach(function (p) {
    frag.appendChild(p.id === editingPresetId ? buildPresetEditCard(p) : buildPresetCard(p));
  });

  // кнопка добавления пресета из выделенного клипа — внизу списка
  var add = document.createElement("button");
  add.className = "fp-add";
  add.innerHTML = "＋ Пресет из выделенного клипа";
  add.title = "Считать эффекты с выделенного на таймлайне клипа и сохранить как пресет";
  add.addEventListener("click", addPresetFromClip);
  frag.appendChild(add);

  box.appendChild(frag);
}

function buildPresetCard(p) {
  var card = document.createElement("div");
  card.className = "fx-preset";

  var head = document.createElement("div"); head.className = "fp-head";
  var title = document.createElement("span"); title.className = "fp-title"; title.textContent = p.title;
  var pencil = document.createElement("span"); pencil.className = "fp-edit"; pencil.textContent = "✎"; pencil.title = "Редактировать / переименовать";
  pencil.addEventListener("click", function (e) { e.stopPropagation(); startEditPreset(p.id); });
  head.appendChild(title); head.appendChild(pencil);
  card.appendChild(head);

  var chain = document.createElement("div"); chain.className = "fp-chain";
  chain.innerHTML = p.chain.length
    ? p.chain.map(function (n) { return "<b>" + escHtml(n) + "</b>"; }).join(" → ")
    : "<i>нет эффектов</i>";
  card.appendChild(chain);

  card.addEventListener("click", function () { applyPreset(p, card); });
  card.addEventListener("contextmenu", function (e) { e.preventDefault(); e.stopPropagation(); showPresetMenu(e, p.id); });
  return card;
}

function buildPresetEditCard(p) {
  var card = document.createElement("div");
  card.className = "fx-preset editing";

  var head = document.createElement("div"); head.className = "fp-head";
  var inp = document.createElement("input"); inp.className = "fp-rename"; inp.value = p.title; inp.placeholder = "Название пресета";
  inp.addEventListener("input", function () { p.title = inp.value; });
  inp.addEventListener("keydown", function (e) { if (e.key === "Enter") finishEditPreset(p.id); });
  var done = document.createElement("button"); done.className = "fp-done"; done.textContent = "Готово";
  done.addEventListener("click", function () { finishEditPreset(p.id); });
  head.appendChild(inp); head.appendChild(done);
  card.appendChild(head);

  var list = document.createElement("div"); list.className = "fp-edit-list";
  if (!p.chain.length) {
    var em = document.createElement("div"); em.className = "fp-empty"; em.textContent = "Эффектов нет. Добавь из выделенного клипа кнопкой ниже.";
    list.appendChild(em);
  }
  p.chain.forEach(function (n, idx) {
    var row = document.createElement("div"); row.className = "fp-edit-fx";
    row.innerHTML = "<span>" + escHtml(n) + "</span><span class='fp-fx-del' title='Убрать из пресета'>✕</span>";
    row.querySelector(".fp-fx-del").addEventListener("click", function () {
      p.chain.splice(idx, 1);
      if (p.settings) p.settings.splice(idx, 1);
      savePresets(); renderPresets();
    });
    list.appendChild(row);
  });
  card.appendChild(list);

  var addFx = document.createElement("button"); addFx.className = "fp-addfx";
  addFx.textContent = "＋ добавить эффекты из выделенного клипа";
  addFx.addEventListener("click", function () { addEffectsFromClipToPreset(p.id); });
  card.appendChild(addFx);

  var delBtn = document.createElement("button"); delBtn.className = "fp-delete";
  delBtn.textContent = "Удалить пресет";
  delBtn.addEventListener("click", function () { deletePreset(p.id); });
  card.appendChild(delBtn);
  return card;
}

function startEditPreset(id) { editingPresetId = id; renderPresets(); }
function finishEditPreset(id) {
  var p = presetById(id);
  if (p && !p.title.trim()) p.title = "Пресет";
  editingPresetId = null; savePresets(); renderPresets();
}
function deletePreset(id) {
  presets = presets.filter(function (p) { return p.id !== id; });
  if (editingPresetId === id) editingPresetId = null;
  savePresets(); renderPresets();
}

function showPresetMenu(e, id) {
  buildMenu(e.clientX, e.clientY, [{
    title: "Пресет",
    items: [
      { label: "Редактировать", icon: "✎", action: function () { startEditPreset(id); } },
      { label: "Удалить", icon: "🗑", danger: true, action: function () { deletePreset(id); } }
    ]
  }]);
}

// «+» — создать пресет из эффектов выделенного клипа
function addPresetFromClip() {
  setPresetStatus("Читаю эффекты выделенного клипа…", "");
  csInterface.evalScript("getClipEffects()", function (res) {
    var data; try { data = JSON.parse(res); } catch (e) { data = null; }
    if (!data || !data.ok) {
      if (data && data.reason === "no_qe") setPresetStatus("⚠ QE DOM недоступен — эффекты клипа не прочитать", "error");
      else setPresetStatus("⚠ " + ((data && data.msg) || "Не удалось прочитать клип"), "error");
      return;
    }
    var effects = data.effects || [];
    var settings = data.settings || [];
    if (!effects.length) {
      setPresetStatus("⚠ На выделенном клипе нет эффектов — нечего сохранять", "error");
      return;
    }
    var name = "Мой пресет " + (presets.length + 1);
    var id = "p_" + Date.now();
    presets.push({ id: id, title: name, chain: effects, settings: settings });
    savePresets();
    editingPresetId = id; // сразу даём переименовать
    renderPresets();
    setPresetStatus("✅ Пресет создан из клипа (" + effects.length + " эфф.) — впиши название", "success");
  });
}

// добавить эффекты выделенного клипа в существующий пресет (при редактировании)
function addEffectsFromClipToPreset(id) {
  setPresetStatus("Читаю эффекты выделенного клипа…", "");
  csInterface.evalScript("getClipEffects()", function (res) {
    var data; try { data = JSON.parse(res); } catch (e) { data = null; }
    if (!data || !data.ok) {
      setPresetStatus("⚠ " + ((data && data.msg) || "Не удалось прочитать клип"), "error");
      return;
    }
    var p = presetById(id);
    if (!p) return;
    var effects = data.effects || [];
    var sset = data.settings || [];
    if (!effects.length) { setPresetStatus("⚠ На клипе нет эффектов", "error"); return; }
    // выравниваем настройки старой части пресета (старые пресеты без settings)
    if (!p.settings) p.settings = [];
    while (p.settings.length < p.chain.length) p.settings.push([]);
    p.chain = p.chain.concat(effects);
    p.settings = p.settings.concat(sset);
    savePresets(); renderPresets();
    setPresetStatus("✅ Добавлено эффектов: " + effects.length, "success");
  });
}

// Применить пресет (цепочку эффектов) на выделенные клипы
function applyPreset(p, card) {
  if (!p.chain.length) { setPresetStatus("⚠ В пресете нет эффектов", "error"); return; }
  if (card) card.classList.add("busy");
  setPresetStatus("Применяю «" + p.title + "»…", "");

  var payload = JSON.stringify({ names: p.chain, settings: (p.settings || []) });
  var arg = payload.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

  // Сначала убеждаемся, что host.jsx загружен (актуально для Premiere 2026)
  ensureHost(function (hostOk, hostRes) {
    if (!hostOk) {
      if (card) card.classList.remove("busy");
      setPresetStatus("⚠ host.jsx не загрузился в этой версии Premiere — пресет применить нельзя. " +
        "Перезапусти панель; если не поможет — ExtendScript/CEP, похоже, отключён. (" +
        String(hostRes).substring(0, 80) + ")", "error");
      return;
    }
    csInterface.evalScript('applyAudioEffectChainEx("' + arg + '")', function (res) {
      if (card) card.classList.remove("busy");
      var data;
      try { data = JSON.parse(res); } catch (e) { data = null; }
      if (data && data.ok) {
        setPresetStatus("✅ " + data.msg, "success");
      } else if (data && data.reason === "no_qe") {
        setPresetStatus("⚠ QE DOM недоступен — пресет применить нельзя", "error");
      } else if (data && data.msg) {
        setPresetStatus("⚠ " + data.msg, "error");
      } else {
        var raw = (res === undefined || res === null || res === "") ? "(пустой ответ)" : String(res);
        if (raw === "EvalScript error.") {
          // host.jsx загружен (ensureHost прошёл), но вызов всё равно упал на уровне движка
          raw = "EvalScript error — вызов упал в ExtendScript. Перезапусти панель и попробуй снова.";
        }
        if (raw.length > 160) raw = raw.substring(0, 160) + "…";
        setPresetStatus("⚠ Ошибка скрипта: " + raw, "error");
      }
    });
  });
}

// ══════════════════════════════════════════════
//  СОРТЕР PROJECT-ПАНЕЛИ
// ══════════════════════════════════════════════
var STORAGE_SORT = "mflib_sort";

function openSorter() {
  loadSortPrefs();
  document.getElementById("sort-overlay").classList.remove("hidden");
  var cfg = document.getElementById("btn-sort-cfg");
  if (cfg) cfg.classList.add("active");
  var st = document.getElementById("sort-status");
  if (st) { st.textContent = ""; st.className = ""; }
}

function closeSorter() {
  document.getElementById("sort-overlay").classList.add("hidden");
  var cfg = document.getElementById("btn-sort-cfg");
  if (cfg) cfg.classList.remove("active");
}

function collectSortOpts() {
  var cats = {}, names = {};
  var catEls = document.querySelectorAll(".sort-cat input[data-cat]");
  for (var i = 0; i < catEls.length; i++) cats[catEls[i].dataset.cat] = catEls[i].checked;
  var binEls = document.querySelectorAll(".sort-cat .sc-bin");
  for (var j = 0; j < binEls.length; j++) names[binEls[j].dataset.bin] = binEls[j].value.trim() || binEls[j].dataset.bin;
  return {
    cats: cats, names: names,
    removeEmpty: document.getElementById("sort-rm-empty").checked,
    removeUnused: document.getElementById("sort-rm-unused").checked,
    ignore: document.getElementById("sort-ignore").value || "",
    selectedOnly: document.getElementById("sort-selected-only").checked,
    subByExt: document.getElementById("sort-sub-ext").checked
  };
}

function saveSortPrefs() {
  try { localStorage.setItem(STORAGE_SORT, JSON.stringify(collectSortOpts())); } catch (e) {}
}

function loadSortPrefs() {
  try {
    var o = JSON.parse(localStorage.getItem(STORAGE_SORT));
    if (!o) return;
    if (o.cats) {
      var catEls = document.querySelectorAll(".sort-cat input[data-cat]");
      for (var i = 0; i < catEls.length; i++) {
        if (o.cats[catEls[i].dataset.cat] !== undefined) catEls[i].checked = o.cats[catEls[i].dataset.cat];
      }
    }
    if (o.names) {
      var binEls = document.querySelectorAll(".sort-cat .sc-bin");
      for (var j = 0; j < binEls.length; j++) {
        if (o.names[binEls[j].dataset.bin]) binEls[j].value = o.names[binEls[j].dataset.bin];
      }
    }
    if (o.removeEmpty !== undefined) document.getElementById("sort-rm-empty").checked = o.removeEmpty;
    if (o.removeUnused !== undefined) document.getElementById("sort-rm-unused").checked = o.removeUnused;
    if (o.ignore !== undefined) document.getElementById("sort-ignore").value = o.ignore;
    if (o.selectedOnly !== undefined) document.getElementById("sort-selected-only").checked = o.selectedOnly;
    if (o.subByExt !== undefined) document.getElementById("sort-sub-ext").checked = o.subByExt;
  } catch (e) {}
}

// Общий вызов сортировки; onStatus(ok, msg) — куда отдать результат
function doSort(opts, onStatus) {
  var arg = JSON.stringify(opts).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  csInterface.evalScript('runProjectSort("' + arg + '")', function (res) {
    var data;
    try { data = JSON.parse(res); } catch (e) { data = null; }
    if (data && data.ok) {
      var parts = ["Разложено: " + data.moved];
      if (data.removedUnused) parts.push("удалено неиспольз.: " + data.removedUnused);
      if (data.removedEmpty) parts.push("пустых папок убрано: " + data.removedEmpty);
      if (data.skipped) parts.push("пропущено: " + data.skipped);
      onStatus(true, parts.join(" · "));
    } else if (data && data.msg) {
      onStatus(false, data.msg);
    } else {
      var raw = (res === undefined || res === null || res === "") ? "(пустой ответ)" : String(res);
      if (raw.length > 140) raw = raw.substring(0, 140) + "…";
      onStatus(false, "Ошибка скрипта: " + raw);
    }
  });
}

// Сортировка из открытого окна настроек (статус — внутри окна)
function runSort() {
  var btn = document.getElementById("sort-run");
  var st = document.getElementById("sort-status");
  var opts = collectSortOpts();
  saveSortPrefs();

  btn.classList.add("busy");
  st.className = ""; st.textContent = "Сортирую проект…";
  doSort(opts, function (ok, msg) {
    btn.classList.remove("busy");
    st.className = ok ? "success" : "error";
    st.textContent = (ok ? "✅ " : "⚠ ") + msg;
  });
}

// Сортировка в один клик по сохранённым настройкам (статус — в нижнюю строку).
function runSortQuick() {
  doSortNow();
}

function doSortNow() {
  loadSortPrefs();              // подтянуть сохранённые настройки в форму
  var opts = collectSortOpts(); // и собрать их
  flashStatus("Сортирую проект…", "");
  document.getElementById("btn-sort").classList.add("busy");
  doSort(opts, function (ok, msg) {
    document.getElementById("btn-sort").classList.remove("busy");
    flashStatus((ok ? "✅ " : "⚠ ") + msg, ok ? "success" : "error");
  });
}

function bindSorter() {
  var overlay = document.getElementById("sort-overlay");
  if (!overlay) return;
  overlay.addEventListener("click", function (e) { if (e.target === overlay) closeSorter(); });
  document.getElementById("sort-run").addEventListener("click", runSort);
  // сохранять настройки при изменении
  overlay.addEventListener("change", saveSortPrefs);
}

// Режим перемещения плиток (карандаш)
function toggleFxEdit() {
  state.fxEdit = !state.fxEdit;
  var btn = document.getElementById("fx-edit");
  if (btn) {
    btn.classList.toggle("active", state.fxEdit);
    btn.title = state.fxEdit ? "Готово (выключить перемещение)" : "Режим перемещения плиток";
  }
  // подсветка доски в режиме редактирования
  var dockBody = document.getElementById("fx-dock-body");
  var tabBody  = document.getElementById("fx-groups");
  [dockBody, tabBody].forEach(function (el) {
    if (el) el.classList.toggle("fx-board-edit", state.fxEdit);
  });
  if (state.fxEdit) setFooterMsg("✎ Режим перемещения: таскай плитки и тяни за угол", "");
}

// Навесить эффект через QE DOM. Если QE недоступен — честно сообщаем.
function applyEffect(it, btn) {
  if (btn) btn.classList.add("busy");
  setFooterMsg("Навешиваю «" + it.label + "»…", "");

  csInterface.evalScript('applyAudioEffect("' + escPath(it.fx) + '")', function (res) {
    if (btn) btn.classList.remove("busy");
    var data;
    try { data = JSON.parse(res); } catch (e) { data = { ok: false, msg: "Неизвестный ответ" }; }

    if (data.ok) {
      setFooterMsg("✅ " + (data.msg || ("Навешено: " + it.label)), "success");
    } else if (data.reason === "no_qe") {
      setFooterMsg("⚠ QE DOM недоступен в этой сборке Premiere — навесить эффект кодом нельзя", "error");
    } else if (data.reason === "no_clip") {
      setFooterMsg("⚠ Сначала выдели аудиоклип на таймлайне", "error");
    } else {
      setFooterMsg("⚠ " + (data.msg || "Не удалось навесить эффект"), "error");
    }
  });
}

// Настройки расположения/подписей эффектов
function setFxLayout(layout) {
  if (layout !== "dock" && layout !== "tab") return;
  state.fxLayout = layout;
  saveViewPrefs();
  markFxSettingRows();
  // если ушли из вкладки в док — вернёмся к SFX-режиму отображения
  if (layout === "dock") {
    document.getElementById("view-track").classList.remove("show-fx");
  } else if (state.mode === "fx") {
    document.getElementById("view-track").classList.add("show-fx");
    renderFxGroups();
  }
  applyFxLayout();
}

function setFxLabels(lbl) {
  if (lbl !== "full" && lbl !== "abbr") return;
  state.fxLabels = lbl;
  saveViewPrefs();
  markFxSettingRows();
  renderFxDock();
  renderFxGroups();
}

function markFxSettingRows() {
  var loc = document.querySelectorAll(".fxloc-row");
  for (var i = 0; i < loc.length; i++) loc[i].classList.toggle("active", loc[i].dataset.fxloc === state.fxLayout);
  var lbl = document.querySelectorAll(".fxlbl-row");
  for (var j = 0; j < lbl.length; j++) lbl[j].classList.toggle("active", lbl[j].dataset.fxlbl === state.fxLabels);
}

function bindFxControls() {
  // слайдер: задаёт ОДИНАКОВЫЙ размер всем плиткам сразу, ПОЭТАПНО (шагами).
  // Точная подгонка каждой плитки — за угол в режиме редактирования.
  var size = document.getElementById("fx-size");
  if (size) {
    size.min = String(FX_TILE_MIN); size.max = String(FX_TILE_MAX); size.step = String(FX_SIZE_STEP);
    size.value = state.fxTileSize || FX_TILE_DEF;
    size.title = "Размер всех плиток";
    size.addEventListener("input", function () {
      var s = snapDim(parseInt(this.value, 10));
      state.fxTileSize = s;
      for (var k in state.fxBoard) { var p = fxPos(k); p.w = s; p.h = s; }
      renderActiveFxBoard();
    });
    size.addEventListener("change", function () { saveFxBoard(); saveViewPrefs(); });
  }

  // карандаш: вкл/выкл режим перемещения плиток
  var edit = document.getElementById("fx-edit");
  if (edit) {
    edit.addEventListener("click", function () { toggleFxEdit(); });
  }

  // резайзер высоты дока
  var rez = document.getElementById("fx-dock-resizer");
  var dock = document.getElementById("fx-dock");
  var dragging = false, startY = 0, startH = 0;
  if (rez) {
    rez.addEventListener("mousedown", function (e) {
      dragging = true; startY = e.clientY; startH = dock.offsetHeight;
      rez.classList.add("dragging"); document.body.classList.add("fx-resizing");
      e.preventDefault();
    });
    document.addEventListener("mousemove", function (e) {
      if (!dragging) return;
      var h = startH - (e.clientY - startY); // тянем вверх → выше
      h = Math.max(90, Math.min(400, h));
      state.fxDockH = h;
      dock.style.height = h + "px";
    });
    document.addEventListener("mouseup", function () {
      if (!dragging) return;
      dragging = false;
      rez.classList.remove("dragging"); document.body.classList.remove("fx-resizing");
      saveViewPrefs();
    });
  }

  // строки настроек
  var loc = document.querySelectorAll(".fxloc-row");
  for (var i = 0; i < loc.length; i++) {
    loc[i].addEventListener("click", function () { setFxLayout(this.dataset.fxloc); });
  }
  var lbl = document.querySelectorAll(".fxlbl-row");
  for (var j = 0; j < lbl.length; j++) {
    lbl[j].addEventListener("click", function () { setFxLabels(this.dataset.fxlbl); });
  }
  markFxSettingRows();

  // саб-вкладки Эффекты / Пресеты (в доке и во вкладке)
  ["fxsub-fx", "fxsub-fx-d"].forEach(function (id) {
    var b = document.getElementById(id);
    if (b) b.addEventListener("click", function () { setFxSection("fx"); });
  });
  ["fxsub-presets", "fxsub-presets-d"].forEach(function (id) {
    var b = document.getElementById(id);
    if (b) b.addEventListener("click", function () { setFxSection("presets"); });
  });
}


function bindEvents() {
  document.getElementById("btn-choose-root").addEventListener("click", chooseRoot);

  var searchTimer = null;
  var searchInput = document.getElementById("search-input");
  // при фокусе на поиск — ставим превью на паузу, чтобы звук не мешал печатать
  searchInput.addEventListener("focus", function () {
    if (player.playing) player.pause();
  });
  searchInput.addEventListener("input", function () {
    var val = this.value.toLowerCase();
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () {
      applySearchQuery(val);
    }, 120);
  });
  document.getElementById("btn-clear-search").addEventListener("click", function () {
    document.getElementById("search-input").value = "";
    applySearchQuery("");
  });

  document.getElementById("btn-back").addEventListener("click", goBack);
  document.getElementById("btn-refresh").addEventListener("click", manualRefresh);
  document.getElementById("btn-add-timeline").addEventListener("click", addSelected);
  document.getElementById("btn-add-folder").addEventListener("click", addAnotherRoot);
  document.getElementById("tab-folders").addEventListener("click", function () { setTab("folders"); });
  document.getElementById("tab-favs").addEventListener("click", function () { setTab("favs"); });
  document.getElementById("tab-cols").addEventListener("click", function () { setTab("cols"); });
  document.getElementById("btn-new-col").addEventListener("click", function () { createCollection(null, []); });
  document.getElementById("mode-sfx").addEventListener("click", function () { setMode("sfx"); });
  document.getElementById("mode-fx").addEventListener("click", function () { setMode("fx"); });
  document.getElementById("btn-sort").addEventListener("click", runSortQuick);
  var sortCfg = document.getElementById("btn-sort-cfg");
  if (sortCfg) sortCfg.addEventListener("click", openSorter);
  bindSorter();

  var sfxList = document.getElementById("sfx-list");

  // КЛИК: по строке → выбор + мгновенное воспроизведение
  //        по уже выбранной → play/pause
  //        по пустому месту → снять выделение (плеер исчезает)
  sfxList.addEventListener("click", function (e) {
    var item = closestItem(e.target, "sfx-item");
    if (!item) {
      if (e.target === sfxList) deselectFile();
      return;
    }
    var f = state.filteredSfx[+item.dataset.idx];
    if (!f) return;

    if (hasClass(e.target, "sfx-star")) {
      toggleFavorite(f, e.target);
      return;
    }

    if (hasClass(e.target, "sfx-btn-add")) {
      selectFile(f, item);
      addSelected();
      return;
    }

    var isSame = state.selectedFile && state.selectedFile.path === f.path;
    if (isSame) {
      player.toggle();          // и кнопка ▶ на строке, и сама строка
    } else {
      selectFile(f, item);
      player.load(f, true);     // сразу играем
    }
  });

  // ДАБЛ-КЛИК: добавить в таймлайн
  sfxList.addEventListener("dblclick", function (e) {
    var item = closestItem(e.target, "sfx-item");
    if (!item || hasClass(e.target, "sfx-btn-add") || hasClass(e.target, "sfx-star")) return;
    var f = state.filteredSfx[+item.dataset.idx];
    if (!f) return;
    selectFile(f, item);
    addSelected();
  });

  // ПКМ по звуку — контекстное меню (избранное / в коллекцию)
  sfxList.addEventListener("contextmenu", function (e) {
    var item = closestItem(e.target, "sfx-item");
    if (!item) return;
    var f = state.filteredSfx[+item.dataset.idx];
    if (!f) return;
    e.preventDefault();
    showSoundContextMenu(e, f);
  });

  // закрытие контекстного меню
  document.addEventListener("click", function (e) {
    var menu = document.getElementById("ctx-menu");
    if (!menu.classList.contains("hidden") && !menu.contains(e.target)) hideContextMenu();
  });
  document.addEventListener("scroll", hideContextMenu, true);
  window.addEventListener("blur", hideContextMenu);

  var scrollPending = false;
  sfxList.addEventListener("scroll", function () {
    var nearEnd = (state.viewMode === "grid" && state.gridDir === "v")
      ? sfxList.scrollLeft + sfxList.clientWidth >= sfxList.scrollWidth - 300
      : sfxList.scrollTop + sfxList.clientHeight >= sfxList.scrollHeight - 200;
    if (nearEnd) appendChunk();

    if (!scrollPending) {
      scrollPending = true;
      requestAnimationFrame(function () {
        scrollPending = false;
        scheduleThumbs();
      });
    }
  });

  // Esc — снять выделение; Пробел — пауза/плей
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      if (player.hasSelection()) player.clearSelection();
      else deselectFile();
      return;
    }
    if (e.code === "Space" || e.key === " ") {
      var ae = document.activeElement;
      // не мешаем печатать пробелы в поиске
      if (ae && ae.tagName === "INPUT" && (ae.type === "text" || ae.type === "search")) return;
      if (player.file) {
        e.preventDefault();
        player.toggle();
      }
    }
  });

  // Drag&drop звука из списка/сетки прямо на таймлайн Premiere
  sfxList.addEventListener("dragstart", function (e) {
    var item = closestItem(e.target, "sfx-item");
    if (!item) { e.preventDefault(); return; }
    var f = state.filteredSfx[+item.dataset.idx];
    if (!f) { e.preventDefault(); return; }

    e.dataTransfer.effectAllowed = "copy";
    e.dataTransfer.setData("com.adobe.cep.dnd.file.0", f.path);

    // если у этого файла раньше выставляли in/out выделением — сбрасываем,
    // чтобы перетянулся целиком
    if (trimmedDurations[f.path]) {
      csInterface.evalScript(
        'resetTrim("' + escPath(f.path) + '",' + trimmedDurations[f.path].toFixed(4) + ')',
        function () {}
      );
      delete trimmedDurations[f.path];
    }
  });
}

// Файлы, которым в этой сессии ставили in/out (path → полная длительность)
var trimmedDurations = {};

// ══════════════════════════════════════════════
//  РЕНДЕР ФРАГМЕНТА В WAV (для drag&drop куска)
// ══════════════════════════════════════════════
function encodeWavSelection(buf, startSec, endSec) {
  var sr = buf.sampleRate;
  var ch = Math.min(2, buf.numberOfChannels);
  var s0 = Math.max(0, Math.floor(startSec * sr));
  var s1 = Math.min(buf.length, Math.ceil(endSec * sr));
  var frames = Math.max(1, s1 - s0);
  var blockAlign = ch * 2; // 16-bit PCM
  var dataSize = frames * blockAlign;

  var ab = new ArrayBuffer(44 + dataSize);
  var dv = new DataView(ab);
  function wstr(o, s) { for (var i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); }

  wstr(0, "RIFF"); dv.setUint32(4, 36 + dataSize, true); wstr(8, "WAVE");
  wstr(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true);
  dv.setUint16(22, ch, true); dv.setUint32(24, sr, true);
  dv.setUint32(28, sr * blockAlign, true); dv.setUint16(32, blockAlign, true);
  dv.setUint16(34, 16, true); wstr(36, "data"); dv.setUint32(40, dataSize, true);

  var chans = [];
  for (var c = 0; c < ch; c++) chans.push(buf.getChannelData(c));

  var off = 44;
  for (var i = s0; i < s1; i++) {
    for (var c2 = 0; c2 < ch; c2++) {
      var v = chans[c2][i];
      v = Math.max(-1, Math.min(1, v));
      dv.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7FFF, true);
      off += 2;
    }
  }
  return ab;
}

// Varispeed-ресэмплинг (линейная интерполяция): rate>1 — выше и короче,
// rate<1 — ниже и длиннее. Звучит ровно как превью с Pitch.
function resampleChannels(buf, s0Sec, s1Sec, rate) {
  var sr = buf.sampleRate;
  var ch = Math.min(2, buf.numberOfChannels);
  var s0 = Math.max(0, Math.floor(s0Sec * sr));
  var s1 = Math.min(buf.length, Math.ceil(s1Sec * sr));
  var inFrames  = Math.max(1, s1 - s0);
  var outFrames = Math.max(1, Math.round(inFrames / rate));

  var channels = [];
  for (var c = 0; c < ch; c++) {
    var src = buf.getChannelData(c);
    var dst = new Float32Array(outFrames);
    for (var i = 0; i < outFrames; i++) {
      var pos  = s0 + i * rate;
      var i0   = Math.floor(pos);
      var frac = pos - i0;
      var a = src[i0] !== undefined ? src[i0] : 0;
      var b = src[i0 + 1] !== undefined ? src[i0 + 1] : a;
      dst[i] = a + (b - a) * frac;
    }
    channels.push(dst);
  }
  return { channels: channels, sampleRate: sr, frames: outFrames };
}

function encodeWavChannels(seg) {
  var ch = seg.channels.length;
  var blockAlign = ch * 2;
  var dataSize = seg.frames * blockAlign;

  var ab = new ArrayBuffer(44 + dataSize);
  var dv = new DataView(ab);
  function wstr(o, s) { for (var i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); }

  wstr(0, "RIFF"); dv.setUint32(4, 36 + dataSize, true); wstr(8, "WAVE");
  wstr(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true);
  dv.setUint16(22, ch, true); dv.setUint32(24, seg.sampleRate, true);
  dv.setUint32(28, seg.sampleRate * blockAlign, true); dv.setUint16(32, blockAlign, true);
  dv.setUint16(34, 16, true); wstr(36, "data"); dv.setUint32(40, dataSize, true);

  var off = 44;
  for (var i = 0; i < seg.frames; i++) {
    for (var c = 0; c < ch; c++) {
      var v = seg.channels[c][i];
      v = Math.max(-1, Math.min(1, v));
      dv.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7FFF, true);
      off += 2;
    }
  }
  return ab;
}

// Кусок [startSec; endSec] текущего буфера с применённым Pitch (и Reverse,
// т.к. берётся activeBuffer). Координаты — в текущей ориентации.
function renderProcessedWav(startSec, endSec) {
  var buf = player.activeBuffer();
  if (player.rate === 1) return encodeWavSelection(buf, startSec, endSec); // быстрый путь
  return encodeWavChannels(resampleChannels(buf, startSec, endSec, player.rate));
}

function tmpFragmentPath(srcName) {
  var base = stripExt(srcName).replace(/[^\wа-яА-ЯёЁ\- ]/g, "_").slice(0, 60);
  return nodePath.join(nodeOs.tmpdir(), "MFLIB_" + base + "_" + Date.now() + ".wav");
}

// Подчистить старые фрагменты прошлых сессий
function cleanupTmpFragments() {
  if (!nodeFs || !nodeOs) return;
  try {
    var dir = nodeOs.tmpdir();
    var names = nodeFs.readdirSync(dir);
    var dayAgo = Date.now() - 24 * 60 * 60 * 1000;
    for (var i = 0; i < names.length; i++) {
      if (names[i].indexOf("MFLIB_") !== 0) continue;
      var p = nodePath.join(dir, names[i]);
      try {
        if (nodeFs.statSync(p).mtimeMs < dayAgo) nodeFs.unlinkSync(p);
      } catch (e) {}
    }
  } catch (e) {}
}

function bindSettings() {
  var btn   = document.getElementById("btn-settings");
  var panel = document.getElementById("settings-panel");

  btn.addEventListener("click", function (e) {
    e.stopPropagation();
    panel.classList.toggle("hidden");
  });
  // закрытие: крестик или клик по тёмному фону (вне модалки)
  var closeBtn = document.getElementById("settings-close");
  if (closeBtn) closeBtn.addEventListener("click", function () { panel.classList.add("hidden"); });
  panel.addEventListener("click", function (e) {
    if (e.target === panel) panel.classList.add("hidden"); // клик по фону
  });

  var rows = document.querySelectorAll(".theme-row");
  for (var i = 0; i < rows.length; i++) {
    rows[i].addEventListener("click", function () {
      setTheme(this.dataset.theme);
    });
  }

  // кастомная палитра на свотчах (живое изменение + commit при OK)
  bindColorPicker();
  var resetBtn = document.getElementById("btn-reset-custom");
  if (resetBtn) resetBtn.addEventListener("click", resetManualColors);

  // режим папок: дерево / навигация
  var fmodeRows = document.querySelectorAll(".fmode-row");
  for (var j = 0; j < fmodeRows.length; j++) {
    fmodeRows[j].addEventListener("click", function () {
      setFolderMode(this.dataset.fmode);
    });
  }

  // раскрытие: одна ветка / несколько
  var fexpRows = document.querySelectorAll(".fexp-row");
  for (var k = 0; k < fexpRows.length; k++) {
    fexpRows[k].addEventListener("click", function () {
      state.folderExpand = this.dataset.fexp;
      saveViewPrefs();
      applyFolderModeUI();
      if (state.folderExpand === "single") collapseToSingleBranch();
    });
  }
  applyFolderModeUI();
}

// При переключении в «одна открытая» — схлопнуть всё, кроме ветки выбранной папки
function collapseToSingleBranch() {
  if (state.folderMode !== "tree") return;
  var keepPath = state.displayedFolderPath || state.rootPath;
  if (!keepPath) return;
  var next = {};
  for (var p in expandedPaths) {
    if (!expandedPaths[p]) continue;
    if (p === state.rootPath || isAncestorOf(p, keepPath) || p === keepPath) next[p] = true;
  }
  expandedPaths = next;
  renderFolderTree();
}

function isAncestorOf(ancestor, path) {
  var sep = path.indexOf("\\") !== -1 ? "\\" : "/";
  var pre = ancestor.charAt(ancestor.length - 1) === sep ? ancestor : ancestor + sep;
  return path.indexOf(pre) === 0;
}

function setFolderMode(mode) {
  if (mode !== "tree" && mode !== "nav") return;
  if (state.folderMode === mode) return;
  state.folderMode = mode;
  saveViewPrefs();
  applyFolderModeUI();

  if (mode === "nav" && state.rootPath) {
    // в навигации возвращаемся к корню, чтобы история была консистентной
    state.currentPath = state.rootPath;
    state.history = [];
    document.getElementById("btn-back").disabled = true;
    loadFolders(state.rootPath);
    updateBreadcrumb();
  } else {
    renderFolders();
  }
}

function applyFolderModeUI() {
  var tree = state.folderMode === "tree";
  document.body.classList.toggle("tree-mode", tree);
  var rows = document.querySelectorAll(".fmode-row");
  for (var i = 0; i < rows.length; i++) {
    rows[i].classList.toggle("active", rows[i].dataset.fmode === state.folderMode);
  }
  var erows = document.querySelectorAll(".fexp-row");
  for (var j = 0; j < erows.length; j++) {
    erows[j].classList.toggle("active", erows[j].dataset.fexp === state.folderExpand);
  }
}

// ── Переключение вида: список / сетка / направление / размер ──
function bindViewControls() {
  var btnList = document.getElementById("vw-list");
  var btnGrid = document.getElementById("vw-grid");
  var btnDir  = document.getElementById("vw-dir");
  var size    = document.getElementById("vw-size");

  // слайдер 2..8; вправо = крупнее, поэтому колонки = 10 - значение
  size.value = 10 - state.gridCols;

  btnList.addEventListener("click", function () { setViewMode("list"); });
  btnGrid.addEventListener("click", function () { setViewMode("grid"); });
  btnDir.addEventListener("click", function () {
    state.gridDir = state.gridDir === "h" ? "v" : "h";
    saveViewPrefs();
    applyViewState();
    renderSfxList();
  });
  // меняется ТОЛЬКО по шагам — сетка всегда заполняет ширину без зазоров
  size.addEventListener("input", function () {
    var cols = 10 - parseInt(this.value, 10);
    if (cols === state.gridCols) return;
    state.gridCols = cols;
    updateGridMetrics();
  });
  size.addEventListener("change", saveViewPrefs);

  applyViewState();
}

function setViewMode(mode) {
  if (state.viewMode === mode) return;
  state.viewMode = mode;
  saveViewPrefs();
  applyViewState();
  renderSfxList();
}

function applyViewState() {
  var list = document.getElementById("sfx-list");
  var grid = state.viewMode === "grid";

  list.classList.toggle("grid", grid);
  list.classList.toggle("vflow", grid && state.gridDir === "v");
  document.getElementById("sfx-table-header").classList.toggle("hidden", grid);

  document.getElementById("vw-list").classList.toggle("active", !grid);
  document.getElementById("vw-grid").classList.toggle("active", grid);
  document.getElementById("vw-dir").classList.toggle("hidden", !grid);
  document.getElementById("vw-size").classList.toggle("hidden", !grid);
  document.getElementById("vw-dir").textContent = state.gridDir === "h" ? "⇅" : "⇄";

  requestAnimationFrame(updateGridMetrics);
}

// Пересчёт размеров плиток так, чтобы N колонок/рядов ЧЁТКО заполняли панель
function updateGridMetrics() {
  if (state.viewMode !== "grid") return;
  var list = document.getElementById("sfx-list");
  var cols = state.gridCols;
  var gap = 8, pad = 20;
  var r = document.documentElement.style;
  r.setProperty("--cols", cols);

  var tileW;
  if (state.gridDir === "h") {
    var w = Math.floor((list.clientWidth - pad - gap * (cols - 1)) / cols);
    if (w < 40) w = 40;
    tileW = w;
    r.setProperty("--tile-w", w + "px");
    r.setProperty("--tile-h", Math.round(w * 0.62) + 34 + "px");
  } else {
    var h = Math.floor((list.clientHeight - pad - gap * (cols - 1)) / cols);
    if (h < 60) h = 60;
    tileW = Math.max(90, Math.round((h - 34) * 1.5));
    r.setProperty("--tile-h", h + "px");
    r.setProperty("--tile-w", tileW + "px");
  }

  // шрифт подписи и кнопка ▶ масштабируются вместе с плиткой
  var font = Math.max(9, Math.min(12, Math.round(tileW * 0.08)));
  r.setProperty("--tile-font", font + "px");
  var btn = Math.max(18, Math.min(34, Math.round(tileW * 0.16)));
  r.setProperty("--tile-btn", btn + "px");
  list.classList.toggle("compact", tileW < 125);

  refreshThumbSizes();
}

// Перерисовать готовые миниатюры под новый размер плиток
function refreshThumbSizes() {
  var canvases = document.querySelectorAll('.tile-wave[data-state="done"]');
  for (var i = 0; i < canvases.length; i++) {
    var p = canvases[i].getAttribute("data-path");
    if (thumbCache[p]) drawThumb(canvases[i], thumbCache[p]);
  }
}

function saveViewPrefs() {
  localStorage.setItem(STORAGE_VIEW, JSON.stringify({
    mode: state.viewMode, dir: state.gridDir, cols: state.gridCols, fmode: state.folderMode, fexp: state.folderExpand,
    fxLayout: state.fxLayout, fxLabels: state.fxLabels, fxSize: state.fxSize, fxDockH: state.fxDockH,
    fxTileSize: state.fxTileSize
  }));
}

function bindResizer() {
  var resizer = document.getElementById("resizer");
  var dragging = false;

  resizer.addEventListener("mousedown", function (e) {
    dragging = true;
    resizer.classList.add("dragging");
    document.body.classList.add("resizing");
    e.preventDefault();
  });
  var gridRaf = false;
  document.addEventListener("mousemove", function (e) {
    if (!dragging) return;
    var bodyRect = document.getElementById("body").getBoundingClientRect();
    var w = e.clientX - bodyRect.left;
    w = Math.max(120, Math.min(500, w));
    setSidebarWidth(w);
    if (!gridRaf) {
      gridRaf = true;
      requestAnimationFrame(function () { gridRaf = false; updateGridMetrics(); });
    }
  });
  document.addEventListener("mouseup", function () {
    if (!dragging) return;
    dragging = false;
    resizer.classList.remove("dragging");
    document.body.classList.remove("resizing");
    localStorage.setItem(STORAGE_SIDEW, String(document.getElementById("sidebar").offsetWidth));
    player.redrawWave();
    player.drawSelection();
    updateGridMetrics();
  });
}

function setSidebarWidth(w) {
  var sb = document.getElementById("sidebar");
  sb.style.width = w + "px";
  sb.style.minWidth = w + "px";
}

function bindPlayer() {
  document.getElementById("pl-play").addEventListener("click", function () { player.toggle(); });
  document.getElementById("pl-loop").addEventListener("click", function () { player.setLoop(!player.loop); });
  document.getElementById("pl-volume").addEventListener("input", function () {
    player.setVolume(this.value / 100);
  });
  document.getElementById("pl-pitch").addEventListener("input", function () {
    player.setPitch(parseInt(this.value, 10));
  });
  document.getElementById("pl-pitch-reset").addEventListener("click", function () {
    document.getElementById("pl-pitch").value = 0;
    player.setPitch(0);
  });
  document.getElementById("pl-reverse").addEventListener("change", function () {
    player.setReverse(this.checked);
  });
  // ── волна: клик = перемотка, протяжка = выделение диапазона ──
  var wrap = document.getElementById("pl-wave-wrap");
  var selEl = document.getElementById("pl-selection");
  var selDrag = { active: false, moved: false, startX: 0 };

  wrap.addEventListener("mousedown", function (e) {
    if (e.target === selEl) return; // это начало drag&drop выделения
    if (!player.duration || e.button !== 0) return;
    selDrag.active = true;
    selDrag.moved  = false;
    selDrag.startX = e.clientX - wrap.getBoundingClientRect().left;
    e.preventDefault();
  });

  document.addEventListener("mousemove", function (e) {
    if (!selDrag.active) return;
    var rect = wrap.getBoundingClientRect();
    var x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    if (!selDrag.moved && Math.abs(x - selDrag.startX) < 4) return;
    selDrag.moved = true;
    var a = (Math.min(selDrag.startX, x) / rect.width) * player.duration;
    var b = (Math.max(selDrag.startX, x) / rect.width) * player.duration;
    player.setSelection(a, b);
  });

  document.addEventListener("mouseup", function (e) {
    if (!selDrag.active) return;
    selDrag.active = false;
    if (!selDrag.moved) {
      // обычный клик — перемотка и снятие выделения
      var rect = wrap.getBoundingClientRect();
      var frac = (e.clientX - rect.left) / rect.width;
      player.clearSelection();
      player.seek(frac * player.duration);
    }
  });

  // Drag&drop выделенного диапазона на таймлайн Premiere.
  // Тащим ОРИГИНАЛЬНЫЙ файл (полное медиа), перед этим снимаем снапшот
  // клипов с этим файлом в секвенции. После дропа находим новый клип
  // и обрезаем до выделения. Медиа полное → клип тянется влево/вправо
  // до самых краёв исходного звука, без «заборчиков».
  // Исключение: при включённом Reverse файл рендерится во временный WAV
  // (развёрнутого оригинала на диске не существует).
  var HANDLE_SEC = 30; // запас для reverse-фрагментов
  var pendingTrim = null;

  selEl.addEventListener("dragstart", function (e) {
    if (!player.file || !player.hasSelection()) { e.preventDefault(); return; }
    e.dataTransfer.effectAllowed = "copy";
    pendingTrim = null;

    var needRender = player.reversed || player.pitch !== 0;

    if (!needRender) {
      // ── основной путь: оригинальный файл целиком ──
      var sel = player.selectionInOriginal();
      e.dataTransfer.setData("com.adobe.cep.dnd.file.0", player.file.path);
      pendingTrim = {
        path: player.file.path,
        inSec: sel.inSec,
        outSec: sel.outSec,
        snapshot: null, // заполнится асинхронно до дропа
        tries: 0
      };
      var job = pendingTrim;
      csInterface.evalScript('listClipsByPath("' + escPath(player.file.path) + '")', function (res) {
        if (job === pendingTrim && typeof res === "string" && res !== "EvalScript error.") {
          job.snapshot = res;
        } else if (job.snapshot === null) {
          job.snapshot = "";
        }
      });
      setFooterMsg("🎬 Фрагмент " + fmtTime(player.selEnd - player.selStart) + " — кидай на таймлайн", "success");
      return;
    }

    // ── Pitch и/или Reverse: рендерим обработанный кусок с запасом ──
    var dragPath = null;
    if (nodeFs && nodeOs && player.buffer) {
      try {
        var rate = player.rate;
        var h0 = Math.max(0, player.selStart - HANDLE_SEC);
        var h1 = Math.min(player.duration, player.selEnd + HANDLE_SEC);
        var ab = renderProcessedWav(h0, h1);
        dragPath = tmpFragmentPath(player.file.name);
        nodeFs.writeFileSync(dragPath, new Uint8Array(ab));
        // позиции внутри обработанного файла растянуты/сжаты на rate
        pendingTrim = {
          path: dragPath,
          inSec:  (player.selStart - h0) / rate,
          outSec: (player.selEnd - h0) / rate,
          snapshot: "",
          tries: 0
        };
      } catch (err) {
        console.error("Fragment render failed:", err);
        dragPath = null;
      }
    }

    if (dragPath) {
      e.dataTransfer.setData("com.adobe.cep.dnd.file.0", dragPath);
      var fx = [];
      if (player.pitch !== 0) fx.push("Pitch " + (player.pitch > 0 ? "+" : "") + player.pitch);
      if (player.reversed) fx.push("Reverse");
      setFooterMsg("🎬 Фрагмент (" + fx.join(", ") + ") — кидай на таймлайн", "success");
    } else {
      e.preventDefault();
      setFooterMsg("⚠ Не удалось подготовить фрагмент", "error");
    }
  });

  // После дропа начинаем опрашивать секвенцию СРАЗУ и часто —
  // обрезаем клип в первые же миллисекунды, как только Premiere его положил
  selEl.addEventListener("dragend", function () {
    if (!pendingTrim) return;
    var job = pendingTrim;
    pendingTrim = null;
    scheduleDropTrim(job, 0);
  });

  var TRIM_POLL_MS  = 120; // частота опроса
  var TRIM_MAX_TRIES = 40; // ~5 секунд на самый медленный импорт

  function scheduleDropTrim(job, delay) {
    setTimeout(function () {
      if (job.snapshot === null) {
        // снапшот ещё не пришёл — он почти готов, ждём чуть-чуть
        if (++job.tries < TRIM_MAX_TRIES) scheduleDropTrim(job, 60);
        return;
      }
      csInterface.evalScript(
        'trimNewClipByPath("' + escPath(job.path) + '",' +
          job.inSec.toFixed(4) + ',' + job.outSec.toFixed(4) + ',"' + job.snapshot + '")',
        function (res) {
          var ok = false;
          try { ok = JSON.parse(res).ok; } catch (e) {}
          if (!ok && ++job.tries < TRIM_MAX_TRIES) {
            scheduleDropTrim(job, TRIM_POLL_MS); // клип ещё не появился — опрашиваем дальше
          }
        }
      );
    }, delay);
  }

  window.addEventListener("resize", function () {
    player.redrawWave();
    player.drawSelection();
    updateGridMetrics();
  });

  // Клик в другое окно (таймлайн Premiere и т.д.) — панель теряет фокус,
  // превью автоматически ставится на паузу
  window.addEventListener("blur", function () {
    if (player.playing) player.pause();
  });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden && player.playing) player.pause();
  });
}

function closestItem(el, cls) {
  while (el && el !== document) {
    if (el.classList && el.classList.contains(cls)) return el;
    el = el.parentNode;
  }
  return null;
}
function hasClass(el, cls) { return el && el.classList && el.classList.contains(cls); }

// ══════════════════════════════════════════════
//  КОРНЕВЫЕ ПАПКИ (несколько) / ИНДЕКС
// ══════════════════════════════════════════════
// ══════════════════════════════════════════════
//  СВОЙ БРАУЗЕР ПАПОК (в стиле плагина, поверх UI панели)
// ══════════════════════════════════════════════
var fb = { cb: null, current: "", chosen: "" };

function openFolderBrowser(title, callback) {
  fb.cb = callback;
  fb.current = "";
  fb.chosen = "";
  document.getElementById("fb-title").textContent = title || "Выбери папку";
  document.getElementById("fb-overlay").classList.remove("hidden");
  document.getElementById("fb-choose").disabled = true;
  document.getElementById("fb-current").textContent = "—";

  if (nodeFs) {
    // показываем диски/стартовые точки через Node (быстро, кроссплатформенно)
    fbShowDrivesNode();
  } else {
    csInterface.evalScript("listDrives()", function (res) {
      var drives = [];
      try { drives = JSON.parse(res) || []; } catch (e) {}
      fbRenderRoots(drives);
    });
  }
}

// Вернуться к списку дисков/расположений (используется и кнопкой «вверх»)
function fbShowDrives() {
  if (nodeFs) {
    fbShowDrivesNode();
  } else {
    csInterface.evalScript("listDrives()", function (res) {
      var drives = [];
      try { drives = JSON.parse(res) || []; } catch (e) {}
      fbRenderRoots(drives);
    });
  }
}

function closeFolderBrowser() {
  document.getElementById("fb-overlay").classList.add("hidden");
  fb.cb = null;
}

function fbShowDrivesNode() {
  var roots = [];
  try {
    var os = nodeOs.platform();
    if (os === "win32") {
      var letters = "CDEFGHIJKLMNOPQRSTUVWXYZ".split("");
      for (var i = 0; i < letters.length; i++) {
        var p = letters[i] + ":\\";
        try { if (nodeFs.existsSync(p)) roots.push({ name: letters[i] + ":\\", path: p }); } catch (e) {}
      }
    } else {
      var home = nodeOs.homedir();
      if (home) roots.push({ name: "Домашняя", path: home });
      try {
        var vols = nodeFs.readdirSync("/Volumes");
        for (var v = 0; v < vols.length; v++) roots.push({ name: vols[v], path: "/Volumes/" + vols[v] });
      } catch (e2) {}
    }
    // рабочий стол
    try {
      var desk = nodePath.join(nodeOs.homedir(), "Desktop");
      if (nodeFs.existsSync(desk)) roots.push({ name: "Рабочий стол", path: desk });
    } catch (e3) {}
  } catch (e) {}
  fbRenderRoots(roots);
}

function fbRenderRoots(roots) {
  fb.current = "";
  fb.chosen = "";
  document.getElementById("fb-path").textContent = "Выбор диска / расположения";
  document.getElementById("fb-current").textContent = "—";
  document.getElementById("fb-choose").disabled = true;

  var list = document.getElementById("fb-list");
  list.innerHTML = "";
  if (!roots.length) {
    list.innerHTML = '<div class="fb-empty">Нет доступных дисков</div>';
    return;
  }
  var frag = document.createDocumentFragment();
  roots.forEach(function (r) {
    var row = document.createElement("div");
    row.className = "fb-row";
    row.innerHTML = '<span class="fb-ic">💽</span><span class="fb-nm">' + escHtml(r.name) +
                    '</span><span class="fb-go">›</span>';
    row.addEventListener("click", function () { fbOpen(r.path); });
    frag.appendChild(row);
  });
  list.appendChild(frag);
}

// Открыть папку в браузере (показать подпапки)
function fbOpen(path) {
  fb.current = path;
  fb.chosen = path; // текущая папка по умолчанию выбираема
  document.getElementById("fb-path").textContent = path;
  document.getElementById("fb-current").textContent = "Выбрано: " + baseName(path);
  document.getElementById("fb-choose").disabled = false;

  if (nodeFs) {
    var data = { path: path, subs: [], parent: null };
    try {
      var parent = nodePath.dirname(path);
      if (parent && parent !== path) data.parent = parent;
      var entries = nodeFs.readdirSync(path, { withFileTypes: true });
      var useDir = entries.length > 0 && typeof entries[0] === "object";
      for (var i = 0; i < entries.length; i++) {
        var nm = useDir ? entries[i].name : entries[i];
        if (!nm || nm.charAt(0) === ".") continue;
        var full = nodePath.join(path, nm);
        var isDir = false;
        if (useDir && typeof entries[i].isDirectory === "function") isDir = entries[i].isDirectory();
        else { try { isDir = nodeFs.statSync(full).isDirectory(); } catch (e) {} }
        if (isDir) data.subs.push({ name: nm, path: full });
      }
      data.subs.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; });
    } catch (e) {}
    fbRender(data);
  } else {
    csInterface.evalScript('browseFolder("' + escPath(path) + '")', function (res) {
      var data;
      try { data = JSON.parse(res); } catch (e) { data = { path: path, subs: [] }; }
      if (data.error) { fbRender({ path: path, subs: [] }); return; }
      fbRender(data);
    });
  }
}

function fbRender(data) {
  var list = document.getElementById("fb-list");
  list.innerHTML = "";
  var frag = document.createDocumentFragment();

  // «вверх»: в обычной папке — на уровень выше; в корне диска — к выбору диска
  var up = document.createElement("div");
  up.className = "fb-row up";
  if (data.parent) {
    up.innerHTML = '<span class="fb-ic">↰</span><span class="fb-nm">.. (на уровень выше)</span>';
    up.addEventListener("click", function () { fbOpen(data.parent); });
  } else {
    up.innerHTML = '<span class="fb-ic">↰</span><span class="fb-nm">.. (к выбору диска)</span>';
    up.addEventListener("click", function () { fbShowDrives(); });
  }
  frag.appendChild(up);

  if (!data.subs.length) {
    var empty = document.createElement("div");
    empty.className = "fb-empty";
    empty.textContent = "Нет вложенных папок — можно выбрать эту";
    frag.appendChild(empty);
  } else {
    data.subs.forEach(function (sub) {
      var row = document.createElement("div");
      row.className = "fb-row";
      row.innerHTML = '<span class="fb-ic">' + folderIconHtml(sub.path) + '</span><span class="fb-nm">' + escHtml(sub.name) +
                      '</span><span class="fb-go">›</span>';
      // одиночный клик — выбрать как кандидата; двойной — зайти внутрь
      row.addEventListener("click", function () {
        fb.chosen = sub.path;
        document.getElementById("fb-current").textContent = "Выбрано: " + sub.name;
        document.getElementById("fb-choose").disabled = false;
        var sel = list.querySelector(".fb-row.selected");
        if (sel) sel.classList.remove("selected");
        row.classList.add("selected");
      });
      row.addEventListener("dblclick", function () { fbOpen(sub.path); });
      frag.appendChild(row);
    });
  }
  list.appendChild(frag);
}

function bindFolderBrowser() {
  document.getElementById("fb-close").addEventListener("click", closeFolderBrowser);
  document.getElementById("fb-cancel").addEventListener("click", closeFolderBrowser);
  document.getElementById("fb-overlay").addEventListener("click", function (e) {
    if (e.target === this) closeFolderBrowser();
  });
  document.getElementById("fb-choose").addEventListener("click", function () {
    var chosen = fb.chosen || fb.current;
    var cb = fb.cb;
    closeFolderBrowser();
    if (chosen && cb) cb(chosen);
  });
}

// Первый выбор корня (с оверлея или кнопки «Выбрать папку»)
function chooseRoot() {
  openFolderBrowser("Выбери корневую папку с SFX", function (path) {
    if (!path) return;
    if (state.roots.indexOf(path) === -1) {
      state.roots.push(path);
      saveRoots();
    }
    indexAllRoots(true);
  });
}

// Кнопка «＋ Add folder» — добавить ещё один корень
function addAnotherRoot() {
  openFolderBrowser("Добавить ещё папку с SFX", function (path) {
    if (!path) return;
    if (state.roots.indexOf(path) !== -1) {
      setFooterMsg("Эта папка уже добавлена", "error");
      return;
    }
    state.roots.push(path);
    saveRoots();
    expandedPaths[path] = true;
    if (nodeFs) {
      scanBranchInto(path);
      index.files.sort(byName);
      startWatching();
      renderFolders();
    } else {
      renderFolders();
    }
    setFooterMsg("✅ Добавлена папка: " + baseName(path), "success");
  });
}

function removeRoot(path) {
  var i = state.roots.indexOf(path);
  if (i === -1) return;
  state.roots.splice(i, 1);
  saveRoots();
  if (nodeFs) purgeFromIndex(path);
  delete expandedPaths[path];
  if (state.displayedFolderPath && (state.displayedFolderPath === path || isAncestorOf(path, state.displayedFolderPath))) {
    deselectFile();
    state.displayedFolderPath = "";
    state.currentSfx = [];
    renderSfxList();
    document.getElementById("current-folder-name").textContent = "— папка не выбрана —";
    document.getElementById("current-folder-name").classList.add("empty");
  }
  startWatching();
  if (state.roots.length === 0) {
    document.getElementById("no-root-overlay").style.display = "";
  }
  renderFolders();
}

// Восстановление сохранённых корней при запуске
function initRoots(roots) {
  state.roots = roots.slice();
  state.rootPath = roots[roots.length - 1];
  saveRoots();
  expandedPaths = {};
  for (var i = 0; i < roots.length; i++) expandedPaths[roots[i]] = (roots.length === 1);
  jsxChildrenCache = {};
  document.getElementById("no-root-overlay").style.display = "none";
  document.getElementById("btn-back").disabled = true;
  indexAllRoots(false);
}

function saveRoots() {
  state.rootPath = state.roots.length ? state.roots[state.roots.length - 1] : "";
  localStorage.setItem(STORAGE_ROOTS, JSON.stringify(state.roots));
  if (state.rootPath) localStorage.setItem(STORAGE_ROOT, state.rootPath); // legacy
}

function baseName(p) {
  var parts = p.replace(/\\/g, "/").split("/").filter(Boolean);
  return parts[parts.length - 1] || p;
}

// Полная индексация всех корней
function indexAllRoots(silent) {
  document.getElementById("no-root-overlay").style.display = "none";
  document.getElementById("btn-back").disabled = true;

  if (!nodeFs) {
    // ExtendScript fallback: показываем первый корень навигацией
    var first = state.roots[0];
    state.currentPath = first;
    expandedPaths[first] = true;
    loadFoldersJSX(first);
    loadSfxJSX(first);
    renderFolders();
    return;
  }
  buildIndexMulti(silent);
  startWatching();
  updateBreadcrumb();
}

// Ручное обновление (кнопка ⟳)
function manualRefresh() {
  if (!state.roots.length) return;
  var btn = document.getElementById("btn-refresh");
  btn.classList.add("spinning");
  setTimeout(function () { btn.classList.remove("spinning"); }, 800);

  if (nodeFs) buildIndexMulti(true);
  else {
    loadFoldersJSX(state.currentPath || state.roots[0]);
    loadSfxJSX(state.displayedFolderPath || state.roots[0]);
  }
}

function listDirNode(dir) {
  var out = { dirs: [], files: [] };
  var entries;
  try { entries = nodeFs.readdirSync(dir, { withFileTypes: true }); }
  catch (e) { return out; }
  var useDirents = entries.length > 0 && typeof entries[0] === "object" && entries[0] !== null;

  for (var i = 0; i < entries.length; i++) {
    var name = useDirents ? entries[i].name : entries[i];
    if (!name || name.charAt(0) === ".") continue;
    var full = nodePath.join(dir, name);

    var isDir, isFile;
    if (useDirents && typeof entries[i].isDirectory === "function") {
      isDir = entries[i].isDirectory(); isFile = entries[i].isFile();
    } else {
      try { var st = nodeFs.statSync(full); isDir = st.isDirectory(); isFile = st.isFile(); }
      catch (e2) { continue; }
    }

    if (isDir) out.dirs.push({ name: name, path: full });
    else if (isFile) {
      var dot = name.lastIndexOf(".");
      if (dot > 0) {
        var ext = name.slice(dot + 1).toLowerCase();
        if (SUPPORTED_EXTS[ext]) out.files.push({ name: name, path: full, ext: ext.toUpperCase(), dir: dir });
      }
    }
  }
  return out;
}

// Полный обход ВСЕХ корней порциями
function buildIndexMulti(silent) {
  index.ready = false; index.building = true;
  index.files = []; index.folders = {}; index.scanned = 0;

  var queue = state.roots.slice();
  if (!silent) {
    renderFolders();
    showLoading("Индексирую библиотеку…");
  }

  function tick() {
    var n = 0;
    while (queue.length && n < DIRS_PER_TICK) {
      var dir = queue.shift();
      var res = listDirNode(dir);
      index.folders[dir] = res.dirs;
      for (var i = 0; i < res.files.length; i++) index.files.push(res.files[i]);
      for (var j = 0; j < res.dirs.length; j++)  queue.push(res.dirs[j].path);
      index.scanned++; n++;
    }
    if (queue.length) {
      if (!silent) showLoading("Индексирую… " + index.files.length + " файлов");
      setTimeout(tick, 0);
    } else {
      index.building = false; index.ready = true;
      index.files.sort(byName);
      state.allFolders = decorateFolders(index.folders[state.currentPath] || []);
      if (state.searchActive) { runSearch(); return; }
      if (silent) {
        refreshAfterIndexChange();
      } else {
        renderFolders(findSelectedIdx());
        if (state.displayedFolderPath) loadSfx(state.displayedFolderPath);
      }
    }
  }
  setTimeout(tick, 0);
}

function decorateFolders(dirs) {
  var out = [];
  for (var i = 0; i < dirs.length; i++) {
    var hasSubs;
    if (index.ready && index.folders[dirs[i].path]) hasSubs = index.folders[dirs[i].path].length > 0;
    else hasSubs = quickHasSubdirs(dirs[i].path);
    out.push({ name: dirs[i].name, path: dirs[i].path, hasSubs: hasSubs });
  }
  out.sort(byName);
  return out;
}

function quickHasSubdirs(dir) {
  try {
    var entries = nodeFs.readdirSync(dir, { withFileTypes: true });
    var useDirents = entries.length > 0 && typeof entries[0] === "object";
    for (var i = 0; i < entries.length; i++) {
      var name = useDirents ? entries[i].name : entries[i];
      if (!name || name.charAt(0) === ".") continue;
      if (useDirents && typeof entries[i].isDirectory === "function") {
        if (entries[i].isDirectory()) return true;
      } else {
        try { if (nodeFs.statSync(nodePath.join(dir, name)).isDirectory()) return true; } catch (e) {}
      }
    }
  } catch (e) {}
  return false;
}

function byName(a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; }

function findSelectedIdx() {
  for (var i = 0; i < state.allFolders.length; i++) {
    if (state.allFolders[i].path === state.displayedFolderPath) return i;
  }
  return -1;
}

// ══════════════════════════════════════════════
//  АВТООБНОВЛЕНИЕ БИБЛИОТЕКИ (fs.watch)
// ══════════════════════════════════════════════
var watcher = null;
var watchers = [];
var watchDebounce = null;
var watchDirty = {};   // изменённые пути
var watchFull = false; // нужен полный пересчёт

function startWatching() {
  stopWatching();
  if (!nodeFs) return; // без Node автообновления нет — есть кнопка ⟳
  for (var i = 0; i < state.roots.length; i++) {
    (function (root) {
      try {
        var w = nodeFs.watch(root, { recursive: true }, function (ev, fname) {
          if (!fname) {
            watchFull = true;
          } else {
            var full = nodePath.join(root, String(fname));
            watchDirty[nodePath.dirname(full)] = true;
            watchDirty[full] = true;
          }
          clearTimeout(watchDebounce);
          watchDebounce = setTimeout(applyWatchChanges, 1000);
        });
        watchers.push(w);
      } catch (e) { /* recursive watch недоступен для этого корня */ }
    })(state.roots[i]);
  }
}

function stopWatching() {
  for (var i = 0; i < watchers.length; i++) {
    try { watchers[i].close(); } catch (e) {}
  }
  watchers = [];
  watchDirty = {}; watchFull = false;
  clearTimeout(watchDebounce);
}

function applyWatchChanges() {
  if (!state.roots.length) return;
  if (index.building) { // идёт индексация — подождём её
    clearTimeout(watchDebounce);
    watchDebounce = setTimeout(applyWatchChanges, 1500);
    return;
  }

  var dirs = Object.keys(watchDirty);
  watchDirty = {};
  var needFull = watchFull || dirs.length > 60;
  watchFull = false;

  if (needFull) {
    buildIndexMulti(true); // тихий полный пересчёт всех корней
    return;
  }

  var changed = false;
  for (var i = 0; i < dirs.length; i++) {
    if (updateIndexForDir(dirs[i])) changed = true;
  }
  if (changed) {
    index.files.sort(byName);
    refreshAfterIndexChange();
  }
}

// Точечно пересканировать одну папку (добавление/удаление файлов и подпапок)
function updateIndexForDir(dir) {
  try {
    var st = null;
    try { st = nodeFs.statSync(dir); } catch (eS) { st = null; }

    if (!st) return purgeFromIndex(dir);   // путь удалён
    if (st.isFile()) return false;          // файл обработаем через его папку
    if (!st.isDirectory()) return false;

    var res = listDirNode(dir);
    index.folders[dir] = res.dirs;

    // файлы непосредственно этой папки — заменить
    var keep = [];
    for (var i = 0; i < index.files.length; i++) {
      if (index.files[i].dir !== dir) keep.push(index.files[i]);
    }
    for (var j = 0; j < res.files.length; j++) keep.push(res.files[j]);
    index.files = keep;

    // незнакомые подпапки (скопировали папку целиком) — просканировать ветку
    for (var d = 0; d < res.dirs.length; d++) {
      if (index.folders[res.dirs[d].path] === undefined) {
        scanBranchInto(res.dirs[d].path);
      }
    }
    return true;
  } catch (e) {
    return false;
  }
}

function scanBranchInto(start) {
  var queue = [start];
  while (queue.length) {
    var dir = queue.shift();
    var res = listDirNode(dir);
    index.folders[dir] = res.dirs;
    for (var i = 0; i < res.files.length; i++) index.files.push(res.files[i]);
    for (var j = 0; j < res.dirs.length; j++)  queue.push(res.dirs[j].path);
  }
}

function purgeFromIndex(p) {
  var sep = p.indexOf("\\") !== -1 ? "\\" : "/";
  var prefix = p + sep;
  var touched = false;

  for (var key in index.folders) {
    if (key === p || key.indexOf(prefix) === 0) { delete index.folders[key]; touched = true; }
  }
  var keep = [];
  for (var i = 0; i < index.files.length; i++) {
    var f = index.files[i];
    if (f.dir === p || f.dir.indexOf(prefix) === 0 || f.path === p) { touched = true; continue; }
    keep.push(f);
  }
  index.files = keep;
  return touched;
}

// Мягко обновить интерфейс: без сброса выбора, поиска и скролла
function refreshAfterIndexChange() {
  if (state.searchActive) { runSearch(); return; }
  renderFolders();

  if (!state.displayedFolderPath) return;
  var listEl = document.getElementById("sfx-list");
  var scroll = (state.viewMode === "grid" && state.gridDir === "v") ? listEl.scrollLeft : listEl.scrollTop;

  // вкладка избранного — пересобираем список папок-источников и звуки
  if (state.tab === "favs" || state.displayedFolderPath === "__favs__") {
    renderFavsPane();
    loadFavorites();
  } else if (state.tab === "cols" || String(state.displayedFolderPath).indexOf("__col__") === 0) {
    // коллекции — обновим дерево коллекций и текущий показанный узел
    renderCollections();
    if (state.colView) {
      if (state.colView.childKey) openCollectionChild(state.colView.colId, state.colView.childKey);
      else openCollectionAll(state.colView.colId);
    }
  } else {
    state.currentSfx = filesUnder(state.displayedFolderPath);
    renderSfxList();
  }

  // выбранный файл мог исчезнуть с диска
  if (state.selectedFile) {
    var still = false;
    for (var i = 0; i < state.currentSfx.length; i++) {
      if (state.currentSfx[i].path === state.selectedFile.path) { still = true; break; }
    }
    if (!still) deselectFile();
  }

  requestAnimationFrame(function () {
    if (state.viewMode === "grid" && state.gridDir === "v") listEl.scrollLeft = scroll;
    else listEl.scrollTop = scroll;
  });
}

// ══════════════════════════════════════════════
//  ЗАГРУЗКА ПАПОК / SFX
// ══════════════════════════════════════════════
function loadFolders(path) {
  if (nodeFs) {
    var dirs = index.folders[path];
    if (dirs === undefined) { dirs = listDirNode(path).dirs; index.folders[path] = dirs; }
    state.allFolders = decorateFolders(dirs);
    renderFolders();
  } else loadFoldersJSX(path);
}

function loadSfx(path) {
  state.displayedFolderPath = path;
  state.lastFolderPath = path; // запоминаем последнюю реальную папку
  deselectFile();
  setFolderTitle(path);

  if (nodeFs) {
    if (index.building || index.ready) {
      state.currentSfx = filesUnder(path);
      renderSfxList();
      return;
    }
    state.currentSfx = scanRecursiveNode(path);
    renderSfxList();
  } else loadSfxJSX(path);
}

// ══════════════════════════════════════════════
//  ВКЛАДКИ САЙДБАРА + ИЗБРАННОЕ
// ══════════════════════════════════════════════
function setTab(tab) {
  if (tab !== "folders" && tab !== "favs" && tab !== "cols") return;
  state.tab = tab;
  if (tab !== "folders") { clearSel(); }

  document.getElementById("tab-folders").classList.toggle("active", tab === "folders");
  document.getElementById("tab-favs").classList.toggle("active", tab === "favs");
  document.getElementById("tab-cols").classList.toggle("active", tab === "cols");
  document.getElementById("pane-folders").classList.toggle("hidden", tab !== "folders");
  document.getElementById("pane-favs").classList.toggle("hidden", tab !== "favs");
  document.getElementById("pane-cols").classList.toggle("hidden", tab !== "cols");

  if (tab === "folders") {
    // вернуть правую панель к последней реальной папке (а не к избранному/коллекции)
    var cur = state.displayedFolderPath;
    var isRealFolder = cur && cur !== "__favs__" && String(cur).indexOf("__col__") !== 0;
    if (isRealFolder) {
      loadSfx(cur);
    } else {
      var restore = state.lastFolderPath || state.roots[0];
      if (restore) loadSfx(restore);
    }
  } else if (tab === "favs") {
    renderFavsPane();
    loadFavorites();
  } else {
    renderCollections();
  }
}

// Корневая папка библиотеки, под которой лежит данный путь
function rootOf(filePath) {
  for (var i = 0; i < state.roots.length; i++) {
    var r = state.roots[i];
    var sep = r.indexOf("\\") !== -1 ? "\\" : "/";
    var pre = r.charAt(r.length - 1) === sep ? r : r + sep;
    if (filePath === r || filePath.indexOf(pre) === 0) return r;
  }
  return null;
}

// Первая папка ВНУТРИ корня на пути к файлу (как на скрине: «1 Game sound»).
// Если файл лежит прямо в корне — вернём сам корень.
function topFolderOf(fileDir) {
  var root = rootOf(fileDir);
  if (!root) return fileDir;
  if (fileDir === root) return root;
  var sep = root.indexOf("\\") !== -1 ? "\\" : "/";
  var rest = fileDir.slice(root.length);
  while (rest.charAt(0) === sep) rest = rest.slice(1);
  var first = rest.split(sep)[0];
  return first ? (root + sep + first) : root;
}

// Относительный путь папки файла от его корня: "1 Game sound / CS-GO / guns"
function relPathFromRoot(fileDir) {
  var root = rootOf(fileDir);
  if (!root || fileDir === root) return "";
  var sep = root.indexOf("\\") !== -1 ? "\\" : "/";
  var rest = fileDir.slice(root.length);
  while (rest.charAt(0) === sep) rest = rest.slice(1);
  return rest.split(/[\\/]/).filter(Boolean).join(" / ");
}

function favList() {
  var out = [];
  for (var p in favorites) if (favorites.hasOwnProperty(p)) out.push(favorites[p]);
  out.sort(byName);
  return out;
}

function saveFavs() {
  try { localStorage.setItem(STORAGE_FAVS, JSON.stringify(favList())); } catch (e) {}
}

function isFav(path) { return !!favorites[path]; }

// Папка-группа для избранного: верхняя папка под корнем.
// Старые избранные (без groupDir) — досчитываем на лету.
function favGroupDir(f) {
  if (f.groupDir) return f.groupDir;
  var g = topFolderOf(f.dir || "");
  return g || f.dir || "(неизвестно)";
}

// Поставить/снять звезду. btnEl — нажатая кнопка (для мгновенного отклика)
function toggleFavorite(f, btnEl) {
  if (favorites[f.path]) {
    delete favorites[f.path];
    if (btnEl) { btnEl.textContent = "☆"; btnEl.classList.remove("on"); }
  } else {
    // группируем избранное по ВЕРХНЕЙ папке (первой внутри корня),
    // чтобы слева было видно, откуда «по верхам» добавлен звук
    var top = topFolderOf(f.dir);
    favorites[f.path] = { name: f.name, path: f.path, ext: f.ext, dir: f.dir,
                          groupDir: top, relPath: relPathFromRoot(f.dir) };
    if (btnEl) { btnEl.textContent = "★"; btnEl.classList.add("on"); }
  }
  saveFavs();
  updateFavCount();

  // если открыта вкладка избранного — обновим и список папок, и звуки
  if (state.tab === "favs") {
    renderFavsPane();
    loadFavorites();
  }
}

function updateFavCount() {
  var n = favList().length;
  var c = document.getElementById("favs-count");
  if (c) c.textContent = n ? (n + " " + pluralFiles(n)) : "";
}

// Левая панель вкладки «Избранное»: список папок-источников
function renderFavsPane() {
  updateFavCount();
  var all = liveFavList();
  var hint = document.getElementById("favs-hint");
  var box  = document.getElementById("favs-folders");

  if (!all.length) {
    if (hint) hint.style.display = "block";
    if (box)  box.innerHTML = "";
    return;
  }
  if (hint) hint.style.display = "none";
  if (!box) return;

  // Строим настоящее дерево путей: для каждого избранного раскладываем его
  // папку (dir) на сегменты от корня и наращиваем узлы. Это даёт ПОЛНЫЙ путь,
  // как в обычном дереве папок.
  var forest = {}; // path -> node { name, path, count, children:{} }

  function ensureNode(parentChildren, name, path) {
    if (!parentChildren[path]) parentChildren[path] = { name: name, path: path, count: 0, children: {} };
    return parentChildren[path];
  }

  for (var i = 0; i < all.length; i++) {
    var f = all[i];
    var root = rootOf(f.dir) || f.dir;
    var sep = root.indexOf("\\") !== -1 ? "\\" : "/";

    // путь от корня до папки файла, посегментно
    var rootNode = ensureNode(forest, baseName(root), root);
    rootNode.count++;

    var cur = rootNode;
    var acc = root;
    if (f.dir && f.dir !== root) {
      var rest = f.dir.slice(root.length);
      while (rest.charAt(0) === sep) rest = rest.slice(1);
      var segs = rest.split(/[\\/]/).filter(Boolean);
      for (var s = 0; s < segs.length; s++) {
        acc = acc + sep + segs[s];
        cur = ensureNode(cur.children, segs[s], acc);
        cur.count++;
      }
    }
  }

  // самовосстановление выбранного узла
  if (state.favFolder !== "__all__") {
    var exists = false;
    (function check(children) {
      for (var k in children) {
        if (k === state.favFolder) { exists = true; return; }
        check(children[k].children);
      }
    })(forest);
    if (!exists) state.favFolder = "__all__";
  }

  box.innerHTML = "";
  var frag = document.createDocumentFragment();

  var total = all.length;
  frag.appendChild(makeFavRow("__all__", "Все избранные", total, "★", 0, false, false));

  var rootKeys = Object.keys(forest).sort();
  for (var r = 0; r < rootKeys.length; r++) {
    renderFavNode(frag, forest[rootKeys[r]], 0);
  }
  box.appendChild(frag);
}

// Рекурсивный рендер узла дерева избранного с раскрытием
function renderFavNode(frag, node, depth) {
  var childKeys = Object.keys(node.children).sort();
  var hasKids = childKeys.length > 0;
  var open = !!favExpanded[node.path];

  frag.appendChild(makeFavRow(node.path, node.name, node.count,
                              folderIconHtml(node.path), depth, hasKids, open));

  if (open && hasKids) {
    for (var i = 0; i < childKeys.length; i++) {
      renderFavNode(frag, node.children[childKeys[i]], depth + 1);
    }
  }
}

var favExpanded = {}; // папки, раскрытые в дереве избранного

// depth — уровень отступа; hasKids — есть вложенные папки (рисуем шеврон)
function makeFavRow(dir, label, count, icon, depth, hasKids, open) {
  var row = document.createElement("div");
  row.className = "fav-folder" + (dir === "__all__" ? " all" : "") +
                  (state.favFolder === dir ? " selected" : "");
  row.style.paddingLeft = (10 + depth * 14) + "px";
  row.title = dir === "__all__" ? "Показать все избранные" : dir;

  var chev = (dir !== "__all__")
    ? (hasKids ? '<span class="ff-chev' + (open ? " open" : "") + '">›</span>'
               : '<span class="ff-chev spacer">›</span>')
    : "";

  row.innerHTML =
    chev +
    '<span class="ff-icon">' + icon + "</span>" +
    '<span class="ff-name">' + escHtml(label) + "</span>" +
    '<span class="ff-count">' + count + "</span>";

  row.addEventListener("click", function (e) {
    if (e.target.classList && e.target.classList.contains("ff-chev") && hasKids) {
      favExpanded[dir] = !favExpanded[dir];
      renderFavsPane();
      return;
    }
    state.favFolder = dir;
    loadFavorites();
    renderFavsPane();
  });
  return row;
}

// Избранное, отсеянное от удалённых с диска файлов
function liveFavList() {
  var all = favList();
  if (nodeFs && index.ready) {
    var alive = {};
    for (var i = 0; i < index.files.length; i++) alive[index.files[i].path] = true;
    var cleaned = [];
    for (var j = 0; j < all.length; j++) if (alive[all[j].path]) cleaned.push(all[j]);
    return cleaned;
  }
  return all;
}

// Правый список = избранные звуки (все / по верхней папке / по конкретной подпапке)
function loadFavorites() {
  state.displayedFolderPath = "__favs__";
  deselectFile();

  var all = liveFavList();
  var sel = state.favFolder;
  var filtered;
  var titleName;

  if (sel === "__all__") {
    filtered = all;
    titleName = null;
  } else {
    // совпадение по верхней группе ИЛИ по точной папке-источнику
    filtered = all.filter(function (f) {
      return favGroupDir(f) === sel || f.dir === sel ||
             (f.dir && f.dir.indexOf(sel + (sel.indexOf("\\") !== -1 ? "\\" : "/")) === 0);
    });
    titleName = baseName(sel);
  }

  var el = document.getElementById("current-folder-name");
  el.textContent = sel === "__all__" ? "★ Избранное" : "★ " + titleName;
  el.classList.remove("empty");

  state.currentSfx = filtered;
  renderSfxList();
}

// ══════════════════════════════════════════════
//  КОЛЛЕКЦИИ
// ══════════════════════════════════════════════
function saveCols() {
  try { localStorage.setItem(STORAGE_COLS, JSON.stringify(collections)); } catch (e) {}
}

function colById(id) {
  for (var i = 0; i < collections.length; i++) if (collections[i].id === id) return collections[i];
  return null;
}

function createCollection(name, items) {
  if (!name) {
    name = window.prompt("Название коллекции:", "Новая коллекция");
    if (name === null) return null;       // отмена
    name = name.trim() || "Новая коллекция";
  }
  var col = { id: "col_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
              name: name, folders: [], sounds: [] };
  collections.push(col);
  if (items && items.length) addItemsToCollection(col.id, items);
  saveCols();
  setTab("cols");
  state.openCol = col.id;
  renderCollections();
  setFooterMsg("✅ Коллекция «" + name + "» создана", "success");
  return col;
}

function renameCollection(id) {
  var col = colById(id);
  if (!col) return;
  var name = window.prompt("Новое название:", col.name);
  if (name === null) return;
  col.name = name.trim() || col.name;
  saveCols();
  renderCollections();
}

function deleteCollection(id) {
  var col = colById(id);
  if (!col) return;
  if (!window.confirm("Удалить коллекцию «" + col.name + "»? (папки на диске не тронутся)")) return;
  collections = collections.filter(function (c) { return c.id !== id; });
  if (state.openCol === id) state.openCol = null;
  saveCols();
  renderCollections();
  if (state.colView && state.colView.colId === id) {
    state.colView = null; clearRightPanel();
  }
}

// items: [{kind:'folder'|'sound', name, path, ext?, dir?}]
function addItemsToCollection(id, items) {
  var col = colById(id);
  if (!col) return 0;
  var added = 0;
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    if (it.kind === "folder") {
      if (!col.folders.some(function (f) { return f.path === it.path; })) {
        col.folders.push({ name: it.name, path: it.path });
        added++;
      }
    } else {
      if (!col.sounds.some(function (s) { return s.path === it.path; })) {
        col.sounds.push({ name: it.name, path: it.path, ext: it.ext, dir: it.dir });
        added++;
      }
    }
  }
  saveCols();
  return added;
}

function removeFromCollection(id, kind, path) {
  var col = colById(id);
  if (!col) return;
  if (kind === "folder") col.folders = col.folders.filter(function (f) { return f.path !== path; });
  else col.sounds = col.sounds.filter(function (s) { return s.path !== path; });
  saveCols();
  renderCollections();
  // если показан этот элемент справа — обновим
  if (state.colView && state.colView.colId === id) openCollectionChild(id, state.colView.childKey);
}

function colItemCount(col) { return col.folders.length + col.sounds.length; }

// ── ЛЕВАЯ ПАНЕЛЬ: дерево коллекций ──
function renderCollections() {
  var hint = document.getElementById("cols-hint");
  var list = document.getElementById("cols-list");
  if (hint) hint.style.display = collections.length ? "none" : "block";
  if (!list) return;
  list.innerHTML = "";

  var frag = document.createDocumentFragment();
  collections.forEach(function (col) {
    var open = state.openCol === col.id;

    var node = document.createElement("div");
    node.className = "col-node" + (state.colView && state.colView.colId === col.id && !state.colView.childKey ? " selected" : "");
    node.innerHTML =
      '<span class="col-icon">' + (open ? "📂" : "📚") + "</span>" +
      '<span class="col-name">' + escHtml(col.name) + "</span>" +
      '<span class="col-count">' + colItemCount(col) + "</span>";
    node.addEventListener("click", function () {
      state.openCol = open ? null : col.id;
      openCollectionAll(col.id);   // показать всё содержимое коллекции справа
      renderCollections();
    });
    node.addEventListener("contextmenu", function (e) {
      e.preventDefault(); e.stopPropagation();
      showCollectionNodeMenu(e, col.id);
    });
    frag.appendChild(node);

    if (open) {
      col.folders.forEach(function (f) {
        frag.appendChild(makeColChild(col.id, "folder", f, folderIconHtml(f.path)));
      });
      col.sounds.forEach(function (s) {
        frag.appendChild(makeColChild(col.id, "sound", s, "🎵"));
      });
      if (colItemCount(col) === 0) {
        var empty = document.createElement("div");
        empty.className = "col-child";
        empty.style.opacity = "0.6";
        empty.innerHTML = '<span class="cc-name" style="font-style:italic">пусто — добавь папки/звуки</span>';
        frag.appendChild(empty);
      }
    }
  });
  list.appendChild(frag);
}

function makeColChild(colId, kind, item, icon) {
  var key = kind + ":" + item.path;
  var row = document.createElement("div");
  row.className = "col-child" + (state.colView && state.colView.colId === colId && state.colView.childKey === key ? " selected" : "");
  row.title = item.path;
  row.innerHTML =
    '<span class="cc-icon">' + icon + "</span>" +
    '<span class="cc-name">' + escHtml(stripExt(item.name)) + "</span>" +
    '<span class="cc-x" title="Убрать из коллекции">✕</span>';
  row.addEventListener("click", function (e) {
    if (e.target.classList.contains("cc-x")) {
      removeFromCollection(colId, kind, item.path);
      return;
    }
    openCollectionChild(colId, key);
  });
  return row;
}

// ── ПРАВАЯ ПАНЕЛЬ: содержимое коллекции ──
function clearRightPanel() {
  state.currentSfx = [];
  renderSfxList();
  var el = document.getElementById("current-folder-name");
  el.textContent = "— ничего не выбрано —";
  el.classList.add("empty");
}

// Показать все звуки коллекции (папки разворачиваются рекурсивно + отдельные звуки)
function openCollectionAll(colId) {
  var col = colById(colId);
  if (!col) return;
  state.colView = { colId: colId, childKey: null };
  state.displayedFolderPath = "__col__" + colId;
  deselectFile();

  var out = [];
  var seen = {};
  function push(f) { if (!seen[f.path]) { seen[f.path] = true; out.push(f); } }

  col.folders.forEach(function (fd) {
    var inside = nodeFs && index.ready ? filesUnder(fd.path) : scanRecursiveNode(fd.path);
    inside.forEach(push);
  });
  col.sounds.forEach(push);
  out.sort(byName);

  var el = document.getElementById("current-folder-name");
  el.textContent = "📚 " + col.name;
  el.classList.remove("empty");

  state.currentSfx = out;
  renderSfxList();
}

// Показать один элемент коллекции (папку — её содержимое, звук — только его)
function openCollectionChild(colId, childKey) {
  var col = colById(colId);
  if (!col) return;
  state.colView = { colId: colId, childKey: childKey };
  state.displayedFolderPath = "__col__" + colId + "__" + childKey;
  deselectFile();

  var kind = childKey.split(":")[0];
  var path = childKey.slice(kind.length + 1);
  var out = [];

  if (kind === "folder") {
    out = nodeFs && index.ready ? filesUnder(path) : scanRecursiveNode(path);
    var el = document.getElementById("current-folder-name");
    el.innerHTML = folderIconHtml(path) + " " + escHtml(baseName(path));
    el.classList.remove("empty");
  } else {
    var snd = col.sounds.filter(function (s) { return s.path === path; })[0];
    if (snd) out = [snd];
    var el2 = document.getElementById("current-folder-name");
    el2.textContent = "🎵 " + stripExt(snd ? snd.name : baseName(path));
    el2.classList.remove("empty");
  }
  renderCollections();
  state.currentSfx = out;
  renderSfxList();
}

// ══════════════════════════════════════════════
//  КОНТЕКСТНОЕ МЕНЮ
// ══════════════════════════════════════════════
function buildMenu(x, y, sections) {
  var menu = document.getElementById("ctx-menu");
  menu.innerHTML = "";

  sections.forEach(function (sec, si) {
    if (si > 0) { var sep = document.createElement("div"); sep.className = "ctx-sep"; menu.appendChild(sep); }
    if (sec.title) {
      var t = document.createElement("div"); t.className = "ctx-title"; t.textContent = sec.title;
      menu.appendChild(t);
    }
    sec.items.forEach(function (it) {
      var row = document.createElement("div");
      row.className = "ctx-item" + (it.danger ? " danger" : "") + (it.submenu ? " ctx-sub" : "");
      row.innerHTML = (it.icon ? '<span>' + it.icon + "</span>" : "") +
                      "<span>" + escHtml(it.label) + "</span>" +
                      (it.submenu ? '<span class="ctx-arrow">▸</span>' : "");
      if (it.submenu) {
        var sub = document.createElement("div");
        sub.className = "ctx-submenu";
        it.submenu.forEach(function (sit) {
          var srow = document.createElement("div");
          srow.className = "ctx-item";
          srow.innerHTML = (sit.icon ? '<span>' + sit.icon + "</span>" : "") + "<span>" + escHtml(sit.label) + "</span>";
          srow.addEventListener("click", function (e) { e.stopPropagation(); hideContextMenu(); sit.action(); });
          sub.appendChild(srow);
        });
        row.appendChild(sub);
      } else if (it.action) {
        row.addEventListener("click", function () { hideContextMenu(); it.action(); });
      }
      menu.appendChild(row);
    });
  });

  menu.classList.remove("hidden");

  // снимаем прошлые ограничения перед измерением
  menu.style.maxHeight = "";
  menu.style.overflowY = "";

  var vw = window.innerWidth, vh = window.innerHeight;
  var pad = 6;
  var mw = menu.offsetWidth, mh = menu.offsetHeight;

  // по горизонтали: если не влезает справа — раскрываем влево от курсора
  var left = x;
  if (x + mw + pad > vw) left = x - mw;
  left = Math.max(pad, Math.min(left, vw - mw - pad));

  // по вертикали: если не влезает вниз — пробуем вверх; если и так не влезает —
  // прижимаем и ограничиваем высоту со скроллом, чтобы пункты не обрезались
  var top = y;
  var spaceBelow = vh - y - pad;
  var spaceAbove = y - pad;
  if (mh > spaceBelow) {
    if (mh <= spaceAbove) {
      top = y - mh;                 // разворачиваем вверх
    } else {
      // не влезает ни вниз, ни вверх — берём бо́льшую сторону и скроллим
      if (spaceBelow >= spaceAbove) {
        top = y;
        menu.style.maxHeight = spaceBelow + "px";
      } else {
        top = pad;
        menu.style.maxHeight = spaceAbove + "px";
      }
      menu.style.overflowY = "auto";
    }
  }
  top = Math.max(pad, Math.min(top, vh - Math.min(mh, menu.offsetHeight) - pad));

  menu.style.left = left + "px";
  menu.style.top  = top + "px";

  // подменю: если справа от меню нет места — раскрываем его ВЛЕВО,
  // чтобы оно не уехало за край панели (и не пряталось под окном Premiere)
  var subWidth = 190; // примерная ширина подменю
  var subs = menu.querySelectorAll(".ctx-sub");
  for (var s = 0; s < subs.length; s++) {
    var rightEdge = left + mw + subWidth + pad;
    subs[s].classList.toggle("open-left", rightEdge > vw);
  }
}

function hideContextMenu() {
  document.getElementById("ctx-menu").classList.add("hidden");
}

// меню для выделенных папок в дереве
function showTreeContextMenu(e) {
  var n = selCount();
  var items = selItems();
  var label = n > 1 ? ("В коллекцию (" + n + " папок)") : "В коллекцию";

  var addExisting = collections.map(function (col) {
    return { label: col.name, icon: "📚", action: function () {
      var c = addItemsToCollection(col.id, items);
      clearSel(); renderFolderTree();
      setFooterMsg("✅ Добавлено в «" + col.name + "»: " + c, "success");
    }};
  });
  addExisting.unshift({ label: "✚ Новая коллекция…", icon: "", action: function () {
    var snapshot = items.slice();
    clearSel(); renderFolderTree();
    createCollection(null, snapshot);
  }});

  // выбор цвета папки (для всех выделенных)
  var colorChoices = FOLDER_PALETTE.map(function (c) {
    return { label: c.name, icon: colorDot(c.hex), action: function () {
      items.forEach(function (it) { setFolderColor(it.path, c.hex); });
      clearSel(); renderFolderTree();
    }};
  });
  colorChoices.push({ label: "Сбросить цвет", icon: colorDot(null), action: function () {
    items.forEach(function (it) { setFolderColor(it.path, null); });
    clearSel(); renderFolderTree();
  }});

  buildMenu(e.clientX, e.clientY, [{
    title: n > 1 ? (n + " папок выделено") : "Папка",
    items: [
      { label: label, icon: "📚", submenu: addExisting },
      { label: "Цвет папки", icon: "🎨", submenu: colorChoices }
    ]
  }]);
}

// Палитра цветов папок
var FOLDER_PALETTE = [
  { name: "Жёлтый (по умолч.)", hex: "#f0a030" },
  { name: "Красный",  hex: "#e0564e" },
  { name: "Оранжевый", hex: "#e0804e" },
  { name: "Зелёный",  hex: "#5bbf6a" },
  { name: "Голубой",  hex: "#4aa3e0" },
  { name: "Синий",    hex: "#5a78e0" },
  { name: "Фиолетовый", hex: "#a06ae0" },
  { name: "Розовый",  hex: "#e06ab0" },
  { name: "Серый",    hex: "#9c948c" }
];

function colorDot(hex) {
  if (!hex) return '<span style="display:inline-block;width:13px;height:13px;border-radius:3px;border:1px solid var(--text-muted)"></span>';
  return '<span style="display:inline-block;width:13px;height:13px;border-radius:3px;background:' + hex + '"></span>';
}

function setFolderColor(path, hex) {
  if (hex) folderColors[path] = hex;
  else delete folderColors[path];
  try { localStorage.setItem(STORAGE_FCOLORS, JSON.stringify(folderColors)); } catch (e) {}
}

function folderColorOf(path) { return folderColors[path] || null; }

// Единый цвет папки по умолчанию — классический «жёлтый» (как системные папки).
var FOLDER_DEFAULT = "#e8a83c";

// ЕДИНЫЙ значок папки (классическая папка с язычком). Форма всегда одна и та же,
// во всех местах интерфейса; меняется ТОЛЬКО цвет заливки.
function folderSvg(col) {
  col = col || FOLDER_DEFAULT;
  var back = shadeHex(col, -0.2); // задняя часть на 20% темнее (штатная shadeHex: amt -1..1)
  return '<svg class="folder-svg" width="15" height="15" viewBox="0 0 24 24" style="vertical-align:-2px">' +
    '<path fill="' + back + '" d="M2 6.4c0-1 .8-1.8 1.8-1.8h5.1c.5 0 1 .2 1.3.6l1.2 1.3H20.2c1 0 1.8.8 1.8 1.8v1.1H2V6.4z"/>' +
    '<path fill="' + col + '" d="M2.3 8.4h19.4c1 0 1.8.9 1.7 1.9l-.7 7c-.1.9-.9 1.6-1.8 1.6H3.8c-1 0-1.8-.8-1.8-1.8V8.4z"/>' +
    '</svg>';
}

// Значок папки с учётом её сохранённого цвета (open сохранён для совместимости вызовов, но форма едина).
function folderIconHtml(path, open) {
  return folderSvg(folderColorOf(path) || FOLDER_DEFAULT);
}

// меню для звука в списке/сетке
function showSoundContextMenu(e, f) {
  var item = { kind: "sound", name: f.name, path: f.path, ext: f.ext, dir: f.dir };

  var addExisting = collections.map(function (col) {
    return { label: col.name, icon: "📚", action: function () {
      var c = addItemsToCollection(col.id, [item]);
      setFooterMsg(c ? ("✅ Добавлено в «" + col.name + "»") : "Уже в коллекции", c ? "success" : "error");
    }};
  });
  addExisting.unshift({ label: "✚ Новая коллекция…", action: function () {
    createCollection(null, [item]);
  }});

  var items = [
    { label: (isFav(f.path) ? "Убрать из избранного" : "В избранное"), icon: isFav(f.path) ? "★" : "☆",
      action: function () { toggleFavorite(f, null); refreshStarsInList(); } },
    { label: "В коллекцию", icon: "📚", submenu: addExisting }
  ];

  // коллекции, в которых этот звук уже есть — предложить удалить
  var inCols = collections.filter(function (col) {
    return col.sounds.some(function (s) { return s.path === f.path; });
  });
  if (inCols.length === 1) {
    var only = inCols[0];
    items.push({ label: "Удалить из «" + only.name + "»", icon: "✕", danger: true,
      action: function () { removeFromCollection(only.id, "sound", f.path); setFooterMsg("Удалено из «" + only.name + "»", "success"); } });
  } else if (inCols.length > 1) {
    items.push({ label: "Удалить из коллекции", icon: "✕", danger: true,
      submenu: inCols.map(function (col) {
        return { label: col.name, icon: "📚", action: function () {
          removeFromCollection(col.id, "sound", f.path);
          setFooterMsg("Удалено из «" + col.name + "»", "success");
        }};
      }) });
  }

  buildMenu(e.clientX, e.clientY, [{ title: stripExt(f.name), items: items }]);
}

// меню для узла коллекции (переименовать/удалить)
function showCollectionNodeMenu(e, colId) {
  buildMenu(e.clientX, e.clientY, [{
    title: "Коллекция",
    items: [
      { label: "Переименовать…", icon: "✎", action: function () { renameCollection(colId); } },
      { label: "Удалить коллекцию", icon: "🗑", danger: true, action: function () { deleteCollection(colId); } }
    ]
  }]);
}

// обновить звёзды в видимом списке (после смены избранного через меню)
function refreshStarsInList() {
  var rows = document.querySelectorAll(".sfx-item");
  for (var i = 0; i < rows.length; i++) {
    var f = state.filteredSfx[+rows[i].dataset.idx];
    if (!f) continue;
    var star = rows[i].querySelector(".sfx-star");
    if (!star) continue;
    var on = isFav(f.path);
    star.textContent = on ? "★" : "☆";
    star.classList.toggle("on", on);
  }
}

function filesUnder(path) {
  var sep = (path.indexOf("\\") !== -1) ? "\\" : "/";
  var prefix = path.charAt(path.length - 1) === sep ? path : path + sep;
  var out = [];
  for (var i = 0; i < index.files.length; i++) {
    var f = index.files[i];
    if (f.dir === path || f.dir.indexOf(prefix) === 0) out.push(f);
  }
  return out;
}

function scanRecursiveNode(root) {
  var out = [], queue = [root];
  while (queue.length) {
    var res = listDirNode(queue.shift());
    for (var i = 0; i < res.files.length; i++) out.push(res.files[i]);
    for (var j = 0; j < res.dirs.length; j++)  queue.push(res.dirs[j].path);
  }
  out.sort(byName);
  return out;
}

function setFolderTitle(path) {
  var parts = path.replace(/\\/g, "/").split("/");
  var el = document.getElementById("current-folder-name");
  el.textContent = parts[parts.length - 1] || path;
  el.classList.remove("empty");
}

function showLoading(msg) {
  document.getElementById("sfx-list").innerHTML =
    '<div class="loading">' + escHtml(msg || "Загружаю файлы…") + "</div>";
}

// ── Fallback: ExtendScript ──
function loadFoldersJSX(path) {
  csInterface.evalScript('getFolders("' + escPath(path) + '")', function (res) {
    try {
      var data = JSON.parse(res);
      if (data.error) { console.error(data.error); return; }
      state.allFolders = data;
      renderFolders();
    } catch (e) { console.error("getFolders parse:", e, res); }
  });
}

function loadSfxJSX(path) {
  showLoading("Загружаю файлы…");
  csInterface.evalScript('getSfxFiles("' + escPath(path) + '")', function (res) {
    try {
      var data = JSON.parse(res);
      if (data.error) { console.error(data.error); return; }
      state.currentSfx = data;
      renderSfxList();
    } catch (e) { console.error("getSfxFiles parse:", e, res); }
  });
}

// ══════════════════════════════════════════════
//  РЕНДЕР ПАПОК
// ══════════════════════════════════════════════
// Диспетчер: дерево или плоский список (навигация)
function renderFolders(selectedIdx) {
  if (state.searchActive && searchTree) { renderFolderTreeFiltered(); return; }
  if (state.folderMode === "tree") renderFolderTree();
  else renderFolderList(selectedIdx);
}

// ── РЕЖИМ «ДЕРЕВО» (стиль Premiere Project Panel) ──
var expandedPaths = {};   // path → true (раскрытые узлы)
var jsxChildrenCache = {}; // кэш подпапок для fallback без Node

function renderFolderTree() {
  var list = document.getElementById("folder-list");
  list.innerHTML = "";

  if (!state.roots.length) {
    list.innerHTML = '<div class="folder-empty">Выбери корневую папку</div>';
    return;
  }

  var frag = document.createDocumentFragment();
  for (var i = 0; i < state.roots.length; i++) {
    var rp = state.roots[i];
    appendTreeNode(frag, { name: baseName(rp), path: rp, hasSubs: true }, 0, true);
  }
  list.appendChild(frag);
}

function appendTreeNode(container, folder, depth, isRoot) {
  var item = document.createElement("div");
  item.className = "folder-item tree" + (isRoot ? " root" : "");
  if (folder.path === state.displayedFolderPath) item.classList.add("selected");
  if (state.selPaths[folder.path]) item.classList.add("multisel");
  item.style.paddingLeft = (8 + depth * 14) + "px";

  var expanded = !!expandedPaths[folder.path];
  var chev = folder.hasSubs
    ? '<span class="chev' + (expanded ? " open" : "") + '">›</span>'
    : '<span class="chev spacer">›</span>';

  item.innerHTML =
    chev +
    '<span class="folder-icon">' + folderIconHtml(folder.path, expanded && folder.hasSubs) + "</span>" +
    '<span class="folder-name">' + escHtml(folder.name) + "</span>" +
    (isRoot ? '<span class="root-tools"><button class="root-tool" title="Убрать эту папку из библиотеки">✕</button></span>' : "");

  item.addEventListener("click", function (e) {
    if (e.target.classList && e.target.classList.contains("root-tool")) {
      e.stopPropagation();
      removeRoot(folder.path);
      return;
    }
    if (e.target.classList && e.target.classList.contains("chev") && folder.hasSubs) {
      toggleExpand(folder.path); // клик по стрелке — только раскрыть
      return;
    }
    if (e.ctrlKey || e.metaKey) {       // Ctrl-клик — добавить/убрать из выделения
      toggleSel(folder.path, folder.name);
      renderFolderTree();
      return;
    }
    if (e.shiftKey && state.selAnchor) { // Shift — диапазон по видимым папкам
      selectRange(state.selAnchor, folder.path);
      renderFolderTree();
      return;
    }
    clearSel();
    state.selAnchor = folder.path;
    selectTreeFolder(folder.path);
  });

  item.addEventListener("dblclick", function (e) {
    e.stopPropagation();
    if (folder.hasSubs) toggleExpand(folder.path);
  });

  item.addEventListener("contextmenu", function (e) {
    e.preventDefault();
    e.stopPropagation();
    // если папка не в выделении — выделить только её
    if (!state.selPaths[folder.path]) {
      clearSel();
      addSel(folder.path, folder.name);
    }
    showTreeContextMenu(e);
  });

  // ── перетаскивание для сортировки — ТОЛЬКО корневые папки ──
  if (isRoot) {
    item.setAttribute("draggable", "true");
    item.classList.add("root-draggable");

    item.addEventListener("dragstart", function (e) {
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("mflib/root", folder.path);
      rootDrag = folder.path;
      item.classList.add("dragging");
    });
    item.addEventListener("dragend", function () {
      rootDrag = null;
      item.classList.remove("dragging");
      var ds = document.querySelectorAll(".folder-item.drop-above,.folder-item.drop-below");
      for (var k = 0; k < ds.length; k++) ds[k].classList.remove("drop-above", "drop-below");
    });
    item.addEventListener("dragover", function (e) {
      if (!rootDrag || rootDrag === folder.path) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      var r = item.getBoundingClientRect();
      var below = (e.clientY - r.top) > r.height / 2;
      item.classList.toggle("drop-below", below);
      item.classList.toggle("drop-above", !below);
    });
    item.addEventListener("dragleave", function () {
      item.classList.remove("drop-above", "drop-below");
    });
    item.addEventListener("drop", function (e) {
      if (!rootDrag || rootDrag === folder.path) return;
      e.preventDefault();
      e.stopPropagation();
      var r = item.getBoundingClientRect();
      var below = (e.clientY - r.top) > r.height / 2;
      reorderRoot(rootDrag, folder.path, below);
      item.classList.remove("drop-above", "drop-below");
    });
  }

  container.appendChild(item);

  if (expanded && folder.hasSubs) {
    var kids = treeChildren(folder.path);
    for (var i = 0; i < kids.length; i++) {
      appendTreeNode(container, kids[i], depth + 1, false);
    }
  }
}

var rootDrag = null;

// Переставить корень dragPath относительно targetPath (ниже/выше)
function reorderRoot(dragPath, targetPath, below) {
  var from = state.roots.indexOf(dragPath);
  if (from === -1) return;
  state.roots.splice(from, 1);
  var to = state.roots.indexOf(targetPath);
  if (to === -1) { state.roots.push(dragPath); }
  else { state.roots.splice(below ? to + 1 : to, 0, dragPath); }
  saveRoots();
  renderFolderTree();
}

// ── мультивыделение в дереве ──
function addSel(path, name) { state.selPaths[path] = { path: path, name: name }; }
function toggleSel(path, name) {
  if (state.selPaths[path]) delete state.selPaths[path];
  else { addSel(path, name); state.selAnchor = path; }
}
function clearSel() { state.selPaths = {}; }
function selCount() { return Object.keys(state.selPaths).length; }
function selItems() {
  var out = [];
  for (var p in state.selPaths) out.push({ kind: "folder", name: state.selPaths[p].name, path: p });
  return out;
}
// диапазон по плоскому списку видимых узлов дерева
function selectRange(fromPath, toPath) {
  var rows = document.querySelectorAll("#folder-list .folder-item.tree");
  var paths = [];
  // восстановим path каждого узла по подсветке невозможно — используем порядок DOM + dataset
  // проще: соберём видимые пути из текущего дерева
  var order = visibleTreePaths();
  var i1 = order.indexOf(fromPath), i2 = order.indexOf(toPath);
  if (i1 === -1 || i2 === -1) { addSel(toPath, baseName(toPath)); return; }
  if (i1 > i2) { var t = i1; i1 = i2; i2 = t; }
  for (var i = i1; i <= i2; i++) addSel(order[i], baseName(order[i]));
}
function visibleTreePaths() {
  var order = [];
  function walk(folder) {
    order.push(folder.path);
    if (expandedPaths[folder.path] && folder.hasSubs) {
      var kids = treeChildren(folder.path);
      for (var i = 0; i < kids.length; i++) walk(kids[i]);
    }
  }
  for (var r = 0; r < state.roots.length; r++) {
    walk({ name: baseName(state.roots[r]), path: state.roots[r], hasSubs: true });
  }
  return order;
}


function treeChildren(path) {
  if (nodeFs) {
    var dirs = index.folders[path];
    if (dirs === undefined) {
      dirs = listDirNode(path).dirs;
      index.folders[path] = dirs;
    }
    return decorateFolders(dirs);
  }
  // fallback ExtendScript: грузим асинхронно, перерисуем по готовности
  if (jsxChildrenCache[path]) return jsxChildrenCache[path];
  if (jsxChildrenCache[path] !== null) {
    jsxChildrenCache[path] = null; // помечаем «грузится»
    csInterface.evalScript('getFolders("' + escPath(path) + '")', function (res) {
      try {
        var data = JSON.parse(res);
        jsxChildrenCache[path] = data.error ? [] : data;
      } catch (e) { jsxChildrenCache[path] = []; }
      renderFolderTree();
    });
  }
  return [];
}

function toggleExpand(path) {
  var willOpen = !expandedPaths[path];

  // режим «только одна открытая»: при раскрытии новой ветки
  // закрываем все остальные, оставляя корень и предков этой папки
  if (willOpen && state.folderExpand === "single") {
    var next = {};
    for (var p in expandedPaths) {
      if (!expandedPaths[p]) continue;
      if (p === state.rootPath || isAncestorOf(p, path)) next[p] = true;
    }
    expandedPaths = next;
  }

  expandedPaths[path] = willOpen;
  renderFolderTree();
}

function selectTreeFolder(path) {
  state.currentPath = path;
  loadSfx(path);
  renderFolderTree(); // обновить подсветку выбранного
}

// ── РЕЖИМ «НАВИГАЦИЯ» (как раньше) ──
function renderFolderList(selectedIdx) {
  var list = document.getElementById("folder-list");
  list.innerHTML = "";

  if (state.allFolders.length === 0) {
    list.innerHTML = '<div class="folder-empty">Нет подпапок</div>';
    return;
  }

  var frag = document.createDocumentFragment();
  state.allFolders.forEach(function (folder, idx) {
    var item = document.createElement("div");
    item.className = "folder-item";
    if (idx === selectedIdx) item.classList.add("selected");

    var icon = folderIconHtml(folder.path);
    item.innerHTML =
      '<span class="folder-icon">' + icon + "</span>" +
      '<span class="folder-name">' + escHtml(folder.name) + "</span>" +
      (folder.hasSubs ? '<span class="folder-arrow">›</span>' : "");

    item.addEventListener("click", function () {
      var sel = list.querySelector(".folder-item.selected");
      if (sel) sel.classList.remove("selected");
      item.classList.add("selected");
      loadSfx(folder.path);
    });
    item.addEventListener("dblclick", function (e) {
      e.stopPropagation();
      enterFolder(folder.path);
    });
    frag.appendChild(item);
  });
  list.appendChild(frag);
}

function enterFolder(path) {
  state.history.push({ sidebarPath: state.currentPath, displayPath: state.displayedFolderPath });
  state.currentPath = path;
  document.getElementById("btn-back").disabled = false;
  loadFolders(path);
  loadSfx(path);
  updateBreadcrumb();
}

function goBack() {
  if (state.history.length === 0) return;
  var prev = state.history.pop();
  state.currentPath = prev.sidebarPath;
  document.getElementById("btn-back").disabled = state.history.length === 0;
  loadFolders(prev.sidebarPath);
  loadSfx(prev.displayPath);
  updateBreadcrumb();
}

// ══════════════════════════════════════════════
//  РЕНДЕР SFX
// ══════════════════════════════════════════════
function renderSfxList() {
  var list = document.getElementById("sfx-list");
  list.innerHTML = "";
  state.renderedCount = 0;

  var query = state.searchQuery;
  state.filteredSfx = !query
    ? state.currentSfx
    : state.currentSfx.filter(function (f) {
        return f.name.toLowerCase().indexOf(query) !== -1;
      });

  var count = state.filteredSfx.length;
  document.getElementById("sfx-count").textContent = count + " " + pluralFiles(count);

  if (count === 0) {
    list.innerHTML =
      '<div class="sfx-empty">' +
        '<div class="sfx-empty-icon">🔇</div>' +
        "<p>" + (query ? "Ничего не найдено" : (index.building ? "Сканирую…" : "Здесь нет SFX-файлов")) + "</p>" +
      "</div>";
    return;
  }
  appendChunk();
}

function appendChunk() {
  var files = state.filteredSfx;
  if (state.renderedCount >= files.length) return;

  var list = document.getElementById("sfx-list");
  var end  = Math.min(state.renderedCount + RENDER_CHUNK, files.length);
  var grid = state.viewMode === "grid";
  var html = "";

  for (var i = state.renderedCount; i < end; i++) {
    var f = files[i];
    var selected = state.selectedFile && state.selectedFile.path === f.path;
    var playing  = selected && player.playing;
    var cls = (selected ? " selected" : "") + (playing ? " playing" : "");
    var starOn = favorites[f.path] ? " on" : "";
    var starHtml = '<button class="sfx-star' + starOn + '" title="В избранное">' + (starOn ? "★" : "☆") + "</button>";

    if (grid) {
      html +=
        '<div class="sfx-item tile' + cls + '" data-idx="' + i + '" draggable="true">' +
          '<div class="tile-wave-wrap"><canvas class="tile-wave" data-path="' + escHtml(f.path) + '"></canvas></div>' +
          starHtml +
          '<div class="tile-caption">' +
            '<button class="sfx-play-btn" title="Играть / Пауза">' + (playing ? "⏸" : "▶") + "</button>" +
            '<span class="sfx-name" title="' + escHtml(f.name) + '">' + escHtml(stripExt(f.name)) + "</span>" +
            '<span class="sfx-ext ext-' + f.ext.toLowerCase() + '">' + f.ext + "</span>" +
            '<button class="sfx-btn-add" title="Добавить в таймлайн">+</button>' +
          "</div>" +
        "</div>";
    } else {
      html +=
        '<div class="sfx-item' + cls + '" data-idx="' + i + '" draggable="true">' +
          '<button class="sfx-play-btn" title="Играть / Пауза">' + (playing ? "⏸" : "▶") + "</button>" +
          starHtml +
          '<span class="sfx-name" title="' + escHtml(f.name) + '">' + escHtml(stripExt(f.name)) + "</span>" +
          '<span class="sfx-ext ext-' + f.ext.toLowerCase() + '">' + f.ext + "</span>" +
          '<button class="sfx-btn-add" title="Добавить в таймлайн">+</button>' +
        "</div>";
    }
  }

  var temp = document.createElement("div");
  temp.innerHTML = html;
  var frag = document.createDocumentFragment();
  while (temp.firstChild) frag.appendChild(temp.firstChild);
  list.appendChild(frag);
  state.renderedCount = end;

  if (grid) requestAnimationFrame(scheduleThumbs);
}

// ══════════════════════════════════════════════
//  ПОИСК ПО БИБЛИОТЕКЕ + ФИЛЬТРАЦИЯ ДЕРЕВА
//  Ввёл текст → слева остаются только папки (по всем корням),
//  где есть звук с похожим (подстрока) названием, раскрытые до них.
//  Стёр → дерево и правый список возвращаются к состоянию до поиска
//  (снимок expandedPaths + выбранной папки).
//  Глобальный поиск требует Node-индекса; без него — старое поведение.
// ══════════════════════════════════════════════
var searchSnapshot   = null;  // { exp, disp, cur, lastFolder } — состояние до поиска
var searchMatchesAll = [];    // все совпадения по текущему запросу (по всем корням)
var searchTree       = null;  // { hits, allowed, counts } — отфильтрованное дерево
var searchScopeDir   = null;  // выбранная во время поиска папка (сужает правый список)
var _searchStylesDone = false;

// Единая точка входа — вызывается из поля ввода и кнопки очистки.
function applySearchQuery(rawVal) {
  var val = (rawVal || "").toLowerCase();
  if (val === state.searchQuery) return;

  var entering = !!val && !state.searchQuery;
  var leaving  = !val && !!state.searchQuery;

  if (entering) snapshotBeforeSearch();
  state.searchQuery = val;

  if (leaving) { restoreAfterSearch(); return; }
  if (val) runSearch();
  else renderSfxList();
}

// Снимок состояния дерева/выбора перед первым символом запроса.
function snapshotBeforeSearch() {
  var exp = {};
  for (var k in expandedPaths) if (expandedPaths[k]) exp[k] = true;
  searchSnapshot = {
    exp: exp,
    disp: state.displayedFolderPath,
    cur:  state.currentPath,
    lastFolder: state.lastFolderPath
  };
  searchScopeDir = null;
}

// Вернуть всё к состоянию до поиска.
function restoreAfterSearch() {
  state.searchActive = false;
  searchMatchesAll = [];
  searchTree = null;
  searchScopeDir = null;

  if (searchSnapshot) {
    expandedPaths = searchSnapshot.exp || {};
    state.displayedFolderPath = searchSnapshot.disp;
    state.currentPath = searchSnapshot.cur;
    if (searchSnapshot.lastFolder) state.lastFolderPath = searchSnapshot.lastFolder;
  }
  searchSnapshot = null;

  // правый список — назад к папке, выбранной до поиска
  var p = state.displayedFolderPath;
  var real = p && p !== "__favs__" && String(p).indexOf("__col__") !== 0;
  if (real) {
    if (nodeFs && (index.ready || index.building)) state.currentSfx = filesUnder(p);
    else if (nodeFs) state.currentSfx = scanRecursiveNode(p);
  }
  renderFolders();
  renderSfxList();
}

// Активный поиск: совпадения по всему индексу + построение дерева.
function runSearch() {
  // глобальный поиск возможен только при наличии Node-индекса
  if (!(nodeFs && index.files.length)) {
    state.searchActive = false;     // деградация: фильтруем только текущую папку
    renderSfxList();
    return;
  }
  ensureSearchStyles();
  state.searchActive = true;

  searchMatchesAll = searchMatches(state.searchQuery);
  searchTree = buildSearchTree(searchMatchesAll);

  // правый список — все совпадения (или сужение по выбранной в дереве папке)
  state.currentSfx = (searchScopeDir && searchTree.allowed[searchScopeDir])
    ? matchesUnder(searchScopeDir)
    : searchMatchesAll;

  renderSfxList();
  renderFolders(); // при searchActive уйдёт в отфильтрованное дерево
}

// Совпадения по подстроке имени среди всех файлов индекса.
function searchMatches(q) {
  q = q.toLowerCase();
  var out = [];
  for (var i = 0; i < index.files.length; i++) {
    if (index.files[i].name.toLowerCase().indexOf(q) !== -1) out.push(index.files[i]);
  }
  return out;
}

// Цепочка папок от корня до dir включительно: [root, root/a, root/a/b, …, dir]
function ancestorsChain(dir) {
  var root = rootOf(dir);
  if (!root) return [dir];
  if (dir === root) return [root];
  var sep = root.indexOf("\\") !== -1 ? "\\" : "/";
  var rest = dir.slice(root.length);
  while (rest.charAt(0) === sep) rest = rest.slice(1);
  var parts = rest.split(/[\\/]/);
  var chain = [root], cur = root;
  for (var i = 0; i < parts.length; i++) {
    if (!parts[i]) continue;
    cur = cur + sep + parts[i];
    chain.push(cur);
  }
  return chain;
}

// hits — папки, прямо содержащие совпадение; allowed — все папки на пути к ним;
// counts — число совпадений в поддереве папки (для бейджа).
function buildSearchTree(matches) {
  var hits = {}, allowed = {}, counts = {};
  for (var i = 0; i < matches.length; i++) {
    var dir = matches[i].dir;
    hits[dir] = true;
    var chain = ancestorsChain(dir);
    for (var j = 0; j < chain.length; j++) {
      allowed[chain[j]] = true;
      counts[chain[j]] = (counts[chain[j]] || 0) + 1;
    }
  }
  return { hits: hits, allowed: allowed, counts: counts };
}

// Совпадения, лежащие в папке path или её поддереве.
function matchesUnder(path) {
  var sep = path.indexOf("\\") !== -1 ? "\\" : "/";
  var pre = path.charAt(path.length - 1) === sep ? path : path + sep;
  var out = [];
  for (var i = 0; i < searchMatchesAll.length; i++) {
    var d = searchMatchesAll[i].dir;
    if (d === path || d.indexOf(pre) === 0) out.push(searchMatchesAll[i]);
  }
  return out;
}

// ── Отрисовка отфильтрованного дерева (только папки с совпадениями) ──
function renderFolderTreeFiltered() {
  var list = document.getElementById("folder-list");
  list.innerHTML = "";

  var st = searchTree;
  var frag = document.createDocumentFragment();
  var shown = 0;
  for (var i = 0; i < state.roots.length; i++) {
    var rp = state.roots[i];
    if (st && st.allowed[rp]) { appendFilteredNode(frag, { name: baseName(rp), path: rp }, 0, true); shown++; }
  }
  if (!shown) {
    list.innerHTML = '<div class="folder-empty">Ничего не найдено</div>';
    return;
  }
  list.appendChild(frag);
}

function appendFilteredNode(container, folder, depth, isRoot) {
  var st = searchTree;
  var kids = filteredChildren(folder.path);
  var hasKids = kids.length > 0;
  var isHit = !!(st && st.hits[folder.path]);
  var cnt = (st && st.counts[folder.path]) || 0;

  var item = document.createElement("div");
  item.className = "folder-item tree" + (isRoot ? " root" : "") + (isHit ? " has-hit" : "");
  if (folder.path === state.displayedFolderPath) item.classList.add("selected");
  item.style.paddingLeft = (8 + depth * 14) + "px";

  var chev = hasKids
    ? '<span class="chev open">›</span>'
    : '<span class="chev spacer">›</span>';

  item.innerHTML =
    chev +
    '<span class="folder-icon">' + folderIconHtml(folder.path, hasKids) + "</span>" +
    '<span class="folder-name">' + escHtml(folder.name) + "</span>" +
    (cnt ? '<span class="folder-hit-count">' + cnt + "</span>" : "");

  item.addEventListener("click", function () { selectSearchFolder(folder.path); });

  container.appendChild(item);
  for (var i = 0; i < kids.length; i++) appendFilteredNode(container, kids[i], depth + 1, false);
}

// Подпапки данной папки, входящие в отфильтрованный набор.
function filteredChildren(path) {
  var st = searchTree;
  if (!st) return [];
  var kids = treeChildren(path);
  var out = [];
  for (var i = 0; i < kids.length; i++) if (st.allowed[kids[i].path]) out.push(kids[i]);
  return out;
}

// Клик по папке во время поиска — сузить правый список до её совпадений.
function selectSearchFolder(path) {
  searchScopeDir = path;
  state.displayedFolderPath = path;
  state.currentPath = path;
  state.currentSfx = matchesUnder(path);
  renderSfxList();
  renderFolderTreeFiltered();
}

// Мини-стиль: бейдж количества + подсветка папки-совпадения.
function ensureSearchStyles() {
  if (_searchStylesDone) return;
  _searchStylesDone = true;
  var css =
    ".folder-item.has-hit .folder-name{font-weight:600;}" +
    ".folder-hit-count{flex-shrink:0;margin-left:6px;font-size:10px;line-height:1;" +
    "padding:2px 6px;border-radius:9px;background:var(--accent);" +
    "color:var(--selected-text,#fff);opacity:.92;}";
  var el = document.createElement("style");
  el.id = "mflib-search-style";
  el.textContent = css;
  document.head.appendChild(el);
}

// ══════════════════════════════════════════════
//  МИНИАТЮРЫ ВОЛН (ленивая отрисовка)
// ══════════════════════════════════════════════
var thumbCache = {};      // path → offscreen canvas
var thumbOrder = [];      // для ограничения кэша
var thumbQueue = [];
var thumbActive = 0;
var THUMB_MAX_CACHE = 400;
var THUMB_CONCURRENCY = 2;

function resetThumbs() {
  thumbCache = {}; thumbOrder = []; thumbQueue = [];
  var canvases = document.querySelectorAll(".tile-wave");
  for (var i = 0; i < canvases.length; i++) canvases[i].removeAttribute("data-state");
  if (state.viewMode === "grid") requestAnimationFrame(scheduleThumbs);
}

// Ставим в очередь только видимые (± запас) плитки
function scheduleThumbs() {
  if (state.viewMode !== "grid") return;
  var list = document.getElementById("sfx-list");
  var rect = list.getBoundingClientRect();
  var margin = 350;
  var canvases = list.querySelectorAll(".tile-wave:not([data-state])");

  for (var i = 0; i < canvases.length; i++) {
    var r = canvases[i].getBoundingClientRect();
    var visible =
      r.bottom > rect.top - margin && r.top < rect.bottom + margin &&
      r.right  > rect.left - margin && r.left < rect.right + margin;
    if (visible) {
      canvases[i].setAttribute("data-state", "queued");
      thumbQueue.push(canvases[i]);
    }
  }
  pumpThumbs();
}

function pumpThumbs() {
  while (thumbActive < THUMB_CONCURRENCY && thumbQueue.length) {
    var canvas = thumbQueue.shift();
    if (!document.body.contains(canvas)) continue;
    thumbActive++;
    renderThumb(canvas, function () {
      thumbActive--;
      pumpThumbs();
    });
  }
}

function renderThumb(canvas, done) {
  var path = canvas.getAttribute("data-path");

  if (thumbCache[path]) {
    drawThumb(canvas, thumbCache[path]);
    canvas.setAttribute("data-state", "done");
    done();
    return;
  }

  readFileArrayBuffer(path, function (ab, err) {
    if (err || !ab || !document.body.contains(canvas)) {
      canvas.setAttribute("data-state", "err");
      done();
      return;
    }
    player.ensureCtx();
    player.ctx.decodeAudioData(ab, function (buf) {
      var img = buildThumbImage(buf, 260, 140);
      thumbCache[path] = img;
      thumbOrder.push(path);
      if (thumbOrder.length > THUMB_MAX_CACHE) {
        delete thumbCache[thumbOrder.shift()];
      }
      if (document.body.contains(canvas)) drawThumb(canvas, img);
      canvas.setAttribute("data-state", "done");
      done();
    }, function () {
      canvas.setAttribute("data-state", "err");
      done();
    });
  });
}

function buildThumbImage(buf, W, H) {
  var off = document.createElement("canvas");
  off.width = W; off.height = H;
  var g = off.getContext("2d");
  var color = getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "#ddd";
  g.fillStyle = color;

  var chans = Math.min(2, buf.numberOfChannels);
  var laneH = H / chans;

  for (var ch = 0; ch < chans; ch++) {
    var data = buf.getChannelData(ch);
    var step = Math.max(1, Math.floor(data.length / W));
    var mid  = laneH * ch + laneH / 2;
    var amp  = (laneH / 2) * 0.92;

    for (var x = 0; x < W; x++) {
      var start = Math.floor(x * data.length / W);
      var min = 1, max = -1;
      for (var i = 0; i < step; i++) {
        var v = data[start + i];
        if (v === undefined) break;
        if (v < min) min = v;
        if (v > max) max = v;
      }
      if (min > max) { min = 0; max = 0; }
      var y1 = mid - max * amp;
      var y2 = mid - min * amp;
      g.fillRect(x, y1, 1, Math.max(1, y2 - y1));
    }
  }
  return off;
}

function drawThumb(canvas, img) {
  var wrap = canvas.parentNode;
  canvas.width  = wrap.clientWidth;
  canvas.height = wrap.clientHeight;
  var g = canvas.getContext("2d");
  g.clearRect(0, 0, canvas.width, canvas.height);
  g.drawImage(img, 0, 0, canvas.width, canvas.height);
}

function pluralFiles(n) {
  var m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return "файл";
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return "файла";
  return "файлов";
}

function stripExt(name) {
  var dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(0, dot) : name;
}

// ══════════════════════════════════════════════
//  ВЫБОР ФАЙЛА
// ══════════════════════════════════════════════
function selectFile(f, itemEl) {
  var prev = document.querySelector(".sfx-item.selected");
  if (prev) prev.classList.remove("selected");
  if (itemEl) itemEl.classList.add("selected");
  state.selectedFile = f;
  updateFooter();
}

function deselectFile() {
  state.selectedFile = null;
  var prev = document.querySelector(".sfx-item.selected");
  if (prev) prev.classList.remove("selected");
  hidePlayer();
  updateFooter();
}

// ══════════════════════════════════════════════
//  FOOTER
// ══════════════════════════════════════════════
function updateFooter() {
  syncFooterToButtons();
}

// Единая нижняя строка статуса (видна в любой вкладке)
var _statusTimer = null;
function flashStatus(msg, type) {
  var el = document.getElementById("status-bar");
  if (!el) return;
  el.textContent = msg || "";
  el.className = (msg ? "show" : "") + (type ? " " + type : "");
  clearTimeout(_statusTimer);
  if (msg && type !== "error") {
    _statusTimer = setTimeout(function () { el.className = ""; el.textContent = ""; }, 3500);
  }
}

function setFooterMsg(msg, type) {
  var el = document.getElementById("selected-info");
  if (el) { el.textContent = msg; el.className = type || ""; }
  flashStatus(msg, type); // дублируем в нижнюю строку (видно и во вкладках)
  setTimeout(updateFooter, 3000);
}

// ══════════════════════════════════════════════
//  ДОБАВИТЬ В ТАЙМЛАЙН
// ══════════════════════════════════════════════
function addSelected() {
  if (!state.selectedFile) return;
  if (player.playing) player.pause(); // чтобы не звучало в два голоса

  var path = state.selectedFile.path;

  function finish(res) {
    try {
      var data = JSON.parse(res);
      setFooterMsg((data.ok ? "✅ " : "⚠ ") + data.msg, data.ok ? "success" : "error");
    } catch (e) {
      setFooterMsg("✅ Готово", "success");
    }
  }

  // Pitch/Reverse активны для этого файла → запекаем обработку в temp-WAV,
  // иначе в таймлайн уйдёт «сырой» звук без эффектов
  var fxActive = player.file && player.file.path === path &&
                 (player.pitch !== 0 || player.reversed) &&
                 nodeFs && nodeOs && player.buffer;

  if (fxActive) {
    try {
      var rate = player.rate;
      var hasSel = player.hasSelection();
      var a = hasSel ? player.selStart : 0;
      var b = hasSel ? player.selEnd : player.duration;
      var h0 = Math.max(0, a - 30);
      var h1 = Math.min(player.duration, b + 30);

      var ab = renderProcessedWav(h0, h1);
      var tmp = tmpFragmentPath(player.file.name);
      nodeFs.writeFileSync(tmp, new Uint8Array(ab));

      var inS  = (a - h0) / rate;
      var outS = (b - h0) / rate;
      csInterface.evalScript(
        'addToTimeline("' + escPath(tmp) + '",' + inS.toFixed(4) + ',' + outS.toFixed(4) + ')',
        finish
      );
      return;
    } catch (e) {
      console.error("FX render failed, fallback to raw:", e);
    }
  }

  var args = '"' + escPath(path) + '"';

  // если в плеере выделен диапазон ЭТОГО файла — вставляем фрагмент
  var sel = null;
  if (player.file && player.file.path === path && player.hasSelection()) {
    sel = player.selectionInOriginal();
  }

  function doAdd() {
    if (sel) {
      args += "," + sel.inSec.toFixed(4) + "," + sel.outSec.toFixed(4);
      trimmedDurations[path] = player.duration;
    }
    csInterface.evalScript("addToTimeline(" + args + ")", finish);
  }

  // выделения нет, но файлу раньше ставили in/out — сначала сбросим
  if (!sel && trimmedDurations[path]) {
    var dur = trimmedDurations[path];
    delete trimmedDurations[path];
    csInterface.evalScript('resetTrim("' + escPath(path) + '",' + dur.toFixed(4) + ')', doAdd);
  } else {
    doAdd();
  }
}

// ══════════════════════════════════════════════
//  ХЛЕБНЫЕ КРОШКИ / УТИЛИТЫ
// ══════════════════════════════════════════════
function updateBreadcrumb() {
  var bc = document.getElementById("breadcrumb");
  if (!state.rootPath || !state.currentPath) { bc.textContent = ""; return; }
  var rel = state.currentPath.replace(state.rootPath, "").replace(/\\/g, "/");
  var parts = rel.split("/").filter(Boolean);
  var bcLabel = parts.length === 0 ? "Корень" : "/ " + parts.join(" / ");
  bc.innerHTML = folderSvg(FOLDER_DEFAULT) + " " + escHtml(bcLabel);
}

function toFileUrl(filePath) {
  var isWin = /^[A-Za-z]:\\/.test(filePath);
  var parts = filePath.split(/[\\/]/).map(function (seg, i) {
    if (isWin && i === 0) return seg;
    return encodeURIComponent(seg);
  });
  return (isWin ? "file:///" : "file://") + parts.join("/");
}

function escPath(p) { return p.replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }
function escHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
