/* ===== Motion Panel — main.js ===== */
var cs = new CSInterface();

/* отдать host'у путь к папке расширения — чтобы он нашёл .ffx-псевдоэффекты в бандле.
   getSystemPath отдаёт URL-кодированный путь (на macOS «Application Support» → %20),
   поэтому ОБЯЗАТЕЛЬНО decodeURIComponent — иначе new File() в ExtendScript не найдёт .ffx. */
(function () {
  try {
    if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
      var ep = window.__adobe_cep__.getSystemPath('extension');
      if (ep) { try { ep = decodeURIComponent(ep); } catch (eDec) {} cs.evalScript('MP_setExtPath(' + jsxStr(ep) + ')'); }
    }
  } catch (e) {}
})();

/* ---- лог отладки (секция «Логи» в настройках) ---- */
var MP_LOG = [];
function MP_log(line) {
  var ts = new Date().toTimeString().slice(0, 8);
  MP_LOG.push('[' + ts + '] ' + line);
  if (MP_LOG.length > 500) MP_LOG.shift();
  var box = document.getElementById('logBox');
  var pop = document.getElementById('settingsPop');
  if (box && pop && !pop.hidden) { box.textContent = MP_LOG.join('\n'); box.scrollTop = box.scrollHeight; }
}
window.addEventListener('error', function (e) {
  MP_log('JS ERROR: ' + (e.message || e) + (e.filename ? ' @ ' + (e.filename.split('/').pop()) + ':' + e.lineno : ''));
});
/* авто-лог всех вызовов хоста и ответов */
(function () {
  if (!cs || !cs.evalScript) return;
  var orig = cs.evalScript.bind(cs);
  cs.evalScript = function (script, cb) {
    MP_log('▶ ' + String(script).slice(0, 160));
    orig(script, function (res) {
      MP_log('◀ ' + String(res).slice(0, 500));
      if (cb) cb(res);
    });
  };
})();

/* ---------------- утилиты ---------------- */
var $  = function (s, p) { return (p || document).querySelector(s); };
var $$ = function (s, p) { return Array.prototype.slice.call((p || document).querySelectorAll(s)); };

function toast(msg) {
  var t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._tm);
  toast._tm = setTimeout(function () { t.classList.remove('show'); }, 1800);
}

var store = {
  _ns: function (k) { return (WS_KEYS[k] && typeof activeWs !== 'undefined' && activeWs) ? ('ws_' + activeWs + '_' + k) : k; },
  get: function (k, fallback) {
    try {
      var v = localStorage.getItem('mp_' + this._ns(k));
      if (v === null || v === 'null' || v === 'undefined') return fallback;
      var parsed = JSON.parse(v);
      return (parsed === null || parsed === undefined) ? fallback : parsed;
    } catch (e) { return fallback; }
  },
  set: function (k, v) { try { localStorage.setItem('mp_' + this._ns(k), JSON.stringify(v)); } catch (e) {} }
};

/* ===== ВОРКСПЕЙСЫ: независимые раскладки (эти ключи хранятся отдельно для каждого воркспейса) ===== */
var WS_KEYS = { boards: 1, widgetPos: 1, widgetSizes: 1, widgetHeights: 1, boardGroups: 1, widgetColors: 1, modulesOff: 1, tabOrder: 1, paletteSizes: 1, flowOrder: 1 };
var workspaces = store.get('workspaces', null);
if (!workspaces || !workspaces.length) { workspaces = [{ id: 'ws1', name: 'Workspace 1' }]; store.set('workspaces', workspaces); }
var activeWs = store.get('activeWs', null);
(function () { for (var i = 0; i < workspaces.length; i++) if (workspaces[i].id === activeWs) return; activeWs = workspaces[0].id; store.set('activeWs', activeWs); })();
/* однократный перенос старой «общей» раскладки в первый воркспейс */
if (!store.get('wsMigrated', false)) {
  for (var _wk in WS_KEYS) {
    var _old = null; try { _old = localStorage.getItem('mp_' + _wk); } catch (e) {}
    if (_old !== null) { try { localStorage.setItem('mp_ws_' + activeWs + '_' + _wk, _old); } catch (e2) {} }
  }
  store.set('wsMigrated', true);
}


/* ============================================================
   ЯЗЫК (RU/EN)
============================================================ */
var LANGS = {
  ru: {
    w_anchor: 'Anchor Point', w_nulltool: 'Add Null', w_unprecomp: 'Unprecomp', w_dupcomp: 'Duplicate', w_fitcomp: 'Fit to Comp', w_upscale4k: '4K Copy', w_addlimb: 'Add Limb', w_stagger: 'Sequence',
    w_elastic: 'Elastic', w_bounce: 'Bounce',
    w_palettes: 'Палитры', w_palextract: 'Палитра из картинки', w_bezier: 'Cubic-график', w_library: 'Библиотека графиков', w_texttools: 'Текст: Split / Shapes',
    pex_uploadlabel: 'Загрузите картинку', pex_upload: 'Загрузить', pex_reupload: 'Загрузить другую', pex_save: 'Сохранить в палитры', pex_copy: 'Копировать палитру', pex_saved: 'Палитра сохранена', pex_copied: 'Палитра скопирована', pex_notimg: 'Это не изображение', pex_nocolors: 'Цвета не найдены',
    tfx_replay: 'Повтор', tfx_preview: 'ПРЕВЬЮ', tfx_params: 'ПАРАМЕТРЫ', tfx_apply: 'Применить к слоям', tfx_selecthint: 'Выделите слой(и)', tfx_soon: 'Применение добавим позже', tfx_animate: 'Анимация:', tfx_in: 'In', tfx_out: 'Out', tfx_both: 'Both',
    tfx_applied: 'Применено: {0}', tfx_resethint: 'Двойной клик — сброс к базовому',
    w_exprtools: 'Expressions',
    cat_main: 'Основные инструменты', cat_color: 'Цвет', cat_anim: 'Анимация',
    page_home: 'Home', page_palettes: 'Палитры', page_graph: 'Графики', page_expr: 'Expressions',
    expr_title: 'Expressions', expr_add: '+ Добавить с таймлайна',
    expr_empty: 'Пусто. Выдели слой с выражениями и нажми «Добавить с таймлайна».',
    expr_name_ph: 'Название…', expr_code_ph: '// Expression…',
    expr_save: 'Сохранить', expr_apply_btn: 'Применить к выделенным',
    expr_need_ae: 'Expressions работают только в After Effects',
    expr_nosel: 'Сначала выдели слой с выражениями',
    expr_noexpr: 'На выделенном слое нет выражений',
    expr_noprops: 'Выдели свойства в таймлайне, к которым применить',
    expr_added: 'Добавлено выражений: {0}',
    expr_applied: 'Применено к свойствам: {0}',
    expr_applied_done: 'Готово',
    expr_rename_tip: 'Двойной клик — переименовать', expr_pick: 'Выбери выражение слева или добавь с таймлайна.', expr_delete: 'Удалить',
    expr_edit_tip: 'Открыть и отредактировать',
    expr_apply_tip: 'Применить к выделенным свойствам',
    expr_del_tip: 'Удалить',
    tfx_tab_anim: 'Анимация', tfx_tab_fonts: 'Шрифты',
    tfx_cap_add: '+ Добавить с таймлайна', tfx_need_ae: 'Работает только в After Effects',
    tfx_cap_nosel: 'Сначала выдели слой с анимацией', tfx_cap_noanim: 'На выделенном слое не найдено анимации (кейфреймы Transform или Text Animators)',
    tfx_cap_added: 'Анимация захвачена как пресет', tfx_cap_applynosel: 'Сначала выдели слой(и), к которым применить',
    tfx_cap_speed: 'Скорость', tfx_cap_delay: 'Задержка', tfx_cap_from: 'Захвачено: {0}',
    tfx_cap_del: 'Удалить пресет', tfx_cap_rename_tip: 'Двойной клик — переименовать',
    tfx_cap_note: 'Захваченный пресет переносит кейфреймы Transform и текстовых аниматоров. Speed меняет темп, Delay сдвигает старт к плейхеду.',
    font_new: '+ Новая комбинация', font_count_one: 'шрифт', font_role_a: 'Заголовок', font_role_b: 'Текст',
    font_add2: '+ Добавить второй шрифт', font_pick_label: 'ШРИФТЫ',
    font_apply: 'Применить', font_save: 'Сохранить пресет', font_saved: 'Пресет шрифтов сохранён',
    font_delete: 'Удалить пресет', font_search_ph: 'Поиск шрифта…',
    font_nosel: 'Сначала выдели текстовый слой', font_notext: 'Среди выделенных нет текстовых слоёв',
    font_applied: 'Шрифт применён: {0}', font_need_ae: 'Применение шрифта работает только в After Effects',
    font_sample_b: 'Съешь же ещё этих мягких французских булок да выпей чаю',
    font_empty: 'Нет пресетов. Нажми «Новая комбинация» и собери пару шрифтов.',
    font_rename_tip: 'Двойной клик — переименовать', font_new_name: 'Новая комбинация',
    palettes_title: 'Палитры', library_title: 'Библиотека',
    apply_keys: 'Применить к ключам', new_palette: '+ Новая палитра',
    preset_placeholder: 'Имя графика…', ok: 'Ок',
    lib_empty: 'Пока пусто — настрой график выше и нажми «+», чтобы сохранить его.',
    lib_new: '➕ Новая библиотека…',
    lib_keep_one: 'Нельзя удалить единственную библиотеку',
    lib_deleted: 'Библиотека «{0}» удалена',
    lib_del_hint: 'Удалить библиотеку',
    autoapply_label: 'Авто-применять график к выделенным ключам',
    add_layout: 'Layout:', add_search: 'Поиск инструментов…',
    add_hint: 'Выбери инструмент слева — он добавится на текущую страницу.',
    add_none: 'Ничего не найдено', on_pages: 'на',
    set_lang: 'Язык', set_theme: 'Цвета', set_ui: 'Размер интерфейса',
    set_tiles: 'Плитки', hidelabels_label: 'Скрывать подписи у плиток (только иконки)',
    ctx_color: 'Color', ws_new: '+ Новый воркспейс', ws_rename: 'Переименовать', ws_del: 'Удалить воркспейс',
    ws_save_default: '★ Запомнить как стартовую', ws_save_default_hint: 'Новые воркспейсы будут создаваться с текущей раскладкой', ws_saved_default: 'Текущая раскладка сохранена как стартовая',
    set_title: 'Настройки', set_modules: 'Модули', set_modules_hint: 'Включай и выключай функции панели. Вкладка без функций прячется сама.',
    th_accent: 'Акцент', th_bg: 'Фон', th_card: 'Элементы', th_txt: 'Текст', th_reset: 'Сбросить цвета', wcol_hint: 'Цвет / группа плашки', grp_del: 'Удалить группу', grp_eject: 'Вынуть из группы',
    edit_add_color: '+ Add new color', update: 'Update',
    dd_words: 'Words', dd_lines: 'Lines', dd_chars: 'Characters',
    t_layout_on: 'Режим раскладки: тащи блоки, размер — за зелёный уголок',
    t_layout_off: 'Раскладка сохранена', t_size_reset: 'Размер сброшен',
    t_anchor: 'Anchor point перемещён', t_null: 'Null добавлен', t_null_primary: 'Primary добавлен',
    t_limb: 'Конечность создана', t_elastic: 'Elastic применён: {0} св.', t_bounce: 'Bounce применён: {0} св.',
    w_sorttool: 'Сортировка', w_sortset: 'Настройки сортировки', t_sort: 'Разложено: {0} · удалено: {1}', t_sortsaved: 'Настройки сортировки сохранены',
    t_noprops: 'Выдели свойства на таймлайне (P, S, R, T…)',
    t_unprecomp: 'Разобрано прекомпозов: ', t_dup: 'Дубликат: {0} · прекомпозы независимы', t_dup_repl: 'Заменено независимой копией: {0}', t_fit: 'Подогнано под длину композиции · прекомпозов: {0}', t_up4k: '4K-копия создана: {0} · оригинал не тронут', t_stagger: 'Сдвинуто слоёв: {0}', t_stag_playhead: 'Слои выстроены к плейхеду: {0}', t_stag_reverse: 'Порядок развёрнут · слоёв: {0}', t_nosel_layers: 'Сначала выдели слои на таймлайне', t_applied: 'Применено к {0} пар(е) ключей',
    t_added: '«{0}» добавлен на «{1}»', t_already: '«{0}» уже на этой странице',
    t_removed: '«{0}» убран с этой вкладки', t_pinned: '«{0}» — базовый элемент этой вкладки, он закреплён',
    t_copied: '{0} скопирован', t_no_colors: 'В палитре нет цветов',
    t_pal_removed: 'Палитра удалена', t_pal_dup: 'Дубликат создан', t_pal_upd: 'Палитра обновлена',
    t_imported: 'Null «{0}» добавлен на таймлайн',
    t_saved: '«{0}» сохранён', t_loaded: '«{0}» загружен', t_need_name: 'Введи имя графика',
    t_browser: 'Режим браузера — AE не подключён', t_done: 'Готово',
    t_split: 'Текст разделён: {0} слоёв', t_shapes: 'Текст сконвертирован в шейпы',
    t_theme_reset: 'Цвета сброшены',
    t_color_applied: 'Цвет применён: {0} сл.',
    t_color_applied_stroke: 'Цвет обводки применён: {0} сл.',
    t_no_stroke: 'У выбранных слоёв нет обводки',
    sw_title: 'Клик — заливка • Shift — обводка • Alt — копировать • ПКМ — заменить • тащи — местами',
    sw_del: 'Удалить цвет',
    pal_rename_hint: 'Клик — переименовать',
    t_sort_manual: 'Сортировка: вручную', t_sort_name: 'Сортировка: по имени', t_sort_new: 'Сортировка: новые сверху',
    t_size: 'Размер карточек: {0}',
    tip_sort: 'Сортировка|Вручную (перетаскивай карточки) → по имени → новые сверху.',
    tip_size: 'Размер|Размер карточек: S → M → L.',
    tip_pedit: 'Переименовать|Изменить имя графика.',
    tip_layout: 'Раскладка|Включает редактирование: перетаскивай вкладки и панели, меняй размер за зелёный уголок. Двойной клик по уголку — сброс размера.',
    tip_settings: 'Настройки|Язык и цвета панели.',
    tip_dots: 'Preview|Плотность кружков показывает, где анимация замедляется (кучнее) и где ускоряется (реже). Клик — упрощённый плейбек.',
    tip_apply: 'Применить|Ставит текущий изинг на выделенные соседние ключи в активной композиции.',
    tip_savepreset: 'Сохранить график|Добавляет текущую кривую в активную библиотеку — появится снизу, имя можно переименовать.',
    tip_anchor: 'Anchor Point|Клик ставит якорь выбранных слоёв в выбранную точку — слой визуально не сдвигается.',
    tip_null: 'Add Null|Клик — один общий Null на все выбранные слои (центр, общая длительность, парентинг). Shift — отдельный Null каждому слою. Если выбраны только нули — жёлтый Primary поверх. Alt — классический Null.',
    tip_unprecomp: 'Unprecomp|Переносит все слои из выбранной прекомпозиции в текущую композицию (порядок, тайминг и трансформ сохраняются), сам прекомпоз удаляется.',
    tip_dup: 'Duplicate|Дублирует ВЫДЕЛЕННЫЙ на таймлайне слой (копия встаёт над ним). Если источник — прекомпоз, он и все вложенные прекомпозы копируются независимо: правки в дубликате не трогают оригинал. С зажатым Shift — не добавляет копию сверху, а заменяет источник самого слоя независимой копией прекомпоза (на месте).',
    tip_fit: 'Fit to Comp|Растягивает ВЫДЕЛЕННЫЙ прекомпоз и ВСЕ вложенные под длину текущей композиции. Обычный клик — удлиняет тайминг слоёв (длина прекомпозов и слоёв тянется до конца компа), а КЛЮЧИ остаются на местах — анимация не перетаймливается. Shift+клик — растягивает и содержимое: слои и ключи тянутся пропорционально. Внимание: правит ИСХОДНЫЕ прекомпозы — изменения видны во всех копиях.',
    tip_split: 'Split|Разделяет выбранный текстовый слой на отдельные слои по принципу из списка справа.',
    tip_ddbtn: 'Принцип разделения|Words — по словам, Lines — по строкам, Characters — по символам.',
    tip_t2s: 'Text → Shapes|Конвертирует выбранный текстовый слой в shape-слой (Create Shapes from Text).',
    tip_addtile: 'Добавить инструмент|Открывает библиотеку инструментов — выбранный добавится на текущую страницу.',
    tip_miniplus: 'Новый слот|Добавляет ещё один квадратик с «+», в который можно положить цвет.',
    tip_palmenu: 'Меню палитры|Import — Null с цветами на таймлайн, Remove, Duplicate, Edit.',
    tip_speed: 'Speed|График скорости: тяни кривую — по горизонтали influence, по вертикали скорость.',
    tip_value: 'Value|График значения с осями: то же кубическое сглаживание, что и в Cubic.',
    tip_cubic: 'Cubic|Классический cubic-bezier: тащи оранжевую и синюю точки.'
  },
  en: {
    w_anchor: 'Anchor Point', w_nulltool: 'Add Null', w_unprecomp: 'Unprecomp', w_dupcomp: 'Duplicate', w_fitcomp: 'Fit to Comp', w_upscale4k: '4K Copy', w_addlimb: 'Add Limb', w_stagger: 'Sequence',
    w_elastic: 'Elastic', w_bounce: 'Bounce',
    w_palettes: 'Palettes', w_palextract: 'Image Palette Extractor', w_bezier: 'Cubic graph', w_library: 'Graph library', w_texttools: 'Text: Split / Shapes',
    pex_uploadlabel: 'Upload Image', pex_upload: 'Upload', pex_reupload: 'Upload New Image', pex_save: 'Save to palettes', pex_copy: 'Copy palette', pex_saved: 'Palette saved', pex_copied: 'Palette copied', pex_notimg: 'Not an image', pex_nocolors: 'No colors found',
    tfx_replay: 'Replay', tfx_preview: 'LIVE PREVIEW', tfx_params: 'PARAMETERS', tfx_apply: 'Apply to layers', tfx_selecthint: 'Select one or more layers', tfx_soon: 'Apply logic coming soon', tfx_animate: 'Animate:', tfx_in: 'In', tfx_out: 'Out', tfx_both: 'Both',
    tfx_applied: 'Applied: {0}', tfx_resethint: 'Double-click to reset',
    w_exprtools: 'Expressions',
    cat_main: 'Core tools', cat_color: 'Color', cat_anim: 'Animation',
    page_home: 'Home', page_palettes: 'Palettes', page_graph: 'Graphs', page_expr: 'Expressions',
    expr_title: 'Expressions', expr_add: '+ Add from timeline',
    expr_empty: 'Empty. Select a layer with expressions and click “Add from timeline”.',
    expr_name_ph: 'Name…', expr_code_ph: '// Expression…',
    expr_save: 'Save', expr_apply_btn: 'Apply to selected',
    expr_need_ae: 'Expressions work only in After Effects',
    expr_nosel: 'Select a layer with expressions first',
    expr_noexpr: 'No expressions on the selected layer',
    expr_noprops: 'Select properties in the timeline to apply to',
    expr_added: 'Expressions added: {0}',
    expr_applied: 'Applied to properties: {0}',
    expr_applied_done: 'Done',
    expr_rename_tip: 'Double-click to rename', expr_pick: 'Select an expression on the left, or add from the timeline.', expr_delete: 'Delete',
    expr_edit_tip: 'Open and edit',
    expr_apply_tip: 'Apply to selected properties',
    expr_del_tip: 'Delete',
    tfx_tab_anim: 'Animation', tfx_tab_fonts: 'Fonts',
    tfx_cap_add: '+ Add from timeline', tfx_need_ae: 'Works only in After Effects',
    tfx_cap_nosel: 'Select a layer with animation first', tfx_cap_noanim: 'No animation found on the selected layer (Transform keyframes or Text Animators)',
    tfx_cap_added: 'Animation captured as a preset', tfx_cap_applynosel: 'Select the layer(s) to apply to first',
    tfx_cap_speed: 'Speed', tfx_cap_delay: 'Delay', tfx_cap_from: 'Captured: {0}',
    tfx_cap_del: 'Delete preset', tfx_cap_rename_tip: 'Double-click to rename',
    tfx_cap_note: 'A captured preset carries Transform and Text Animator keyframes. Speed changes the pace, Delay shifts the start to the playhead.',
    font_new: '+ New combination', font_count_one: 'font', font_role_a: 'Heading', font_role_b: 'Body',
    font_add2: '+ Add a second font', font_pick_label: 'FONTS',
    font_apply: 'Apply', font_save: 'Save preset', font_saved: 'Font preset saved',
    font_delete: 'Delete preset', font_search_ph: 'Search font…',
    font_nosel: 'Select a text layer first', font_notext: 'No text layers among the selection',
    font_applied: 'Font applied: {0}', font_need_ae: 'Applying a font works only in After Effects',
    font_sample_b: 'The quick brown fox jumps over the lazy dog',
    font_empty: 'No presets yet. Click “New combination” and pair two fonts.',
    font_rename_tip: 'Double-click to rename', font_new_name: 'New combination',
    palettes_title: 'Palettes', library_title: 'Library',
    apply_keys: 'Apply to keyframes', new_palette: '+ New palette',
    preset_placeholder: 'Graph name…', ok: 'OK',
    lib_empty: 'Empty for now — tweak the graph above and hit «+» to save it.',
    lib_new: '➕ New library…',
    lib_keep_one: 'Can’t delete the only library',
    lib_deleted: 'Library “{0}” deleted',
    lib_del_hint: 'Delete library',
    autoapply_label: 'Auto-apply graph to selected keyframes',
    add_layout: 'Layout:', add_search: 'Search tools…',
    add_hint: 'Pick a tool on the left — it will be added to the current page.',
    add_none: 'Nothing found', on_pages: 'on',
    set_lang: 'Language', set_theme: 'Colors', set_ui: 'Interface size',
    set_tiles: 'Tiles', hidelabels_label: 'Hide tile labels (icons only)',
    ctx_color: 'Color', ws_new: '+ New workspace', ws_rename: 'Rename', ws_del: 'Delete workspace',
    ws_save_default: '★ Save as starting layout', ws_save_default_hint: 'New workspaces will start from the current layout', ws_saved_default: 'Current layout saved as the starting one',
    set_title: 'Settings', set_modules: 'Modules', set_modules_hint: 'Turn panel features on and off. A tab with no features hides itself.',
    th_accent: 'Accent', th_bg: 'Background', th_card: 'Elements', th_txt: 'Text', th_reset: 'Reset colors', wcol_hint: 'Tile color / group', grp_del: 'Delete group', grp_eject: 'Remove from group',
    edit_add_color: '+ Add new color', update: 'Update',
    dd_words: 'Words', dd_lines: 'Lines', dd_chars: 'Characters',
    t_layout_on: 'Layout mode: drag blocks, resize via the green corner',
    t_layout_off: 'Layout saved', t_size_reset: 'Size reset',
    t_anchor: 'Anchor point moved', t_null: 'Null added', t_null_primary: 'Primary added',
    t_limb: 'Limb created', t_elastic: 'Elastic applied to {0} prop.', t_bounce: 'Bounce applied to {0} prop.',
    w_sorttool: 'Sort', w_sortset: 'Sort Settings', t_sort: 'Sorted: {0} · removed: {1}', t_sortsaved: 'Sort settings saved',
    t_noprops: 'Select properties in the timeline (P, S, R, T…)',
    t_unprecomp: 'Precomps unpacked: ', t_dup: 'Duplicated: {0} · precomps independent', t_dup_repl: 'Replaced with independent copy: {0}', t_fit: 'Fitted to comp length · precomps: {0}', t_up4k: '4K copy created: {0} · original untouched', t_stagger: 'Layers shifted: {0}', t_stag_playhead: 'Layers aligned to playhead: {0}', t_stag_reverse: 'Stacking reversed · layers: {0}', t_nosel_layers: 'Select layers on the timeline first', t_applied: 'Applied to {0} key pair(s)',
    t_added: '“{0}” added to “{1}”', t_already: '“{0}” is already on this page',
    t_removed: '“{0}” removed from this tab', t_pinned: '“{0}” is pinned to this tab',
    t_copied: '{0} copied', t_no_colors: 'Palette has no colors',
    t_pal_removed: 'Palette removed', t_pal_dup: 'Duplicate created', t_pal_upd: 'Palette updated',
    t_imported: 'Null “{0}” added to the timeline',
    t_saved: '“{0}” saved', t_loaded: '“{0}” loaded', t_need_name: 'Enter a graph name',
    t_browser: 'Browser mode — AE is not connected', t_done: 'Done',
    t_split: 'Text split: {0} layers', t_shapes: 'Text converted to shapes',
    t_theme_reset: 'Colors reset',
    t_color_applied: 'Color applied to {0} layer(s)',
    t_color_applied_stroke: 'Stroke color applied to {0} layer(s)',
    t_no_stroke: 'Selected layers have no stroke',
    sw_title: 'Click — fill • Shift — stroke • Alt — copy • RMB — replace • drag — reorder',
    sw_del: 'Delete colour',
    pal_rename_hint: 'Click to rename',
    t_sort_manual: 'Sort: manual', t_sort_name: 'Sort: by name', t_sort_new: 'Sort: newest first',
    t_size: 'Card size: {0}',
    tip_sort: 'Sorting|Manual (drag cards) → by name → newest first.',
    tip_size: 'Size|Card size: S → M → L.',
    tip_pedit: 'Rename|Change the graph name.',
    tip_layout: 'Layout|Toggles editing: drag tabs and panels, resize via the green corner. Double-click the corner to reset size.',
    tip_settings: 'Settings|Panel language and colors.',
    tip_dots: 'Preview|Dot density shows where the animation slows down (denser) and speeds up (sparser). Click for a simplified playback.',
    tip_apply: 'Apply|Puts the current easing on selected adjacent keyframes in the active comp.',
    tip_savepreset: 'Save graph|Adds the current curve to the active library — appears at the bottom, rename it later.',
    tip_anchor: 'Anchor Point|Click moves the anchor of selected layers to the chosen spot — no visual shift.',
    tip_null: 'Add Null|Click — one shared Null for all selected layers (center, combined duration, parenting). Shift — a separate Null per layer. If only nulls are selected — a yellow Primary on top. Alt — classic Null.',
    tip_unprecomp: 'Unprecomp|Moves all layers out of the selected precomp into the current comp (order, timing and transform preserved) and deletes the precomp.',
    tip_dup: 'Duplicate|Duplicates the SELECTED timeline layer (copy goes right above it). If its source is a precomp, that precomp and all nested precomps are copied independently — edits to the duplicate don’t affect the original. Hold Shift to replace the layer’s own source with the independent precomp copy in place (no new layer).',
    tip_fit: 'Fit to Comp|Stretches the SELECTED precomp and ALL nested ones to the current comp length. Plain click — extends layer timing (precomp and layer durations stretch to the comp end), but KEYFRAMES stay put — the animation is not retimed. Shift+click — stretches contents too: layers and keyframes scale proportionally. Note: this edits the SOURCE precomps — changes appear in every copy.',
    tip_split: 'Split|Splits the selected text layer into separate layers using the mode on the right.',
    tip_ddbtn: 'Split mode|Words, Lines or Characters.',
    tip_t2s: 'Text → Shapes|Converts the selected text layer into a shape layer (Create Shapes from Text).',
    tip_addtile: 'Add tool|Opens the tool library — the chosen one is added to the current page.',
    tip_miniplus: 'New slot|Adds one more “+” square for a color.',
    tip_palmenu: 'Palette menu|Import — a Null with colors on the timeline, Remove, Duplicate, Edit.',
    tip_speed: 'Speed|Speed graph: drag the curve — horizontal is influence, vertical is speed.',
    tip_value: 'Value|Value graph with axes: same cubic easing as Cubic.',
    tip_cubic: 'Cubic|Classic cubic-bezier: drag the orange and blue points.'
  }
};
var lang = store.get('lang', 'ru');
function t(k) {
  var d = LANGS[lang] || LANGS.ru;
  var v = d[k] !== undefined ? d[k] : LANGS.ru[k];
  if (v === undefined) v = k;
  for (var i = 1; i < arguments.length; i++) v = v.replace('{' + (i - 1) + '}', arguments[i]);
  return v;
}

/* ============================================================
   ТЕМА (пользовательские цвета)
============================================================ */
var THEME_DEF = { accent: '#4F8DF7', bg: '#161616', card: '#232323', txt: '#D7D7D7' };
var theme = store.get('theme', JSON.parse(JSON.stringify(THEME_DEF)));

function shadeHex(hex, amt) {
  var rgb = hexToRgb(hex.replace('#', '')) || [30, 30, 30];
  function c(v) { return Math.max(0, Math.min(255, Math.round(v + amt))); }
  return '#' + rgbToHex(c(rgb[0]), c(rgb[1]), c(rgb[2]));
}
function hexToRgba(hex, a) {
  var rgb = hexToRgb(hex.replace('#', '')) || [79, 141, 247];
  return 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + a + ')';
}
function applyTheme() {
  var r = document.documentElement.style;
  r.setProperty('--accent', theme.accent);
  r.setProperty('--h-in', theme.accent);
  r.setProperty('--accent-soft', hexToRgba(theme.accent, 0.26));
  r.setProperty('--accent-soft-h', hexToRgba(theme.accent, 0.38));
  r.setProperty('--bg', theme.bg);
  r.setProperty('--bg-soft', shadeHex(theme.bg, 8));
  r.setProperty('--bg-card', theme.card);
  r.setProperty('--bg-raise', shadeHex(theme.card, 10));
  r.setProperty('--bg-inner', shadeHex(theme.card, -6));
  r.setProperty('--bg-cell', shadeHex(theme.card, 4));
  r.setProperty('--line', shadeHex(theme.card, 16));
  var txt = theme.txt || THEME_DEF.txt;
  r.setProperty('--txt', txt);
  r.setProperty('--txt-dim', hexToRgba(txt, 0.6));
  $$('.theme-row').forEach(function (row) {
    $('.th-chip', row).style.background = theme[row.dataset.th];
  });
}

function handleHostResult(res, okMsg) {
  if (res === 'browser') { toast(t('t_browser')); return false; }
  if (res && res.indexOf('err:') === 0) { toast(res.slice(4)); return false; }
  if (okMsg) toast(okMsg);
  return true;
}

function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

/* ============================================================
   ЦВЕТ: конвертации HSB/RGB/HEX
============================================================ */
function hsbToRgb(h, s, v) {
  s /= 100; v /= 100;
  var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r, g, b;
  if (h < 60)       { r = c; g = x; b = 0; }
  else if (h < 120) { r = x; g = c; b = 0; }
  else if (h < 180) { r = 0; g = c; b = x; }
  else if (h < 240) { r = 0; g = x; b = c; }
  else if (h < 300) { r = x; g = 0; b = c; }
  else              { r = c; g = 0; b = x; }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
function rgbToHsb(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
  if (d) {
    if (mx === r) h = 60 * (((g - b) / d) % 6);
    else if (mx === g) h = 60 * ((b - r) / d + 2);
    else h = 60 * ((r - g) / d + 4);
  }
  if (h < 0) h += 360;
  return [Math.round(h), Math.round(mx ? d / mx * 100 : 0), Math.round(mx * 100)];
}
function rgbToHex(r, g, b) {
  function p(n) { n = Math.max(0, Math.min(255, Math.round(n))).toString(16); return n.length < 2 ? '0' + n : n; }
  return (p(r) + p(g) + p(b)).toUpperCase();
}
function hexToRgb(hex) {
  hex = String(hex).replace('#', '');
  if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null;
  return [parseInt(hex.slice(0, 2), 16), parseInt(hex.slice(2, 4), 16), parseInt(hex.slice(4, 6), 16)];
}

/* ============================================================
   COLOR PICKER (стиль нативного AE)
============================================================ */
var picker = (function () {
  var ov = $('#pickerOverlay');
  var sbArea = $('#sbArea'), sbCursor = $('#sbCursor');
  var hueStrip = $('#hueStrip'), hueCursor = $('#hueCursor');
  var preview = $('#pickPreview');
  var fH = $('#fH'), fS = $('#fS'), fB = $('#fB');
  var fR = $('#fR'), fG = $('#fG'), fB2 = $('#fB2'), fHex = $('#fHex');

  var st = { h: 32, s: 45, b: 50 };
  var cb = null;

  function render(skipInputs) {
    var rgb = hsbToRgb(st.h, st.s, st.b);
    var hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
    sbArea.style.background = 'hsl(' + st.h + ',100%,50%)';
    sbCursor.style.left = st.s + '%';
    sbCursor.style.top = (100 - st.b) + '%';
    hueCursor.style.top = (st.h / 360 * 100) + '%';
    preview.style.background = '#' + hex;
    if (!skipInputs) {
      fH.value = Math.round(st.h); fS.value = Math.round(st.s); fB.value = Math.round(st.b);
      fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
      fHex.value = hex;
    }
  }

  function drag(el, onMove) {
    el.addEventListener('mousedown', function (e) {
      e.preventDefault();
      onMove(e);
      function mm(ev) { onMove(ev); }
      function mu() {
        window.removeEventListener('mousemove', mm);
        window.removeEventListener('mouseup', mu);
      }
      window.addEventListener('mousemove', mm);
      window.addEventListener('mouseup', mu);
    });
  }

  drag(sbArea, function (e) {
    var r = sbArea.getBoundingClientRect();
    st.s = Math.max(0, Math.min(100, (e.clientX - r.left) / r.width * 100));
    st.b = Math.max(0, Math.min(100, 100 - (e.clientY - r.top) / r.height * 100));
    render();
  });
  drag(hueStrip, function (e) {
    var r = hueStrip.getBoundingClientRect();
    st.h = Math.max(0, Math.min(359.9, (e.clientY - r.top) / r.height * 360));
    render();
  });

  function fromHsbInputs() {
    st.h = Math.max(0, Math.min(360, +fH.value || 0));
    st.s = Math.max(0, Math.min(100, +fS.value || 0));
    st.b = Math.max(0, Math.min(100, +fB.value || 0));
    render(true);
    var rgb = hsbToRgb(st.h, st.s, st.b);
    fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
    fHex.value = rgbToHex(rgb[0], rgb[1], rgb[2]);
  }
  function fromRgbInputs() {
    var r = Math.max(0, Math.min(255, +fR.value || 0));
    var g = Math.max(0, Math.min(255, +fG.value || 0));
    var b = Math.max(0, Math.min(255, +fB2.value || 0));
    var hsb = rgbToHsb(r, g, b);
    st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
    render(true);
    fHex.value = rgbToHex(r, g, b);
  }
  function fromHexInput() {
    var rgb = hexToRgb(fHex.value);
    if (!rgb) return;
    var hsb = rgbToHsb(rgb[0], rgb[1], rgb[2]);
    st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
    render(true);
    fR.value = rgb[0]; fG.value = rgb[1]; fB2.value = rgb[2];
    fH.value = hsb[0]; fS.value = hsb[1]; fB.value = hsb[2];
  }

  [fH, fS, fB].forEach(function (i) { i.addEventListener('input', fromHsbInputs); });
  [fR, fG, fB2].forEach(function (i) { i.addEventListener('input', fromRgbInputs); });
  fHex.addEventListener('input', fromHexInput);
  fHex.addEventListener('keydown', function (e) { if (e.key === 'Enter') ok(); });

  function ok() {
    var rgb = hsbToRgb(st.h, st.s, st.b);
    var hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
    ov.hidden = true;
    if (cb) cb(hex);
    cb = null;
  }
  $('#pickOk').addEventListener('click', ok);
  $('#pickCancel').addEventListener('click', function () { ov.hidden = true; cb = null; });

  /* пипетка: в AE — нативная пипетка AE ($.colorPicker, надёжно во всех CEP);
     в обычном браузере — EyeDropper API, если доступен */
  var ed = $('#eyedropBtn');
  ed.addEventListener('click', function () {
    if (cs.isCEP()) {
      cs.evalScript('MP_eyedropper()', function (resp) {
        if (resp && resp !== 'cancel' && resp !== 'browser' && /^[0-9A-Fa-f]{6}$/.test(resp)) {
          fHex.value = resp.toUpperCase();
          fromHexInput();
        }
      });
    } else if (window.EyeDropper) {
      new EyeDropper().open().then(function (res) {
        fHex.value = res.sRGBHex.replace('#', '').toUpperCase();
        fromHexInput();
      }).catch(function () {});
    } else {
      toast('Пипетка недоступна в этой среде');
    }
  });

  return {
    open: function (startHex, callback) {
      cb = callback;
      var rgb = hexToRgb(startHex || '7F6446') || [127, 100, 70];
      var hsb = rgbToHsb(rgb[0], rgb[1], rgb[2]);
      st.h = hsb[0]; st.s = hsb[1]; st.b = hsb[2];
      render();
      ov.hidden = false;
    }
  };
})();

/* ============================================================
   ВНЕШНЕЕ ОКНО ПИКЕРА (modeless-расширение)
   В AE открываем отдельное плавающее окно (picker.html) — оно НЕ внутри панели.
   Связь в обе стороны двумя независимыми каналами (что-нибудь да сработает):
     • CEP-события  mp.picker.open / mp.picker.result
     • мейлбокс в общем ExtendScript-движке: $.global.MP_pickStart / MP_pickResult
   В браузере (отладка) — фолбэк на встроенный HTML-пикер выше.
============================================================ */
var PICKER_EXT_ID = 'com.motionpanel.base.picker';
var _pickPending = null;   // {cb, done}
var _pickPoll = null;

function _stopPickPoll() { if (_pickPoll) { clearInterval(_pickPoll); _pickPoll = null; } }

function _resolvePick(v) {
  if (!_pickPending || _pickPending.done) return;
  v = (v == null) ? '' : String(v);
  if (v === 'cancel') { _pickPending.done = true; _pickPending = null; _stopPickPoll(); if (cs.isCEP()) cs.evalScript('$.global.MP_pickResult=""', function () {}); return; }
  if (!/^[0-9A-Fa-f]{6}$/.test(v)) return;          // ещё нет результата / "undefined" / "browser"
  _pickPending.done = true;
  var cb = _pickPending.cb;
  _pickPending = null;
  _stopPickPoll();
  if (cs.isCEP()) cs.evalScript('$.global.MP_pickResult=""', function () {});
  cb(v.toUpperCase());
}

if (cs.isCEP()) {
  cs.addEventListener('mp.picker.result', function (ev) {
    _resolvePick(ev && ev.data !== undefined ? ev.data : '');
  });
}

function openColorPicker(startHex, cb) {
  if (!cs.isCEP()) { picker.open(startHex, cb); return; }   // браузерный фолбэк
  var start = (startHex || '').replace('#', '');
  _pickPending = { cb: cb, done: false };
  _stopPickPoll();
  // 1) чистим прошлый результат и кладём старт; 2) ТОЛЬКО ПОТОМ открываем окно, шлём событие
  //    и запускаем опрос — иначе опрос мог бы подхватить устаревший результат предыдущего выбора.
  cs.evalScript('$.global.MP_pickResult=""; $.global.MP_pickStart="' + start + '";', function () {
    cs.requestOpenExtension(PICKER_EXT_ID, '');
    cs.dispatchEvent('mp.picker.open', start);   // если окно уже живо — подхватит мгновенно
    // авто-«второй клик» на передний план — но ТОЛЬКО если выбор ещё ждётся
    // (иначе при быстром закрытии окно открывалось бы заново → дёрганье CEP и зависание AE)
    setTimeout(function () {
      if (_pickPending && !_pickPending.done) cs.requestOpenExtension(PICKER_EXT_ID, '');
    }, 320);
    var ticks = 0;
    _pickPoll = setInterval(function () {
      ticks++;
      if (!_pickPending || _pickPending.done || ticks > 240) { _stopPickPoll(); return; }
      cs.evalScript('String($.global.MP_pickResult)', function (v) { _resolvePick(v); });
    }, 300);
  });
}

/* ============================================================
   ВКЛАДКИ
============================================================ */
$$('.tab').forEach(function (tab) {
  tab.addEventListener('click', function () {
    if (document.body.classList.contains('editing')) return;
    $$('.tab').forEach(function (t) { t.classList.remove('active'); });
    tab.classList.add('active');
    $$('.page').forEach(function (p) {
      p.classList.toggle('active', p.dataset.page === tab.dataset.tab);
    });
    renderBoards(); // общий элемент уезжает на активную вкладку
    if (typeof fitSquares === 'function') fitSquares();
    if (typeof applyPalSize === 'function') requestAnimationFrame(applyPalSize);  // гарантируем высоту свотчей после раскладки
  });
});

/* переключение вкладок колёсиком мыши (по видимым вкладкам) */
(function () {
  var tabsEl = $('#tabs');
  if (!tabsEl) return;
  tabsEl.addEventListener('wheel', function (e) {
    if (document.body.classList.contains('editing')) return;
    var vis = $$('.tab', tabsEl).filter(function (t) { return t.offsetParent !== null; });
    if (vis.length < 2) return;
    e.preventDefault();
    var cur = 0;
    for (var i = 0; i < vis.length; i++) { if (vis[i].classList.contains('active')) { cur = i; break; } }
    var dir = e.deltaY > 0 ? 1 : -1;
    var next = cur + dir;
    if (next < 0 || next >= vis.length) return;          // упёрлись в край списка — стоим, без закольцовки
    if (typeof activateTab === 'function') activateTab(vis[next]);
  }, { passive: false });
})();

/* ============================================================
   НАСТРОЙКИ
============================================================ */
var settingsBtn = $('#settingsBtn'), settingsPop = $('#settingsPop');
settingsBtn.addEventListener('click', function (e) {
  e.stopPropagation();
  settingsPop.hidden = !settingsPop.hidden;
  if (!settingsPop.hidden) {                       // открыли — показать накопленный лог
    var box = document.getElementById('logBox');
    if (box) { box.textContent = MP_LOG.join('\n'); box.scrollTop = box.scrollHeight; }
  }
});
(function () {
  var c = document.getElementById('logCopy'), cl = document.getElementById('logClear');
  if (c) c.addEventListener('click', function () {
    var txt = MP_LOG.join('\n');
    var ta = document.createElement('textarea');
    ta.value = txt;
    ta.style.position = 'fixed'; ta.style.left = '-9999px'; ta.style.top = '0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    toast(ok ? 'Лог скопирован' : 'Не вышло — выдели текст в окне вручную и Ctrl+C');
  });
  if (cl) cl.addEventListener('click', function () {
    MP_LOG = []; var box = document.getElementById('logBox'); if (box) box.textContent = '';
  });
})();
settingsPop.addEventListener('click', function (e) {     // клик по затемнённому фону — закрыть
  if (e.target === settingsPop) settingsPop.hidden = true;
});
(function () { var sc = $('#setClose'); if (sc) sc.addEventListener('click', function () { settingsPop.hidden = true; }); })();
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !settingsPop.hidden) settingsPop.hidden = true; });

var layoutBtn = $('#layoutBtn');
var addGroupBtn = $('#addGroupBtn');
layoutBtn.addEventListener('click', function () {
  var on = !document.body.classList.contains('editing');
  document.body.classList.toggle('editing', on);
  layoutBtn.classList.toggle('on', on);
  setDraggable(on);
  toast(on ? t('t_layout_on') : t('t_layout_off'));
});
if (addGroupBtn) addGroupBtn.addEventListener('click', function () {
  // группу можно создать без «карандаша» — режим раскладки включится сам
  if (!document.body.classList.contains('editing')) {
    document.body.classList.add('editing');
    layoutBtn.classList.add('on');
    setDraggable(true);
  }
  var page = $('.page.active') ? $('.page.active').dataset.page : 'home';
  var gs = groupsFor(page);
  var n = 1; gs.forEach(function (g) { var m = /^группа\s+(\d+)$/i.exec(g.name || ''); if (m && +m[1] >= n) n = +m[1] + 1; });
  var board = $('.board[data-board="' + page + '"]'), y = 0;
  if (board) {
    for (var i = 0; i < board.children.length; i++) {
      var c = board.children[i];
      if (c.classList && (c.classList.contains('widget') || c.classList.contains('group-box'))) {
        var b = c.offsetTop + c.offsetHeight; if (b > y) y = b;
      }
    }
    y = y ? y + 10 : 0;
  }
  gs.push({ gid: 'g' + Date.now(), name: 'группа ' + n, color: '', members: [], collapsed: false, x: 0, y: y, w: 40 });
  saveGroups();
  renderBoards();
});



/* ============================================================
   ДОСКИ: реестр виджетов, рендер, плюс-плитка, окно добавления
============================================================ */
var WIDGETS = {
  anchor:    { cat: 'cat_main',  w: 100 },
  nulltool:  { cat: 'cat_main',  w: 30 },
  unprecomp: { cat: 'cat_main',  w: 30 },
  dupcomp:   { cat: 'cat_main',  w: 30 },
  fitcomp:   { cat: 'cat_main',  w: 30 },
  upscale4k: { cat: 'cat_main',  w: 30 },
  sorttool:  { cat: 'cat_main',  w: 45 },
  addlimb:   { cat: 'cat_main',  w: 30 },
  elastic:   { cat: 'cat_anim',  w: 30 },
  bounce:    { cat: 'cat_anim',  w: 30 },
  texttools: { cat: 'cat_main',  w: 100 },
  stagger:   { cat: 'cat_anim',  w: 40 },
  palettes:  { cat: 'cat_color', w: 100 },
  palextract:{ cat: 'cat_color', w: 100 },
  bezier:    { cat: 'cat_anim',  w: 100 }
};
function wName(id) { return t('w_' + id); }

var DEFAULT_BOARDS = { home: ['anchor', 'nulltool', 'unprecomp', 'dupcomp', 'fitcomp', 'upscale4k', 'sorttool', 'addlimb', 'elastic', 'bounce', 'texttools', 'stagger'], palettes: ['palettes', 'palextract'], graph: ['bezier'] };
/* родная вкладка каждого элемента — там он закреплён намертво */
var NATIVE = { anchor: 'home', nulltool: 'home', unprecomp: 'home', dupcomp: 'home', fitcomp: 'home', upscale4k: 'home', sorttool: 'home', addlimb: 'home', elastic: 'home', bounce: 'home', texttools: 'home', stagger: 'home', palettes: 'palettes', palextract: 'palettes', bezier: 'graph' };

/* ===== БАЗОВАЯ РАСКЛАДКА (как на скрине): применяется новым воркспейсам и при первом запуске ===== */
var DEFAULT_LAYOUT = {
  boards: { home: ['anchor', 'nulltool', 'unprecomp', 'dupcomp', 'fitcomp', 'upscale4k', 'sorttool', 'addlimb', 'elastic', 'bounce', 'texttools', 'stagger'], palettes: ['palettes', 'palextract'], graph: ['bezier'] },
  widgetPos: { home: {
    anchor:    { x: 1,  y: 4 },
    nulltool:  { x: 40, y: 118 },
    addlimb:   { x: 59, y: 118 },
    texttools: { x: 1,  y: 320 },
    stagger:   { x: 1,  y: 388 }
  } },
  widgetSizes: { 'home::anchor': 38, 'home::nulltool': 16, 'home::addlimb': 17, 'home::texttools': 97, 'home::stagger': 40 },
  widgetColors: {
    dupcomp: '#3FB6C4', unprecomp: '#3FB6C4', fitcomp: '#3FB6C4', upscale4k: '#3FB6C4',
    nulltool: '#A877E6', addlimb: '#46C28E',
    bounce: '#E8A23D', elastic: '#E8A23D',
    texttools: '#E6584D'
  },
  boardGroups: { home: [
    { gid: 'gcomp', name: 'Comp', color: '#3FB6C4', members: ['dupcomp', 'unprecomp', 'fitcomp', 'upscale4k'], collapsed: false, x: 39, y: 4,   w: 60, autosize: true },
    { gid: 'ganim', name: 'Animation', color: '#E8A23D', members: ['bounce', 'elastic'], collapsed: false, x: 1,  y: 190, w: 37, autosize: true }
  ] }
};
/* записать базовую раскладку в стор указанного воркспейса */
function seedLayoutInto(wsId, lay) {
  function put(k, v) { try { localStorage.setItem('mp_ws_' + wsId + '_' + k, JSON.stringify(v)); } catch (e) {} }
  put('boards', lay.boards); put('widgetPos', lay.widgetPos); put('widgetSizes', lay.widgetSizes);
  put('widgetColors', lay.widgetColors); put('boardGroups', lay.boardGroups);
}
/* первый запуск с чистого листа (нет ни старых данных, ни данных воркспейса) — засеять базовую раскладку */
if (localStorage.getItem('mp_ws_' + activeWs + '_boards') === null) {
  seedLayoutInto(activeWs, DEFAULT_LAYOUT);
}

var boards = store.get('boards', null) || JSON.parse(JSON.stringify(DEFAULT_BOARDS));
// добавляем новые вкладки/закреплённые виджеты, которых не было в сохранённой раскладке (апгрейд)
Object.keys(DEFAULT_BOARDS).forEach(function (pg) { if (!boards[pg]) boards[pg] = DEFAULT_BOARDS[pg].slice(); });
Object.keys(NATIVE).forEach(function (id) {
  var here = false;
  for (var b in boards) if (boards[b].indexOf(id) !== -1) { here = true; break; }
  if (!here) { var pg = NATIVE[id]; boards[pg] = boards[pg] || []; boards[pg].push(id); }
});
// устаревший виджет sortset слит в объединённый sorttool — убираем его из раскладки
for (var _sb in boards) { if (boards[_sb] instanceof Array) { var _si = boards[_sb].indexOf('sortset'); while (_si !== -1) { boards[_sb].splice(_si, 1); _si = boards[_sb].indexOf('sortset'); } } }
// вкладка Expression переведена на собственный список — убираем старый виджет exprtools и его доску
for (var _eb in boards) { if (boards[_eb] instanceof Array) { var _ei = boards[_eb].indexOf('exprtools'); while (_ei !== -1) { boards[_eb].splice(_ei, 1); _ei = boards[_eb].indexOf('exprtools'); } } }
if (boards.expr) delete boards.expr;

/* ===== МОДУЛИ (конструктор функций): включение/выключение функционала ===== */
var modulesOff = store.get('modulesOff', []);          // id выключенных модулей
function isModOff(id) { return modulesOff.indexOf(id) !== -1; }
function saveMods() { store.set('modulesOff', modulesOff); }
function setModule(id, on) {
  var i = modulesOff.indexOf(id);
  if (on && i !== -1) modulesOff.splice(i, 1);
  else if (!on && i === -1) modulesOff.push(id);
  saveMods();
}
/* есть ли у вкладки хоть один включённый модуль (иначе вкладку прячем) */
function tabHasModules(tab) {
  if (tab === 'text') return true;   // текстовая вкладка — всегда видима (не модульная)
  if (tab === 'expr') return true;   // вкладка Expression — собственный список, не модульная
  var ids = Object.keys(WIDGETS);
  for (var i = 0; i < ids.length; i++) {
    var id = ids[i];
    if (isModOff(id)) continue;
    if (NATIVE[id] === tab) return true;
    if ((boards[tab] || []).indexOf(id) !== -1) return true;
  }
  return false;
}
function activateTab(tabEl) {
  if (!tabEl) return;
  $$('.tab').forEach(function (t) { t.classList.remove('active'); });
  tabEl.classList.add('active');
  var tb = tabEl.dataset.tab;
  $$('.page').forEach(function (p) { p.classList.toggle('active', p.dataset.page === tb); });
  renderBoards();
  if (typeof fitSquares === 'function') fitSquares();
  if (typeof applyPalSize === 'function') requestAnimationFrame(applyPalSize);
}
function applyModuleVisibility() {
  $$('.tab').forEach(function (tab) {
    var show = tabHasModules(tab.dataset.tab);
    tab.classList.toggle('mod-hidden', !show);
    var pg = $('.page[data-page="' + tab.dataset.tab + '"]');
    if (pg) pg.classList.toggle('mod-hidden', !show);
  });
  var active = $('.tab.active');
  if (!active || active.classList.contains('mod-hidden')) {   // активная вкладка спряталась — уходим на первую видимую
    var vis = $$('.tab').filter(function (t) { return !t.classList.contains('mod-hidden'); });
    if (vis[0]) activateTab(vis[0]);
  }
}
/* список включения/выключения функций в настройках (сгруппирован по вкладкам) */
function renderModuleList() {
  var box = $('#moduleList');
  if (!box) return;
  box.innerHTML = '';
  var TAB_ORDER = ['home', 'palettes', 'graph', 'expr', 'text'];
  var byTab = {};
  Object.keys(WIDGETS).forEach(function (id) {
    var tab = NATIVE[id] || 'home';
    (byTab[tab] = byTab[tab] || []).push(id);
  });
  var order = TAB_ORDER.filter(function (t) { return byTab[t]; });
  Object.keys(byTab).forEach(function (t) { if (order.indexOf(t) === -1) order.push(t); });
  order.forEach(function (tab) {
    var grp = document.createElement('div'); grp.className = 'mod-group';
    var gh = document.createElement('div'); gh.className = 'mod-group-head'; gh.textContent = pageTitle(tab);
    grp.appendChild(gh);
    byTab[tab].forEach(function (id) {
      var row = document.createElement('label'); row.className = 'mod-row';
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !isModOff(id);
      cb.addEventListener('change', function () {
        setModule(id, cb.checked);
        renderBoards();
        applyModuleVisibility();
      });
      var nm = document.createElement('span'); nm.className = 'mod-name'; nm.textContent = wName(id);
      row.appendChild(cb); row.appendChild(nm);
      grp.appendChild(row);
    });
    box.appendChild(grp);
  });
}

/* ===== ВОРКСПЕЙСЫ: переключение, создание, переименование, удаление ===== */
function curWs() { for (var i = 0; i < workspaces.length; i++) if (workspaces[i].id === activeWs) return workspaces[i]; return null; }
function saveWs() { store.set('workspaces', workspaces); }
/* перечитать все per-ws переменные из стора (уже под текущим activeWs) */
function loadWorkspaceVars() {
  boards = store.get('boards', null) || JSON.parse(JSON.stringify(DEFAULT_BOARDS));
  Object.keys(DEFAULT_BOARDS).forEach(function (b) { if (!boards[b] || !(boards[b] instanceof Array)) boards[b] = DEFAULT_BOARDS[b].slice(); });
  Object.keys(NATIVE).forEach(function (id) { var home = NATIVE[id]; if (boards[home].indexOf(id) === -1) boards[home].push(id); });
  Object.keys(boards).forEach(function (b) { boards[b] = boards[b].filter(function (id) { return !!WIDGETS[id]; }); });
  widgetPos = store.get('widgetPos', {});
  widgetSizes = store.get('widgetSizes', {});
  widgetHeights = store.get('widgetHeights', {});
  boardGroups = store.get('boardGroups', {});
  widgetColors = store.get('widgetColors', {});
  modulesOff = store.get('modulesOff', []);
  paletteSizes = store.get('paletteSizes', null) || {};
  flowOrder = store.get('flowOrder', {});
}
function switchWorkspace(id) {
  if (!id || id === activeWs) { renderWsSwitcher(); return; }
  activeWs = id; store.set('activeWs', id);
  loadWorkspaceVars();
  $$('.tab').forEach(function (t) { t.classList.remove('active'); });
  $$('.page').forEach(function (p) { p.classList.remove('active'); });
  var firstTab = $('.tab[data-tab="home"]') || $$('.tab')[0];
  if (firstTab) { firstTab.classList.add('active'); var pg = $('.page[data-page="' + firstTab.dataset.tab + '"]'); if (pg) pg.classList.add('active'); }
  applyTabOrder();
  renderBoards();
  applyModuleVisibility();
  renderPalettes();
  renderModuleList();
  renderWsSwitcher();
  if (typeof fitSquares === 'function') fitSquares();
}
function addWorkspace() {
  var id = 'ws' + Date.now();
  var snap = store.get('defaultLayout', null);   // сохранённая пользователем эталонная раскладка
  if (snap && typeof snap === 'object') {
    for (var k in snap) { if (WS_KEYS[k]) { try { localStorage.setItem('mp_ws_' + id + '_' + k, JSON.stringify(snap[k])); } catch (e) {} } }
  } else if (workspaces[0]) {
    // нет сохранённой — копируем Workspace 1 (твою текущую раскладку 1:1)
    var baseId = workspaces[0].id;
    var any = false;
    for (var k2 in WS_KEYS) {
      var raw = null; try { raw = localStorage.getItem('mp_ws_' + baseId + '_' + k2); } catch (e2) {}
      if (raw !== null) { any = true; try { localStorage.setItem('mp_ws_' + id + '_' + k2, raw); } catch (e3) {} }
    }
    if (!any) seedLayoutInto(id, DEFAULT_LAYOUT);   // совсем пусто — берём встроенную
  } else {
    seedLayoutInto(id, DEFAULT_LAYOUT);
  }
  workspaces.push({ id: id, name: 'Workspace ' + (workspaces.length + 1) });
  saveWs();
  switchWorkspace(id);   // дальше настраивается независимо
}
/* запомнить текущую раскладку как стартовую для новых воркспейсов */
function saveAsDefaultLayout() {
  var snap = {};
  for (var k in WS_KEYS) { var v = store.get(k, null); if (v !== null) snap[k] = v; }   // читает текущий воркспейс
  store.set('defaultLayout', snap);   // глобальный ключ (не привязан к воркспейсу)
  toast(t('ws_saved_default'));
}
function deleteWorkspace(id) {
  if (workspaces.length <= 1) return;       // последний не удаляем
  for (var k in WS_KEYS) { try { localStorage.removeItem('mp_ws_' + id + '_' + k); } catch (e) {} }
  workspaces = workspaces.filter(function (w) { return w.id !== id; });
  saveWs();
  if (activeWs === id) switchWorkspace(workspaces[0].id);
  else renderWsSwitcher();
}
function renderWsSwitcher() {
  var nm = $('#wsName'); if (nm) nm.textContent = (curWs() ? curWs().name : 'Workspace');
  var menu = $('#wsMenu'); if (!menu) return;
  menu.innerHTML = '';
  workspaces.forEach(function (w) {
    var row = document.createElement('div'); row.className = 'ws-item' + (w.id === activeWs ? ' active' : '');
    var pick = document.createElement('button'); pick.className = 'ws-pick'; pick.textContent = w.name;
    pick.addEventListener('click', function () { menu.hidden = true; switchWorkspace(w.id); });
    var ren = document.createElement('button'); ren.className = 'ws-mini'; ren.innerHTML = '&#9998;'; ren.title = t('ws_rename');
    ren.addEventListener('click', function (e) {
      e.stopPropagation();
      var inp = document.createElement('input'); inp.className = 'ws-rename-input'; inp.value = w.name; inp.maxLength = 24;
      pick.replaceWith(inp); inp.focus(); inp.select();
      function commit() { var v = inp.value.trim(); if (v) w.name = v; saveWs(); renderWsSwitcher(); }
      inp.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') commit(); if (ev.key === 'Escape') renderWsSwitcher(); });
      inp.addEventListener('blur', commit);
      inp.addEventListener('click', function (ev) { ev.stopPropagation(); });
    });
    var del = document.createElement('button'); del.className = 'ws-mini del'; del.innerHTML = '&#10005;'; del.title = t('ws_del');
    del.addEventListener('click', function (e) { e.stopPropagation(); deleteWorkspace(w.id); });
    row.appendChild(pick); row.appendChild(ren);
    if (workspaces.length > 1) row.appendChild(del);
    menu.appendChild(row);
  });
  var add = document.createElement('button'); add.className = 'ws-add'; add.textContent = t('ws_new');
  add.addEventListener('click', function () { menu.hidden = true; addWorkspace(); });
  menu.appendChild(add);
  var save = document.createElement('button'); save.className = 'ws-add ws-savedef'; save.textContent = t('ws_save_default');
  save.title = t('ws_save_default_hint');
  save.addEventListener('click', function () { menu.hidden = true; saveAsDefaultLayout(); });
  menu.appendChild(save);
}
(function () {
  var btn = $('#wsCurrentBtn'), menu = $('#wsMenu');
  if (btn && menu) {
    btn.addEventListener('click', function (e) { e.stopPropagation(); menu.hidden = !menu.hidden; });
    document.addEventListener('click', function (e) {
      if (!menu.hidden && !menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) menu.hidden = true;
    });
  }
})();

/* гарантируем структуру и закреплённые базовые элементы */
(function enforcePinned() {
  Object.keys(DEFAULT_BOARDS).forEach(function (b) {
    if (!boards[b] || !(boards[b] instanceof Array)) boards[b] = [];
  });
  Object.keys(NATIVE).forEach(function (id) {
    var home = NATIVE[id];
    if (boards[home].indexOf(id) === -1) boards[home].push(id);
  });
  // убрать устаревшие id (например бывший 'library', влитый в карточку графика)
  Object.keys(boards).forEach(function (b) {
    boards[b] = boards[b].filter(function (id) { return !!WIDGETS[id]; });
  });
})();

function saveBoards() { store.set('boards', boards); }

function widgetNode(id) { return $('.widget[data-widget="' + id + '"]'); }
function widgetLocations(id) {
  var out = [];
  for (var b in boards) if (boards[b].indexOf(id) !== -1) out.push(b);
  return out;
}
function pageTitle(b) {
  return t('page_' + b);
}

var widgetSizes = store.get('widgetSizes', {});     // {id: ширина в %}
var hideToolLabels = store.get('hideToolLabels', false);   // скрывать подписи у плиток (только иконки) — по умолчанию выкл
var widgetColors = store.get('widgetColors', {});   // {id: hex} — цвет/группа плашки
var WCOLORS = ['#4F8DF7', '#46C28E', '#E8A23D', '#E6584D', '#A877E6', '#3FB6C4', '#E673B0', '#8A8F98'];
var widgetHeights = store.get('widgetHeights', {}); // {id: высота в px}
var widgetPos = store.get('widgetPos', {});         // {board: {id: {x:%, y:px}}}

/* ---- группы-контейнеры (#1c-расширение) ---- */
var boardGroups = store.get('boardGroups', {});     // {page:[{gid,name,color,members:[id],collapsed,x:%,y:px,w:%}]}
var flowOrder = store.get('flowOrder', {});         // {page:['w:id'|'g:gid',...]} — порядок плашек/групп в потоке
function groupsFor(p) { return boardGroups[p] || (boardGroups[p] = []); }
function saveGroups() { store.set('boardGroups', boardGroups); }
function groupedSet(p) {
  var s = {};
  (boardGroups[p] || []).forEach(function (g) { (g.members || []).forEach(function (id) { s[id] = g; }); });
  return s;
}
function groupById(p, gid) {
  var gs = boardGroups[p] || [];
  for (var i = 0; i < gs.length; i++) if (gs[i].gid === gid) return gs[i];
  return null;
}
function removeFromGroups(p, id) {
  (boardGroups[p] || []).forEach(function (g) {
    var i = g.members.indexOf(id);
    if (i !== -1) { g.members.splice(i, 1); delete g.cols; }   // состав изменился — пересчитать колонки (правка 3)
  });
}
/* группа из <2 участников недопустима: распускаем (оставшегося, если есть, возвращаем на доску на место группы) */
function dissolveSmallGroups(page) {
  var gs = boardGroups[page] || [], changed = false;
  for (var i = gs.length - 1; i >= 0; i--) {
    var g = gs[i];
    var mem = (g.members || []).filter(function (id) { return WIDGETS[id]; });
    if (mem.length < 2) {
      mem.forEach(function (id) { setPos(page, id, g.x || 0, g.y || 0); });   // оставшийся — свободно на месте группы
      gs.splice(i, 1); changed = true;
    }
  }
  if (changed) { saveGroups(); store.set('widgetPos', widgetPos); }
  return changed;
}

function posOf(boardName, id) {
  return (widgetPos[boardName] || {})[id] || null;
}
function setPos(boardName, id, x, y) {
  if (!widgetPos[boardName]) widgetPos[boardName] = {};
  widgetPos[boardName][id] = { x: x, y: y };
}

/* ===== ПОТОК (flow): порядок плашек/групп на доске вместо свободных координат ===== */
/* первичное построение порядка из старой раскладки (по координатам сверху-вниз, слева-направо) */
function buildFlowOrder(page) {
  if (flowOrder[page] && flowOrder[page].length) return flowOrder[page];
  var grouped = groupedSet(page);
  var blocks = [];
  (boards[page] || []).forEach(function (id) {
    if (grouped[id] || !WIDGETS[id]) return;
    var p = posOf(page, id) || { x: 0, y: 99999 };
    blocks.push({ tok: 'w:' + id, y: (p.y || 0), x: (p.x || 0) });
  });
  (boardGroups[page] || []).forEach(function (g) {
    blocks.push({ tok: 'g:' + g.gid, y: (g.y || 0), x: (g.x || 0) });
  });
  blocks.sort(function (a, b) { return (a.y - b.y) || (a.x - b.x); });
  flowOrder[page] = blocks.map(function (b) { return b.tok; });
  store.set('flowOrder', flowOrder);
  return flowOrder[page];
}
/* чистим порядок: убираем мёртвые токены, дописываем новые свободные плашки и группы */
function reconcileFlow(page) {
  var fo = buildFlowOrder(page).slice();
  var grouped = groupedSet(page);
  fo = fo.filter(function (t) {
    if (t.indexOf('w:') === 0) { var id = t.slice(2); return !!WIDGETS[id] && !grouped[id] && (boards[page] || []).indexOf(id) !== -1; }
    if (t.indexOf('g:') === 0) { return !!groupById(page, t.slice(2)); }
    return false;
  });
  // убираем дубликаты
  var seen = {}; fo = fo.filter(function (t) { if (seen[t]) return false; seen[t] = 1; return true; });
  // дописываем недостающие свободные плашки (новые/добавленные) и группы
  (boards[page] || []).forEach(function (id) {
    if (!WIDGETS[id] || grouped[id]) return;
    if (fo.indexOf('w:' + id) === -1) fo.push('w:' + id);
  });
  (boardGroups[page] || []).forEach(function (g) {
    if (fo.indexOf('g:' + g.gid) === -1) fo.push('g:' + g.gid);
  });
  flowOrder[page] = fo; store.set('flowOrder', flowOrder);
  return fo;
}
/* пересобрать порядок доски из текущего DOM (после перетаскивания) */
function rebuildFlow(board, page) {
  var order = [];
  for (var i = 0; i < board.children.length; i++) {
    var c = board.children[i];
    if (!c.classList) continue;
    if (c.classList.contains('widget') && c.dataset.widget) order.push('w:' + c.dataset.widget);
    else if (c.classList.contains('group-box') && c.dataset.gid) order.push('g:' + c.dataset.gid);
  }
  flowOrder[page] = order; store.set('flowOrder', flowOrder);
}
/* пересобрать состав группы из DOM (после сортировки плашек внутри группы) */
function rebuildGroupMembers(body, page, gid) {
  var g = groupById(page, gid); if (!g) return;
  var ids = [];
  for (var i = 0; i < body.children.length; i++) {
    var c = body.children[i];
    if (c.classList && c.classList.contains('widget') && c.dataset.widget) ids.push(c.dataset.widget);
  }
  g.members = ids; saveGroups();
}

/* ступенчатый ресайз: снап значения к ближайшей ступени (вместо непрерывного масштаба) */
var MP_TS_STEPS = [0.6, 0.75, 0.9, 1.0, 1.1];
function MP_snapStep(v, steps) {
  var best = steps[0], bd = Math.abs(v - steps[0]);
  for (var i = 1; i < steps.length; i++) {
    var d = Math.abs(v - steps[i]);
    if (d < bd) { bd = d; best = steps[i]; }
  }
  return best;
}

/* масштабируем содержимое плитки-инструмента под её размер: иконка/подпись
   уменьшаются вместе с плиткой, ничего не обрезается; совсем мелкая — только иконка */
function scaleTool(node) {
  if (!node || !node.classList) return;
  if (node.classList.contains('in-group')) return;   // плитками в группах управляет scaleGroupBox (масштаб от ширины панели/группы через --gt на .group-box)
  var isTool = node.classList.contains('tool');
  var isScale = node.classList.contains('w-scale');
  if (!isTool && !isScale) return;
  var w = node.offsetWidth, h = node.offsetHeight;
  if (!w || !h) return;
  if (node.classList.contains('wide')) {
    // широкая составная плашка (Split/Characters) — масштаб по ширине, не схлопывается в иконку
    var tw = w / 250;
    tw = Math.max(0.5, Math.min(1.15, tw));
    tw = MP_snapStep(tw, MP_TS_STEPS);                  // ступенчато, как у мелких плиток
    node.style.setProperty('--ts', tw.toFixed(3));
    node.classList.remove('icon-only');
    return;
  }
  if (node.classList.contains('sort-w')) {
    // объединённый бар Sort (кнопка + шестерёнка): масштаб по ширине, в иконку не схлопывается
    var sb = w / 120;
    sb = Math.max(0.55, Math.min(1.2, sb));
    sb = MP_snapStep(sb, MP_TS_STEPS);
    node.style.setProperty('--ts', sb.toFixed(3));
    node.classList.remove('icon-only');
    return;
  }
  if (isScale && !isTool) {
    // компактная карточка (Sequence и любые будущие .w-scale): содержимое тянется и по ширине, И по высоте,
    // поэтому при уменьшении плашки ничего не обрезается и остаётся рабочим
    var sw = Math.min(w / 150, (h - 18) / 145);
    sw = Math.max(0.42, Math.min(1.3, sw));
    sw = MP_snapStep(sw, MP_TS_STEPS);
    node.style.setProperty('--ts', sw.toFixed(3));
    return;
  }
  // Home (free-board): размер плитки привязан к ШИРИНЕ ДОСКИ так же, как позиции (тоже %),
  // → позиции и размеры масштабируются синхронно, относительная раскладка сохраняется при любом
  // размере окна и не налезает при увеличении. Выше потолка плитки фиксируются (просто разъезжаются).
  var board = node.closest('.board');
  var bw = board ? (board.clientWidth || board.offsetWidth || 0) : 0;
  var ts;
  if (bw >= 40) {
    ts = Math.max(0.5, Math.min(1.1, bw / 460));   // ts=1.0 около 460px, потолок 1.1
  } else {
    ts = Math.max(0.4, Math.min(1.1, Math.min(w / 90, h / 70)));   // запасной путь, если ширина не замерена
  }
  ts = MP_snapStep(ts, MP_TS_STEPS);              // ступенчато, а не непрерывно
  node.style.setProperty('--ts', ts.toFixed(3));
  node.classList.toggle('icon-only', !!hideToolLabels);   // подписи скрываются только по настройке, а не сами при уменьшении
  // размер КОРОБКИ плитки тоже ступенчатый (от --ts в px), а не % от доски:
  // при ресайзе панели плитка меняет размер скачками и не схлопывается в точку.
  // Уважаем ручной размер (если пользователь тянул уголок) — тогда не трогаем.
  if (bw >= 40) {
    if (!getWVal(node)) node.style.width = Math.round(62 * ts) + 'px';
    if (!getHVal(node)) node.style.height = Math.round(50 * ts) + 'px';
  }
}

/* плитки в группах ужимаются вместе с шириной панели (как иконки в Motion 4).
   --gt ставится на доску и наследуется плитками: масштабирует и бокс (calc 66/60), и содержимое (--ts).
   Берём ширину доски (стабильна, без обратной связи через контент) → никаких дёрганий. */
/* сколько плиток в верхнем ряду группы сейчас (для фиксации числа колонок при ресайзе) */
function countCols(box) {
  var body = box && box.querySelector('.group-body');
  if (!body) return 1;
  var tiles = [];
  for (var i = 0; i < body.children.length; i++) {
    var c = body.children[i];
    if (c.classList && c.classList.contains('widget') && c.classList.contains('tool') && !c.classList.contains('wide')) tiles.push(c);
  }
  if (!tiles.length) return 1;
  var minTop = Infinity;
  tiles.forEach(function (t) { if (t.offsetTop < minTop) minTop = t.offsetTop; });
  var n = 0;
  tiles.forEach(function (t) { if (Math.abs(t.offsetTop - minTop) < 6) n++; });
  return Math.max(1, n);
}
function scaleGroupBox(box) {
  if (!box || !box.classList || !box.classList.contains('group-box')) return;
  var body = box.querySelector('.group-body');
  if (!body) return;
  var board = box.closest('.board');
  var boardW = board ? (board.clientWidth || board.offsetWidth || 0) : 0;
  if (boardW < 40) return;                              // скрытая/незамеренная вкладка — не трогаем
  var REF = 500, MIN = 0.42, GAP = 7, BASE = 66, PADB = 18, BORDER = 2;   // PADB — гориз. паддинг тела (2×9)
  var g = board ? groupById(board.dataset.board, box.dataset.gid) : null;
  // плитки-инструменты в группе
  var n = 0;
  for (var i = 0; i < body.children.length; i++) {
    var c = body.children[i];
    if (c.classList && c.classList.contains('widget') && c.classList.contains('tool') && !c.classList.contains('wide')) n++;
  }
  var s;
  if (box.classList.contains('autosize') && n > 0) {
    // АВТО-группа: при сужении панели переходит на меньшее число колонок И ужимается, оставаясь в доступной справа ширине →
    // структурируется, не вылезает за край и не налезает на соседей.
    var maxW = Math.max(BASE * 0.4, (100 - ((g && g.x) || 0)) / 100 * boardW);
    var Kmax = Math.max(1, Math.floor((maxW - PADB + GAP) / (BASE + GAP)));   // сколько колонок (полноразмерных) влезает по ширине
    var K = Math.max(1, Math.min(n, Kmax));
    s = Math.max(MIN, Math.min(1, boardW / REF));
    var wpx = s * (BASE * K + GAP * (K - 1) + PADB) + BORDER;                 // явная ширина бокса под K колонок (border-box)
    if (wpx > maxW) wpx = maxW;
    box.style.width = wpx.toFixed(1) + 'px';
  } else if (n > 0) {
    // явная ширина (после ресайза): плитки ужимаются под ширину бокса при ФИКСИРОВАННОМ числе колонок (правка 3) — не переносятся
    var inner = box.clientWidth;                        // внутренняя ширина бокса (без рамки), не зависит от --gt
    if (inner <= 1) { box.style.setProperty('--gt', '1'); return; }
    var Kf = (g && g.cols > 0) ? g.cols : countCols(box);
    Kf = Math.max(1, Math.min(Kf, n));
    s = Math.max(MIN, Math.min(1, inner / (Kf * BASE + (Kf - 1) * GAP + PADB)));
  } else {
    s = Math.max(MIN, Math.min(1, boardW / REF));       // пустая группа
  }
  box.style.setProperty('--gt', s.toFixed(3));          // --gt на БОКСЕ → масштабирует шапку, тело и плитки целиком
}
function scaleBoardGroups(board) {
  if (!board) return;
  var bw = board.clientWidth || board.offsetWidth || 0;
  if (bw >= 40) board.style.setProperty('--pw', Math.max(0.5, Math.min(1, bw / 500)).toFixed(3));  // панель-масштаб: мин-ширины плашек ужимаются пропорционально → не налезают при сужении
  var boxes = $$('.group-box', board);
  for (var i = 0; i < boxes.length; i++) scaleGroupBox(boxes[i]);
}

/* размеры виджета храним отдельно для каждой доски (один виджет на разных вкладках = независимые размеры) */
function wsizeKey(node) {
  var b = node.closest('.board');
  return (b && b.dataset.board ? b.dataset.board + '::' : '') + node.dataset.widget;
}
function getWVal(node) {
  var k = wsizeKey(node), id = node.dataset.widget;
  return widgetSizes[k] !== undefined ? widgetSizes[k] : widgetSizes[id];
}
function getHVal(node) {
  var k = wsizeKey(node), id = node.dataset.widget;
  return widgetHeights[k] !== undefined ? widgetHeights[k] : widgetHeights[id];
}
function applySize(node) {
  var defW = (WIDGETS[node.dataset.widget] && WIDGETS[node.dataset.widget].w) || 100;
  var p = getWVal(node) || defW;
  node.style.width = (p >= 100) ? '100%' : 'calc(' + p + '% - ' + ((100 - p) * 0.1).toFixed(1) + 'px)';
  if (node.dataset.widget === 'bezier') {
    var bh = getHVal(node);
    if (bh) { node.style.height = bh + 'px'; node.classList.add('h-fixed'); }
    else    { node.style.height = '';        node.classList.remove('h-fixed'); }
    if (typeof resizeGraph === 'function') resizeGraph();
    return;
  }
  var hh = getHVal(node);
  if (hh) { node.style.height = hh + 'px'; node.classList.add('h-fixed'); }
  else    { node.style.height = '';        node.classList.remove('h-fixed'); }
  scaleTool(node);
}

function ensureResizeHandle(node) {
  if ($('.resize-handle', node)) return;
  var h = document.createElement('div');
  h.className = 'resize-handle';
  h.title = '';
  node.appendChild(h);
}
window.addEventListener('resize', function () { $$('.board').forEach(scaleBoardGroups); $$('.board > .widget.tool').forEach(scaleTool); });

/* ---- цвет/группа плашки (#1c) ---- */
function applyWidgetColor(node) {
  var c = widgetColors[node.dataset.widget];
  var isTool = node.classList.contains('tool');
  if (c) {
    node.style.setProperty('--wcol', c);
    node.classList.add('has-wcol');
    node.style.boxShadow = isTool ? '' : ('inset 0 0 0 2px ' + c);   // у плиток кольцо рисует ::after (поверх заливки)
  } else {
    node.style.removeProperty('--wcol');
    node.classList.remove('has-wcol');
    node.style.boxShadow = 'inset 0 0 0 1.5px rgba(255,255,255,.45)';   // базовая обводка как раньше (для всех)
  }
}
/* цвет элемента теперь меняется по ПКМ (контекстное окно «Color»);
   кружок-точка и стрелка-eject убраны — их функции закрывает ПКМ и Drag&Drop */
var _wcolApply = null, _wcolCur = '', _wcolPop = null;
function buildWcolPop() {
  if (_wcolPop) return _wcolPop;
  var pop = document.createElement('div');
  pop.className = 'wcol-pop'; pop.hidden = true;
  var hd = document.createElement('div'); hd.className = 'wcol-title'; hd.id = 'wcolTitle';
  pop.appendChild(hd);
  var grid = document.createElement('div'); grid.className = 'wcol-grid';
  WCOLORS.forEach(function (c) {
    var s = document.createElement('button');
    s.className = 'wcol-sw'; s.style.background = c; s.dataset.c = c;
    grid.appendChild(s);
  });
  var none = document.createElement('button');
  none.className = 'wcol-none'; none.textContent = '✕'; none.dataset.c = '';
  grid.appendChild(none);
  pop.appendChild(grid);
  pop.addEventListener('click', function (e) {
    var sw = e.target.closest('[data-c]');
    if (!sw) return;
    if (_wcolApply) _wcolApply(sw.dataset.c);
    pop.hidden = true;
  });
  document.body.appendChild(pop);
  _wcolPop = pop;
  return pop;
}
function openWcolXY(x, y, current, applyFn) {
  _wcolCur = current || '';
  _wcolApply = applyFn;
  var pop = buildWcolPop();
  var tt = $('#wcolTitle', pop); if (tt) tt.textContent = t('ctx_color');
  $$('.wcol-sw', pop).forEach(function (s) { s.classList.toggle('cur', s.dataset.c === _wcolCur); });
  pop.hidden = false;
  pop.style.left = Math.max(6, Math.min(window.innerWidth - pop.offsetWidth - 6, x)) + 'px';
  pop.style.top = Math.max(6, Math.min(window.innerHeight - pop.offsetHeight - 6, y)) + 'px';
}
/* ПКМ по виджету или группе → окно выбора цвета */
document.addEventListener('contextmenu', function (e) {
  var tg = e.target;
  if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.isContentEditable)) return;  // в полях ввода — нативное меню
  var w = e.target.closest('.widget');
  if (w && w.closest('.board')) {
    e.preventDefault();
    var id = w.dataset.widget;
    openWcolXY(e.clientX, e.clientY, widgetColors[id], function (c) {
      if (c) widgetColors[id] = c; else delete widgetColors[id];
      store.set('widgetColors', widgetColors);
      var n = widgetNode(id); if (n) applyWidgetColor(n);
    });
    return;
  }
  var gb = e.target.closest('.group-box');
  if (gb) {
    e.preventDefault();
    var page = $('.page.active') ? $('.page.active').dataset.page : 'home';
    var g = groupById(page, gb.dataset.gid);
    if (g) openWcolXY(e.clientX, e.clientY, g.color, function (c) { g.color = c || ''; saveGroups(); renderBoards(); });
    return;
  }
});
document.addEventListener('click', function (e) {
  if (_wcolPop && !_wcolPop.hidden && !_wcolPop.contains(e.target)) _wcolPop.hidden = true;
});

/* следим за изменением высоты виджетов (удалили палитру, добавили/убрали свотч и т.п.) —
   пересчитываем высоту активной доски, чтобы снизу не оставалось пустоты (#3) */
var _boardRO = window.ResizeObserver ? new ResizeObserver(function (entries) {
  var fix = {};
  entries.forEach(function (en) {
    var b = en.target.closest ? en.target.closest('.board') : null;
    if (en.target && en.target.classList && en.target.classList.contains('tool')) scaleTool(en.target);
    if (!b) return;
    var pg = b.closest('.page');
    if (pg && pg.classList.contains('active')) fix[b.dataset.board] = b;
  });
  Object.keys(fix).forEach(function (k) { layoutBoard(fix[k]); });
}) : null;

function renderBoards() {
  var storeBox = $('#widgetStore');
  // всё на склад
  Object.keys(WIDGETS).forEach(function (id) {
    var n = widgetNode(id);
    if (n) storeBox.appendChild(n);
  });
  /* один элемент может числиться на нескольких вкладках, но DOM-узел один —
     активная страница забирает его первой (остальные всё равно скрыты) */
  var activePage = $('.page.active') ? $('.page.active').dataset.page : 'home';
  var order = [activePage].concat(Object.keys(boards).filter(function (b) { return b !== activePage; }));
  var placed = {};
  var changed = false;
  order.forEach(function (bName) {
    var board = $('.board[data-board="' + bName + '"]');
    if (!board) return;
    board.classList.toggle('stack', bName !== 'home');   // блочные вкладки (стопка с перестановкой) — все, кроме Домика
    $$('.group-box', board).forEach(function (gb) { gb.remove(); });   // группы перестроим заново
    $$('.flow-add', board).forEach(function (b) { b.remove(); });      // на случай остатков потока
    var grouped = groupedSet(bName);
    var visible = bName === activePage;
    var maxBottom = 0;
    (boards[bName] || []).forEach(function (id) {
      if (placed[id]) return;
      if (isModOff(id)) return;     // модуль выключен — оставляем на складе (скрыт)
      var n = widgetNode(id);
      if (!n) return;
      if (grouped[id]) return;      // эта плашка внутри группы — её разместит renderGroups
      n.classList.remove('in-group');
      ensureResizeHandle(n);
      applyWidgetColor(n);
      board.appendChild(n);
      applySize(n);                  // ВАЖНО: после appendChild — иначе размер вкладки (board::id) не находится
      if (_boardRO) _boardRO.observe(n);
      placed[id] = true;
      var p = posOf(bName, id);
      if (!p) {
        if (!visible) return; // на скрытой вкладке высоты нулевые — позицию назначим при первом открытии
        p = { x: 0, y: maxBottom ? maxBottom + 10 : 0 };
        setPos(bName, id, p.x, p.y);
        changed = true;
      }
      // визуальная страховка от вылета за правый край — сохранённую позицию НЕ трогаем,
      // иначе при сужении панели плашки «уезжают» влево навсегда и не возвращаются при расширении (правка 2)
      var wPctP = (board.clientWidth ? n.offsetWidth / board.clientWidth * 100 : 0);
      var vx = Math.max(0, Math.min(100 - wPctP, p.x || 0));
      var vy = Math.max(0, p.y || 0);
      n.style.left = vx + '%';
      n.style.top = vy + 'px';
      scaleTool(n);
      var bottom = vy + n.offsetHeight;
      if (bottom > maxBottom) maxBottom = bottom;
    });
    renderGroups(board, bName, placed);
  });
  if (changed) store.set('widgetPos', widgetPos);
  // позиции элементов на доске не трогаем авто-логикой (никакого расталкивания/подтягивания)
  $$('.board').forEach(function (board) {
    var oldTile = $('.add-tile', board);
    if (oldTile) oldTile.remove();
    if (board.dataset.board === activePage) layoutBoard(board);
  });
  if (typeof applyPalSize === 'function') applyPalSize();
  setDraggable(document.body.classList.contains('editing'));
}

/* подтягиваем одиночную плашку, «улетевшую» далеко вниз (восстановление потеряшек) */
function tidyStranded(board, page) {
  if ((board.clientWidth || 0) < 40) return;   // нет размера — не трогаем
  var items = [];
  for (var i = 0; i < board.children.length; i++) {
    var el = board.children[i];
    if (!el.classList) continue;
    var isW = el.classList.contains('widget'), isG = el.classList.contains('group-box');
    if (!isW && !isG) continue;
    items.push({ el: el, id: isW ? el.dataset.widget : null, top: el.offsetTop, bottom: el.offsetTop + el.offsetHeight });
  }
  if (items.length < 2) return;
  items.sort(function (a, b) { return a.top - b.top; });
  var lowest = items[items.length - 1];
  var maxOther = 0;
  for (var j = 0; j < items.length - 1; j++) if (items[j].bottom > maxOther) maxOther = items[j].bottom;
  if (lowest.id && lowest.top > maxOther + 120) {       // одинокая свободная плашка далеко внизу — поднимаем к контенту
    var ny = Math.max(0, maxOther + 10);
    var lx = parseFloat(lowest.el.style.left) || 0;
    setPos(page, lowest.id, lx, ny);
    lowest.el.style.top = ny + 'px';
    store.set('widgetPos', widgetPos);
  }
}

/* ===== группы-контейнеры: рендер + взаимодействие ===== */
function renderGroups(board, page, placed) {
  var gs = boardGroups[page] || [];
  gs.forEach(function (g) {
    var box = document.createElement('div');
    box.className = 'group-box' + (g.collapsed ? ' collapsed' : '') + (g.autosize ? ' autosize' : '');
    box.dataset.gid = g.gid;
    box.style.left = (g.x || 0) + '%';
    box.style.top = (g.y || 0) + 'px';
    if (g.autosize) { box.style.width = ''; box.style.maxWidth = (100 - (g.x || 0)) + '%'; }
    else { var gw = Math.min(g.w || 40, 100 - (g.x || 0)); box.style.width = gw + '%'; }
    if (g.color) { box.style.borderColor = g.color; box.style.setProperty('--gcol', g.color); box.classList.add('has-gcol'); }

    var head = document.createElement('div');
    head.className = 'group-head';
    head.innerHTML =
      '<span class="group-name" spellcheck="false"></span>' +
      '<span class="group-actions">' +
        '<button class="group-collapse">' + (g.collapsed ? '▸' : '▾') + '</button>' +
        '<span class="group-grip">⠿</span>' +
        '<button class="group-del">✕</button>' +
      '</span>';
    $('.group-name', head).textContent = g.name || '';
    box.appendChild(head);

    var body = document.createElement('div');
    body.className = 'group-body';
    (g.members || []).slice().forEach(function (id) {
      if (placed[id]) return;
      if (isModOff(id)) return;
      var n = widgetNode(id);
      if (!n || !n.classList.contains('tool')) return;   // в группы — только плашки-инструменты
      n.classList.add('in-group');
      ensureResizeHandle(n);
      applyWidgetColor(n);
      n.style.left = ''; n.style.top = ''; n.style.width = ''; n.style.height = '';
      n.style.removeProperty('--ts'); n.style.removeProperty('--gt');   // масштаб плитки в группе задаёт доска через наследуемый --gt
      body.appendChild(n);
      placed[id] = true;
    });
    box.appendChild(body);

    var rz = document.createElement('div');
    rz.className = 'group-resize';
    box.appendChild(rz);
    board.appendChild(box);
    scaleGroupBox(box);
  });
}

/* перетаскивание/ресайз/действия групп (всё — только в режиме раскладки) */
(function () {
  var box = null, board = null, page = '', g = null, mode = '', offX = 0, offY = 0;
  var lastX = 0, lastY = 0;

  document.addEventListener('mousedown', function (e) {
    if (!document.body.classList.contains('editing')) return;
    var rz = e.target.closest('.group-resize');
    if (!rz) return;                                  // перемещение группы теперь делает общий sortable (за шапку)
    var box0 = e.target.closest('.group-box');
    if (!box0) return;
    box = box0;
    board = box.closest('.board'); page = board.dataset.board;
    g = groupById(page, box.dataset.gid);
    if (!g) { box = null; return; }
    e.preventDefault(); e.stopPropagation();
    mode = 'resize';
    g.cols = countCols(box);                          // фиксируем число колонок на момент начала ресайза → плитки масштабируются, не переносятся (правка 3)
    var bxr = box.getBoundingClientRect();
    offX = e.clientX - bxr.left; offY = e.clientY - bxr.top;
    lastX = g.x || 0; lastY = g.y || 0;
    window.addEventListener('mousemove', gMove);
    window.addEventListener('mouseup', gUp);
  });

  function boxRect(b) { return { l: b.offsetLeft, t: b.offsetTop, r: b.offsetLeft + b.offsetWidth, b: b.offsetTop + b.offsetHeight }; }
  // пересекается ли текущая рамка с другой группой
  function hitsOtherGroup() {
    var me = boxRect(box);
    var others = board.querySelectorAll('.group-box');
    for (var i = 0; i < others.length; i++) {
      if (others[i] === box) continue;
      var o = boxRect(others[i]);
      if (me.l < o.r - 1 && me.r > o.l + 1 && me.t < o.b - 1 && me.b > o.t + 1) return true;
    }
    return false;
  }
  // максимально допустимая ширина (%), пока не упёрлись в плашку/группу справа или в край плагина
  function maxWidthPct() {
    var maxW = 100 - (g.x || 0);
    var brW = board.clientWidth || 1;
    var myTop = box.offsetTop, myBot = box.offsetTop + box.offsetHeight;
    for (var i = 0; i < board.children.length; i++) {
      var o = board.children[i];
      if (o === box || !o.classList) continue;
      if (!(o.classList.contains('group-box') || o.classList.contains('widget'))) continue;
      var oTop = o.offsetTop, oBot = o.offsetTop + o.offsetHeight;
      if (oTop < myBot && oBot > myTop) {                 // пересечение по вертикали
        var oLeftPct = o.offsetLeft / brW * 100;
        if (oLeftPct >= (g.x || 0)) maxW = Math.min(maxW, oLeftPct - (g.x || 0) - 1);
      }
    }
    return Math.max(14, maxW);
  }

  function gMove(e) {
    if (!box) return;
    var br = board.getBoundingClientRect();
    if (mode === 'move') {
      var x = (e.clientX - br.left - offX) / br.width * 100;
      var y = e.clientY - br.top - offY;
      x = Math.round(x / 2.5) * 2.5;
      var wPct = box.offsetWidth / br.width * 100;
      x = Math.max(0, Math.min(100 - wPct, x));
      y = Math.max(0, Math.round(y / 10) * 10);
      box.style.left = x + '%'; box.style.top = y + 'px';
      if (hitsOtherGroup()) {                              // наехали на другую группу — откат к последней свободной точке
        box.style.left = lastX + '%'; box.style.top = lastY + 'px';
      } else {
        lastX = x; lastY = y; g.x = x; g.y = y;
      }
    } else {
      var w = (e.clientX - br.left - box.offsetLeft) / br.width * 100;
      w = Math.round(w / 5) * 5;                            // шаг 5% — как у плашек
      w = Math.max(14, Math.min(maxWidthPct(), w));        // упираемся в плашки/группы и край плагина
      box.classList.remove('autosize');
      box.style.width = w + '%';
      g.w = w; g.autosize = false;
      scaleGroupBox(box);                                  // значки внутри ужимаются под новую ширину группы (правка 1)
    }
  }
  function gUp() {
    if (box) { saveGroups(); }
    box = null; board = null; g = null;
    window.removeEventListener('mousemove', gMove);
    window.removeEventListener('mouseup', gUp);
  }
})();

/* делегированные клики по элементам группы */
document.addEventListener('click', function (e) {
  var page = $('.page.active') ? $('.page.active').dataset.page : 'home';

  var col2 = e.target.closest('.group-collapse');
  if (col2) {
    var gb2 = col2.closest('.group-box'); var g2 = gb2 && groupById(page, gb2.dataset.gid);
    if (g2) { g2.collapsed = !g2.collapsed; saveGroups(); renderBoards(); }
    return;
  }
  var del = e.target.closest('.group-del');
  if (del) {
    var gb3 = del.closest('.group-box'); var g3 = gb3 && groupById(page, gb3.dataset.gid);
    if (g3) {
      var gs = boardGroups[page] || [];
      var idx = gs.indexOf(g3);
      if (idx !== -1) gs.splice(idx, 1);   // участники просто вернутся на доску (renderBoards разложит их свободно)
      saveGroups(); renderBoards();
    }
    return;
  }
});

/* правка имени группы */
document.addEventListener('dblclick', function (e) {
  var nm = e.target.closest('.group-name');
  if (!nm || !document.body.classList.contains('editing')) return;
  nm.contentEditable = 'true';
  nm.focus();
  document.execCommand && document.execCommand('selectAll', false, null);
});
function commitGroupName(nm) {
  var page = $('.page.active') ? $('.page.active').dataset.page : 'home';
  var gb = nm.closest('.group-box'); var g = gb && groupById(page, gb.dataset.gid);
  nm.contentEditable = 'false';
  if (g) { g.name = (nm.textContent || '').trim() || g.name; nm.textContent = g.name; saveGroups(); }
}
document.addEventListener('blur', function (e) {
  if (e.target && e.target.classList && e.target.classList.contains('group-name') && e.target.isContentEditable) commitGroupName(e.target);
}, true);
document.addEventListener('keydown', function (e) {
  if (e.target && e.target.classList && e.target.classList.contains('group-name') && e.target.isContentEditable && e.key === 'Enter') {
    e.preventDefault(); e.target.blur();
  }
});

/* пересчёт высоты доски + позиция плюса */
function layoutBoard(board) {
  scaleBoardGroups(board);                  // плитки в группах ужимаются под ширину панели/группы (до замера высоты)
  var maxBottom = 0;
  for (var i = 0; i < board.children.length; i++) {
    var w = board.children[i];
    if (!w.classList || (!w.classList.contains('widget') && !w.classList.contains('group-box'))) continue;
    var b = w.offsetTop + w.offsetHeight;   // прямые дети доски: свободные плашки + группы
    if (b > maxBottom) maxBottom = b;
  }
  board.style.minHeight = (maxBottom + 70) + 'px';
  renderAddSlots(board);
}

/* ---- геометрия виджетов + расталкивание при наезде (#3) ---- */
function wRect(n) { return { l: n.offsetLeft, t: n.offsetTop, w: n.offsetWidth, h: n.offsetHeight, r: n.offsetLeft + n.offsetWidth, b: n.offsetTop + n.offsetHeight }; }
/* базовый зазор между плашками на free-board (Variant A: grid-snap с зазором). Меняй число — меняется отступ. */
var BOARD_GAP = 10;
/* «пересекаются» = ближе, чем BOARD_GAP (а не только реальное наложение) — так держим базовый отступ */
function wOverlap(a, b) { var G = BOARD_GAP; return a.l < b.r + G && a.r > b.l - G && a.t < b.b + G && a.b > b.t - G; }

/* магнит: если плитка рядом с соседом — прижать её ровно на BOARD_GAP (одинаково по H и V) */
function magnetGap(board, node, lPx, tPx) {
  var w = node.offsetWidth, h = node.offsetHeight, G = BOARD_GAP, TH = G + 2;   // мягкий магнит: только коррекция почти-впритык (~12px), без дальних рывков
  var others = [];
  $$('.board > .widget', board).forEach(function (o) { if (o !== node) others.push(wRect(o)); });
  $$('.board > .group-box', board).forEach(function (gg) { if (gg !== node) others.push(wRect(gg)); });
  var l = lPx, t = tPx;
  for (var pass = 0; pass < 2; pass++) {
    var r = l + w, b = t + h;
    for (var i = 0; i < others.length; i++) {
      var o = others[i];
      if ((b > o.t - TH) && (t < o.b + TH)) {                 // по вертикали рядом → магнитим по горизонтали
        if (Math.abs(l - (o.r + G)) <= TH) l = o.r + G;
        else if (Math.abs(r - (o.l - G)) <= TH) l = o.l - G - w;
      }
      if ((r > o.l - TH) && (l < o.r + TH)) {                 // по горизонтали рядом → магнитим по вертикали
        if (Math.abs(t - (o.b + G)) <= TH) t = o.b + G;
        else if (Math.abs(b - (o.t - G)) <= TH) t = o.t - G - h;
      }
    }
  }
  return { l: Math.max(0, l), t: Math.max(0, t) };
}
var MP_placeWhy = '';
function canPlaceAt(board, node, lPx, tPx) {
  var bw = board.clientWidth || board.offsetWidth || 1;
  if (bw < 40) { MP_placeWhy = 'board not measured (bw=' + bw + ')'; return true; }   // доска без размера — не мешаем ставить
  var w = node.offsetWidth, h = node.offsetHeight;
  if (lPx < -0.5 || tPx < -0.5 || lPx + w > bw + 1) { MP_placeWhy = 'edge l=' + Math.round(lPx) + ' w=' + w + ' bw=' + Math.round(bw); return false; }
  var rr = { l: lPx, t: tPx, r: lPx + w, b: tPx + h };
  var blocked = '';
  function chk(o, kind, key) {
    if (blocked) return;
    if (rr.l < o.r - 1 && rr.r > o.l + 1 && rr.t < o.b - 1 && rr.b > o.t + 1)        // РЕАЛЬНОЕ наложение (без зазора)
      blocked = kind + ' ' + key + ' @' + Math.round(o.l) + ',' + Math.round(o.t) + ' ' + Math.round(o.r - o.l) + 'x' + Math.round(o.b - o.t);
  }
  $$('.board > .widget', board).forEach(function (o) { if (o !== node) chk(wRect(o), 'widget', o.dataset.widget); });
  $$('.board > .group-box', board).forEach(function (g2) { if (g2 !== node) chk(wRect(g2), 'group', g2.dataset.gid || '?'); });
  MP_placeWhy = blocked ? ('overlap ' + blocked) : '';
  return !blocked;
}

/* ближайшее свободное место для плашки/группы возле точки сброса (leftPct в %, topPx в px).
   НИКОГО не двигаем — переставляется только сам node. Соседи (.widget и .group-box) остаются на месте.
   Если место занято — спиральный поиск по сетке снапа (2.5% по X, 10px по Y) до ближайшей свободной клетки. */
function nearestFreePos(board, node, leftPct, topPx) {
  var bw = board.clientWidth || board.offsetWidth || 1;
  var w = node.offsetWidth, h = node.offsetHeight, wPct = w / bw * 100;
  var others = [];
  $$('.board > .widget', board).forEach(function (o) { if (o !== node) others.push(wRect(o)); });
  $$('.board > .group-box', board).forEach(function (g) { if (g !== node) others.push(wRect(g)); });
  function fits(lp, tp) {
    var l = lp / 100 * bw, t = tp, r = l + w, b = t + h;
    if (l < -0.5 || t < -0.5 || r > bw + 1) return false;
    for (var i = 0; i < others.length; i++) { if (wOverlap({ l: l, t: t, r: r, b: b }, others[i])) return false; }
    return true;
  }
  // РЕАЛЬНОЕ наложение (без зазора) — плитки буквально друг на друге
  function rawHit(lp, tp) {
    var l = lp / 100 * bw, t = tp, r = l + w, b = t + h;
    if (l < -0.5 || t < -0.5 || r > bw + 1) return true;            // за краем доски — считаем занято
    for (var i = 0; i < others.length; i++) {
      var o = others[i];
      if (l < o.r - 1 && r > o.l + 1 && t < o.b - 1 && b > o.t + 1) return true;
    }
    return false;
  }
  var stepX = 2.5, stepY = 10;
  function snapLP(v) { return Math.max(0, Math.min(100 - wPct, Math.round(v / stepX) * stepX)); }
  function snapTP(v) { return Math.max(0, Math.round(v / stepY) * stepY); }
  leftPct = snapLP(leftPct); topPx = snapTP(topPx);
  if (!rawHit(leftPct, topPx)) return { x: leftPct, y: topPx };     // пустое место — оставляем РОВНО тут (без телепорта)
  if (fits(leftPct, topPx)) return { x: leftPct, y: topPx };        // место с зазором свободно — тоже тут
  for (var rad = 1; rad <= 16; rad++) {                             // иначе ищем ближайшее с зазором, но НЕДАЛЕКО
    var best = null, bestD = Infinity;
    for (var dx = -rad; dx <= rad; dx++) {
      for (var dy = -rad; dy <= rad; dy++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== rad) continue;   // только внешнее кольцо текущего радиуса
        var lp = snapLP(leftPct + dx * stepX), tp = snapTP(topPx + dy * stepY);
        if (!fits(lp, tp)) continue;
        var ddx = (lp - leftPct) / 100 * bw, ddy = tp - topPx, d = ddx * ddx + ddy * ddy;
        if (d < bestD) { bestD = d; best = { x: lp, y: tp }; }
      }
    }
    if (best) return best;                                            // ближайшая свободная в этом кольце — берём её
  }
  return { x: leftPct, y: topPx };                                    // доска забита — оставляем как есть
}

/* пересекается ли виджет с любым другим на доске или вылезает за её правый край */
function overlapsOthers(board, node) {
  var nr = wRect(node);
  var bw = board.clientWidth || board.offsetWidth;
  if (bw && nr.r > bw + 1) return true;
  var i;
  var ws = $$('.board > .widget', board);
  for (i = 0; i < ws.length; i++) {
    if (ws[i] === node) continue;
    if (wOverlap(nr, wRect(ws[i]))) return true;
  }
  var gs = $$('.board > .group-box', board);            // группы — тоже препятствия (раньше ресайз их не видел)
  for (i = 0; i < gs.length; i++) {
    if (gs[i] === node || gs[i].contains(node)) continue;   // свою группу-родителя не считаем
    if (wOverlap(nr, wRect(gs[i]))) return true;
  }
  return false;
}

/* сдвигаем плашку вправо/вниз, пока не встанет на свободное место (вынутые из группы не лезут друг в друга) */
function nudgeToFree(board, page, node) {
  if (!node) return;
  var bw = board.clientWidth || board.offsetWidth || 1;
  var wPct = node.offsetWidth / bw * 100;
  var x = parseFloat(node.style.left) || 0;
  var y = parseInt(node.style.top, 10) || 0;
  var tries = 0;
  while (overlapsOthers(board, node) && tries < 60) {
    x += wPct + 2;
    if (x > 100 - wPct) { x = 0; y += node.offsetHeight + 10; }
    node.style.left = x + '%';
    node.style.top = y + 'px';
    tries++;
  }
  setPos(page, node.dataset.widget, x, y);
  store.set('widgetPos', widgetPos);
}

/* разводим все свободные плашки, чтобы они не накладывались друг на друга и на группы */
function resolveOverlaps(board, page) {
  var bw = board.clientWidth || board.offsetWidth || 0;
  if (bw < 40) return;     // доска ещё не получила размер (старт/скрытая) — НЕ трогаем сохранённые позиции
  var placed = [];
  board.querySelectorAll('.group-box').forEach(function (gb) {     // группы — препятствия
    placed.push({ l: gb.offsetLeft, t: gb.offsetTop, r: gb.offsetLeft + gb.offsetWidth, b: gb.offsetTop + gb.offsetHeight });
  });
  var moved = false;
  $$('.board > .widget', board).forEach(function (n) {
    var ow = n.offsetWidth, oh = n.offsetHeight;
    var wPct = ow / bw * 100;
    var x0 = parseFloat(n.style.left) || 0, y0 = parseInt(n.style.top, 10) || 0;
    var x = x0, y = y0, tries = 0;
    function hit() {
      var px = x / 100 * bw, r = { l: px, t: y, r: px + ow, b: y + oh };
      for (var i = 0; i < placed.length; i++) {
        var p = placed[i];
        if (r.l < p.r - 1 && r.r > p.l + 1 && r.t < p.b - 1 && r.b > p.t + 1) return true;
      }
      return false;
    }
    while (hit() && tries < 80) {
      x += wPct + 2;
      if (x > 100 - wPct) { x = 0; y += oh + 10; }
      tries++;
    }
    if (x !== x0 || y !== y0) {
      n.style.left = x + '%'; n.style.top = y + 'px';
      setPos(page, n.dataset.widget, x, y); moved = true;
    }
    var fx = x / 100 * bw;
    placed.push({ l: fx, t: y, r: fx + ow, b: y + oh });
  });
  if (moved) store.set('widgetPos', widgetPos);
}

/* как resolveOverlaps, но mover остаётся на месте (как его бросили), а наезжающие соседи раздвигаются */
function resolveAround(board, page, mover) {
  var bw = board.clientWidth || board.offsetWidth || 0;
  if (bw < 40) return;
  var placed = [];
  board.querySelectorAll('.group-box').forEach(function (gb) {     // группы — препятствия
    placed.push({ l: gb.offsetLeft, t: gb.offsetTop, r: gb.offsetLeft + gb.offsetWidth, b: gb.offsetTop + gb.offsetHeight });
  });
  if (mover) { var mr = wRect(mover); placed.push({ l: mr.l, t: mr.t, r: mr.r, b: mr.b }); }   // перетащенная — зафиксирована
  var moved = false;
  $$('.board > .widget', board).forEach(function (n) {
    if (n === mover) return;
    var ow = n.offsetWidth, oh = n.offsetHeight, wPct = ow / bw * 100;
    var x0 = parseFloat(n.style.left) || 0, y0 = parseInt(n.style.top, 10) || 0;
    var x = x0, y = y0, tries = 0;
    function hit() {
      var px = x / 100 * bw, r = { l: px, t: y, r: px + ow, b: y + oh };
      for (var i = 0; i < placed.length; i++) {
        var p = placed[i];
        if (r.l < p.r - 1 && r.r > p.l + 1 && r.t < p.b - 1 && r.b > p.t + 1) return true;
      }
      return false;
    }
    while (hit() && tries < 80) {
      x += wPct + 2;
      if (x > 100 - wPct) { x = 0; y += oh + 10; }
      tries++;
    }
    if (x !== x0 || y !== y0) {
      n.style.left = x + '%'; n.style.top = y + 'px';
      setPos(page, n.dataset.widget, x, y); moved = true;
    }
    var fx = x / 100 * bw;
    placed.push({ l: fx, t: y, r: fx + ow, b: y + oh });
  });
  if (moved) store.set('widgetPos', widgetPos);
}


var pushOrig = null;
function snapshotPositions(board, mover) {
  pushOrig = {};
  $$('.board > .widget', board).forEach(function (o) {
    if (o === mover) return;
    pushOrig[o.dataset.widget] = { l: o.offsetLeft, t: o.offsetTop, w: o.offsetWidth, h: o.offsetHeight };
  });
}

/* раздвигаем соседей под mover; если mover ушёл/уменьшился и больше не перекрывает
   родное место соседа — сосед возвращается туда обратно */
function pushOthers(board, mover) {
  if (!pushOrig) return;
  var bw = board.clientWidth || board.offsetWidth;
  if (!bw) return;
  var mr = wRect(mover);
  $$('.board > .widget', board).forEach(function (o) {
    if (o === mover) return;
    var orig = pushOrig[o.dataset.widget];
    if (!orig) return;
    var oRect = { l: orig.l, t: orig.t, r: orig.l + orig.w, b: orig.t + orig.h, w: orig.w, h: orig.h };
    var nx = orig.l, ny = orig.t;         // по умолчанию — родное место (вернётся, когда освободится)
    if (wOverlap(mr, oRect)) {
      var penX = Math.min(mr.r, oRect.r) - Math.max(mr.l, oRect.l);
      var penY = Math.min(mr.b, oRect.b) - Math.max(mr.t, oRect.t);
      if (penY <= penX) {
        if (oRect.t + orig.h / 2 >= mr.t + mr.h / 2) ny = mr.b + 8;     // сосед ниже центра — вниз
        else ny = mr.t - orig.h - 8;                                    // выше — вверх
      } else {
        if (oRect.l + orig.w / 2 >= mr.l + mr.w / 2) nx = mr.r + 8;     // правее — вправо
        else nx = mr.l - orig.w - 8;                                    // левее — влево
      }
      nx = Math.max(0, Math.min(Math.max(0, bw - orig.w), nx));
      ny = Math.max(0, ny);
    }
    var xPct = nx / bw * 100;
    o.style.left = xPct + '%';
    o.style.top = ny + 'px';
    o._px = xPct; o._py = ny;
  });
}

/* ---- единый компактный «+»: вплотную справа от виджета + один снизу (#4/#3) ---- */
var pendingAddPos = null;    // куда поставить добавляемый виджет {x:%, y:px}
var ADD_PLUS = 22, ADD_GAP = 4;
function renderAddSlots(board) {
  var old = $$('.add-slot', board);
  for (var k = 0; k < old.length; k++) old[k].remove();
  var bw = board.clientWidth || board.offsetWidth;
  if (!bw) return;
  // блочные вкладки (сетка): только один «+» снизу по центру — добавить блок в конец
  if (board.classList.contains('stack')) {
    var mb = 0;
    for (var si = 0; si < board.children.length; si++) {
      var sw = board.children[si];
      if (sw.classList && sw.classList.contains('widget')) { var sb = sw.offsetTop + sw.offsetHeight; if (sb > mb) mb = sb; }
    }
    var by2 = mb ? mb + 10 : 0, bx2 = Math.max(0, (bw - ADD_PLUS) / 2);
    var sbtn = document.createElement('button');
    sbtn.className = 'add-slot'; sbtn.setAttribute('data-tip', t('tip_addtile')); sbtn.innerHTML = '<span></span>';
    sbtn.style.left = bx2 + 'px'; sbtn.style.top = by2 + 'px'; sbtn.style.width = ADD_PLUS + 'px'; sbtn.style.height = ADD_PLUS + 'px';
    (function (ay) { sbtn.addEventListener('click', function () { pendingAddPos = { x: 0, y: ay }; openAddWindow(); }); })(by2);
    board.insertBefore(sbtn, board.firstChild);
    return;
  }
  var rects = [], grects = [], maxBottom = 0;
  $$('.board > .widget', board).forEach(function (w) {
    var r = wRect(w); rects.push(r);
    if (r.b > maxBottom) maxBottom = r.b;
  });
  $$('.group-box', board).forEach(function (gb) {       // группы — тоже препятствия для «+»
    var r = wRect(gb); grects.push(r);
    if (r.b > maxBottom) maxBottom = r.b;
  });

  function spotFree(x, y, w, h) {
    var rr = { l: x, t: y, r: x + w, b: y + h };
    for (var i = 0; i < rects.length; i++) if (wOverlap(rr, rects[i])) return false;
    for (var j = 0; j < grects.length; j++) if (wOverlap(rr, grects[j])) return false;
    return true;
  }
  function makeSlot(xpx, ypx, addXpx, addYpx) {
    var btn = document.createElement('button');
    btn.className = 'add-slot';
    btn.setAttribute('data-tip', t('tip_addtile'));
    btn.innerHTML = '<span></span>';
    btn.style.left = xpx + 'px';
    btn.style.top = ypx + 'px';
    btn.style.width = ADD_PLUS + 'px';
    btn.style.height = ADD_PLUS + 'px';
    (function (ax, ay) {
      btn.addEventListener('click', function () {
        pendingAddPos = { x: ax / bw * 100, y: ay };
        openAddWindow();
      });
    })(addXpx, addYpx);
    board.insertBefore(btn, board.firstChild);   // под виджетами по z-порядку
  }

  // «+» вплотную справа от каждого виджета, если справа свободно
  rects.forEach(function (r) {
    var x = r.r + ADD_GAP;
    if (x + ADD_PLUS > bw) return;
    if (!spotFree(x, r.t, ADD_PLUS, r.h)) return;
    var y = r.t + Math.max(0, (r.h - ADD_PLUS) / 2);
    makeSlot(x, y, x, r.t);                        // новый виджет — на уровне строки, правее
  });

  // «+» справа от каждой группы — чтобы можно было добавлять плашку рядом с группой
  grects.forEach(function (r) {
    var x = r.r + ADD_GAP;
    if (x + ADD_PLUS > bw) return;
    if (!spotFree(x, r.t, ADD_PLUS, Math.min(r.h, 60))) return;
    var y = r.t + Math.max(0, (Math.min(r.h, 60) - ADD_PLUS) / 2);
    makeSlot(x, y, x, r.t);
  });

  // «+» снизу — добавить в конец; центрируем кнопку по элементу, под которым она стоит
  var lowest = null;
  rects.forEach(function (r) { if (!lowest || r.b > lowest.b) lowest = r; });
  var by = maxBottom ? maxBottom + 10 : 0;
  var bx = 0;
  if (lowest) {
    bx = lowest.l + (lowest.w - ADD_PLUS) / 2;
    bx = Math.max(0, Math.min(Math.max(0, bw - ADD_PLUS), bx));
  }
  makeSlot(bx, by, 0, by);   // кнопка — по центру нижнего элемента; новый виджет — слева на новой строке
}

/* убрать виджет с доски (в режиме раскладки) */
document.addEventListener('click', function (e) {
  var btn = e.target.closest('.w-remove');
  if (!btn) return;
  var w = btn.closest('.widget');
  var id = w.dataset.widget;
  var page = $('.page.active').dataset.page;
  if (NATIVE[id] === page) {
    toast(t('t_pinned', wName(id)));
    return;
  }
  var arr = boards[page] || [];
  var ix = arr.indexOf(id);
  if (ix > -1) {
    arr.splice(ix, 1);
    removeFromGroups(page, id); saveGroups();
    if (flowOrder[page]) { var fi = flowOrder[page].indexOf('w:' + id); if (fi > -1) { flowOrder[page].splice(fi, 1); store.set('flowOrder', flowOrder); } }
    saveBoards(); renderBoards();
    toast(t('t_removed', wName(id)));
  }
});

/* ---- окно добавления (как Motion Tools) ---- */
var addOverlay = $('#addOverlay');

function openAddWindow() {
  buildAddTree($('#addSearch').value);
  addOverlay.hidden = false;
}
$('#addClose').addEventListener('click', function () { addOverlay.hidden = true; pendingAddPos = null; });
addOverlay.addEventListener('click', function (e) { if (e.target === addOverlay) { addOverlay.hidden = true; pendingAddPos = null; } });
$('#addSearch').addEventListener('input', function () { buildAddTree(this.value); });

function buildAddTree(filter) {
  filter = (filter || '').trim().toLowerCase();
  var curPage = ($('.page.active') && $('.page.active').dataset.page) || 'home';   // на какой вкладке открыли «+»
  var tree = $('#addTree');
  tree.innerHTML = '';
  var TAB_ORDER = ['home', 'palettes', 'graph', 'expr', 'text'];
  // основные папки = вкладки (родная вкладка элемента), внутри — подгруппы по категории
  var byTab = {};
  Object.keys(WIDGETS).forEach(function (id) {
    if (isModOff(id)) return;                 // выключенные модули нельзя добавить
    // вне главной (Домик) доска — «блочная»: добавить можно только функции, родные для этой вкладки
    if (curPage !== 'home' && (NATIVE[id] || 'home') !== curPage) return;
    if (filter && wName(id).toLowerCase().indexOf(filter) === -1) return;
    var tab = NATIVE[id] || 'home';
    var sub = t(WIDGETS[id].cat);
    byTab[tab] = byTab[tab] || {};
    (byTab[tab][sub] = byTab[tab][sub] || []).push(id);
  });
  var tabs = TAB_ORDER.filter(function (tb) { return byTab[tb]; });
  Object.keys(byTab).forEach(function (tb) { if (tabs.indexOf(tb) === -1) tabs.push(tb); });

  function makeItem(id) {
    var locs = widgetLocations(id);
    var onCur = !!(boards[curPage] && boards[curPage].indexOf(id) !== -1);
    var it = document.createElement('button');
    it.className = 'add-item' + (onCur ? ' is-added' : '');
    var where = locs.length
      ? t('on_pages') + ' «' + locs.map(function (l) { return esc(pageTitle(l)); }).join('», «') + '»'
      : '+';
    var chk = '<span class="add-check"><svg viewBox="0 0 16 16" width="13" height="13"><path d="M3.5 8.6l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
    it.innerHTML = '<span class="add-left">' + chk + '<span class="add-name">' + esc(wName(id)) + '</span></span><span class="where">' + where + '</span>';
    it.addEventListener('click', function () { addWidgetToCurrent(id); });
    return it;
  }

  tabs.forEach(function (tb) {
    var catEl = document.createElement('div');
    catEl.className = 'add-cat open';
    var head = document.createElement('button');
    head.className = 'add-cat-head';
    head.innerHTML = '<span class="tri"></span>' + esc(pageTitle(tb));
    head.addEventListener('click', function () { catEl.classList.toggle('open'); });
    var items = document.createElement('div');
    items.className = 'add-cat-items';
    var subs = byTab[tb];
    var subNames = Object.keys(subs);
    if (subNames.length <= 1) {
      // одна подгруппа — показываем элементы прямо во вкладке (без лишней вложенности)
      subNames.forEach(function (s) { subs[s].forEach(function (id) { items.appendChild(makeItem(id)); }); });
    } else {
      subNames.forEach(function (s) {
        var subEl = document.createElement('div');
        subEl.className = 'add-subcat open';
        var sh = document.createElement('button');
        sh.className = 'add-subcat-head';
        sh.innerHTML = '<span class="tri"></span>' + esc(s);
        sh.addEventListener('click', function () { subEl.classList.toggle('open'); });
        var si = document.createElement('div');
        si.className = 'add-cat-items';
        subs[s].forEach(function (id) { si.appendChild(makeItem(id)); });
        subEl.appendChild(sh); subEl.appendChild(si);
        items.appendChild(subEl);
      });
    }
    catEl.appendChild(head);
    catEl.appendChild(items);
    tree.appendChild(catEl);
  });
  if (!tree.children.length) tree.innerHTML = '<div class="add-hint" style="padding:8px 6px">' + t('add_none') + '</div>';
}

/* новый виджет не должен ложиться поверх других: прижимаем в доску по ширине
   и опускаем вниз до первого свободного места под точкой добавления (#2) */
function resolveNewWidgetOverlap(page, id) {
  var board = $('.board[data-board="' + page + '"]');
  if (!board) return;
  var node = widgetNode(id);
  if (!node || node.parentElement !== board) return;
  if (id === 'bezier' && typeof resizeGraph === 'function') resizeGraph(); // график квадратный: зафиксируем высоту до замера
  var bw = board.clientWidth || board.offsetWidth;
  if (!bw) return;
  var others = [];
  $$('.board > .widget', board).forEach(function (o) { if (o !== node) others.push(wRect(o)); });
  var w = node.offsetWidth, h = node.offsetHeight;
  var x = node.offsetLeft, y = node.offsetTop;
  if (x + w > bw) x = Math.max(0, bw - w);   // не вылезаем за правый край доски
  function free(yy) {
    var rr = { l: x, t: yy, r: x + w, b: yy + h };
    for (var i = 0; i < others.length; i++) if (wOverlap(rr, others[i])) return false;
    return true;
  }
  if (!free(y)) {
    var guard = 0;
    while (!free(y) && guard < 6000) { y += 6; guard += 6; }
  }
  var xPct = x / bw * 100;
  setPos(page, id, xPct, y);
  store.set('widgetPos', widgetPos);
  node.style.left = xPct + '%';
  node.style.top = y + 'px';
  layoutBoard(board);
}

function addWidgetToCurrent(id) {
  var page = $('.page.active').dataset.page;
  if (boards[page].indexOf(id) !== -1) { toast(t('t_already', wName(id))); pendingAddPos = null; return; }
  boards[page].push(id);
  var hadPos = !!pendingAddPos;
  if (pendingAddPos) {
    setPos(page, id, pendingAddPos.x, pendingAddPos.y);
    store.set('widgetPos', widgetPos);
  }
  saveBoards(); renderBoards();
  if (hadPos) resolveNewWidgetOverlap(page, id);   // подгоняем под место, без наложения
  pendingAddPos = null;
  addOverlay.hidden = true;
  toast(t('t_added', wName(id), pageTitle(page)));
}


/* ---- ресайз виджетов за уголок (в режиме раскладки) ---- */
(function () {
  var node = null, board = null, startSizes = null, startOverlap = false, collided = false;

  document.addEventListener('mousedown', function (e) {
    var h = e.target.closest('.resize-handle');
    if (!h || !document.body.classList.contains('editing')) return;
    e.preventDefault();
    e.stopPropagation();
    node = h.closest('.widget');
    board = node.closest('.board');
    node.draggable = false;
    node.classList.add('resizing');
    board.classList.add('collide-anim');
    snapshotPositions(board, node);
    startOverlap = overlapsOthers(board, node);   // плашка уже лежит на соседе? тогда ресайз свободный (иначе залочена в обе стороны)
    collided = false;
    try { MP_log('resize START id=' + node.dataset.widget + ' board=' + (board.dataset.board || '?') + ' startOverlap=' + startOverlap + ' w=' + Math.round(node.offsetWidth) + ' h=' + Math.round(node.offsetHeight)); } catch (eL0) {}
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });

  function onMove(e) {
    if (!node) return;
    var id = node.dataset.widget;
    var skey = (board && board.dataset.board ? board.dataset.board + '::' : '') + id;   // ключ размера для этой доски
    var br = board.getBoundingClientRect();
    var nr = node.getBoundingClientRect();
    var bdW = parseFloat(getComputedStyle(node).borderRightWidth) || 0;    // ширина рамки-зазора (0 у виджетов без неё)
    var bdH = parseFloat(getComputedStyle(node).borderBottomWidth) || 0;   // компенсируем, чтобы видимый край плашки шёл ровно за курсором

    // --- ШИРИНА (шаг 5%) --- не даём заехать на соседа: при наложении откатываем
    var pPrev = widgetSizes[skey];
    var p = (e.clientX - nr.left + bdW) / br.width * 100;
    p = Math.round(p / 5) * 5;
    p = Math.max(10, Math.min(100, p));
    widgetSizes[skey] = p;
    applySize(node);
    if (id === 'bezier' && typeof resizeGraph === 'function') resizeGraph();
    if (!startOverlap && overlapsOthers(board, node)) {
      collided = true;
      // не откатываем целиком — ужимаем до ближайшего влезающего размера, чтобы плашка дорастала вплотную (останется только зазор)
      var q = p;
      while (q > 10) {
        q -= 1;
        node.style.width = (q >= 100) ? '100%' : 'calc(' + q + '% - ' + ((100 - q) * 0.1).toFixed(1) + 'px)';
        if (!overlapsOthers(board, node)) break;
      }
      if (q <= 10 && overlapsOthers(board, node)) { if (pPrev === undefined) delete widgetSizes[skey]; else widgetSizes[skey] = pPrev; }
      else { widgetSizes[skey] = q; }
      applySize(node);
      if (id === 'bezier' && typeof resizeGraph === 'function') resizeGraph();
    }

    // --- ВЫСОТА --- (график тоже тянется по вертикали; внутренности подстраиваются)
    var hPrev = widgetHeights[skey];
    var hp = Math.round((e.clientY - nr.top + bdH) / 10) * 10;
    var minH = (id === 'bezier') ? 140 : (node.querySelector('.square-fit') ? 110 : 34);
    if (hp >= minH) {
      widgetHeights[skey] = Math.min(900, hp);
      applySize(node);
      if (id === 'bezier' && typeof resizeGraph === 'function') resizeGraph();
      if (!startOverlap && overlapsOthers(board, node)) {
        collided = true;
        var qh = Math.min(900, hp);
        while (qh - 5 >= minH) {
          qh -= 5;
          node.style.height = qh + 'px';
          if (!overlapsOthers(board, node)) break;
        }
        if (overlapsOthers(board, node)) { if (hPrev === undefined) delete widgetHeights[skey]; else widgetHeights[skey] = hPrev; }
        else { widgetHeights[skey] = qh; }
        applySize(node);
        if (id === 'bezier' && typeof resizeGraph === 'function') resizeGraph();
      }
    }
    if (typeof scaleTool === 'function') scaleTool(node);
    if (typeof fitSquares === 'function') fitSquares();
  }

  function onUp() {
    if (node) {
      node.classList.remove('resizing');
      try {
        var _sk = (board && board.dataset.board ? board.dataset.board + '::' : '') + node.dataset.widget;
        var _fin = wRect(node), _who = '';
        $$('.board > .widget', board).forEach(function (o) { if (o !== node && !_who && wOverlap(_fin, wRect(o))) _who = 'widget ' + o.dataset.widget; });
        $$('.board > .group-box', board).forEach(function (o) { if (o !== node && !o.contains(node) && !_who && wOverlap(_fin, wRect(o))) _who = 'group ' + (o.dataset.gid || '?'); });
        MP_log('resize END id=' + node.dataset.widget +
          ' w=' + (widgetSizes[_sk] !== undefined ? widgetSizes[_sk] + '%' : 'auto') +
          ' h=' + (widgetHeights[_sk] !== undefined ? widgetHeights[_sk] + 'px' : 'auto') +
          ' clamped=' + collided + ' startOverlap=' + startOverlap + ' overlap=' + (_who || 'none'));
      } catch (eLog) {}
      pushOrig = null;
      store.set('widgetSizes', widgetSizes);
      store.set('widgetHeights', widgetHeights);
      var bd = board;
      $$('.board > .widget', bd).forEach(function (o) {
        if (o._px !== undefined) {
          setPos(bd.dataset.board, o.dataset.widget, o._px, o._py);
          delete o._px; delete o._py;
        }
      });
      store.set('widgetPos', widgetPos);
      layoutBoard(bd);
      setTimeout(function () { bd.classList.remove('collide-anim'); }, 200);
    }
    node = null; board = null;
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
  }

  /* двойной клик по уголку — сброс размера к авто */
  document.addEventListener('dblclick', function (e) {
    var h = e.target.closest('.resize-handle');
    if (!h) return;
    var w = h.closest('.widget');
    var b = w.closest('.board');
    var sk = (b && b.dataset.board ? b.dataset.board + '::' : '') + w.dataset.widget;
    delete widgetSizes[sk]; delete widgetHeights[sk];
    delete widgetSizes[w.dataset.widget];
    delete widgetHeights[w.dataset.widget];
    store.set('widgetSizes', widgetSizes);
    store.set('widgetHeights', widgetHeights);
    applySize(w);
    if (typeof resizeGraph === 'function') resizeGraph();
    toast(t('t_size_reset'));
  });
})();

/* ---- drag&drop раскладки ---- */
function setDraggable(on) {
  $$('.tab').forEach(function (t) { t.draggable = on; });
}

function enableReorder(container, itemSelector, onDone) {
  var dragged = null;
  container.addEventListener('dragstart', function (e) {
    var item = e.target.closest(itemSelector);
    if (!item || !document.body.classList.contains('editing')) return;
    dragged = item;
    e.dataTransfer.effectAllowed = 'move';
  });
  container.addEventListener('dragover', function (e) {
    var item = e.target.closest(itemSelector);
    if (!dragged || !item || item === dragged) return;
    e.preventDefault();
    item.classList.add('drag-over');
  });
  container.addEventListener('dragleave', function (e) {
    var item = e.target.closest(itemSelector);
    if (item) item.classList.remove('drag-over');
  });
  container.addEventListener('drop', function (e) {
    var item = e.target.closest(itemSelector);
    if (!dragged || !item || item === dragged) return;
    e.preventDefault();
    item.classList.remove('drag-over');
    var rect = item.getBoundingClientRect();
    var before;
    if (container.id === 'tabs') {
      before = e.clientX < rect.left + rect.width / 2;
    } else {
      // доска с переносом: внутри ряда сравниваем по X, между рядами — по Y
      var inRow = e.clientY >= rect.top && e.clientY <= rect.bottom;
      before = inRow ? (e.clientX < rect.left + rect.width / 2)
                     : (e.clientY < rect.top + rect.height / 2);
    }
    container.insertBefore(dragged, before ? item : item.nextSibling);
    dragged = null;
    if (onDone) onDone();
  });
}

enableReorder($('#tabs'), '.tab', function () {
  store.set('tabOrder', $$('.tab').map(function (t) { return t.dataset.tab; }));
});

/* ---- свободное перемещение по доске + объединение в группы через candidate-пайплайн ----
   Перемещение: плашка поднимается над остальными (z-index), едет за курсором с учётом offset клика,
                соседи плавно расступаются «ровно на место» (с учётом колонок). Позиция пишется в state.
   Группировка (как папка на телефоне): пересечение → score → порог 35% (или центр внутри) →
                выдержка наведения ~320мс → фиксация кандидата (с гистерезисом против мигания) →
                группа создаётся ТОЛЬКО на отпускании. Быстрый проход поверх — НЕ группирует. */
(function () {
  var dragEl = null, board = null, page = '', ghost = null, kind = '';
  var startX = 0, startY = 0, offX = 0, offY = 0, w0 = 0, h0 = 0, started = false, wasMember = false, srcGid = '';
  var snapX = 0, snapY = 0, bw = 1, snap = null, gsnap = null, srcRect = null, lastPos = null, lastPosG = null;
  var curCand = null, confirmed = false, hoverTimer = null;
  var GAPV = 8, THRESH = 0.35, HOVER = 320, HYST = 0.12;

  document.addEventListener('mousedown', function (e) {
    if (e.button !== undefined && e.button !== 0) return;          // только ЛКМ (ПКМ — меню цвета)
    if (!document.body.classList.contains('editing')) return;
    if (e.target.closest('.resize-handle') || e.target.closest('.w-remove') ||
        e.target.closest('.group-resize') || e.target.closest('.group-del') ||
        e.target.closest('.group-collapse')) return;
    var nm = e.target.closest('.group-name'); if (nm && nm.isContentEditable) return;
    var gHead = e.target.closest('.group-head'), memberW = e.target.closest('.group-body .widget'), topW = e.target.closest('.board > .widget');
    if (memberW) { dragEl = memberW; kind = 'widget'; wasMember = true; }
    else if (gHead) { dragEl = gHead.closest('.group-box'); kind = 'group'; wasMember = false; }
    else if (topW) { dragEl = topW; kind = 'widget'; wasMember = false; }
    else { dragEl = null; return; }
    board = dragEl.closest('.board'); if (!board) { dragEl = null; return; }
    if (board.classList.contains('stack')) { dragEl = null; return; }   // блочная вкладка: перестановка отдельным обработчиком (ниже)
    page = board.dataset.board; startX = e.clientX; startY = e.clientY; started = false;
    curCand = null; confirmed = false; srcGid = '';
    if (wasMember) { var gb0 = dragEl.closest('.group-box'); if (gb0) srcGid = gb0.dataset.gid; }
    var r = dragEl.getBoundingClientRect(); offX = e.clientX - r.left; offY = e.clientY - r.top; w0 = r.width; h0 = r.height;
    e.preventDefault();
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });
  // безопасный сброс drag (потеря фокуса/прерывание указателя) — не оставляем зависшего состояния
  window.addEventListener('pointercancel', cancelDrag);
  window.addEventListener('blur', cancelDrag);

  function begin() {
    started = true;
    var _br = board.getBoundingClientRect(), _dr = dragEl.getBoundingClientRect();   // исходная клетка ДО подъёма/выноса
    srcRect = { l: _dr.left - _br.left, t: _dr.top - _br.top, w: _dr.width, h: _dr.height };   // и для плашки, и для группы — нужно для возврата
    if (kind === 'widget' && wasMember) { removeFromGroups(page, dragEl.dataset.widget); dragEl.classList.remove('in-group'); board.appendChild(dragEl); applySize(dragEl); }
    bw = board.clientWidth || 1;
    snap = {};
    $$('.board > .widget', board).forEach(function (o) { if (o === dragEl) return; snap[o.dataset.widget] = { el: o, l: o.offsetLeft, t: o.offsetTop, w: o.offsetWidth, h: o.offsetHeight }; });
    gsnap = {};
    $$('.board > .group-box', board).forEach(function (gb) { if (gb === dragEl) return; gsnap[gb.dataset.gid] = { el: gb, l: gb.offsetLeft, t: gb.offsetTop, w: gb.offsetWidth, h: gb.offsetHeight }; });
    var rr = dragEl.getBoundingClientRect(); w0 = rr.width; h0 = rr.height;
    ghost = document.createElement('div'); ghost.className = 'drag-ghost'; ghost.style.width = w0 + 'px'; ghost.style.height = h0 + 'px'; board.appendChild(ghost);
    dragEl.classList.add('flow-dragging'); dragEl.style.width = w0 + 'px'; dragEl.style.height = h0 + 'px';   // .flow-dragging = position:fixed, z-index:9999
    document.body.classList.add('flow-sorting');
  }

  function computeSnap(e) {
    var br = board.getBoundingClientRect();
    var x = (e.clientX - offX - br.left) / bw * 100; x = Math.round(x / 2.5) * 2.5;
    var wPct = w0 / bw * 100; x = Math.max(0, Math.min(100 - wPct, x));
    var y = Math.max(0, Math.round((e.clientY - offY - br.top) / 10) * 10);
    snapX = x; snapY = y;
  }
  function ghostVP() { var br = board.getBoundingClientRect(); var l = br.left + snapX / 100 * bw, t = br.top + snapY; return { left: l, top: t, right: l + w0, bottom: t + h0, cx: l + w0 / 2, cy: t + h0 / 2 }; }
  function resetOthers() {
    lastPos = null; lastPosG = null;
    if (snap) Object.keys(snap).forEach(function (id) { var s = snap[id]; s.el.style.left = (s.l / bw * 100) + '%'; s.el.style.top = s.t + 'px'; });
    if (gsnap) Object.keys(gsnap).forEach(function (gid) { var s = gsnap[gid]; s.el.style.top = s.t + 'px'; });
  }
  function ghostShow(on) { if (!ghost) return; ghost.style.display = on ? 'block' : 'none'; if (on) { ghost.style.left = snapX + '%'; ghost.style.top = snapY + 'px'; } }

  /* ---------- candidate-пайплайн ---------- */
  function rectInter(a, b) { var l = Math.max(a.left, b.left), t = Math.max(a.top, b.top), r = Math.min(a.right, b.right), bt = Math.min(a.bottom, b.bottom); if (r <= l || bt <= t) return 0; return (r - l) * (bt - t); }
  // эффективный score плашки/группы относительно «призрака» (центр внутри даёт пол 0.5)
  function scoreOf(el) {
    var v = ghostVP(), r = el.getBoundingClientRect();
    var area = (v.right - v.left) * (v.bottom - v.top) || 1;
    var sc = rectInter(v, r) / area;
    var centerIn = v.cx >= r.left && v.cx <= r.right && v.cy >= r.top && v.cy <= r.bottom;
    return centerIn ? Math.max(sc, 0.5) : sc;
  }
  // лучший валидный target (плашка → новая группа, либо группа → добавить); только для перетаскивания плашки-инструмента
  function findCandidate() {
    if (kind !== 'widget' || !dragEl.classList.contains('tool') || dragEl.classList.contains('wide')) return null; // group+item/group+group/широкие — нельзя
    var did = dragEl.dataset.widget, best = null, bestScore = THRESH;
    $$('.board > .widget.tool', board).forEach(function (o) {                 // item + item
      if (o === dragEl || o.classList.contains('wide')) return;               // не сам с собой, не широкие
      var s = scoreOf(o); if (s >= bestScore + 1e-6 || (s >= THRESH && !best)) { if (s >= THRESH && s > bestScore - 1e-6) { bestScore = s; best = { el: o, type: 'tile', score: s }; } }
    });
    $$('.board > .group-box', board).forEach(function (gb) {                   // item + существующая группа
      if (gb === dragEl) return;
      if (gb.dataset.gid === srcGid) return;                                   // нельзя вернуть в ту же группу, откуда тянем
      var g = groupById(page, gb.dataset.gid); if (g && g.members.indexOf(did) !== -1) return; // уже в этой группе
      var s = scoreOf(gb); if (s >= THRESH && s > bestScore - 1e-6) { bestScore = s; best = { el: gb, type: 'group', score: s }; }
    });
    return best;
  }
  function candVisual(c, ready) {
    c.el.classList.remove('group-merge', 'group-drop', 'cand-ready');
    c.el.classList.add(c.type === 'group' ? 'group-drop' : 'group-merge');
    if (ready) c.el.classList.add('cand-ready');
  }
  function clearCandVisual() { if (curCand && curCand.el) curCand.el.classList.remove('group-merge', 'group-drop', 'cand-ready'); }
  function clearCandidate() { if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; } clearCandVisual(); curCand = null; confirmed = false; }
  function fixateAfterHover() {
    hoverTimer = setTimeout(function () {            // выдержка наведения прошла → кандидат подтверждён
      confirmed = true; if (curCand) candVisual(curCand, true);
      resetOthers(); ghostShow(false);
    }, HOVER);
  }
  function switchTo(c) { clearCandVisual(); if (hoverTimer) clearTimeout(hoverTimer); curCand = c; confirmed = false; candVisual(c, false); fixateAfterHover(); }
  function updateCandidate() {
    var best = findCandidate();
    if (curCand) {
      var cs = document.body.contains(curCand.el) ? scoreOf(curCand.el) : 0;
      if (cs < THRESH) { clearCandidate(); }                                   // ушли с кандидата → сброс
      else {
        curCand.score = cs;
        if (best && best.el !== curCand.el && best.score > cs + HYST) switchTo(best); // меняем только если заметно лучше (гистерезис)
        return;
      }
    }
    if (best) switchTo(best);
  }

  /* относительный сдвиг-перестановка: сосед двигается ТОЛЬКО если перетаскиваемая плашка реально
     прошла мимо него по вертикали (между исходной клеткой и точкой вставки). В момент старта (точка
     вставки ≈ исходная клетка) полоса пуста — никто не двигается. Колонка значения не имеет. */
  function reorderShift() {
    var iy = snapY + h0 / 2, shift = h0 + GAPV, sCy = srcRect ? (srcRect.t + srcRect.h / 2) : null;
    lastPos = {}; lastPosG = {};
    function ny(t, h) {
      if (sCy === null) return t;
      var c = t + h / 2;
      if (iy < sCy) { if (c > iy && c < sCy) return Math.max(0, t + shift); }
      else if (iy > sCy) { if (c > sCy && c < iy) return Math.max(0, t - shift); }
      return t;
    }
    Object.keys(snap).forEach(function (id) { var s = snap[id]; var y = ny(s.t, s.h); lastPos[id] = { x: s.l / bw * 100, y: y }; s.el.style.left = lastPos[id].x + '%'; s.el.style.top = y + 'px'; });
    Object.keys(gsnap).forEach(function (gid) { var s = gsnap[gid]; var y = ny(s.t, s.h); lastPosG[gid] = y; s.el.style.top = y + 'px'; });
  }

  function onMove(e) {
    if (!dragEl) return;
    if (!started) { if (Math.abs(e.clientX - startX) < 5 && Math.abs(e.clientY - startY) < 5) return; begin(); }
    dragEl.style.left = (e.clientX - offX) + 'px';
    dragEl.style.top = (e.clientY - offY) + 'px';
    computeSnap(e);
    if (kind === 'group') { ghostShow(true); return; }     // группа двигается свободно как единый объект
    updateCandidate();
    ghostShow(!confirmed);                                  // соседей НЕ трогаем; призрак прячем когда кандидат подтверждён (будет группа)
  }

  function setElInstant(el, leftPct, topPx) { el.style.transition = 'none'; el.style.left = leftPct + '%'; el.style.top = topPx + 'px'; void el.offsetHeight; el.style.transition = ''; }

  function onUp() {
    if (!dragEl) { cleanup(); return; }
    if (!started) { clearCandidate(); cleanup(); return; }
    var el = dragEl, id = el.dataset.widget;
    var op = (kind === 'widget' && curCand && confirmed) ? { type: curCand.type === 'group' ? 'add' : 'new', el: curCand.el } : null;
    el.classList.remove('flow-dragging'); el.style.width = ''; el.style.height = '';
    clearCandidate();

    if (kind === 'group') {                                  // отпускаем группу — ровно как плашку: магнит + коллизии + возврат
      var g2 = groupById(page, el.dataset.gid);
      el.style.left = ''; el.style.top = '';
      if (g2) {
        var bwG = board.clientWidth || board.offsetWidth || 1;
        var rawLg = snapX / 100 * bwG, rawTg = snapY;
        var mgG = magnetGap(board, el, rawLg, rawTg);        // магнит учитывает и плашки, и другие группы
        var uLg = null, uTg = null, howG = '';
        if (canPlaceAt(board, el, mgG.l, mgG.t)) { uLg = mgG.l; uTg = mgG.t; howG = 'magnet'; }
        else if (canPlaceAt(board, el, rawLg, rawTg)) { uLg = rawLg; uTg = rawTg; howG = 'raw'; }
        if (uLg === null) {                                  // упёрлись в край — вписать в доску
          var ewG = el.offsetWidth, cLg = Math.max(0, Math.min(rawLg, bwG - ewG)), cTg = Math.max(0, rawTg);
          if (canPlaceAt(board, el, cLg, cTg)) { uLg = cLg; uTg = cTg; howG = 'clamp-edge'; }
        }
        if (uLg !== null) { g2.x = uLg / bwG * 100; g2.y = uTg; MP_log('drop group gid=' + el.dataset.gid + ' -> PLACE [' + howG + '] l=' + Math.round(uLg) + ' t=' + Math.round(uTg)); }
        else if (srcRect) { g2.x = srcRect.l / bwG * 100; g2.y = srcRect.t; MP_log('drop group gid=' + el.dataset.gid + ' -> REVERT [' + MP_placeWhy + ']'); }
        else { g2.x = snapX; g2.y = snapY; }
        saveGroups();
      }
      renderBoards(); cleanup(); return;
    }
    applySize(el);

    if (op && op.type === 'add') {                           // item → существующая группа
      var gid = op.el.dataset.gid; removeFromGroups(page, id);
      var g = groupById(page, gid);
      if (g && g.members.indexOf(id) === -1) g.members.push(id);
      if (g) delete g.cols;                                   // состав изменился — пересчитать колонки (правка 3)
      if (el.classList.contains('wide') && g) { g.autosize = false; if (!g.w || g.w < 60) g.w = 60; }
      if (widgetPos[page]) delete widgetPos[page][id];
      saveGroups();
    } else if (op && op.type === 'new') {                    // item + item → новая группа
      var tid = op.el.dataset.widget;
      var gx = parseFloat(op.el.style.left) || 0, gy = parseInt(op.el.style.top, 10) || 0;
      var gs = groupsFor(page), num = 1;
      gs.forEach(function (gg) { var m = /^группа\s+(\d+)$/i.exec(gg.name || ''); if (m && +m[1] >= num) num = +m[1] + 1; });
      removeFromGroups(page, id); removeFromGroups(page, tid);
      gs.push({ gid: 'g' + Date.now(), name: 'группа ' + num, color: '', members: [tid, id], collapsed: false, x: gx, y: gy, w: 40, autosize: true });
      if (widgetPos[page]) { delete widgetPos[page][id]; delete widgetPos[page][tid]; }
      saveGroups();
    } else {                                                 // свободно: магнит → если влез; иначе точка сброса → если влезла; иначе ВОЗВРАТ
      var bwL = board.clientWidth || board.offsetWidth || 1;
      var rawL = snapX / 100 * bwL, rawT = snapY;
      var mg = magnetGap(board, el, rawL, rawT);
      var useL = null, useT = null, how = '';
      if (canPlaceAt(board, el, mg.l, mg.t)) { useL = mg.l; useT = mg.t; how = 'magnet'; }
      else {
        var why1 = MP_placeWhy;                              // магнит влетел в наложение — пробуем ровно куда бросил
        if (canPlaceAt(board, el, rawL, rawT)) { useL = rawL; useT = rawT; how = 'raw (magnet blocked: ' + why1 + ')'; }
      }
      if (useL === null) {                                   // упёрлось в край — вписать в доску (а не возвращать)
        var ew = el.offsetWidth;
        var cL = Math.max(0, Math.min(rawL, bwL - ew)), cT = Math.max(0, rawT);
        if ((cL !== rawL || cT !== rawT) && canPlaceAt(board, el, cL, cT)) { useL = cL; useT = cT; how = 'clamp-edge'; }
      }
      if (useL !== null) {
        var pct = useL / bwL * 100;
        MP_log('drop free id=' + id + ' x=' + snapX + '% y=' + snapY + ' -> PLACE [' + how + '] l=' + Math.round(useL) + ' t=' + Math.round(useT) + ' bw=' + Math.round(bwL));
        setElInstant(el, pct, useT); setPos(page, id, pct, useT);
      } else if (srcRect) {
        MP_log('drop free id=' + id + ' x=' + snapX + '% y=' + snapY + ' -> REVERT [' + MP_placeWhy + '] to l=' + Math.round(srcRect.l) + ' t=' + Math.round(srcRect.t) + ' bw=' + Math.round(bwL));
        var rx = srcRect.l / bwL * 100; setElInstant(el, rx, srcRect.t); setPos(page, id, rx, srcRect.t);
      } else {
        var pct2 = rawL / bwL * 100; setElInstant(el, pct2, rawT); setPos(page, id, pct2, rawT);
      }
    }
    store.set('widgetPos', widgetPos);
    var dis = dissolveSmallGroups(page);                     // источник, откуда вынесли плашку, мог осиротеть
    if (op || wasMember || dis) renderBoards(); else layoutBoard(board);
    cleanup();
  }

  function cancelDrag() {
    if (!dragEl) return;
    clearCandidate();
    if (ghost && ghost.parentNode) ghost.parentNode.removeChild(ghost); ghost = null;
    document.body.classList.remove('flow-sorting');
    var wasStarted = started;
    cleanup();
    if (wasStarted) renderBoards();                          // вернуть всё из state, без зависшего dragging
  }

  function cleanup() {
    if (ghost && ghost.parentNode) ghost.parentNode.removeChild(ghost); ghost = null;
    document.body.classList.remove('flow-sorting');
    if (dragEl) dragEl.classList.remove('flow-dragging');
    dragEl = null; board = null; started = false; wasMember = false; kind = ''; srcGid = '';
    snap = null; gsnap = null; srcRect = null; lastPos = null; lastPosG = null;
    curCand = null; confirmed = false; if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; }
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
  }
})();

/* ===== блочные вкладки (палитры/график/выражения): перестановка блоков стопкой =====
   свободного перемещения и ресайза нет — блоки во всю ширину, только смена порядка вверх/вниз */
(function () {
  var dragEl = null, board = null, page = '';
  function stop() { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); }
  document.addEventListener('mousedown', function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    if (!document.body.classList.contains('editing')) return;
    if (e.target.closest('.resize-handle') || e.target.closest('.w-remove')) return;
    var w = e.target.closest('.widget');
    if (!w) return;
    var bd = w.closest('.board');
    if (!bd || !bd.classList.contains('stack') || w.parentElement !== bd) return;   // только прямой блок блочной вкладки
    board = bd; page = bd.dataset.board; dragEl = w;
    e.preventDefault();
    dragEl.classList.add('sort-lift');
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });
  function onMove(e) {
    if (!dragEl) return;
    var sibs = [];
    for (var i = 0; i < board.children.length; i++) {
      var c = board.children[i];
      if (c.classList && c.classList.contains('widget') && c !== dragEl) sibs.push(c);
    }
    var before = null;
    for (var j = 0; j < sibs.length; j++) {
      var r = sibs[j].getBoundingClientRect();
      var inRow = e.clientY < r.bottom;
      if (e.clientY < r.top || (inRow && e.clientX < r.left + r.width / 2)) { before = sibs[j]; break; }   // порядок чтения: сверху-вниз, слева-направо
    }
    if (before) { if (dragEl.nextElementSibling !== before) board.insertBefore(dragEl, before); }
    else board.appendChild(dragEl);   // позже/ниже всех — в конец
  }
  function onUp() {
    stop();
    if (dragEl) {
      dragEl.classList.remove('sort-lift');
      var order = [];
      for (var i = 0; i < board.children.length; i++) {
        var c = board.children[i];
        if (c.classList && c.classList.contains('widget') && c.dataset.widget) order.push(c.dataset.widget);
      }
      (boards[page] || []).forEach(function (id) { if (order.indexOf(id) === -1) order.push(id); });   // скрытые/выключенные не теряем
      boards[page] = order; saveBoards();
    }
    dragEl = null; board = null; page = '';
    renderBoards();
  }
  window.addEventListener('blur', function () { if (dragEl) { dragEl.classList.remove('sort-lift'); dragEl = null; board = null; page = ''; stop(); } });
})();

function applyTabOrder() {
  var tabOrder = store.get('tabOrder', null);
  var tabs = $('#tabs');
  if (!tabs) return;
  if (tabOrder) {
    tabOrder.forEach(function (name) {
      var t = $('.tab[data-tab="' + name + '"]');
      if (t) tabs.appendChild(t);
    });
  }
  $$('.tab', tabs).forEach(function (t) {                // вкладки не из сохранённого порядка — в конец
    if (!tabOrder || tabOrder.indexOf(t.dataset.tab) === -1) tabs.appendChild(t);
  });
}
applyTabOrder();

/* ============================================================
   ANCHOR POINT
============================================================ */
$('#nullBtn').addEventListener('click', function (e) {
  var mode = e.altKey ? 'alt' : (e.shiftKey ? 'shift' : 'click');
  cs.evalScript('MP_addNull("' + mode + '")', function (res) {
    handleHostResult(res, t('t_null'));
  });
});

$('#unprecompBtn').addEventListener('click', function () {
  cs.evalScript('MP_unprecomp()', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t('t_unprecomp') + res.slice(3)); return; }
    handleHostResult(res, t('t_done'));
  });
});

$('#dupBtn').addEventListener('click', function (e) {
  var replace = !!e.shiftKey;
  cs.evalScript('MP_duplicateComp(' + replace + ')', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t(replace ? 't_dup_repl' : 't_dup', res.slice(3))); return; }
    handleHostResult(res, t('t_done'));
  });
});

$('#fitBtn').addEventListener('click', function (e) {
  var stretchKeys = !!e.shiftKey;   // Shift — растянуть и ключи (старое поведение); обычный клик — только тайминг слоёв, ключи на месте
  cs.evalScript('MP_fitPrecomp(' + stretchKeys + ')', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t('t_fit', res.slice(3))); return; }
    handleHostResult(res, t('t_done'));
  });
});

$('#up4kBtn').addEventListener('click', function () {
  cs.evalScript('MP_upscale4K()', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t('t_up4k', res.slice(3))); return; }
    handleHostResult(res, t('t_done'));
  });
});

/* ===== Sort: настройки проекта + запуск ===== */
var SORT_DEF = { comps: 'Comps', audio: 'Audio', video: 'Video', images: 'Images', old: 'Old Folders', aipsd: 'AI & PSD', nullssolids: 'Nulls & Solids', missing: 'Missing Content', removeOld: false, removeUnused: false, selectedOnly: false, subByExt: false, ignore: '' };
function sortCfg() { var c = store.get('sortCfg', null) || {}; var out = {}; for (var k in SORT_DEF) out[k] = (c[k] !== undefined ? c[k] : SORT_DEF[k]); return out; }
function saveSortCfg(c) { store.set('sortCfg', c); }
function sortTrim(s) { return String(s == null ? '' : s).replace(/^\s+|\s+$/g, ''); }
function runSort() {
  var cfg = sortCfg();
  var arg = JSON.stringify(JSON.stringify(cfg));   // двойная упаковка: ExtendScript получит JSON-строку
  cs.evalScript('MP_sortProject(' + arg + ')', function (res) {
    if (res && res.indexOf('ok:') === 0) { var pr = res.slice(3).split('/'); toast(t('t_sort', pr[0] || '0', pr[1] || '0')); return; }
    handleHostResult(res, t('t_done'));
  });
}
var SORT_FIELDS = { comps: '#srtComps', audio: '#srtAudio', video: '#srtVideo', images: '#srtImages', aipsd: '#srtAiPsd', nullssolids: '#srtNS', missing: '#srtMissing', old: '#srtOld', ignore: '#srtIgnore' };
var SORT_TOGGLES = { removeOld: '#srtRemoveOld', removeUnused: '#srtRemoveUnused', selectedOnly: '#srtSelectedOnly', subByExt: '#srtSubExt' };
function fillSortForm() {
  var c = sortCfg();
  for (var k in SORT_FIELDS) { var el = $(SORT_FIELDS[k]); if (el) el.value = c[k] || ''; }
  for (var g in SORT_TOGGLES) { var el2 = $(SORT_TOGGLES[g]); if (el2) el2.checked = !!c[g]; }
}
function readSortForm() {
  var c = sortCfg();
  for (var k in SORT_FIELDS) { var el = $(SORT_FIELDS[k]); if (el) c[k] = sortTrim(el.value); }
  for (var g in SORT_TOGGLES) { var el2 = $(SORT_TOGGLES[g]); if (el2) c[g] = !!el2.checked; }
  saveSortCfg(c); return c;
}
(function () {
  var ov = $('#sortOverlay');
  var sb = $('#sortBtn'); if (sb) sb.addEventListener('click', function () { runSort(); });
  var ss = $('#sortSetBtn'); if (ss) ss.addEventListener('click', function () { fillSortForm(); if (ov) ov.hidden = false; });
  var cl = $('#srtClose'); if (cl) cl.addEventListener('click', function () { readSortForm(); if (ov) ov.hidden = true; });
  if (ov) ov.addEventListener('click', function (e) { if (e.target === ov) { readSortForm(); ov.hidden = true; } });
  var sv = $('#srtSave'); if (sv) sv.addEventListener('click', function () { readSortForm(); toast(t('t_sortsaved')); });
  var rn = $('#srtRun'); if (rn) rn.addEventListener('click', function () { readSortForm(); runSort(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && ov && !ov.hidden) { readSortForm(); ov.hidden = true; } });
})();

(function () {
  var ap = $('#stagApply');
  if (!ap) return;
  var DIR_ORDER = ['top', 'bottom', 'random'];
  var DIR_ICON = {
    top: '<svg viewBox="0 0 24 24"><rect x="4" y="6" width="8" height="2.6" fill="currentColor"/><rect x="4" y="10.7" width="12" height="2.6" fill="currentColor"/><rect x="4" y="15.4" width="16" height="2.6" fill="currentColor"/></svg>',
    bottom: '<svg viewBox="0 0 24 24"><rect x="4" y="6" width="16" height="2.6" fill="currentColor"/><rect x="4" y="10.7" width="12" height="2.6" fill="currentColor"/><rect x="4" y="15.4" width="8" height="2.6" fill="currentColor"/></svg>',
    random: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h3l10 12h3"/><path d="M4 18h3l3-3.5"/><path d="M14 9.5l3-3.5h3"/><path d="M18 3l3 3-3 3"/><path d="M18 15l3 3-3 3"/></svg>'
  };
  var stagDir = store.get('stagDir', 'top');
  if (DIR_ORDER.indexOf(stagDir) === -1) stagDir = 'top';
  var dirBtn = $('#stagDir');
  function paintDir() { if (dirBtn) dirBtn.innerHTML = DIR_ICON[stagDir]; }
  paintDir();
  if (dirBtn) dirBtn.addEventListener('click', function () {
    stagDir = DIR_ORDER[(DIR_ORDER.indexOf(stagDir) + 1) % DIR_ORDER.length];
    store.set('stagDir', stagDir); paintDir();
  });
  ap.addEventListener('click', function () {
    var amt = Math.max(1, parseInt(($('#stagAmount') || {}).value, 10) || 1);
    var stp = parseInt(($('#stagStep') || {}).value, 10); if (isNaN(stp)) stp = 1;
    cs.evalScript('MP_stagger(' + amt + ',' + stp + ',"' + stagDir + '")', function (res) {
      if (res === 'nosel') { toast(t('t_nosel_layers')); return; }
      if (res && res.indexOf('ok:') === 0) { toast(t('t_stagger', res.slice(3))); return; }
      handleHostResult(res, t('t_done'));
    });
  });
  var phBtn = $('#stagPlayhead');
  if (phBtn) phBtn.addEventListener('click', function () {
    cs.evalScript('MP_arrangeToPlayhead()', function (res) {
      if (res === 'nosel') { toast(t('t_nosel_layers')); return; }
      if (res && res.indexOf('ok:') === 0) { toast(t('t_stag_playhead', res.slice(3))); return; }
      handleHostResult(res, t('t_done'));
    });
  });
  var rvBtn = $('#stagReverse');
  if (rvBtn) rvBtn.addEventListener('click', function () {
    cs.evalScript('MP_reverseStack()', function (res) {
      if (res === 'nosel') { toast(t('t_nosel_layers')); return; }
      if (res && res.indexOf('ok:') === 0) { toast(t('t_stag_reverse', res.slice(3))); return; }
      handleHostResult(res, t('t_done'));
    });
  });
})();

$('#addLimbBtn').addEventListener('click', function () {
  cs.evalScript('MP_addLimb()', function (res) {
    handleHostResult(res, t('t_limb'));
  });
});

$('#elasticBtn').addEventListener('click', function (e) {
  MP_log('Elastic ▶ MP_elastic("click")');
  cs.evalScript('MP_elastic("click")', function (res) {
    MP_log('Elastic ◀ ' + res);
    var head = String(res).split(' §')[0];
    if (head === 'noprops') { toast(t('t_noprops')); return; }
    if (head.indexOf('ok:') === 0) { toast(t('t_elastic', head.slice(3))); return; }
    handleHostResult(head, t('t_elastic', '?'));
  });
});

$('#bounceBtn').addEventListener('click', function (e) {
  MP_log('Bounce ▶ MP_bounce("click")');
  cs.evalScript('MP_bounce("click")', function (res) {
    MP_log('Bounce ◀ ' + res);
    var head = String(res).split(' §')[0];
    if (head === 'noprops') { toast(t('t_noprops')); return; }
    if (head.indexOf('ok:') === 0) { toast(t('t_bounce', head.slice(3))); return; }
    handleHostResult(head, t('t_bounce', '?'));
  });
});

$('#anchorGrid').addEventListener('click', function (e) {
  var btn = e.target.closest('button');
  if (!btn) return;
  cs.evalScript('MP_setAnchor(' + btn.dataset.ax + ',' + btn.dataset.ay + ')', function (res) {
    handleHostResult(res, t('t_anchor'));
  });
});

/* ============================================================
   ПАЛИТРЫ
============================================================ */
var palettes = store.get('palettes', [{ name: '#1 palette', colors: [null, null] }]);
var PAL_SIZES = ['s', 'm', 'l'];
var paletteSizes = store.get('paletteSizes', null) || {};   // {board: 's'|'m'|'l'} — высота свотчей отдельно на каждой вкладке
var _palDefault = store.get('paletteSize', 'm');            // старое глобальное значение — как дефолт при первом запуске
/* на какой доске сейчас находится виджет палитры.
   Видимая палитра всегда на активной вкладке — берём её напрямую, чтобы размер
   не зависел от момента вставки узла в DOM (раньше closest('.board') мог давать
   устаревшую/чужую доску во время перерисовки → размер «сбрасывался»). */
function curPalBoard() {
  var ap = $('.page.active');
  if (ap && ap.dataset.page) return ap.dataset.page;
  var n = widgetNode('palettes');
  if (n) { var b = n.closest('.board'); if (b) return b.dataset.board; }
  return 'palettes';
}
function palSize() { return paletteSizes[curPalBoard()] || _palDefault || 'm'; }
/* применить высоту свотчей текущей доски к списку + ползунку (без полной перерисовки) */
function applyPalSize() {
  var list = $('#paletteList'); if (list) list.className = 'psize-' + palSize();
  var sl = $('#palSizeSlider'); if (sl) { var i = PAL_SIZES.indexOf(palSize()); sl.value = i < 0 ? 1 : i; }
}
var palSwapFrom = null; // {pi, ci} перетаскиваемый свотч
var palRenaming = -1;   // индекс палитры в режиме переименования

function startPaletteRename(pi, spanEl) {
  if (palRenaming === pi) return;
  palRenaming = pi;
  var inp = document.createElement('input');
  inp.className = 'palette-name-input';
  inp.value = palettes[pi].name;
  inp.maxLength = 40;
  spanEl.replaceWith(inp);
  inp.focus(); inp.select();
  function commit() {
    var v = inp.value.trim();
    if (v) palettes[pi].name = v;
    palRenaming = -1;
    savePalettes(); renderPalettes();
  }
  inp.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') commit();
    if (e.key === 'Escape') { palRenaming = -1; renderPalettes(); }
  });
  inp.addEventListener('blur', commit);
  inp.addEventListener('click', function (e) { e.stopPropagation(); });
}
function savePalettes() { store.set('palettes', palettes); }

function renderPalettes() {
  var list = $('#paletteList');
  list.className = 'psize-' + palSize();
  list.innerHTML = '';
  palettes.forEach(function (pal, pi) {
    var el = document.createElement('div');
    el.className = 'palette';

    var row = document.createElement('div');
    row.style.display = 'flex'; row.style.alignItems = 'stretch';

    var swRow = document.createElement('div');
    swRow.className = 'swatch-row';
    swRow.style.flex = '1';

    pal.colors.forEach(function (c, ci) {
      var sw = document.createElement('button');
      if (c) {
        sw.className = 'swatch filled';
        sw.style.background = '#' + c;
        sw.dataset.hex = '#' + c;
        sw.title = '#' + c + ' — ' + t('sw_title');
        sw.addEventListener('click', function (e) {
          if (e.altKey || !cs.isCEP()) { copyHex(c); return; }
          var toStroke = e.shiftKey;
          cs.evalScript('MP_applyColor("' + c + '","' + (toStroke ? 'stroke' : 'fill') + '")', function (res) {
            if (res === 'nosel') { copyHex(c); return; }
            if (res === 'nostroke') { toast(t('t_no_stroke')); return; }
            if (res && res.indexOf('ok:') === 0) {
              toast(t(toStroke ? 't_color_applied_stroke' : 't_color_applied', res.slice(3)));
              return;
            }
            handleHostResult(res, t('t_done'));
          });
        });
        sw.addEventListener('contextmenu', function (e) {
          e.preventDefault();
          e.stopPropagation();   // не пускаем к общему обработчику цвета виджета
          openColorPicker(c, function (hex) {
            palettes[pi].colors[ci] = hex;
            savePalettes(); renderPalettes();
          });
        });
        var del = document.createElement('span');         // крестик — удалить этот цвет
        del.className = 'sw-del';
        del.textContent = '✕';
        del.title = t('sw_del');
        (function (delCi) {
          del.addEventListener('click', function (e) {
            e.stopPropagation();
            palettes[pi].colors.splice(delCi, 1);
            if (!palettes[pi].colors.length) palettes[pi].colors.push(null);
            savePalettes(); renderPalettes();
          });
          del.addEventListener('mousedown', function (e) { e.stopPropagation(); });
        })(ci);
        sw.appendChild(del);
      } else {
        sw.className = 'swatch empty';
        sw.textContent = '+';
        sw.title = 'Добавить цвет';
        sw.addEventListener('click', function () {
          openColorPicker(null, function (hex) {
            palettes[pi].colors[ci] = hex;
            savePalettes(); renderPalettes();
          });
        });
      }
      sw.draggable = true;
      sw.dataset.ci = ci;
      sw.addEventListener('dragstart', function (e) {
        palSwapFrom = { pi: pi, ci: +sw.dataset.ci };
        e.dataTransfer.effectAllowed = 'move';
      });
      sw.addEventListener('dragover', function (e) {
        if (!palSwapFrom || palSwapFrom.pi !== pi || palSwapFrom.ci === +sw.dataset.ci) return;
        e.preventDefault();
        sw.classList.add('sw-over');
      });
      sw.addEventListener('dragleave', function () { sw.classList.remove('sw-over'); });
      sw.addEventListener('drop', function (e) {
        e.preventDefault();
        sw.classList.remove('sw-over');
        if (!palSwapFrom || palSwapFrom.pi !== pi) { palSwapFrom = null; return; }
        var from = palSwapFrom.ci, to = +sw.dataset.ci;
        palSwapFrom = null;
        if (from === to) return;
        var arr = palettes[pi].colors;
        var moved = arr.splice(from, 1)[0];
        arr.splice(to, 0, moved);
        savePalettes(); renderPalettes();
      });
      sw.addEventListener('dragend', function () { palSwapFrom = null; });
      swRow.appendChild(sw);
    });

    var mini = document.createElement('button');
    mini.className = 'mini-plus';
    mini.textContent = '+';
    mini.setAttribute('data-tip', t('tip_miniplus'));
    mini.addEventListener('click', function () {
      pal.colors.push(null);
      savePalettes(); renderPalettes();
    });

    row.appendChild(swRow);
    row.appendChild(mini);
    el.appendChild(row);

    var foot = document.createElement('div');
    foot.className = 'palette-foot';
    var name = document.createElement('span');
    name.className = 'palette-name';
    name.textContent = pal.name;
    name.title = t('pal_rename_hint');
    name.addEventListener('click', function (ev) {
      ev.stopPropagation();
      startPaletteRename(pi, name);
    });
    var menu = document.createElement('button');
    menu.className = 'palette-menu';
    menu.textContent = '•••';
    menu.setAttribute('data-tip', t('tip_palmenu'));
    menu.addEventListener('click', function (e) {
      e.stopPropagation();
      openCtxMenu(pi, menu);
    });
    foot.appendChild(name); foot.appendChild(menu);
    el.appendChild(foot);

    list.appendChild(el);
  });
}

function copyHex(hex) {
  var v = '#' + hex;
  try {
    var ta = document.createElement('textarea');
    ta.value = v; document.body.appendChild(ta);
    ta.select(); document.execCommand('copy');
    document.body.removeChild(ta);
    toast(t('t_copied', v));
  } catch (e) { toast(v); }
}

$('#addPalette').addEventListener('click', function () {
  palettes.push({ name: '#' + (palettes.length + 1) + ' palette', colors: [null, null] });
  savePalettes(); renderPalettes();
});

var palSizeSlider = $('#palSizeSlider');
if (palSizeSlider) {
  var _psi = PAL_SIZES.indexOf(palSize());
  palSizeSlider.value = _psi < 0 ? 1 : _psi;
  palSizeSlider.addEventListener('input', function () {
    paletteSizes[curPalBoard()] = PAL_SIZES[+this.value] || 'm';   // запоминаем размер для текущей вкладки
    store.set('paletteSizes', paletteSizes);
    renderPalettes();
  });
}

/* ===== Image Palette Extractor: акцентные цвета из картинки → в список палитр ===== */
(function () {
  var fileInp = $('#pexFile'), drop = $('#pexDrop'), result = $('#pexResult');
  var imgEl = $('#pexImg'), swRow = $('#pexSwatches'), fnameEl = $('#pexFname');
  var btnUpload = $('#pexUpload'), btnReupload = $('#pexReupload'), btnMenu = $('#pexMenu'), btnSave = $('#pexSave');
  if (!fileInp) return;
  var pexColors = [], pexName = '';

  function openFile() { fileInp.value = ''; fileInp.click(); }
  if (btnUpload) btnUpload.addEventListener('click', function (e) { e.stopPropagation(); openFile(); });
  if (btnReupload) btnReupload.addEventListener('click', openFile);
  if (drop) drop.addEventListener('click', openFile);
  if (drop) {
    drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('pex-dragover'); });
    drop.addEventListener('dragleave', function () { drop.classList.remove('pex-dragover'); });
    drop.addEventListener('drop', function (e) {
      e.preventDefault(); drop.classList.remove('pex-dragover');
      var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) loadFile(f);
    });
  }
  fileInp.addEventListener('change', function () { var f = fileInp.files && fileInp.files[0]; if (f) loadFile(f); });

  function loadFile(f) {
    if (!/^image\//.test(f.type || '')) { toast(t('pex_notimg')); return; }
    pexName = (f.name || 'image').replace(/\.[^.]+$/, '');
    var rd = new FileReader();
    rd.onload = function () {
      var im = new Image();
      im.onload = function () {
        imgEl.src = im.src;
        pexColors = extractPalette(im);
        renderPexSwatches();
        fnameEl.textContent = pexName; fnameEl.title = pexName;
        drop.hidden = true; result.hidden = false;
      };
      im.onerror = function () { toast(t('pex_notimg')); };
      im.src = rd.result;
    };
    rd.readAsDataURL(f);
  }

  function renderPexSwatches() {
    swRow.innerHTML = '';
    if (!pexColors.length) { var em = document.createElement('span'); em.className = 'pex-empty'; em.textContent = t('pex_nocolors'); swRow.appendChild(em); return; }
    pexColors.forEach(function (hex) {
      var sw = document.createElement('button');
      sw.className = 'pex-sw'; sw.style.background = '#' + hex;
      sw.setAttribute('data-tip', '#' + hex);
      sw.addEventListener('click', function () { copyHex(hex); });
      swRow.appendChild(sw);
    });
  }

  // отдельная кнопка «Save to palettes» — добавляет извлечённую палитру в список (прямой клик, без всплывашки)
  if (btnSave) btnSave.addEventListener('click', savePexPalette);
  function savePexPalette() {
    if (!pexColors.length) { toast(t('pex_nocolors')); return; }
    palettes.push({ name: pexName || 'Extracted', colors: pexColors.slice() });
    savePalettes(); renderPalettes();
    toast(t('pex_saved'));
  }

  // меню «•••» — как у палитр: светлое .ctx-menu, Import / Remove / Duplicate, закрытие по click
  if (btnMenu) btnMenu.addEventListener('click', function (e) { e.stopPropagation(); openPexMenu(btnMenu); });
  function openPexMenu(anchor) {
    closePexMenu();
    var m = document.createElement('div'); m.className = 'ctx-menu'; m.id = '_pexPopup';
    m.innerHTML =
      '<button data-act="import"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/></svg>Import</button>' +
      '<button data-act="remove"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 12h8"/></svg>Remove</button>' +
      '<button data-act="duplicate"><svg viewBox="0 0 24 24"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>Duplicate</button>';
    m.addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; var act = b.dataset.act; closePexMenu(); pexAction(act); });
    document.body.appendChild(m);
    var r = anchor.getBoundingClientRect(), mw = m.offsetWidth, mh = m.offsetHeight;
    var x = Math.min(r.right - mw + 10, window.innerWidth - mw - 6), y = r.bottom + 4;
    if (y + mh > window.innerHeight - 6) y = r.top - mh - 4;
    m.style.left = Math.max(6, x) + 'px'; m.style.top = Math.max(6, y) + 'px';
    setTimeout(function () { document.addEventListener('click', pexOutside); }, 0);
  }
  function pexOutside(e) { var m = $('#_pexPopup'); if (m && !m.contains(e.target)) closePexMenu(); }
  function closePexMenu() { var m = $('#_pexPopup'); if (m) m.remove(); document.removeEventListener('click', pexOutside); }

  function pexAction(act) {
    if (!pexColors.length) { toast(t('pex_nocolors')); return; }
    if (act === 'import') {
      var safeName = (pexName || 'Extracted').replace(/\\/g, '').replace(/"/g, '\\"');
      cs.evalScript('MP_importPalette("' + safeName + '","' + pexColors.join(',') + '")', function (res) { handleHostResult(res, t('t_imported', pexName || 'Extracted')); });
    } else if (act === 'remove') {
      pexColors = []; pexName = ''; imgEl.src = ''; swRow.innerHTML = '';
      result.hidden = true; drop.hidden = false;
    } else if (act === 'duplicate') {
      palettes.push({ name: (pexName || 'Extracted') + ' copy', colors: pexColors.slice() });
      savePalettes(); renderPalettes();
      toast(t('t_pal_dup'));
    }
  }

  /* ---------- извлечение палитры: акцентные/насыщенные цвета ---------- */
  function extractPalette(img) {
    var MAX = 96;
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    if (!w || !h) return [];
    var scale = Math.min(1, MAX / Math.max(w, h));
    var cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
    var cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    var ctx = cv.getContext('2d'); ctx.drawImage(img, 0, 0, cw, ch);
    var data; try { data = ctx.getImageData(0, 0, cw, ch).data; } catch (e) { return []; }
    var buckets = {};
    for (var i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 125) continue;                 // прозрачные — мимо
      var r = data[i], g = data[i + 1], b = data[i + 2];
      var key = (r >> 3) + ',' + (g >> 3) + ',' + (b >> 3);   // 5 бит на канал
      var bk = buckets[key]; if (!bk) bk = buckets[key] = { r: 0, g: 0, b: 0, n: 0 };
      bk.r += r; bk.g += g; bk.b += b; bk.n++;
    }
    var arr = [];
    Object.keys(buckets).forEach(function (k) {
      var bk = buckets[k], r = bk.r / bk.n, g = bk.g / bk.n, b = bk.b / bk.n;
      var hsl = rgb2hsl(r, g, b), sat = hsl[1], lig = hsl[2];
      var accent = sat * (1 - Math.abs(lig - 0.55) * 0.9);    // акцентность: насыщенные средне-яркие — выше
      var score = Math.sqrt(bk.n) * (0.1 + accent * 2);       // sqrt(частота): большой фон не давит акценты
      arr.push({ r: r, g: g, b: b, sat: sat, lig: lig, score: score });
    });
    arr.sort(function (a, b) { return b.score - a.score; });
    var picked = [], MAXC = 7, MINDIST = 48;
    for (var j = 0; j < arr.length && picked.length < MAXC; j++) {
      var c = arr[j];
      if (c.lig > 0.96 || c.lig < 0.05) continue;            // не берём чисто белое/чёрное
      var dup = false;
      for (var p = 0; p < picked.length; p++) if (colDist(c, picked[p]) < MINDIST) { dup = true; break; }
      if (!dup) picked.push(c);
    }
    if (picked.length < 3) {                                  // бедная по цвету картинка — добираем
      for (var k2 = 0; k2 < arr.length && picked.length < MAXC; k2++) {
        var c2 = arr[k2], dup2 = false;
        for (var p2 = 0; p2 < picked.length; p2++) if (colDist(c2, picked[p2]) < 24) { dup2 = true; break; }
        if (!dup2) picked.push(c2);
      }
    }
    return picked.map(function (c) { return rgb2hex(c.r, c.g, c.b); });
  }
  function colDist(a, b) { var dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b; return Math.sqrt(dr * dr + dg * dg + db * db); }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, l = (mx + mn) / 2, s = 0, hh = 0;
    if (d) { s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); if (mx === r) hh = ((g - b) / d) % 6; else if (mx === g) hh = (b - r) / d + 2; else hh = (r - g) / d + 4; }
    return [hh * 60, s, l];
  }
  function rgb2hex(r, g, b) { function h2(v) { v = Math.max(0, Math.min(255, Math.round(v))); var s = v.toString(16); return s.length < 2 ? '0' + s : s; } return h2(r) + h2(g) + h2(b); }
})();

/* ============================================================
   EXPRESSIONS (вкладка): кастомные выражения с таймлайна
============================================================ */
var exprItems = store.get('exprItems', []);
var exprSel = store.get('exprSel', null);
var exprFav = store.get('exprFav', []);
function saveExprs() { store.set('exprItems', exprItems); }
function jsxStr(s) { s = String(s); return '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"'; }
function isExprFav(id) { return exprFav.indexOf(id) !== -1; }
function toggleExprFav(id) { var i = exprFav.indexOf(id); if (i === -1) exprFav.push(id); else exprFav.splice(i, 1); store.set('exprFav', exprFav); renderExprList(); }
function exprById(id) { for (var i = 0; i < exprItems.length; i++) if (exprItems[i].id === id) return exprItems[i]; return null; }

function renderExprList() {
  var list = $('#exprListWrap'); if (!list) return;
  list.innerHTML = '';
  var head = document.createElement('div'); head.className = 'tfx-list-head';
  head.innerHTML = '<span>EXPRESSIONS</span><span class="tfx-count">' + exprItems.length + '</span>';
  list.appendChild(head);
  var starSVG = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M12 3.6l2.6 5.27 5.82.85-4.21 4.1.99 5.79L12 17.9 6.79 19.61l.99-5.79-4.21-4.1 5.82-.85z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>';
  var ordered = exprItems.slice().sort(function (a, b) { var fa = isExprFav(a.id) ? 0 : 1, fb = isExprFav(b.id) ? 0 : 1; if (fa !== fb) return fa - fb; return exprItems.indexOf(a) - exprItems.indexOf(b); });
  ordered.forEach(function (it) {
    var el = document.createElement('button'); el.className = 'tfx-item' + (it.id === exprSel ? ' on' : '');
    el.innerHTML = '<span class="tfx-dot"></span><span class="tfx-it-text"><span class="tfx-it-name"></span><span class="tfx-it-desc"></span></span><span class="tfx-star' + (isExprFav(it.id) ? ' on' : '') + '" title="Favorite">' + starSVG + '</span>';
    el.querySelector('.tfx-it-name').textContent = it.name;
    var fl = (it.code || '').split('\n')[0] || ''; el.querySelector('.tfx-it-desc').textContent = fl ? fl.slice(0, 60) : '—';
    el.addEventListener('click', function () { exprSel = it.id; store.set('exprSel', exprSel); renderExprList(); renderExprDetail(); });
    el.querySelector('.tfx-star').addEventListener('click', function (e) { e.stopPropagation(); toggleExprFav(it.id); });
    list.appendChild(el);
  });
  var add = document.createElement('button'); add.className = 'expr-add-btn'; add.textContent = t('expr_add');
  add.addEventListener('click', addExprFromTimeline);
  list.appendChild(add);
}

/* ---- live-превью Expression: распознаём тип выражения и анимируем образец ---- */
var exprPvRaf = null;
function exprStopPreview() { if (exprPvRaf) { cancelAnimationFrame(exprPvRaf); exprPvRaf = null; } }
function exprDetectType(code) {
  var c = String(code || '').toLowerCase();
  if (/wiggle\s*\(/.test(c)) return 'wiggle';
  if (/loopout\s*\(|loopin\s*\(|\bloop\s*\(/.test(c)) return 'loop';
  if (/bounce|spring|elastic|overshoot/.test(c) || (/amp/.test(c) && /freq/.test(c))) return 'bounce';
  if (/math\.sin|math\.cos|\bsin\s*\(|\bcos\s*\(/.test(c)) return 'osc';
  if (/seedrandom|gaussrandom|\brandom\s*\(/.test(c)) return 'random';
  if (/\btime\b/.test(c)) return 'time';
  return 'pulse';
}
function exprPreviewStart(el, type) {
  exprStopPreview();
  if (!el) return;
  var t0 = (window.performance && performance.now) ? performance.now() : Date.now();
  var seed = Math.random() * 1000;
  function frame(now) {
    var t = (now - t0) / 1000;   // секунды
    var tx = 0, ty = 0, rot = 0, sc = 1, op = 1;
    if (type === 'wiggle') {
      var A = 15;
      tx = (Math.sin((t + seed) * 7.1) + 0.5 * Math.sin((t + seed) * 13.3)) * A;
      ty = (Math.cos((t + seed) * 9.7) + 0.5 * Math.sin((t + seed) * 17.9)) * A * 0.7;
    } else if (type === 'loop') {
      tx = Math.sin(t * 2.2) * 26;
    } else if (type === 'bounce') {
      var P = 1.6, ph = t % P, env = Math.exp(-ph * 3.2);
      sc = 1 + Math.sin(ph * 18) * env * 0.32;
      ty = -Math.abs(Math.sin(ph * 9)) * env * 16;
    } else if (type === 'osc') {
      ty = Math.sin(t * 2.6) * 18;
    } else if (type === 'time') {
      rot = (t * 90) % 360;        // непрерывное вращение
    } else if (type === 'random') {
      var step = Math.floor(t * 9), r = Math.sin(step * 12.9898 + seed) * 43758.5453; r = r - Math.floor(r);
      op = 0.3 + 0.7 * (r > 0.5 ? 1 : 0.4);
      tx = (r - 0.5) * 10; ty = (((r * 7) % 1) - 0.5) * 10;
    } else {                        // pulse — по умолчанию
      sc = 1 + Math.sin(t * 2.4) * 0.08;
    }
    el.style.transform = 'translate(' + tx.toFixed(2) + 'px,' + ty.toFixed(2) + 'px) rotate(' + rot.toFixed(2) + 'deg) scale(' + sc.toFixed(3) + ')';
    el.style.opacity = op.toFixed(3);
    exprPvRaf = requestAnimationFrame(frame);
  }
  exprPvRaf = requestAnimationFrame(frame);
}

function renderExprDetail() {
  var box = $('#exprDetail'); if (!box) return;
  exprStopPreview();
  box.innerHTML = '';
  var it = exprById(exprSel);
  if (!it) { var ph = document.createElement('div'); ph.className = 'tfx-d-empty'; ph.textContent = t('expr_pick'); box.appendChild(ph); return; }
  var scroll = document.createElement('div'); scroll.className = 'tfx-d-scroll';
  var top = document.createElement('div'); top.className = 'tfx-d-top';
  var title = document.createElement('div'); title.className = 'tfx-d-title'; title.textContent = it.name; title.title = t('expr_rename_tip');
  title.addEventListener('dblclick', function () { title.contentEditable = 'true'; title.focus(); try { document.execCommand('selectAll', false, null); } catch (e) {} });
  title.addEventListener('blur', function () { title.contentEditable = 'false'; var v = (title.textContent || '').replace(/^\s+|\s+$/g, ''); if (v) it.name = v; title.textContent = it.name; saveExprs(); renderExprList(); });
  title.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); title.blur(); } if (e.key === 'Escape') { title.textContent = it.name; title.blur(); } });
  top.appendChild(title);
  scroll.appendChild(top);
  // LIVE PREVIEW — наглядно показывает характер движения выражения
  var pvLabel = document.createElement('div'); pvLabel.className = 'tfx-section-label'; pvLabel.textContent = 'LIVE PREVIEW';
  scroll.appendChild(pvLabel);
  var pv = document.createElement('div'); pv.className = 'tfx-preview';
  var pvt = document.createElement('span'); pvt.className = 'tfx-preview-text'; pvt.textContent = 'MotionFX';
  pv.appendChild(pvt);
  scroll.appendChild(pv);
  var lbl = document.createElement('div'); lbl.className = 'tfx-section-label'; lbl.textContent = 'EXPRESSION';
  scroll.appendChild(lbl);
  var curType = exprDetectType(it.code);
  var ta = document.createElement('textarea'); ta.className = 'expr-code-edit'; ta.spellcheck = false; ta.value = it.code || '';
  ta.addEventListener('input', function () {
    it.code = ta.value; saveExprs();
    var nt = exprDetectType(ta.value);
    if (nt !== curType) { curType = nt; exprPreviewStart(pvt, nt); }   // тип сменился — перезапустить превью
  });
  ta.addEventListener('blur', function () { renderExprList(); });
  scroll.appendChild(ta);
  box.appendChild(scroll);
  var foot = document.createElement('div'); foot.className = 'tfx-apply-row';
  var del = document.createElement('button'); del.className = 'expr-del-btn'; del.textContent = t('expr_delete');
  del.addEventListener('click', function () { var i = exprItems.indexOf(it); if (i !== -1) exprItems.splice(i, 1); if (exprSel === it.id) exprSel = null; saveExprs(); store.set('exprSel', exprSel); renderExprList(); renderExprDetail(); });
  var spacer = document.createElement('div'); spacer.style.flex = '1';
  var apply = document.createElement('button'); apply.className = 'tfx-anim-btn'; apply.textContent = t('expr_apply_btn');
  apply.addEventListener('click', function () { applyExprCode(it.code); });
  foot.appendChild(del); foot.appendChild(spacer); foot.appendChild(apply);
  box.appendChild(foot);
  exprPreviewStart(pvt, curType);   // запустить превью
}

function applyExprCode(code) {
  if (!cs.isCEP()) { toast(t('expr_need_ae')); return; }
  cs.evalScript('MP_applyExpression(' + jsxStr(code) + ',"")', function (res) {
    if (res === 'noprops') { toast(t('expr_noprops')); return; }
    if (res && res.indexOf('ok:') === 0) { toast(t('expr_applied', res.slice(3))); return; }
    handleHostResult(res, t('expr_applied_done'));
  });
}

function addExprFromTimeline() {
  if (!cs.isCEP()) { toast(t('expr_need_ae')); return; }
  cs.evalScript('MP_collectExpressions()', function (res) {
    if (res === 'nosel') { toast(t('expr_nosel')); return; }
    if (res === 'noexpr') { toast(t('expr_noexpr')); return; }
    if (!res || res.indexOf('ok:') !== 0) { handleHostResult(res, ''); return; }
    var parts = res.split('<<<MPHEAD>>>'); var bodyp = parts.length > 1 ? parts[1] : '';
    var arr = bodyp.length ? bodyp.split('<<<MPEXPR>>>') : [];
    if (!arr.length) { toast(t('expr_noexpr')); return; }
    var base = exprItems.length, lastId = null;
    arr.forEach(function (code, i) { var id = 'e' + Date.now() + '_' + i; exprItems.push({ id: id, name: 'Expr ' + (base + i + 1), code: code }); lastId = id; });
    if (lastId) exprSel = lastId;
    saveExprs(); store.set('exprSel', exprSel); renderExprList(); renderExprDetail();
    toast(t('expr_added', arr.length));
  });
}

/* совместимость со старыми вызовами */
function renderExpressions() { renderExprList(); renderExprDetail(); }

/* ---- контекстное меню ••• ---- */
var ctxMenu = $('#ctxMenu');
var ctxPi = -1;

function openCtxMenu(pi, anchorEl) {
  ctxPi = pi;
  ctxMenu.hidden = false;
  var r = anchorEl.getBoundingClientRect();
  var mw = ctxMenu.offsetWidth, mh = ctxMenu.offsetHeight;
  var x = Math.min(r.right - mw + 10, window.innerWidth - mw - 6);
  var y = r.bottom + 4;
  if (y + mh > window.innerHeight - 6) y = r.top - mh - 4;
  ctxMenu.style.left = Math.max(6, x) + 'px';
  ctxMenu.style.top = Math.max(6, y) + 'px';
}
document.addEventListener('click', function (e) {
  if (!ctxMenu.hidden && !ctxMenu.contains(e.target)) ctxMenu.hidden = true;
});

ctxMenu.addEventListener('click', function (e) {
  var btn = e.target.closest('button');
  if (!btn || ctxPi < 0) return;
  var act = btn.dataset.act;
  var pal = palettes[ctxPi];
  ctxMenu.hidden = true;
  if (!pal) return;

  if (act === 'remove') {
    palettes.splice(ctxPi, 1);
    savePalettes(); renderPalettes();
    toast(t('t_pal_removed'));
  }
  if (act === 'duplicate') {
    var copy = JSON.parse(JSON.stringify(pal));
    copy.name = pal.name + ' copy';
    palettes.splice(ctxPi + 1, 0, copy);
    savePalettes(); renderPalettes();
    toast(t('t_pal_dup'));
  }
  if (act === 'import') {
    var hexes = pal.colors.filter(function (c) { return !!c; });
    if (!hexes.length) { toast(t('t_no_colors')); return; }
    var safeName = pal.name.replace(/\\/g, '').replace(/"/g, '\\"');
    cs.evalScript('MP_importPalette("' + safeName + '","' + hexes.join(',') + '")', function (res) {
      handleHostResult(res, t('t_imported', pal.name));
    });
  }
});

/* ============================================================
   ГРАФИК: Cubic / Value / Speed + превью-полоса
============================================================ */
var bez = { x1: 0, y1: 0, x2: 1, y2: 1 };
var graphModeNow = 'cubic';
var svg = $('#bezSvg');
var W = 300, H = 300, PADX = 42, PADY = 18, vLo = 0, vHi = 1, PAD = 18;
var gDrag = false;                         // во время перетаскивания ручки вертикальный диапазон заморожен (стабильное соответствие курсор→ручка)
/* видимый диапазон значений по вертикали — авто-подгон под текущие ручки (даёт «неограниченную» высоту: график отъезжает, ручка остаётся видимой) */
function computeVRange() {
  if (gDrag) return;                       // заморожен на время drag — не пересчитываем
  var hi = Math.max(1, bez.y1, bez.y2);
  var lo = Math.min(0, bez.y1, bez.y2);
  var m = (hi - lo) * 0.08 + 0.06;       // небольшой запас сверху/снизу
  vLo = lo - m; vHi = hi + m;
}

function toPx(x, y) { return [PADX + x * (W - PADX * 2), PADY + (vHi - y) / (vHi - vLo) * (H - PADY * 2)]; }
function fromPx(px, py) {
  return [Math.min(1, Math.max(0, (px - PADX) / (W - PADX * 2))), vHi - (py - PADY) / (H - PADY * 2) * (vHi - vLo)];
}

/* точка на кривой по параметру t */
function bezXY(t) {
  var mt = 1 - t;
  return [
    3 * bez.x1 * t * mt * mt + 3 * bez.x2 * t * t * mt + t * t * t,
    3 * bez.y1 * t * mt * mt + 3 * bez.y2 * t * t * mt + t * t * t
  ];
}
/* прогресс значения по времени x для произвольных параметров */
function cubicSolveY(x, X1, Y1, X2, Y2) {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  var t = x;
  for (var i = 0; i < 10; i++) {
    var mt = 1 - t;
    var cx = 3 * X1 * t * mt * mt + 3 * X2 * t * t * mt + t * t * t - x;
    var dx = 3 * X1 * (1 - 4 * t + 3 * t * t) + 3 * X2 * (2 * t - 3 * t * t) + 3 * t * t;
    if (Math.abs(cx) < 1e-5) break;
    if (Math.abs(dx) < 1e-6) break;
    t -= cx / dx;
    t = Math.max(0, Math.min(1, t));
  }
  var mt2 = 1 - t;
  return 3 * Y1 * t * mt2 * mt2 + 3 * Y2 * t * t * mt2 + t * t * t;
}
function cubicPeakSpeed(X1, X2) { // макс скорость горба (Y1=0, Y2=1)
  var mx = 0, e = 0.01;
  for (var i = 1; i < 50; i++) {
    var x = i / 50;
    var v = (cubicSolveY(Math.min(1, x + e), X1, 0, X2, 1) - cubicSolveY(Math.max(0, x - e), X1, 0, X2, 1)) / (Math.min(1, x + e) - Math.max(0, x - e));
    if (v > mx) mx = v;
  }
  return mx;
}

/* прогресс значения по времени x (как css cubic-bezier) */
function bezSolveY(x) {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  var t = x;
  for (var i = 0; i < 10; i++) {
    var mt = 1 - t;
    var cx = 3 * bez.x1 * t * mt * mt + 3 * bez.x2 * t * t * mt + t * t * t - x;
    var dx = 3 * bez.x1 * (1 - 4 * t + 3 * t * t) + 3 * bez.x2 * (2 * t - 3 * t * t) + 3 * t * t;
    if (Math.abs(cx) < 1e-5) break;
    if (Math.abs(dx) < 1e-6) break;
    t -= cx / dx;
    t = Math.max(0, Math.min(1, t));
  }
  var mt = 1 - t;
  return 3 * bez.y1 * t * mt * mt + 3 * bez.y2 * t * t * mt + t * t * t;
}

function drawGrid() {
  var g = $('#bezGrid'), s = '';
  var p0 = toPx(0, 1), p1 = toPx(1, 0);
  s += '<rect x="' + p0[0] + '" y="' + p0[1] + '" width="' + (p1[0] - p0[0]) + '" height="' + (p1[1] - p0[1]) + '"/>';
  for (var i = 1; i < 4; i++) {
    var gx = toPx(i / 4, 0)[0];
    s += '<line x1="' + gx + '" y1="' + p0[1] + '" x2="' + gx + '" y2="' + p1[1] + '"/>';
    var gy = toPx(0, i / 4)[1];
    s += '<line x1="' + p0[0] + '" y1="' + gy + '" x2="' + p1[0] + '" y2="' + gy + '"/>';
  }
  g.innerHTML = s;
}

/* подписи осей и пунктиры для режима Value */
function renderAxis() {
  var g = $('#axisG');
  if (graphModeNow !== 'value') { g.innerHTML = ''; return; }
  var p00 = toPx(0, 0), p11 = toPx(1, 1);
  var html = '';
  html += '<line class="guide in" x1="' + p11[0] + '" y1="' + p11[1] + '" x2="' + p11[0] + '" y2="' + (H - 14) + '"/>';
  html += '<line class="guide out" x1="' + p00[0] + '" y1="' + p00[1] + '" x2="' + p00[0] + '" y2="' + (H - 14) + '"/>';
  html += '<text x="3" y="' + (p00[1] - 8) + '" fill="#f07033">0</text>';
  html += '<text x="' + (p11[0] - 12) + '" y="' + (p11[1] + 3) + '" fill="#4f8df7" text-anchor="end">1</text>';
  html += '<text x="' + (p00[0] + 3) + '" y="' + (H - 3) + '" fill="#f07033">0.00</text>';
  html += '<text x="' + (p11[0] - 3) + '" y="' + (H - 3) + '" fill="#4f8df7" text-anchor="end">1.00</text>';
  g.innerHTML = html;
}

/* кривая скорости для режима Speed (редактируемая) */
var speedDrag = null;        // во время перетаскивания шкала заморожена
var lastSpeedScale = 2.2;

function speedAt(side) { // скорость на конце: out — наклон y1/x1, in — (1-y2)/(1-x2)
  if (side === 'out') return bez.y1 / Math.max(bez.x1, 0.02);
  return (1 - bez.y2) / Math.max(1 - bez.x2, 0.02);
}
function mapSpeedY(v, scale) {
  return PAD + (1 - Math.max(0, v) / scale) * (H - PAD * 2);
}

function renderSpeed() {
  var path = $('#speedPath');
  if (graphModeNow !== 'speed') { path.setAttribute('d', ''); return; }
  var N = 80, v = [], hi = 0.001, e = 0.004;
  for (var i = 0; i <= N; i++) {
    var x = i / N;
    var a = Math.max(0, x - e), b = Math.min(1, x + e);
    var sp = (bezSolveY(b) - bezSolveY(a)) / (b - a);
    v.push(sp);
    if (sp > hi) hi = sp;
  }
  var scale = speedDrag ? speedDrag.scale : Math.max(1.8, hi * 1.2);
  lastSpeedScale = scale;
  var d = '';
  for (var j = 0; j <= N; j++) {
    var px = j / N * W;
    var py = Math.min(H - 2, mapSpeedY(v[j], scale));
    d += (j ? 'L' : 'M') + px.toFixed(1) + ',' + py.toFixed(1);
  }
  path.setAttribute('d', d);
}

function setDisplay(sel, on) { $(sel).style.display = on ? '' : 'none'; }

function renderGraph() {
  computeVRange();
  drawGrid();
  renderAxis();
  renderSpeed();

  var editable = graphModeNow !== 'speed';
  ['#bezCurve', '#armOut', '#armIn', '#hOut', '#hIn'].forEach(function (s) { setDisplay(s, editable); });
  setDisplay('#epOut', graphModeNow === 'value');
  setDisplay('#epIn',  graphModeNow === 'value');

  if (editable) {
    var a = toPx(0, 0), b = toPx(1, 1);
    var c1 = toPx(bez.x1, bez.y1), c2 = toPx(bez.x2, bez.y2);
    $('#bezCurve').setAttribute('d',
      'M' + a[0] + ',' + a[1] + ' C' + c1[0] + ',' + c1[1] + ' ' + c2[0] + ',' + c2[1] + ' ' + b[0] + ',' + b[1]);
    $('#hOut').setAttribute('cx', c1[0]); $('#hOut').setAttribute('cy', c1[1]);
    $('#hIn').setAttribute('cx', c2[0]);  $('#hIn').setAttribute('cy', c2[1]);
    var ao = $('#armOut'), ai = $('#armIn');
    ao.setAttribute('x1', a[0]); ao.setAttribute('y1', a[1]);
    ao.setAttribute('x2', c1[0]); ao.setAttribute('y2', c1[1]);
    ai.setAttribute('x1', b[0]); ai.setAttribute('y1', b[1]);
    ai.setAttribute('x2', c2[0]); ai.setAttribute('y2', c2[1]);
    $('#epOut').setAttribute('cx', a[0]); $('#epOut').setAttribute('cy', a[1]);
    $('#epIn').setAttribute('cx', b[0]);  $('#epIn').setAttribute('cy', b[1]);
  }

  function f(v) { return Math.round(v * 100) / 100; }
  $('#bezVals').textContent = f(bez.x1) + ', ' + f(bez.y1) + ', ' + f(bez.x2) + ', ' + f(bez.y2);
  renderDots();
}
var renderBezier = renderGraph; // совместимость со старыми вызовами

/* ---- адаптивный размер: сетка — настоящий квадрат (высота = ширине) ---- */
function resizeGraph() {
  var wrap = svg.closest('.bezier-wrap');
  if (!wrap) return;
  var host = svg.closest('[data-widget="bezier"]');
  var cs = getComputedStyle(wrap);
  var padX = (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
  var padY = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
  var availW = wrap.clientWidth - padX;
  if (availW <= 0) return; // скрытая страница
  var side = availW;
  if (host && host.classList.contains('h-fixed')) {       // высота задана — берём меньшую сторону (квадрат не растягивается)
    var availH = wrap.clientHeight - padY;
    if (availH > 0) side = Math.min(availW, availH);
  }
  side = Math.max(70, Math.round(side));
  svg.style.width = side + 'px';
  svg.style.height = side + 'px';      // всегда квадрат, по центру wrap
  W = side; H = side;
  PADX = Math.round(side * 0.14);       // боковые поля — чтобы базовый квадрат [0,1] выглядел примерно квадратным
  PADY = Math.round(side * 0.06);       // небольшие поля сверху/снизу (диапазон по вертикали авто-подгоняется)
  PAD = PADY;                            // алиас для неактивного speed-кода
  svg.setAttribute('viewBox', '0 0 ' + side + ' ' + side);
  if (host) {                                              // масштаб контролов (кнопка Apply, пресеты, подпись)
    var gs = Math.max(0.55, Math.min(1.1, host.offsetWidth / 300));
    host.style.setProperty('--gs', gs.toFixed(3));
  }
  renderGraph();
}
if (window.ResizeObserver) {
  new ResizeObserver(function () { resizeGraph(); }).observe(svg);
}
window.addEventListener('resize', resizeGraph);

/* ---- перетаскивание контрольных точек ---- */
function attachHandle(el, kx, ky) {
  function move(e) {
    var r = svg.getBoundingClientRect();
    var px = e.clientX - r.left, py = e.clientY - r.top;

    var xy = fromPx(px, py);                 // X зажат в [0,1] (время), Y — значение (диапазон авто-подгоняется)
    var nx = xy[0], ny = xy[1];
    if (e.shiftKey) {
      // магнит к граням квадрата: без выхода за границы + притягиваем к 0 и 1 (для идеального графика)
      ny = Math.max(0, Math.min(1, ny));
      var SNAP = 0.05;
      if (nx < SNAP) nx = 0; else if (nx > 1 - SNAP) nx = 1;
      if (ny < SNAP) ny = 0; else if (ny > 1 - SNAP) ny = 1;
    } else {
      // высота фактически без предела — график «отъезжает», ручка остаётся видна у края (защитный предел от абсурда)
      ny = Math.max(-20, Math.min(60, ny));
    }
    bez[kx] = nx;
    bez[ky] = ny;
    renderGraph();
  }
  function up() {
    gDrag = false;                                       // снимаем заморозку → вид авто-подгоняется под итоговую высоту
    if (speedDrag) speedDrag = null;
    renderGraph();
    window.removeEventListener('mousemove', move);
    window.removeEventListener('mouseup', up);
    autoApplyEase();   // правил график — сразу на выделенные ключи (если включено)
  }
  el.addEventListener('mousedown', function (e) {
    e.preventDefault();
    gDrag = true;                                        // замораживаем вертикальный диапазон на время drag
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  });
}
attachHandle($('#hOut'), 'x1', 'y1');
attachHandle($('#hIn'),  'x2', 'y2');

/* speed-режим: горб следует за курсором — X задаёт пик, Y — высоту */
(function () {
  function applyHump(e) {
    var r = svg.getBoundingClientRect();
    var px = e.clientX - r.left, py = e.clientY - r.top;
    var u = Math.min(0.95, Math.max(0.05, px / W)); // позиция пика
    var h = (1 - (py - PAD) / (H - PAD * 2)) * speedDrag.scale; // желаемая высота
    h = Math.max(1.02, Math.min(30, h));

    // подбираем общий influence T бисекцией под высоту пика
    var hiT = Math.min(0.97 / u, 0.97 / (1 - u), 1.94);
    var loT = 0.05;
    for (var i = 0; i < 14; i++) {
      var mid = (loT + hiT) / 2;
      var pk = cubicPeakSpeed(mid * u, 1 - mid * (1 - u));
      if (pk < h) loT = mid; else hiT = mid;
    }
    var T = (loT + hiT) / 2;
    bez.x1 = Math.min(0.97, Math.max(0.02, T * u));
    bez.x2 = 1 - Math.min(0.97, Math.max(0.02, T * (1 - u)));
    bez.y1 = 0;
    bez.y2 = 1;
    renderGraph();
  }
  function onMove(e) { applyHump(e); }
  function onUp() {
    speedDrag = null;
    renderGraph(); // пере-нормировка шкалы
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
  }
  svg.addEventListener('mousedown', function (e) {
    if (graphModeNow !== 'speed') return;
    e.preventDefault();
    speedDrag = { scale: lastSpeedScale };
    applyHump(e);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });
})();

/* ---- график теперь один (cubic), переключателя режимов нет ---- */

/* ---- превью-полоса с кружками ---- */
var dotsStrip = $('#dotsStrip');
var DOTN = 26;
(function buildDots() {
  for (var i = 0; i < DOTN; i++) {
    var d = document.createElement('span');
    d.className = 'dot';
    dotsStrip.insertBefore(d, $('#playDot'));
  }
})();

function lerpColor(c1, c2, t) {
  return 'rgb(' +
    Math.round(c1[0] + (c2[0] - c1[0]) * t) + ',' +
    Math.round(c1[1] + (c2[1] - c1[1]) * t) + ',' +
    Math.round(c1[2] + (c2[2] - c1[2]) * t) + ')';
}
var DOT_C1 = [120, 54, 32], DOT_C2 = [44, 74, 130]; // приглушённые оранж → синий

function renderDots() {
  var dots = $$('.dot', dotsStrip);
  var pad = 2; // % отступа по краям
  for (var i = 0; i < dots.length; i++) {
    var t = i / (dots.length - 1);
    var y = bezSolveY(t);
    dots[i].style.left = (pad + Math.min(1, Math.max(0, y)) * (100 - pad * 2)) + '%';
    dots[i].style.background = lerpColor(DOT_C1, DOT_C2, t);
  }
}

/* упрощённый плейбек по клику */
var playing = false;
dotsStrip.addEventListener('click', function () {
  if (playing) return;
  playing = true;
  var pd = $('#playDot');
  pd.hidden = false;
  var dur = 1100, t0 = performance.now();
  function step(now) {
    var x = Math.min(1, (now - t0) / dur);
    var pad = 2;
    pd.style.left = (pad + bezSolveY(x) * (100 - pad * 2)) + '%';
    if (x < 1) requestAnimationFrame(step);
    else setTimeout(function () { pd.hidden = true; playing = false; }, 180);
  }
  requestAnimationFrame(step);
});

/* авто-применение графика к выделенным ключам в процессе редактирования (#3c) */
var autoApplyGraph = store.get('autoApplyGraph', true);
function autoApplyEase() {
  if (!autoApplyGraph || !cs.isCEP()) return;
  cs.evalScript('MP_applyCubic(' + bez.x1 + ',' + bez.y1 + ',' + bez.x2 + ',' + bez.y2 + ')', function () {});
}
var autoApplyChk = $('#autoApplyChk');
if (autoApplyChk) {
  autoApplyChk.checked = autoApplyGraph;
  autoApplyChk.addEventListener('change', function () {
    autoApplyGraph = this.checked;
    store.set('autoApplyGraph', autoApplyGraph);
  });
}

var hideLabelsChk = $('#hideLabelsChk');
if (hideLabelsChk) {
  hideLabelsChk.checked = hideToolLabels;
  hideLabelsChk.addEventListener('change', function () {
    hideToolLabels = this.checked;
    store.set('hideToolLabels', hideToolLabels);
    $$('.board > .widget.tool').forEach(scaleTool);   // мгновенно применить ко всем плиткам
  });
}

$('#applyEase').addEventListener('click', function () {
  cs.evalScript('MP_applyCubic(' + bez.x1 + ',' + bez.y1 + ',' + bez.x2 + ',' + bez.y2 + ')', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t('t_applied', res.slice(3))); return; }
    handleHostResult(res, t('t_done'));
  });
});

/* ---- библиотека графиков ---- */
/* встроенные изинги (как у Flow) — переехали сюда наверх, т.к. из них собирается
   библиотека «базовая» при первом запуске */
var EASING_PRESETS = [
  { n: 'linear', v: [0, 0, 1, 1] },
  { n: 'ease',   v: [0.25, 0.1, 0.25, 1] },
  { n: 'in',     v: [0.42, 0, 1, 1] },
  { n: 'out',    v: [0, 0, 0.58, 1] },
  { n: 'inOut',  v: [0.42, 0, 0.58, 1] },
  { n: 'sineIn',  v: [0.12, 0, 0.39, 0] },
  { n: 'sineOut', v: [0.61, 1, 0.88, 1] },
  { n: 'sine',    v: [0.37, 0, 0.63, 1] },
  { n: 'quadIn',  v: [0.11, 0, 0.5, 0] },
  { n: 'quadOut', v: [0.5, 1, 0.89, 1] },
  { n: 'quad',    v: [0.45, 0, 0.55, 1] },
  { n: 'cubicIn',  v: [0.32, 0, 0.67, 0] },
  { n: 'cubicOut', v: [0.33, 1, 0.68, 1] },
  { n: 'cubic',    v: [0.65, 0, 0.35, 1] },
  { n: 'quartIn',  v: [0.5, 0, 0.75, 0] },
  { n: 'quartOut', v: [0.25, 1, 0.5, 1] },
  { n: 'quart',    v: [0.76, 0, 0.24, 1] },
  { n: 'quintIn',  v: [0.64, 0, 0.78, 0] },
  { n: 'quintOut', v: [0.22, 1, 0.36, 1] },
  { n: 'quint',    v: [0.83, 0, 0.17, 1] },
  { n: 'expoIn',  v: [0.7, 0, 0.84, 0] },
  { n: 'expoOut', v: [0.16, 1, 0.3, 1] },
  { n: 'expo',    v: [0.87, 0, 0.13, 1] },
  { n: 'circIn',  v: [0.55, 0, 1, 0.45] },
  { n: 'circOut', v: [0, 0.55, 0.45, 1] },
  { n: 'circ',    v: [0.85, 0, 0.15, 1] },
  { n: 'backIn',  v: [0.36, 0, 0.66, -0.56] },
  { n: 'backOut', v: [0.34, 1.56, 0.64, 1] },
  { n: 'back',    v: [0.68, -0.6, 0.32, 1.6] }
];
function easingLibCurves() {
  return EASING_PRESETS.map(function (e) {
    return { name: e.n, x1: e.v[0], y1: e.v[1], x2: e.v[2], y2: e.v[3] };
  });
}

/* мультибиблиотеки: «базовая» (встроенные изинги) + «Сохранённые» (старые
   пользовательские графики) + любые свои. presets всегда указывает на кривые текущей. */
var libraries = store.get('libraries', null);
if (!libraries || !libraries.length) {
  var _oldPresets = store.get('presets', []);
  libraries = [
    { name: 'базовая', curves: easingLibCurves() },
    { name: 'Сохранённые', curves: _oldPresets }
  ];
}
var curLib = store.get('curLib', 0);
if (curLib < 0 || curLib >= libraries.length) curLib = 0;
var presets = libraries[curLib].curves;
function saveLibs() { store.set('libraries', libraries); store.set('curLib', curLib); }
var presetSize = store.get('presetSize', 'm');   // s | m | l
var presetSort = store.get('presetSort', 'manual'); // manual | name | new
try { if (typeof MP_log === 'function') MP_log('libs loaded: curLib=' + curLib + ' "' + (libraries[curLib] && libraries[curLib].name) + '" sort=' + presetSort + ' order=' + (libraries[curLib] ? libraries[curLib].curves.map(function (c) { return c.name; }).join(' | ') : '-')); } catch (e) {}
var presetEditing = -1; // индекс пресета в режиме переименования
var presetDragFrom = -1;

function displayedPresets() {
  var arr = presets.map(function (p, i) { return { p: p, i: i }; });
  if (presetSort === 'name') arr.sort(function (a, b) { return a.p.name.localeCompare(b.p.name); });
  if (presetSort === 'new') arr.reverse();
  return arr;
}

var SIZE_STEPS = ['s', 'm', 'l'];
var sizeSlider = $('#sizeSlider');
sizeSlider.value = SIZE_STEPS.indexOf(presetSize);
sizeSlider.addEventListener('input', function () {
  presetSize = SIZE_STEPS[+this.value] || 'm';
  store.set('presetSize', presetSize);
  renderPresets();
});
$('#sortBtn').addEventListener('click', function () {
  presetSort = { manual: 'name', name: 'new', 'new': 'manual' }[presetSort];
  store.set('presetSort', presetSort);
  renderPresets();
  toast(t({ manual: 't_sort_manual', name: 't_sort_name', 'new': 't_sort_new' }[presetSort]));
});

function presetPathD(p, w, h) {
  var pad = 8;
  function px(x, y) { return [x * w, pad + (1 - y) * (h - pad * 2)]; }
  var a = px(0, 0), b = px(1, 1), c1 = px(p.x1, p.y1), c2 = px(p.x2, p.y2);
  return 'M' + a[0] + ',' + a[1] + ' C' + c1[0] + ',' + c1[1] + ' ' + c2[0] + ',' + c2[1] + ' ' + b[0] + ',' + b[1];
}

function renderPresets() {
  var list = $('#presetList');
  list.className = 'preset-list size-' + presetSize;
  list.innerHTML = '';
  if (!presets.length) {
    list.innerHTML = '<div class="empty-note">' + t('lib_empty') + '</div>';
    return;
  }
  displayedPresets().forEach(function (item, di) {
    var p = item.p, i = item.i;
    var el = document.createElement('div');
    el.className = 'preset';
    el.draggable = true;
    el.dataset.di = di;
    var nameHtml = (presetEditing === i)
      ? '<input class="pname-input" type="text" maxlength="30" value="' + esc(p.name).replace(/"/g, '&quot;') + '">'
      : '<div class="pname">' + esc(p.name) + '</div>';
    el.innerHTML =
      '<svg viewBox="0 0 90 56" preserveAspectRatio="none"><path d="' + presetPathD(p, 90, 56) + '"/></svg>' +
      nameHtml +
      '<button class="pedit" data-tip="' + esc(t('tip_pedit')) + '"><svg viewBox="0 0 24 24"><path d="M4 20h4L19 9a2.1 2.1 0 0 0-3-3L5 17l-1 3Z"/></svg></button>' +
      '<button class="pdel" title="✕">✕</button>';

    el.addEventListener('click', function (e) {
      if (e.target.closest('.pname-input')) return;
      if (e.target.closest('.pdel')) {
        presets.splice(i, 1);
        presetEditing = -1;
        saveLibs();
        renderPresets();
        return;
      }
      if (e.target.closest('.pedit')) {
        presetEditing = i;
        renderPresets();
        var inp = $('.pname-input', $('#presetList'));
        if (inp) { inp.focus(); inp.select(); }
        return;
      }
      if (presetEditing !== -1) return;
      var ovr = Math.max(0, (PAD - 4) / (H - PAD * 2));
      function cl(v) { return Math.min(1 + ovr, Math.max(-ovr, v)); }
      bez = { x1: p.x1, y1: cl(p.y1), x2: p.x2, y2: cl(p.y2) };
      renderBezier();
      autoApplyEase();
      toast(t('t_loaded', p.name));
    });

    // переименование
    if (presetEditing === i) {
      setTimeout(function () {
        var inp = $('.pname-input', el);
        if (!inp) return;
        function commit() {
          var v = inp.value.trim();
          if (v) p.name = v;
          presetEditing = -1;
          saveLibs();
          renderPresets();
        }
        inp.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter') commit();
          if (ev.key === 'Escape') { presetEditing = -1; renderPresets(); }
        });
        inp.addEventListener('blur', commit);
      }, 0);
    }

    // drag&drop порядок
    el.addEventListener('dragstart', function () { presetDragFrom = di; });
    el.addEventListener('dragover', function (e) {
      if (presetDragFrom === -1 || presetDragFrom === di) return;
      e.preventDefault();
      el.classList.add('drag-over');
    });
    el.addEventListener('dragleave', function () { el.classList.remove('drag-over'); });
    el.addEventListener('drop', function (e) {
      e.preventDefault();
      el.classList.remove('drag-over');
      if (presetDragFrom === -1 || presetDragFrom === di) return;
      var disp = displayedPresets().map(function (it) { return it.p; });
      var moved = disp.splice(presetDragFrom, 1)[0];
      disp.splice(di, 0, moved);
      presets = disp;                 // новый порядок становится ручным
      libraries[curLib].curves = presets;   // presets теперь новый массив — пересвязываем с библиотекой
      presetSort = 'manual';
      store.set('presetSort', presetSort);
      saveLibs();
      try { MP_log('preset reorder: curLib=' + curLib + ' "' + (libraries[curLib] && libraries[curLib].name) + '" sort=' + presetSort + ' -> ' + presets.map(function (p) { return p.name; }).join(' | ')); } catch (e) {}
      presetDragFrom = -1;
      renderPresets();
    });
    el.addEventListener('dragend', function () { presetDragFrom = -1; });

    list.appendChild(el);
  });
}

function nextGraphName() {
  var max = 0;
  presets.forEach(function (p) {
    var m = /^график\s+(\d+)$/i.exec((p && p.name) || '');
    if (m) { var n = +m[1]; if (n > max) max = n; }
  });
  return 'график ' + (max + 1);
}
$('#savePreset').addEventListener('click', function () {
  var nm = nextGraphName();
  presets.push({ name: nm, x1: bez.x1, y1: bez.y1, x2: bez.x2, y2: bez.y2 });
  if (presetSort !== 'manual') { presetSort = 'manual'; store.set('presetSort', presetSort); }   // новый пресет — всегда снизу, поэтому фиксируем ручной порядок
  saveLibs();
  renderPresets();
  var list = $('#presetList');
  if (list) list.scrollTop = list.scrollHeight;   // новый — снизу, прокручиваем к нему
  toast(t('t_saved', nm));
});

/* ---- выбор и управление библиотеками ---- */
var libDDBtn = $('#libDDBtn'), libDDMenu = $('#libDDMenu'), libDDLabel = $('#libDDLabel');
function renderLibSelect() {
  if (libDDLabel) libDDLabel.textContent = (libraries[curLib] && libraries[curLib].name) || '';
  if (!libDDMenu) return;
  libDDMenu.innerHTML = '';
  libraries.forEach(function (lib, i) {
    var row = document.createElement('div');
    row.className = 'lib-row' + (i === curLib ? ' cur' : '');
    var pick = document.createElement('button');
    pick.className = 'lib-pick';
    pick.textContent = lib.name;
    pick.addEventListener('click', function (e) {
      e.stopPropagation();
      libDDMenu.hidden = true;
      switchLib(i);
    });
    row.appendChild(pick);
    if (libraries.length > 1) {                    // крестик удаления — у каждой группы (кроме случая единственной)
      var x = document.createElement('button');
      x.className = 'lib-x';
      x.textContent = '✕';
      x.title = t('lib_del_hint');
      x.addEventListener('click', function (e) {
        e.stopPropagation();
        deleteLib(i);                              // renderLibSelect перестроит меню; оно остаётся открытым
        if (libDDMenu && !libDDMenu.hidden) positionLibDD();
      });
      row.appendChild(x);
    }
    libDDMenu.appendChild(row);
  });
  var nw = document.createElement('button');
  nw.className = 'lib-new';
  nw.textContent = t('lib_new');
  nw.addEventListener('click', function (e) {
    e.stopPropagation();
    libDDMenu.hidden = true;
    openLibName('new');
  });
  libDDMenu.appendChild(nw);
}
function switchLib(i) {
  if (i < 0 || i >= libraries.length) return;
  curLib = i;
  presets = libraries[curLib].curves;
  presetEditing = -1;
  saveLibs();
  renderLibSelect();
  renderPresets();
}
function positionLibDD() {
  if (!libDDBtn || !libDDMenu) return;
  var r = libDDBtn.getBoundingClientRect();
  libDDMenu.style.left = r.left + 'px';
  libDDMenu.style.width = r.width + 'px';
  libDDMenu.style.top = (r.bottom + 4) + 'px';
  var mh = libDDMenu.offsetHeight;
  if (r.bottom + 4 + mh > window.innerHeight - 6) libDDMenu.style.top = Math.max(6, r.top - mh - 4) + 'px';
}
if (libDDBtn) {
  libDDBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    libDDMenu.hidden = !libDDMenu.hidden;
    if (!libDDMenu.hidden) positionLibDD();
  });
  window.addEventListener('resize', function () { if (libDDMenu && !libDDMenu.hidden) positionLibDD(); });
  window.addEventListener('scroll', function () { if (libDDMenu && !libDDMenu.hidden) libDDMenu.hidden = true; }, true);
  document.addEventListener('click', function (e) {
    if (libDDMenu && !libDDMenu.hidden && !libDDMenu.contains(e.target) && e.target !== libDDBtn && !libDDBtn.contains(e.target)) libDDMenu.hidden = true;
  });
}

var libNameMode = 'new'; // 'new' | 'rename'
function openLibName(mode) {
  libNameMode = mode;
  var row = $('#libNameRow'), inp = $('#libNameInput');
  if (!row || !inp) return;
  var sr = $('#saveRow'); if (sr) sr.hidden = true;   // не показываем две строки разом
  row.hidden = false;
  inp.value = (mode === 'rename') ? libraries[curLib].name : '';
  inp.focus(); inp.select();
}
function commitLibName() {
  var inp = $('#libNameInput');
  if (!inp) return;
  var v = inp.value.trim();
  if (!v) { toast(t('t_need_name')); return; }
  if (libNameMode === 'new') {
    libraries.push({ name: v, curves: [] });
    curLib = libraries.length - 1;
    presets = libraries[curLib].curves;
    presetEditing = -1;
  } else {
    libraries[curLib].name = v;
  }
  saveLibs();
  $('#libNameRow').hidden = true;
  renderLibSelect();
  renderPresets();
}
var _libRename = $('#libRename');
if (_libRename) _libRename.addEventListener('click', function () { openLibName('rename'); });
var _libNameOk = $('#libNameOk');
if (_libNameOk) _libNameOk.addEventListener('click', commitLibName);
var _libNameInput = $('#libNameInput');
if (_libNameInput) _libNameInput.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') commitLibName();
  if (e.key === 'Escape') $('#libNameRow').hidden = true;
});
var _libNameCancel = $('#libNameCancel');
if (_libNameCancel) _libNameCancel.addEventListener('click', function () { $('#libNameRow').hidden = true; });

function deleteLib(i) {
  if (libraries.length <= 1) { toast(t('lib_keep_one')); return; }
  if (i < 0 || i >= libraries.length) return;
  var nm = libraries[i].name;
  libraries.splice(i, 1);
  if (curLib >= libraries.length) curLib = libraries.length - 1;
  else if (i < curLib) curLib--;                 // удалили группу выше текущей — сдвигаем индекс
  presets = libraries[curLib].curves;
  presetEditing = -1;
  saveLibs();
  renderLibSelect();
  renderPresets();
  toast(t('lib_deleted', nm));
}

renderLibSelect();
renderPresets();


/* ============================================================
   ТЕКСТ: Split / dropdown / Text → Shapes
============================================================ */
var splitMode = store.get('splitMode', 'chars');

function splitModeLabel() {
  return t({ words: 'dd_words', lines: 'dd_lines', chars: 'dd_chars' }[splitMode]);
}

$('#splitBtn').addEventListener('click', function () {
  cs.evalScript('MP_splitText("' + splitMode + '")', function (res) {
    if (res && res.indexOf('ok:') === 0) { toast(t('t_split', res.slice(3))); return; }
    handleHostResult(res, t('t_done'));
  });
});

$('#textToShapeBtn').addEventListener('click', function () {
  cs.evalScript('MP_textToShapes()', function (res) {
    handleHostResult(res, t('t_shapes'));
  });
});

var ddMenu = $('#splitDDMenu');
function positionDD() {
  var r = $('#splitDDBtn').getBoundingClientRect();
  ddMenu.style.left = r.left + 'px';
  ddMenu.style.width = r.width + 'px';
  ddMenu.style.top = (r.bottom + 4) + 'px';
  // если снизу не влезает — открываем вверх
  var mh = ddMenu.offsetHeight;
  if (r.bottom + 4 + mh > window.innerHeight - 6) {
    ddMenu.style.top = (r.top - mh - 4) + 'px';
  }
}
$('#splitDDBtn').addEventListener('click', function (e) {
  e.stopPropagation();
  ddMenu.hidden = !ddMenu.hidden;
  if (!ddMenu.hidden) { markDD(); positionDD(); }
});
window.addEventListener('resize', function () { if (!ddMenu.hidden) positionDD(); });
window.addEventListener('scroll', function () { if (!ddMenu.hidden) ddMenu.hidden = true; }, true);
document.addEventListener('click', function (e) {
  if (!ddMenu.hidden && !ddMenu.contains(e.target)) ddMenu.hidden = true;
});
function markDD() {
  $$('#splitDDMenu button').forEach(function (b) {
    b.classList.toggle('cur', b.dataset.mode === splitMode);
  });
}
ddMenu.addEventListener('click', function (e) {
  var b = e.target.closest('button');
  if (!b) return;
  splitMode = b.dataset.mode;
  store.set('splitMode', splitMode);
  $('#splitDDLabel').textContent = splitModeLabel();
  ddMenu.hidden = true;
});

/* ============================================================
   НАСТРОЙКИ: язык и цвета
============================================================ */
$('#langSeg').addEventListener('click', function (e) {
  var b = e.target.closest('button');
  if (!b) return;
  lang = b.dataset.lang;
  store.set('lang', lang);
  applyLang();
});

$$('.theme-row').forEach(function (row) {
  row.addEventListener('click', function () {
    settingsPop.hidden = true;
    var key = row.dataset.th;
    openColorPicker(theme[key].replace('#', ''), function (hex) {
      theme[key] = '#' + hex;
      store.set('theme', theme);
      applyTheme();
    });
  });
});

$('#themeReset').addEventListener('click', function () {
  theme = JSON.parse(JSON.stringify(THEME_DEF));
  store.set('theme', theme);
  applyTheme();
  toast(t('t_theme_reset'));
});

/* ---- размер интерфейса (верхняя панель): 3 пресета + ползунок тонкой настройки ---- */
var UI_PRESETS = { s: 0.7, m: 0.85, l: 1.0 };
var uiScale = store.get('uiScale', 1.0);
function syncUiSeg() {
  $$('#uiSeg button').forEach(function (b) { b.classList.toggle('on', Math.abs(UI_PRESETS[b.dataset.ui] - uiScale) < 0.005); });
}
function applyUiScale() {
  document.body.style.setProperty('--ui', uiScale);
  var sl = $('#uiSlider'); if (sl) sl.value = uiScale;
  syncUiSeg();
}
(function () {
  var seg = $('#uiSeg'), sl = $('#uiSlider');
  if (seg) seg.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    uiScale = UI_PRESETS[b.dataset.ui] || 1.0;
    store.set('uiScale', uiScale); applyUiScale();
  });
  if (sl) sl.addEventListener('input', function () {
    uiScale = parseFloat(sl.value) || 1.0;
    store.set('uiScale', uiScale);
    document.body.style.setProperty('--ui', uiScale); syncUiSeg();
  });
  applyUiScale();
})();

/* скругление интерфейса — ползунок «Скругление» (правит CSS-переменную --round на body) */
var uiRound = store.get('uiRound', 5);
function applyRound() {
  document.body.style.setProperty('--round', uiRound + 'px');
  var sl = $('#roundSlider'); if (sl) sl.value = uiRound;
}
(function () {
  var sl = $('#roundSlider');
  if (sl) sl.addEventListener('input', function () {
    uiRound = parseInt(sl.value, 10); if (isNaN(uiRound)) uiRound = 5;
    store.set('uiRound', uiRound);
    document.body.style.setProperty('--round', uiRound + 'px');
  });
  applyRound();
})();

/* ============================================================
   ПРИМЕНЕНИЕ ЯЗЫКА ко всем статичным элементам
============================================================ */
var TIP_MAP = [
  ['#layoutBtn', 'tip_layout'], ['#settingsBtn', 'tip_settings'],
  ['#dotsStrip', 'tip_dots'], ['#applyEase', 'tip_apply'], ['#savePreset', 'tip_savepreset'],
  ['#anchorGrid', 'tip_anchor'], ['#nullBtn', 'tip_null'], ['#unprecompBtn', 'tip_unprecomp'], ['#dupBtn', 'tip_dup'], ['#fitBtn', 'tip_fit'],
  ['#splitBtn', 'tip_split'], ['#splitDDBtn', 'tip_ddbtn'], ['#textToShapeBtn', 'tip_t2s'],
  ['#sortBtn', 'tip_sort'], ['#sizeSlider', 'tip_size']
];

/* ============================================================
   ТЕКСТ: пресеты текстовых анимаций (БАЗА) — слева список, справа редактор
   Каркас: данные-заглушки + рендер + кастомные ползунки. Логика применения к слоям — позже.
============================================================ */
var TFX_PRESETS = [
  { id: 'hero', name: 'Hero Reveal', desc: 'Scale + blur + opacity together. Lands soft.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.8, unit: 's' },
    { k: 'blur', label: 'Blur', min: 0, max: 50, step: 1, val: 12, unit: 'px' },
    { k: 'scale', label: 'Scale start', min: 0, max: 200, step: 1, val: 60, unit: '%' } ] },
  { id: 'slideup', name: 'Slide Up', desc: 'Position + opacity, per character.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.6, unit: 's' },
    { k: 'dist', label: 'Distance', min: 0, max: 300, step: 1, val: 60, unit: 'px' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.5, step: 0.01, val: 0.04, unit: 's' } ] },
  { id: 'wordstagger', name: 'Word Stagger', desc: 'Per-word slide + blur in.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.7, unit: 's' },
    { k: 'blur', label: 'Blur', min: 0, max: 50, step: 1, val: 8, unit: 'px' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.6, step: 0.01, val: 0.08, unit: 's' } ] },
  { id: 'letterstagger', name: 'Letter Stagger', desc: 'Per-letter slide + scale.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.6, unit: 's' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.3, step: 0.01, val: 0.03, unit: 's' },
    { k: 'scale', label: 'Scale start', min: 0, max: 200, step: 1, val: 80, unit: '%' } ] },
  { id: 'wordbounce', name: 'Word Bounce', desc: 'Per-word spring scale.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.9, unit: 's' },
    { k: 'amp', label: 'Bounce', min: 0, max: 100, step: 1, val: 40, unit: '%' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.6, step: 0.01, val: 0.07, unit: 's' } ] },
  { id: 'burst', name: 'Burst', desc: 'Smooth per-letter pop.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.5, unit: 's' },
    { k: 'scale', label: 'Scale start', min: 0, max: 300, step: 1, val: 140, unit: '%' } ] },
  { id: 'typewriter', name: 'Typewriter', desc: 'Letters appear one by one.', params: [
    { k: 'dur', label: 'Duration', min: 0.2, max: 5, step: 0.05, val: 1.2, unit: 's' } ] },
  { id: 'bounceup', name: 'Bounce Up', desc: 'Per-letter spring up.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.8, unit: 's' },
    { k: 'dist', label: 'Distance', min: 0, max: 300, step: 1, val: 80, unit: 'px' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.3, step: 0.01, val: 0.03, unit: 's' } ] },
  { id: 'bouncerotate', name: 'Bounce Rotate', desc: 'Per-letter spring rotate.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.8, unit: 's' },
    { k: 'rot', label: 'Rotation', min: -180, max: 180, step: 1, val: 25, unit: '\u00B0' },
    { k: 'stag', label: 'Stagger', min: 0, max: 0.3, step: 0.01, val: 0.03, unit: 's' } ] },
  { id: 'softbounce', name: 'Soft Bounce', desc: 'Whole text soft bounce.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 1.0, unit: 's' },
    { k: 'amp', label: 'Bounce', min: 0, max: 100, step: 1, val: 30, unit: '%' } ] },
  { id: 'iris', name: 'Iris', desc: 'Scale-down from large.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 3, step: 0.05, val: 0.7, unit: 's' },
    { k: 'scale', label: 'Scale start', min: 100, max: 400, step: 1, val: 200, unit: '%' } ] },
  { id: 'counter', name: 'Number Counter', desc: 'Eased value tick.', params: [
    { k: 'dur', label: 'Duration', min: 0.1, max: 5, step: 0.05, val: 1.2, unit: 's' },
    { k: 'from', label: 'From', min: 0, max: 1000, step: 1, val: 0, unit: '' },
    { k: 'to', label: 'To', min: 0, max: 10000, step: 1, val: 100, unit: '' } ] }
];
(function () {
  var listEl = $('#tfxList'), detailEl = $('#tfxDetail');
  if (!listEl || !detailEl) return;
  var sel = store.get('tfxSel', TFX_PRESETS[0].id);
  if (!TFX_PRESETS.some(function (p) { return p.id === sel; })) sel = TFX_PRESETS[0].id;
  var vals = store.get('tfxVals', {});
  var fav = store.get('tfxFav', []);
  function isFav(id) { return fav.indexOf(id) !== -1; }
  function toggleFav(id) { var i = fav.indexOf(id); if (i === -1) fav.push(id); else fav.splice(i, 1); store.set('tfxFav', fav); renderList(); }

  /* ---- захваченные с таймлайна пресеты (хранятся отдельно от встроенных) ---- */
  var captured = store.get('tfxCaptured', []);   // [{id,name,src,data}]
  function saveCaptured() { store.set('tfxCaptured', captured); }
  function capById(id) { for (var i = 0; i < captured.length; i++) if (captured[i].id === id) return captured[i]; return null; }
  function capWrap(c) {
    return {
      id: c.id, name: c.name, captured: true, src: c.src, data: c.data,
      desc: t('tfx_cap_from', c.src || '—'),
      params: [
        { k: 'speed', label: t('tfx_cap_speed'), min: 25, max: 300, step: 1, val: 100, unit: '%' },
        { k: 'delay', label: t('tfx_cap_delay'), min: 0, max: 2, step: 0.01, val: 0, unit: 's' }
      ]
    };
  }

  function curPreset() {
    var c = capById(sel); if (c) return capWrap(c);
    for (var i = 0; i < TFX_PRESETS.length; i++) if (TFX_PRESETS[i].id === sel) return TFX_PRESETS[i];
    return TFX_PRESETS[0];
  }
  function val(p, par) { return (vals[p.id] && vals[p.id][par.k] != null) ? vals[p.id][par.k] : par.val; }
  function setVal(pid, k, v) { if (!vals[pid]) vals[pid] = {}; vals[pid][k] = v; store.set('tfxVals', vals); }
  function fmt(v) { return (Math.round(v * 100) / 100).toString(); }
  function fmtNum(v) { v = Math.round(v); try { return v.toLocaleString(); } catch (e) { return '' + v; } }
  function valsOf(p) { var o = {}; p.params.forEach(function (par) { o[par.k] = val(p, par); }); return o; }
  function paintSlider(sl) {
    var mn = parseFloat(sl.min), mx = parseFloat(sl.max), v = parseFloat(sl.value);
    sl.style.setProperty('--fill', (mx > mn ? (v - mn) / (mx - mn) * 100 : 0) + '%');
  }

  var TFX_TEXT = 'MotionFX';
  /* конфиг анимации каждого пресета из текущих параметров: старт→финиш, тайминг, режим */
  function presetAnim(p, V) {
    var EZ = 'cubic-bezier(.2,.7,.2,1)', SP = 'cubic-bezier(.2,1.5,.3,1)';
    switch (p.id) {
      case 'hero': return { mode: 'whole', dur: V.dur, easing: EZ, from: { opacity: 0, transform: 'scale(' + (V.scale / 100) + ')', filter: 'blur(' + V.blur + 'px)' }, to: { opacity: 1, transform: 'scale(1)', filter: 'blur(0px)' } };
      case 'iris': return { mode: 'whole', dur: V.dur, easing: EZ, from: { opacity: 0, transform: 'scale(' + (V.scale / 100) + ')' }, to: { opacity: 1, transform: 'scale(1)' } };
      case 'softbounce': return { mode: 'whole', dur: V.dur, easing: SP, from: { opacity: 0, transform: 'scale(' + Math.max(0.1, 1 - V.amp / 100) + ')' }, to: { opacity: 1, transform: 'scale(1)' } };
      case 'slideup': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: EZ, from: { opacity: 0, transform: 'translateY(' + V.dist + 'px)' }, to: { opacity: 1, transform: 'translateY(0px)' } };
      case 'wordstagger': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: EZ, from: { opacity: 0, transform: 'translateX(16px)', filter: 'blur(' + V.blur + 'px)' }, to: { opacity: 1, transform: 'translateX(0px)', filter: 'blur(0px)' } };
      case 'letterstagger': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: EZ, from: { opacity: 0, transform: 'translateY(10px) scale(' + (V.scale / 100) + ')' }, to: { opacity: 1, transform: 'translateY(0px) scale(1)' } };
      case 'wordbounce': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: SP, from: { opacity: 0, transform: 'scale(' + Math.max(0, 1 - V.amp / 100) + ')' }, to: { opacity: 1, transform: 'scale(1)' } };
      case 'burst': return { mode: 'chars', dur: V.dur, stag: 0.02, easing: EZ, from: { opacity: 0, transform: 'scale(' + (V.scale / 100) + ')' }, to: { opacity: 1, transform: 'scale(1)' } };
      case 'bounceup': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: SP, from: { opacity: 0, transform: 'translateY(' + V.dist + 'px)' }, to: { opacity: 1, transform: 'translateY(0px)' } };
      case 'bouncerotate': return { mode: 'chars', dur: V.dur, stag: V.stag, easing: SP, from: { opacity: 0, transform: 'rotate(' + V.rot + 'deg)' }, to: { opacity: 1, transform: 'rotate(0deg)' } };
      case 'typewriter': return { mode: 'chars', dur: 0.04, stag: ((V.dur || 1) / Math.max(1, TFX_TEXT.length)), easing: 'steps(1,end)', from: { opacity: 0 }, to: { opacity: 1 }, novisualstatic: true };
      case 'counter': return { mode: 'number', dur: V.dur, from: V.from, to: V.to };
      default: return { mode: 'whole', dur: V.dur || 0.6, easing: EZ, from: { opacity: 0 }, to: { opacity: 1 } };
    }
  }
  function frame(o) { var f = {}; if (o.opacity != null) f.opacity = o.opacity; if (o.transform) f.transform = o.transform; if (o.filter) f.filter = o.filter; return f; }
  function applyFrame(el, o) { el.style.opacity = (o.opacity != null ? o.opacity : ''); el.style.transform = o.transform || ''; el.style.filter = o.filter || ''; }
  function splitChars(box) {
    box.textContent = ''; var spans = [];
    for (var i = 0; i < TFX_TEXT.length; i++) {
      var s = document.createElement('span'); s.textContent = TFX_TEXT.charAt(i);
      s.style.display = 'inline-block'; s.style.whiteSpace = 'pre';
      box.appendChild(s); spans.push(s);
    }
    return spans;
  }
  function stopPreview(box) {
    if (box._anims) { for (var i = 0; i < box._anims.length; i++) { try { box._anims[i].cancel(); } catch (e) { } } }
    box._anims = [];
    if (box._raf) { cancelAnimationFrame(box._raf); box._raf = null; }
  }
  function canAnim(el) { return typeof el.animate === 'function'; }
  function playPreview() {
    var box = $('#tfxPvText'); if (!box) return;
    var p = curPreset(), V = valsOf(p), cfg = presetAnim(p, V);
    stopPreview(box); box.style.opacity = ''; box.style.transform = ''; box.style.filter = '';
    if (cfg.mode === 'number') { playNumber(box, cfg); return; }
    var ms = Math.max(60, (cfg.dur || 0.6) * 1000);
    if (cfg.mode === 'whole') {
      box.textContent = TFX_TEXT;
      if (canAnim(box)) box._anims = [box.animate([frame(cfg.from), frame(cfg.to)], { duration: ms, easing: cfg.easing, fill: 'both' })];
      else applyFrame(box, cfg.to);
      return;
    }
    var spans = splitChars(box);
    if (!canAnim(box)) { spans.forEach(function (s) { applyFrame(s, cfg.to); }); return; }
    spans.forEach(function (s, i) {
      box._anims.push(s.animate([frame(cfg.from), frame(cfg.to)], { duration: ms, delay: i * (cfg.stag || 0) * 1000, easing: cfg.easing, fill: 'both' }));
    });
  }
  function playNumber(box, cfg) {
    box.textContent = fmtNum(cfg.from);
    var t0 = (window.performance && performance.now) ? performance.now() : Date.now(), dur = Math.max(60, (cfg.dur || 1) * 1000);
    function tick(now) {
      var k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      box.textContent = fmtNum(cfg.from + (cfg.to - cfg.from) * e);
      if (k < 1) box._raf = requestAnimationFrame(tick);
    }
    box._raf = requestAnimationFrame(tick);
  }
  /* статичный «старт» — живой отклик при перетаскивании ползунка (видно величину параметра) */
  function renderStatic() {
    var box = $('#tfxPvText'); if (!box) return;
    var p = curPreset(), V = valsOf(p), cfg = presetAnim(p, V);
    stopPreview(box);
    if (cfg.mode === 'number') { box.style.opacity = ''; box.style.transform = ''; box.style.filter = ''; box.textContent = fmtNum(cfg.from); return; }
    var st = cfg.novisualstatic ? cfg.to : { opacity: 0.9, transform: cfg.from.transform, filter: cfg.from.filter };
    if (cfg.mode === 'whole') { box.textContent = TFX_TEXT; applyFrame(box, st); return; }
    splitChars(box).forEach(function (s) { applyFrame(s, st); });
  }

  function renderList() {
    listEl.innerHTML = '';
    var head = document.createElement('div'); head.className = 'tfx-list-head';
    head.innerHTML = '<span>TEXT</span><span class="tfx-count">' + (TFX_PRESETS.length + captured.length) + '</span>';
    listEl.appendChild(head);
    var starSVG = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M12 3.6l2.6 5.27 5.82.85-4.21 4.1.99 5.79L12 17.9 6.79 19.61l.99-5.79-4.21-4.1 5.82-.85z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>';
    var trashSVG = '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M6.5 7l.8 12.5h9.4L17.5 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    // захваченные с таймлайна — наверху списка
    captured.forEach(function (c) {
      var p = capWrap(c);
      var it = document.createElement('button');
      it.className = 'tfx-item' + (p.id === sel ? ' on' : '');
      it.innerHTML = '<span class="tfx-dot cap"></span><span class="tfx-it-text"><span class="tfx-it-name"></span><span class="tfx-it-desc"></span></span><button class="tfx-trash" title="' + esc(t('tfx_cap_del')) + '">' + trashSVG + '</button>';
      it.querySelector('.tfx-it-name').textContent = p.name;
      it.querySelector('.tfx-it-desc').textContent = p.desc;
      it.addEventListener('click', function () { sel = p.id; store.set('tfxSel', sel); renderList(); renderDetail(); });
      it.querySelector('.tfx-trash').addEventListener('click', function (e) { e.stopPropagation(); deleteCaptured(c.id); });
      listEl.appendChild(it);
    });

    // встроенные пресеты
    var ordered = TFX_PRESETS.slice().sort(function (a, b) {
      var fa = isFav(a.id) ? 0 : 1, fb = isFav(b.id) ? 0 : 1;
      if (fa !== fb) return fa - fb;
      return TFX_PRESETS.indexOf(a) - TFX_PRESETS.indexOf(b);
    });
    ordered.forEach(function (p) {
      var it = document.createElement('button');
      it.className = 'tfx-item' + (p.id === sel ? ' on' : '');
      it.innerHTML = '<span class="tfx-dot"></span><span class="tfx-it-text"><span class="tfx-it-name"></span><span class="tfx-it-desc"></span></span><span class="tfx-star' + (isFav(p.id) ? ' on' : '') + '" title="Favorite">' + starSVG + '</span>';
      it.querySelector('.tfx-it-name').textContent = p.name;
      it.querySelector('.tfx-it-desc').textContent = p.desc;
      it.addEventListener('click', function () { sel = p.id; store.set('tfxSel', sel); renderList(); renderDetail(); });
      it.querySelector('.tfx-star').addEventListener('click', function (e) { e.stopPropagation(); toggleFav(p.id); });
      listEl.appendChild(it);
    });

    // захват анимации с таймлайна
    var add = document.createElement('button'); add.className = 'expr-add-btn'; add.textContent = t('tfx_cap_add');
    add.addEventListener('click', captureFromTimeline);
    listEl.appendChild(add);
  }

  function deleteCaptured(id) {
    var i = -1; for (var j = 0; j < captured.length; j++) if (captured[j].id === id) { i = j; break; }
    if (i === -1) return;
    captured.splice(i, 1); saveCaptured();
    if (sel === id) sel = TFX_PRESETS[0].id, store.set('tfxSel', sel);
    renderList(); renderDetail();
  }

  function renderDetail() {
    var p = curPreset();
    if (p && p.captured) { renderCapturedDetail(p); return; }
    detailEl.innerHTML = '';
    var scroll = document.createElement('div'); scroll.className = 'tfx-d-scroll';

    var top = document.createElement('div'); top.className = 'tfx-d-top';
    var ttl = document.createElement('div'); ttl.className = 'tfx-d-title'; ttl.textContent = p.name;
    var replay = document.createElement('button'); replay.className = 'tfx-replay'; replay.textContent = t('tfx_replay') + ' \u21BB';
    replay.addEventListener('click', playPreview);
    top.appendChild(ttl); top.appendChild(replay);
    scroll.appendChild(top);

    var desc = document.createElement('div'); desc.className = 'tfx-d-desc'; desc.textContent = p.desc;
    scroll.appendChild(desc);

    var pvLabel = document.createElement('div'); pvLabel.className = 'tfx-section-label'; pvLabel.textContent = t('tfx_preview');
    scroll.appendChild(pvLabel);
    var pv = document.createElement('div'); pv.className = 'tfx-preview';
    var pvt = document.createElement('span'); pvt.className = 'tfx-preview-text'; pvt.id = 'tfxPvText'; pvt.textContent = TFX_TEXT;
    pv.appendChild(pvt);
    scroll.appendChild(pv);

    var pLabel = document.createElement('div'); pLabel.className = 'tfx-section-label'; pLabel.textContent = t('tfx_params');
    scroll.appendChild(pLabel);
    var pbox = document.createElement('div'); pbox.className = 'tfx-params';
    p.params.forEach(function (par) {
      var row = document.createElement('div'); row.className = 'tfx-param';
      var lab = document.createElement('div'); lab.className = 'tfx-param-top';
      var nm = document.createElement('span'); nm.className = 'tfx-param-name'; nm.textContent = par.label;
      var vv = document.createElement('span'); vv.className = 'tfx-param-val';
      var cur = val(p, par);
      vv.textContent = fmt(cur) + (par.unit ? ' ' + par.unit : '');
      lab.appendChild(nm); lab.appendChild(vv);
      var sl = document.createElement('input'); sl.type = 'range'; sl.className = 'tfx-slider';
      sl.min = par.min; sl.max = par.max; sl.step = par.step; sl.value = cur;
      sl.title = t('tfx_resethint');
      sl.addEventListener('input', function () {
        var v = parseFloat(sl.value);
        vv.textContent = fmt(v) + (par.unit ? ' ' + par.unit : '');
        setVal(p.id, par.k, v); paintSlider(sl); renderStatic();        // живой отклик величины
      });
      sl.addEventListener('change', function () { playPreview(); });      // отпустил — проиграть
      sl.addEventListener('dblclick', function () {                       // двойной клик — сброс к базовому
        var v = par.val; sl.value = v;
        vv.textContent = fmt(v) + (par.unit ? ' ' + par.unit : '');
        setVal(p.id, par.k, v); paintSlider(sl); playPreview();
      });
      row.appendChild(lab); row.appendChild(sl);
      pbox.appendChild(row); paintSlider(sl);
    });
    scroll.appendChild(pbox);
    detailEl.appendChild(scroll);

    function applyMode(mode) {
      var P = valsOf(p), parts = [];
      for (var kk in P) parts.push(kk + ':' + P[kk]);
      cs.evalScript('MP_applyTextPreset("' + p.id + '","' + parts.join(',') + '","' + mode + '")', function (res) { handleHostResult(res, t('tfx_applied', p.name)); });
    }
    var foot = document.createElement('div'); foot.className = 'tfx-apply-row';
    var albl = document.createElement('span'); albl.className = 'tfx-animate-label'; albl.textContent = t('tfx_animate');
    var abtns = document.createElement('div'); abtns.className = 'tfx-anim-btns';
    [['in', t('tfx_in')], ['out', t('tfx_out')], ['both', t('tfx_both')]].forEach(function (pair) {
      var b = document.createElement('button'); b.className = 'tfx-anim-btn'; b.textContent = pair[1];
      b.addEventListener('click', (function (m) { return function () { applyMode(m); }; })(pair[0]));
      abtns.appendChild(b);
    });
    foot.appendChild(albl); foot.appendChild(abtns);
    detailEl.appendChild(foot);

    playPreview();
  }

  /* лёгкое обобщённое превью для захваченного пресета (точную AE-анимацию в CSS не воспроизводим) */
  function playCapturedPreview(box) {
    if (!box) return;
    stopPreview(box);
    box.style.opacity = ''; box.style.transform = ''; box.style.filter = '';
    if (!canAnim(box)) return;
    box._anims = [box.animate(
      [{ opacity: 0, transform: 'translateY(14px) scale(.96)' },
       { opacity: 1, transform: 'translateY(0px) scale(1)', offset: .55 },
       { opacity: 1, transform: 'translateY(0px) scale(1)' }],
      { duration: 1600, iterations: Infinity, easing: 'cubic-bezier(.2,.7,.2,1)' }
    )];
  }

  function renderCapturedDetail(p) {
    var c = capById(p.id);
    detailEl.innerHTML = '';
    var scroll = document.createElement('div'); scroll.className = 'tfx-d-scroll';

    var top = document.createElement('div'); top.className = 'tfx-d-top';
    var ttl = document.createElement('div'); ttl.className = 'tfx-d-title'; ttl.textContent = p.name; ttl.title = t('tfx_cap_rename_tip');
    ttl.addEventListener('dblclick', function () { ttl.contentEditable = 'true'; ttl.focus(); try { document.execCommand('selectAll', false, null); } catch (e) {} });
    ttl.addEventListener('blur', function () { ttl.contentEditable = 'false'; var v = (ttl.textContent || '').replace(/^\s+|\s+$/g, ''); if (v && c) c.name = v; ttl.textContent = c ? c.name : p.name; saveCaptured(); renderList(); });
    ttl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ttl.blur(); } if (e.key === 'Escape') { ttl.textContent = c ? c.name : p.name; ttl.blur(); } });
    var badge = document.createElement('span'); badge.className = 'tfx-cap-badge'; badge.textContent = 'TIMELINE';
    top.appendChild(ttl); top.appendChild(badge);
    scroll.appendChild(top);

    var desc = document.createElement('div'); desc.className = 'tfx-d-desc'; desc.textContent = p.desc;
    scroll.appendChild(desc);

    var pvLabel = document.createElement('div'); pvLabel.className = 'tfx-section-label'; pvLabel.textContent = t('tfx_preview');
    scroll.appendChild(pvLabel);
    var pv = document.createElement('div'); pv.className = 'tfx-preview';
    var pvt = document.createElement('span'); pvt.className = 'tfx-preview-text'; pvt.id = 'tfxPvText'; pvt.textContent = TFX_TEXT;
    pv.appendChild(pvt);
    scroll.appendChild(pv);

    var note = document.createElement('div'); note.className = 'tfx-cap-note'; note.textContent = t('tfx_cap_note');
    scroll.appendChild(note);

    var pLabel = document.createElement('div'); pLabel.className = 'tfx-section-label'; pLabel.textContent = t('tfx_params');
    scroll.appendChild(pLabel);
    var pbox = document.createElement('div'); pbox.className = 'tfx-params';
    p.params.forEach(function (par) {
      var row = document.createElement('div'); row.className = 'tfx-param';
      var lab = document.createElement('div'); lab.className = 'tfx-param-top';
      var nm = document.createElement('span'); nm.className = 'tfx-param-name'; nm.textContent = par.label;
      var vv = document.createElement('span'); vv.className = 'tfx-param-val';
      var cur = val(p, par);
      vv.textContent = fmt(cur) + (par.unit ? ' ' + par.unit : '');
      lab.appendChild(nm); lab.appendChild(vv);
      var sl = document.createElement('input'); sl.type = 'range'; sl.className = 'tfx-slider';
      sl.min = par.min; sl.max = par.max; sl.step = par.step; sl.value = cur;
      sl.title = t('tfx_resethint');
      sl.addEventListener('input', function () { var v = parseFloat(sl.value); vv.textContent = fmt(v) + (par.unit ? ' ' + par.unit : ''); setVal(p.id, par.k, v); paintSlider(sl); });
      sl.addEventListener('dblclick', function () { var v = par.val; sl.value = v; vv.textContent = fmt(v) + (par.unit ? ' ' + par.unit : ''); setVal(p.id, par.k, v); paintSlider(sl); });
      row.appendChild(lab); row.appendChild(sl);
      pbox.appendChild(row); paintSlider(sl);
    });
    scroll.appendChild(pbox);
    detailEl.appendChild(scroll);

    var foot = document.createElement('div'); foot.className = 'tfx-apply-row';
    var del = document.createElement('button'); del.className = 'expr-del-btn'; del.textContent = t('tfx_cap_del');
    del.addEventListener('click', function () { deleteCaptured(p.id); });
    var spacer = document.createElement('div'); spacer.style.flex = '1';
    var apply = document.createElement('button'); apply.className = 'tfx-anim-btn'; apply.textContent = t('tfx_apply');
    apply.addEventListener('click', function () { applyCaptured(p, 'in'); });
    foot.appendChild(del); foot.appendChild(spacer); foot.appendChild(apply);
    detailEl.appendChild(foot);

    playCapturedPreview(pvt);
  }

  function captureFromTimeline() {
    if (!cs.isCEP()) { toast(t('tfx_need_ae')); return; }
    cs.evalScript('MP_captureTextAnim()', function (res) {
      if (res === 'nosel') { toast(t('tfx_cap_nosel')); return; }
      if (res === 'noanim') { toast(t('tfx_cap_noanim')); return; }
      if (!res || res.indexOf('ok:') !== 0) { handleHostResult(res, ''); return; }
      var data = null; try { data = JSON.parse(res.slice(3)); } catch (e) { toast('parse error'); return; }
      if (!data) { toast('parse error'); return; }
      var id = 'c' + Date.now();
      var nm = (data.src && data.src.length) ? data.src : ('Capture ' + (captured.length + 1));
      captured.unshift({ id: id, name: nm, src: data.src || '', data: data });
      saveCaptured();
      sel = id; store.set('tfxSel', sel);
      renderList(); renderDetail();
      toast(t('tfx_cap_added'));
    });
  }

  function applyCaptured(p, mode) {
    if (!cs.isCEP()) { toast(t('tfx_need_ae')); return; }
    var V = valsOf(p);
    var spd = (V.speed != null ? V.speed : 100);
    var ts = 100 / Math.max(1, spd);     // Speed 200% => вдвое короче по времени
    var delay = (V.delay != null ? V.delay : 0);
    var payload = { cap: p.data, ts: ts, delay: delay, mode: mode };
    var arg = JSON.stringify(JSON.stringify(payload));
    cs.evalScript('MP_applyCapturedTextAnim(' + arg + ')', function (res) {
      if (res === 'nosel') { toast(t('tfx_cap_applynosel')); return; }
      handleHostResult(res, t('tfx_applied', p.name));
    });
  }

  window.renderTfx = function () { renderList(); renderDetail(); };   // на случай смены языка
  renderList();
  renderDetail();
})();

/* ============================================================
   ТЕКСТ — sub-tabs (Анимация / Шрифты)
============================================================ */
(function () {
  var subWrap = $('#tfxSub');
  if (!subWrap) return;
  var bodies = $$('.tfx-body');
  var curSub = store.get('tfxSubTab', 'anim');

  function showSub(name) {
    curSub = name; store.set('tfxSubTab', name);
    $$('#tfxSub .tfx-sub-btn').forEach(function (b) { b.classList.toggle('on', b.dataset.sub === name); });
    bodies.forEach(function (bd) { bd.hidden = (bd.getAttribute('data-sub') !== name); });
    if (name === 'fonts' && window.renderFonts) window.renderFonts();
  }
  $$('#tfxSub .tfx-sub-btn').forEach(function (b) {
    b.addEventListener('click', function () { showSub(b.dataset.sub); });
  });
  window.tfxShowSub = showSub;
  window.syncTfxSubLabels = function () {
    var a = $('#subAnimBtn'), f = $('#subFontsBtn');
    if (a) a.textContent = t('tfx_tab_anim');
    if (f) f.textContent = t('tfx_tab_fonts');
  };
  window.syncTfxSubLabels();
  showSub(curSub);
})();

/* ============================================================
   ШРИФТЫ: пресеты-комбинации + Live Preview + конструктор пар
============================================================ */
(function () {
  var listEl = $('#fontList'), detailEl = $('#fontDetail');
  if (!listEl || !detailEl) return;

  // курируемый фолбэк, если AE не отдаёт список (старые версии без app.fonts)
  var CURATED = ['Inter', 'Helvetica Neue', 'Arial', 'Roboto', 'Montserrat', 'Poppins', 'Open Sans', 'Lato',
    'Oswald', 'Raleway', 'Georgia', 'Times New Roman', 'Playfair Display', 'Merriweather', 'Lora', 'PT Serif',
    'Bebas Neue', 'Archivo', 'Manrope', 'Rubik', 'Nunito', 'Source Sans Pro', 'Work Sans', 'Futura', 'Gill Sans',
    'Courier New', 'Consolas', 'Cormorant Garamond', 'DM Sans', 'Space Grotesk'];

  var DEFAULTS = [
    { id: 'fp_def1', name: 'Montserrat · Georgia',   a: { family: 'Montserrat', ps: '' },       b: { family: 'Georgia', ps: 'Georgia' } },
    { id: 'fp_def2', name: 'Playfair · Source Sans', a: { family: 'Playfair Display', ps: '' },  b: { family: 'Source Sans Pro', ps: '' } },
    { id: 'fp_def3', name: 'Bebas Neue · Lora',      a: { family: 'Bebas Neue', ps: '' },        b: { family: 'Lora', ps: '' } },
    { id: 'fp_def4', name: 'Oswald · PT Serif',      a: { family: 'Oswald', ps: '' },            b: { family: 'PT Serif', ps: '' } }
  ];

  var presets = store.get('fontPresets', null);
  if (!presets) { presets = JSON.parse(JSON.stringify(DEFAULTS)); store.set('fontPresets', presets); }
  var sel = store.get('fontSel', presets[0] ? presets[0].id : '__new');
  var draft = null;   // черновик «новой комбинации»
  var fontsCache = null;

  function saveFonts() { store.set('fontPresets', presets); }
  function byId(id) { for (var i = 0; i < presets.length; i++) if (presets[i].id === id) return presets[i]; return null; }

  function loadFonts(cb) {
    if (fontsCache) { cb(fontsCache); return; }
    if (!cs.isCEP()) { fontsCache = CURATED.map(function (f) { return { family: f, ps: '' }; }); cb(fontsCache); return; }
    cs.evalScript('MP_listFonts()', function (res) {
      var arr = null;
      try { var o = JSON.parse(res); if (o && o.fonts && o.fonts.length) arr = o.fonts; } catch (e) {}
      if (!arr || !arr.length) arr = CURATED.map(function (f) { return { family: f, ps: '' }; });
      arr.sort(function (a, b) { var x = (a.family || '').toLowerCase(), y = (b.family || '').toLowerCase(); return x < y ? -1 : (x > y ? 1 : 0); });
      fontsCache = arr; cb(arr);
    });
  }

  /* плавающий выбор шрифта с поиском */
  var pickerEl = null;
  function closePicker() { if (pickerEl) { pickerEl.remove(); pickerEl = null; document.removeEventListener('mousedown', onDocDown, true); } }
  function onDocDown(e) { if (pickerEl && !pickerEl.contains(e.target)) closePicker(); }
  function openFontPicker(anchorEl, currentFamily, onPick) {
    closePicker();
    pickerEl = document.createElement('div'); pickerEl.className = 'font-picker';
    var sb = document.createElement('div'); sb.className = 'font-picker-search';
    var inp = document.createElement('input'); inp.type = 'text'; inp.placeholder = t('font_search_ph'); inp.spellcheck = false;
    sb.appendChild(inp); pickerEl.appendChild(sb);
    var lw = document.createElement('div'); lw.className = 'font-picker-list'; pickerEl.appendChild(lw);
    document.body.appendChild(pickerEl);

    var r = anchorEl.getBoundingClientRect();
    var pw = pickerEl.offsetWidth, ph = pickerEl.offsetHeight;
    var x = Math.min(r.left, window.innerWidth - pw - 8);
    var y = r.bottom + 4; if (y + ph > window.innerHeight - 8) y = Math.max(8, r.top - ph - 4);
    pickerEl.style.left = Math.max(8, x) + 'px'; pickerEl.style.top = y + 'px';

    function paint(filter) {
      lw.innerHTML = '';
      loadFonts(function (arr) {
        var f = (filter || '').toLowerCase(), shown = 0;
        arr.forEach(function (it) {
          if (f && (it.family || '').toLowerCase().indexOf(f) === -1) return;
          if (shown > 400) return;
          shown++;
          var b = document.createElement('button'); b.className = 'font-opt' + (it.family === currentFamily ? ' on' : '');
          b.textContent = it.family; b.style.fontFamily = "'" + it.family + "'";
          b.addEventListener('click', function () { onPick(it); closePicker(); });
          lw.appendChild(b);
        });
        if (!shown) { var e = document.createElement('div'); e.className = 'font-opt-empty'; e.textContent = '—'; lw.appendChild(e); }
      });
    }
    inp.addEventListener('input', function () { paint(inp.value); });
    paint('');
    setTimeout(function () { try { inp.focus(); } catch (e) {} document.addEventListener('mousedown', onDocDown, true); }, 0);
  }

  function activeObj() {
    if (sel === '__new') {
      if (!draft) draft = { id: '__new', name: t('font_new_name'), a: { family: (fontsCache && fontsCache[0] ? fontsCache[0].family : 'Inter'), ps: (fontsCache && fontsCache[0] ? fontsCache[0].ps : '') }, b: null };
      return draft;
    }
    return byId(sel) || draft || presets[0];
  }

  function renderList() {
    listEl.innerHTML = '';
    var head = document.createElement('div'); head.className = 'tfx-list-head';
    head.innerHTML = '<span>FONTS</span><span class="tfx-count">' + presets.length + '</span>';
    listEl.appendChild(head);
    var trashSVG = '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M6.5 7l.8 12.5h9.4L17.5 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    if (!presets.length) {
      var em = document.createElement('div'); em.className = 'expr-empty'; em.textContent = t('font_empty'); listEl.appendChild(em);
    }
    presets.forEach(function (p) {
      var it = document.createElement('button'); it.className = 'tfx-item' + (p.id === sel ? ' on' : '');
      var sw = '<span class="font-it-swatch"><i style="font-family:\'' + (p.a ? p.a.family : '') + '\'">A</i>' + (p.b ? '<i style="font-family:\'' + p.b.family + '\'">a</i>' : '') + '</span>';
      it.innerHTML = '<span class="tfx-dot"></span><span class="tfx-it-text"><span class="tfx-it-name"></span><span class="tfx-it-desc"></span></span>' + sw + '<button class="tfx-trash" title="' + esc(t('font_delete')) + '">' + trashSVG + '</button>';
      it.querySelector('.tfx-it-name').textContent = p.name;
      it.querySelector('.tfx-it-desc').textContent = (p.a ? p.a.family : '') + (p.b ? ' + ' + p.b.family : '');
      it.addEventListener('click', function () { sel = p.id; store.set('fontSel', sel); renderList(); renderDetail(); });
      it.querySelector('.tfx-trash').addEventListener('click', function (e) { e.stopPropagation(); deletePreset(p.id); });
      listEl.appendChild(it);
    });
    var add = document.createElement('button'); add.className = 'expr-add-btn'; add.textContent = t('font_new');
    add.addEventListener('click', function () { sel = '__new'; draft = null; store.set('fontSel', sel); renderList(); renderDetail(); });
    listEl.appendChild(add);
  }

  function deletePreset(id) {
    var i = -1; for (var j = 0; j < presets.length; j++) if (presets[j].id === id) { i = j; break; }
    if (i === -1) return;
    presets.splice(i, 1); saveFonts();
    if (sel === id) { sel = presets[0] ? presets[0].id : '__new'; store.set('fontSel', sel); }
    renderList(); renderDetail();
  }

  function caretSVG() { return '<svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>'; }

  function renderDetail() {
    var obj = activeObj();
    detailEl.innerHTML = '';
    var scroll = document.createElement('div'); scroll.className = 'tfx-d-scroll';

    var top = document.createElement('div'); top.className = 'tfx-d-top';
    var ttl = document.createElement('div'); ttl.className = 'tfx-d-title'; ttl.textContent = obj.name; ttl.title = t('font_rename_tip');
    ttl.addEventListener('dblclick', function () { ttl.contentEditable = 'true'; ttl.focus(); try { document.execCommand('selectAll', false, null); } catch (e) {} });
    ttl.addEventListener('blur', function () { ttl.contentEditable = 'false'; var v = (ttl.textContent || '').replace(/^\s+|\s+$/g, ''); if (v) obj.name = v; ttl.textContent = obj.name; if (sel !== '__new') saveFonts(); renderList(); });
    ttl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ttl.blur(); } if (e.key === 'Escape') { ttl.textContent = obj.name; ttl.blur(); } });
    top.appendChild(ttl);
    scroll.appendChild(top);

    var pvLabel = document.createElement('div'); pvLabel.className = 'tfx-section-label'; pvLabel.textContent = t('tfx_preview');
    scroll.appendChild(pvLabel);
    var pv = document.createElement('div'); pv.className = 'tfx-preview';
    var pvBox = document.createElement('div'); pvBox.className = 'font-pv';
    var a = document.createElement('div'); a.className = 'font-pv-a'; a.textContent = 'MotionFX'; a.style.fontFamily = "'" + (obj.a ? obj.a.family : '') + "'";
    pvBox.appendChild(a);
    if (obj.b) { var bEl = document.createElement('div'); bEl.className = 'font-pv-b'; bEl.textContent = t('font_sample_b'); bEl.style.fontFamily = "'" + obj.b.family + "'"; pvBox.appendChild(bEl); }
    pv.appendChild(pvBox);
    scroll.appendChild(pv);

    var fl = document.createElement('div'); fl.className = 'tfx-section-label'; fl.textContent = t('font_pick_label');
    scroll.appendChild(fl);
    var rows = document.createElement('div'); rows.className = 'font-rows';

    var rowA = document.createElement('div'); rowA.className = 'font-row';
    var roleA = document.createElement('span'); roleA.className = 'font-role'; roleA.textContent = obj.b ? t('font_role_a') : '';
    var pickA = document.createElement('button'); pickA.className = 'font-pick';
    pickA.innerHTML = '<span class="fp-name"></span>' + caretSVG();
    pickA.querySelector('.fp-name').textContent = obj.a ? obj.a.family : '—';
    pickA.querySelector('.fp-name').style.fontFamily = "'" + (obj.a ? obj.a.family : '') + "'";
    pickA.addEventListener('click', function () { openFontPicker(pickA, obj.a ? obj.a.family : '', function (it) { obj.a = { family: it.family, ps: it.ps || '' }; if (sel !== '__new') saveFonts(); renderDetail(); }); });
    rowA.appendChild(roleA); rowA.appendChild(pickA);
    rows.appendChild(rowA);

    if (obj.b) {
      var rowB = document.createElement('div'); rowB.className = 'font-row';
      var roleB = document.createElement('span'); roleB.className = 'font-role'; roleB.textContent = t('font_role_b');
      var pickB = document.createElement('button'); pickB.className = 'font-pick';
      pickB.innerHTML = '<span class="fp-name"></span>' + caretSVG();
      pickB.querySelector('.fp-name').textContent = obj.b.family;
      pickB.querySelector('.fp-name').style.fontFamily = "'" + obj.b.family + "'";
      pickB.addEventListener('click', function () { openFontPicker(pickB, obj.b.family, function (it) { obj.b = { family: it.family, ps: it.ps || '' }; if (sel !== '__new') saveFonts(); renderDetail(); }); });
      var xB = document.createElement('button'); xB.className = 'font-x'; xB.textContent = '✕';
      xB.addEventListener('click', function () { obj.b = null; if (sel !== '__new') saveFonts(); renderDetail(); });
      rowB.appendChild(roleB); rowB.appendChild(pickB); rowB.appendChild(xB);
      rows.appendChild(rowB);
    } else {
      var addB = document.createElement('button'); addB.className = 'font-add'; addB.textContent = t('font_add2');
      addB.addEventListener('click', function () { openFontPicker(addB, '', function (it) { obj.b = { family: it.family, ps: it.ps || '' }; if (sel !== '__new') saveFonts(); renderDetail(); }); });
      rows.appendChild(addB);
    }
    scroll.appendChild(rows);
    detailEl.appendChild(scroll);

    var foot = document.createElement('div'); foot.className = 'font-apply-row';
    if (sel !== '__new') {
      var del = document.createElement('button'); del.className = 'font-del-btn'; del.textContent = t('font_delete');
      del.addEventListener('click', function () { deletePreset(obj.id); });
      foot.appendChild(del);
    }
    if (obj.b) {
      var applyA = document.createElement('button'); applyA.className = 'font-apply'; applyA.textContent = t('font_apply') + ': ' + (obj.a ? obj.a.family : '');
      applyA.addEventListener('click', function () { applyFont(obj.a); });
      var applyB = document.createElement('button'); applyB.className = 'font-apply alt'; applyB.textContent = t('font_apply') + ': ' + obj.b.family;
      applyB.addEventListener('click', function () { applyFont(obj.b); });
      foot.appendChild(applyA); foot.appendChild(applyB);
    } else {
      var applyOne = document.createElement('button'); applyOne.className = 'font-apply'; applyOne.textContent = t('font_apply');
      applyOne.addEventListener('click', function () { applyFont(obj.a); });
      foot.appendChild(applyOne);
    }
    var save = document.createElement('button'); save.className = 'font-save'; save.textContent = t('font_save');
    save.addEventListener('click', function () { savePreset(obj); });
    foot.appendChild(save);
    detailEl.appendChild(foot);
  }

  function savePreset(obj) {
    if (sel === '__new') {
      var id = 'fp' + Date.now();
      var nm = (obj.name && obj.name !== t('font_new_name')) ? obj.name : ((obj.a ? obj.a.family : 'Font') + (obj.b ? ' · ' + obj.b.family : ''));
      presets.unshift({ id: id, name: nm, a: obj.a, b: obj.b });
      draft = null; sel = id; store.set('fontSel', sel);
    }
    saveFonts(); renderList(); renderDetail();
    toast(t('font_saved'));
  }

  function applyFont(f) {
    if (!f) return;
    if (!cs.isCEP()) { toast(t('font_need_ae')); return; }
    cs.evalScript('MP_applyFont(' + jsxStr(f.ps || '') + ',' + jsxStr(f.family || '') + ')', function (res) {
      if (res === 'nosel') { toast(t('font_nosel')); return; }
      if (res === 'notext') { toast(t('font_notext')); return; }
      handleHostResult(res, t('font_applied', f.family));
    });
  }

  window.renderFonts = function () { renderList(); renderDetail(); };
  renderList();
  renderDetail();
  if (cs.isCEP()) loadFonts(function () {});
})();


function applyLang() {
  // подсветка выбранного языка
  $$('#langSeg button').forEach(function (b) { b.classList.toggle('on', b.dataset.lang === lang); });
  // статичные подписи
  $('.widget[data-widget="palettes"] .widget-title').textContent = t('palettes_title');
  var libT = $('.lib-title'); if (libT) libT.textContent = t('library_title');
  if (typeof renderLibSelect === 'function') renderLibSelect();
  $('#applyEase').textContent = t('apply_keys');
  $('#addPalette').textContent = t('new_palette');
  if (window.renderTfx) window.renderTfx();
  if (window.syncTfxSubLabels) window.syncTfxSubLabels();
  if (window.renderFonts) window.renderFonts();
  var _pexT = $('#pexTitle'); if (_pexT) _pexT.textContent = t('w_palextract');
  var _pexDL = $('#pexDropLabel'); if (_pexDL) _pexDL.textContent = t('pex_uploadlabel');
  var _pexU = $('#pexUpload'); if (_pexU) _pexU.textContent = t('pex_upload');
  var _pexR = $('#pexReupload'); if (_pexR) _pexR.textContent = t('pex_reupload');
  var _pexS = $('#pexSave'); if (_pexS) _pexS.textContent = t('pex_save');
  var _eT = $('.widget[data-widget="exprtools"] .widget-title'); if (_eT) _eT.textContent = t('expr_title');
  var _eAdd = $('#addExpr'); if (_eAdd) _eAdd.textContent = t('expr_add');
  var _eName = $('#exprNameInput'); if (_eName) _eName.placeholder = t('expr_name_ph');
  var _eCode = $('#exprCode'); if (_eCode) _eCode.placeholder = t('expr_code_ph');
  var _eSave = $('#exprSave'); if (_eSave) _eSave.textContent = t('expr_save');
  var _eApply = $('#exprApply'); if (_eApply) _eApply.textContent = t('expr_apply_btn');
  var _eTab = $('.tab[data-tab="expr"]'); if (_eTab) _eTab.title = t('expr_title');
  var _sml = $('#setModulesLabel'); if (_sml) _sml.textContent = t('set_modules');
  var _smt = $('#setTitle'); if (_smt) _smt.textContent = t('set_title');
  var _smh = $('#setModulesHint'); if (_smh) _smh.textContent = t('set_modules_hint');
  var _aal = $('#autoApplyLabel'); if (_aal) _aal.textContent = t('autoapply_label');
  var _stl = $('#setTilesLabel'); if (_stl) _stl.textContent = t('set_tiles');
  var _hll = $('#hideLabelsLabel'); if (_hll) _hll.textContent = t('hidelabels_label');
  $('#addSearch').placeholder = t('add_search');
  $('.add-hint').textContent = t('add_hint');
  $('.add-title').childNodes[0].textContent = t('add_layout') + ' ';
  $('#setLangLabel').textContent = t('set_lang');
  var _sui = $('#setUiLabel'); if (_sui) _sui.textContent = t('set_ui');
  $('#setThemeLabel').textContent = t('set_theme');
  $('#thAccent').textContent = t('th_accent');
  $('#thBg').textContent = t('th_bg');
  $('#thCard').textContent = t('th_card');
  var _thT = $('#thTxt'); if (_thT) _thT.textContent = t('th_txt');
  $('#themeReset').textContent = t('th_reset');
  $('#splitDDLabel').textContent = splitModeLabel();
  $$('#splitDDMenu button').forEach(function (b) {
    b.textContent = t('dd_' + b.dataset.mode);
  });
  // тултипы
  TIP_MAP.forEach(function (pair) {
    var el = $(pair[0]);
    if (el) el.setAttribute('data-tip', t(pair[1]));
  });
  $$('.add-tile').forEach(function (tl) { tl.setAttribute('data-tip', t('tip_addtile')); });
  // перерисовать динамику
  renderPalettes();
  renderPresets();
  renderExpressions();
  renderModuleList();
  if (typeof renderWsSwitcher === 'function') renderWsSwitcher();
}



/* ============================================================
   КВАДРАТНЫЕ СЕТКИ: держим квадрат по меньшей стороне (надёжно для любого CEP)
============================================================ */
function fitSquares() {
  $$('.square-fit').forEach(function (box) {
    var grid = box.firstElementChild;
    if (!grid) return;
    var w = box.clientWidth, h = box.clientHeight;
    if (!w || !h) return;
    var side = Math.min(w, h, 230);
    grid.style.width = side + 'px';
    grid.style.height = side + 'px';
  });
}
if (window.ResizeObserver) {
  var sqObs = new ResizeObserver(function () { fitSquares(); });
  $$('.square-fit').forEach(function (b) { sqObs.observe(b); });
}
window.addEventListener('resize', fitSquares);

/* ============================================================
   СТАРТ
============================================================ */
applyTheme();
renderBoards();
fitSquares();
renderPalettes();
resizeGraph();
renderGraph();
renderPresets();
applyLang();
markDD();
renderWsSwitcher();        // переключатель воркспейсов
applyModuleVisibility();   // спрятать вкладки без включённых модулей (и переключиться, если активная скрыта)
// CEP иногда отдаёт размер панели не сразу — как только доска получит ширину, перерисуем (позиции уже целы благодаря защите выше)
function _settleLayout() {
  var ab = $('.page.active') ? $('.page.active').querySelector('.board') : null;
  if (ab && (ab.clientWidth || 0) > 40) { renderBoards(); fitSquares(); return true; }
  return false;
}
if (window.requestAnimationFrame) requestAnimationFrame(function () { _settleLayout(); });
setTimeout(_settleLayout, 120);
setTimeout(_settleLayout, 400);

/* ============================================================
   ЖЁЛТЫЕ ТУЛТИПЫ-ОПИСАНИЯ ([data-tip="Заголовок|Текст"])
============================================================ */
(function () {
  var tip = document.createElement('div');
  tip.className = 'tipbox';
  document.body.appendChild(tip);
  var tm = null, cur = null;

  function hide() {
    clearTimeout(tm);
    tip.classList.remove('show');
    cur = null;
  }

  document.addEventListener('mouseover', function (e) {
    var el = e.target.closest('[data-tip]');
    if (!el || el === cur) return;
    cur = el;
    clearTimeout(tm);
    tm = setTimeout(function () {
      var parts = (el.getAttribute('data-tip') || '').split('|');
      tip.innerHTML = '<b>' + esc(parts[0]) + '</b>' + esc(parts[1] || '');
      tip.style.left = '0px'; tip.style.top = '0px';
      tip.classList.add('show');
      var r = el.getBoundingClientRect();
      var tw = tip.offsetWidth, th = tip.offsetHeight;
      var x = Math.min(Math.max(6, r.left), window.innerWidth - tw - 6);
      var y = r.bottom + 8;
      if (y + th > window.innerHeight - 6) y = r.top - th - 8;
      tip.style.left = x + 'px';
      tip.style.top = Math.max(6, y) + 'px';
    }, 450);
  });

  document.addEventListener('mouseout', function (e) {
    var el = e.target.closest('[data-tip]');
    if (!el || el !== cur) return;
    if (e.relatedTarget && el.contains(e.relatedTarget)) return; // ещё внутри
    hide();
  });

  document.addEventListener('mousedown', hide);
  window.addEventListener('blur', hide);
})();
